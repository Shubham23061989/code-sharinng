import { useState } from "react";
import ScoreSwatch, { band } from "./ScoreSwatch.jsx";
import Sparkline from "./Sparkline.jsx";
import MetricsRow from "./MetricsRow.jsx";
import { mockFetch } from "../lib/mockData.js";
import { livePsiFetch } from "../lib/psiApi.js";

const CATS = [
  ["performance", "Perf"],
  ["accessibility", "A11y"],
  ["best_practices", "Best Pr."],
  ["seo", "SEO"],
];
const MAX_HISTORY = 20;

function computeBreaches(row, thresholds) {
  return Object.keys(thresholds).filter((k) => {
    const s = row.scores[k];
    return s !== null && s !== undefined && s < thresholds[k];
  });
}

function meanScore(scores) {
  const vals = Object.values(scores).filter((v) => v !== null && v !== undefined);
  return vals.length ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length) : null;
}

export default function Dashboard({ state, history, setHistory, results, setResults }) {
  const [liveMode, setLiveMode] = useState(false);
  const [running, setRunning] = useState(false);
  const [statusText, setStatusText] = useState("No checks run yet.");

  function pushHistory(row, nextHistory) {
    const key = `${row.label}|${row.strategy}`;
    const list = nextHistory[key] ? [...nextHistory[key]] : [];
    list.push({ ts: new Date().toISOString(), scores: row.scores });
    nextHistory[key] = list.length > MAX_HISTORY ? list.slice(-MAX_HISTORY) : list;
  }

  async function runCheck() {
    if (!state.urls.length) {
      setStatusText("Add at least one URL in Config first.");
      return;
    }
    setRunning(true);
    setStatusText(liveMode ? "Calling PageSpeed Insights API…" : "Generating mock data…");

    const strategies = ["mobile", "desktop"];
    const tasks = [];
    state.urls.forEach((entry) => {
      strategies.forEach((strategy) => {
        if (liveMode) {
          tasks.push(
            livePsiFetch(entry, strategy, state.apiKey)
              .then((row) => ({ ok: true, row }))
              .catch((err) => ({
                ok: false,
                err: { label: entry.label, url: entry.url, strategy, error: err.message || String(err) },
              }))
          );
        } else {
          tasks.push(Promise.resolve({ ok: true, row: mockFetch(entry, strategy) }));
        }
      });
    });

    const outcomes = await Promise.all(tasks);
    const rows = [], errors = [];
    const nextHistory = { ...history };
    outcomes.forEach((o) => {
      if (o.ok) {
        rows.push(o.row);
        pushHistory(o.row, nextHistory);
      } else {
        errors.push(o.err);
      }
    });

    setResults({ rows, errors });
    setHistory(nextHistory);

    const now = new Date().toLocaleString();
    if (liveMode && errors.length && rows.length === 0) {
      setStatusText(
        "Live calls failed for all URLs (likely blocked by this sandbox's network policy, or a missing/invalid API key). Try mock mode, or run this project locally."
      );
    } else {
      setStatusText(`Last run: ${now} · ${liveMode ? "live" : "mock"}`);
    }
    setRunning(false);
  }

  const breachCount = results.rows.filter((r) => computeBreaches(r, state.thresholds).length).length;

  return (
    <section className="panel active">
      <div className="toolbar">
        <button className="primary" onClick={runCheck} disabled={running}>
          Run check now
        </button>
        <div className="mode-toggle">
          <span style={{ opacity: liveMode ? 0.55 : 1 }}>Mock data</span>
          <button
            className={`switch ${liveMode ? "on" : ""}`}
            role="switch"
            aria-checked={liveMode}
            onClick={() => setLiveMode((v) => !v)}
          />
          <span>Live API</span>
        </div>
        <span className="status">{statusText}</span>
      </div>

      <div className="stat-ribbon">
        <div className="stat-item accent">
          <div className="n">{results.rows.length || "—"}</div>
          <div className="l">URLs checked</div>
        </div>
        <div className={`stat-item ${breachCount > 0 ? "warn" : results.rows.length ? "ok" : ""}`}>
          <div className="n">{results.rows.length ? breachCount : "—"}</div>
          <div className="l">Threshold breaches</div>
        </div>
        <div className={`stat-item ${results.errors.length > 0 ? "warn" : ""}`}>
          <div className="n">{results.rows.length || results.errors.length ? results.errors.length : "—"}</div>
          <div className="l">Fetch errors</div>
        </div>
      </div>

      {!results.rows.length && !results.errors.length ? (
        <div className="empty">No results yet. Add a URL in Config, then press "Run check now".</div>
      ) : (
        <div className="grid">
          {results.rows.map((row) => {
            const breaches = computeBreaches(row, state.thresholds);
            const key = `${row.label}|${row.strategy}`;
            const histRecords = history[key] || [];
            const histMeans = histRecords.map((r) => meanScore(r.scores));
            let worstBand = "fresh";
            Object.values(row.scores).forEach((s) => {
              const b = band(s);
              if (b === "terracotta") worstBand = "terracotta";
              else if (b === "honey" && worstBand !== "terracotta") worstBand = "honey";
            });
            return (
              <div className={`card status-${worstBand}`} key={key}>
                <div className="head">
                  <div>
                    <div className="label">{row.label}</div>
                    <div className="url">{row.url}</div>
                  </div>
                  <span className="strategy-tag">{row.strategy}</span>
                </div>
                <div className="swatches">
                  {CATS.map(([k, lbl]) => (
                    <ScoreSwatch key={k} label={lbl} score={row.scores[k]} />
                  ))}
                </div>
                <MetricsRow metrics={row.metrics} />
                {breaches.length > 0 && (
                  <div className="breach-note">Below threshold: {breaches.join(", ")}</div>
                )}
                {histMeans.length >= 2 && (
                  <div className="sparkline">
                    <Sparkline points={histMeans} />
                    <span>last {histMeans.length} runs</span>
                  </div>
                )}
              </div>
            );
          })}

          {results.errors.map((err, i) => (
            <div className="card" key={`err-${i}`}>
              <div className="head">
                <div>
                  <div className="label">{err.label}</div>
                  <div className="url">{err.url}</div>
                </div>
              </div>
              <div className="breach-note">
                Fetch error ({err.strategy}): {err.error}
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
