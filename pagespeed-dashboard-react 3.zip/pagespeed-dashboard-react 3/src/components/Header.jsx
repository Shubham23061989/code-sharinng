export default function Header({ tab, setTab }) {
  return (
    <header className="hero">
      <div className="hero-top">
        <div className="brand">
          <span className="drop-icon" aria-hidden="true">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
              <path
                d="M12 2C12 2 5 11.2 5 15.7C5 19.4 8.13 22.4 12 22.4C15.87 22.4 19 19.4 19 15.7C19 11.2 12 2 12 2Z"
                fill="white"
                fillOpacity="0.95"
              />
            </svg>
          </span>
          <div>
            <h1>Site Speed Deck</h1>
            <div className="subtitle">PageSpeed monitoring, dashboard and config</div>
          </div>
        </div>
      </div>
      <nav className="tabs">
        <button className={tab === "dashboard" ? "active" : ""} onClick={() => setTab("dashboard")}>
          Dashboard
        </button>
        <button className={tab === "history" ? "active" : ""} onClick={() => setTab("history")}>
          History
        </button>
        <button className={tab === "email" ? "active" : ""} onClick={() => setTab("email")}>
          Email Preview
        </button>
        <button className={tab === "config" ? "active" : ""} onClick={() => setTab("config")}>
          Config
        </button>
      </nav>
    </header>
  );
}
