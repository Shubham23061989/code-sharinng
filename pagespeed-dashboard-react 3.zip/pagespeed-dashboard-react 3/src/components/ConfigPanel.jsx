import { useState, useMemo } from "react";
import { buildYaml } from "../lib/yamlExport.js";

const THRESHOLD_FIELDS = [
  ["performance", "Performance"],
  ["accessibility", "Accessibility"],
  ["best_practices", "Best Practices"],
  ["seo", "SEO"],
];

function RowList({ items, onRemove, renderLabel, renderSub }) {
  if (!items.length) return <div className="note">None added yet.</div>;
  return (
    <div className="row-list">
      {items.map((item, i) => (
        <div className="row-item" key={i}>
          <div className="main">
            <strong>{renderLabel(item)}</strong>
            {renderSub && <span>{renderSub(item)}</span>}
          </div>
          <button className="del" title="Remove" onClick={() => onRemove(i)}>
            ✕
          </button>
        </div>
      ))}
    </div>
  );
}

export default function ConfigPanel({ state, setState }) {
  const [newLabel, setNewLabel] = useState("");
  const [newUrl, setNewUrl] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [newWa, setNewWa] = useState("");
  const [copied, setCopied] = useState(false);

  const yaml = useMemo(() => buildYaml(state), [state]);

  function update(patch) {
    setState((s) => ({ ...s, ...patch }));
  }

  function addUrl() {
    if (!newUrl.trim()) return;
    update({ urls: [...state.urls, { label: newLabel.trim() || newUrl.trim(), url: newUrl.trim() }] });
    setNewLabel("");
    setNewUrl("");
  }
  function removeUrl(i) {
    update({ urls: state.urls.filter((_, idx) => idx !== i) });
  }

  function addEmail() {
    if (!newEmail.trim()) return;
    update({ emails: [...state.emails, newEmail.trim()] });
    setNewEmail("");
  }
  function removeEmail(i) {
    update({ emails: state.emails.filter((_, idx) => idx !== i) });
  }

  function addWa() {
    if (!newWa.trim()) return;
    update({ whatsapp: [...state.whatsapp, newWa.trim()] });
    setNewWa("");
  }
  function removeWa(i) {
    update({ whatsapp: state.whatsapp.filter((_, idx) => idx !== i) });
  }

  function setThreshold(key, val) {
    update({ thresholds: { ...state.thresholds, [key]: Number(val) } });
  }

  async function copyYaml() {
    try {
      await navigator.clipboard.writeText(yaml);
    } catch {
      /* clipboard API unavailable - user can still select & copy manually from the textarea */
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1200);
  }

  return (
    <section className="panel active">
      <div className="config-grid">
        <div>
          <div className="field-group">
            <h3>Monitored URLs</h3>
            <p className="hint">
              These feed both the dashboard and the exported config below. Matches the{" "}
              <span className="mono">urls.xlsx</span> the backend script reads.
            </p>
            <RowList
              items={state.urls}
              onRemove={removeUrl}
              renderLabel={(u) => u.label}
              renderSub={(u) => u.url}
            />
            <div className="add-row">
              <input
                type="text"
                placeholder="Label (e.g. Waterproofing Solutions)"
                value={newLabel}
                onChange={(e) => setNewLabel(e.target.value)}
              />
              <input
                type="url"
                placeholder="https://…"
                value={newUrl}
                onChange={(e) => setNewUrl(e.target.value)}
              />
              <button className="ghost" onClick={addUrl}>
                Add URL
              </button>
            </div>
          </div>

          <div className="field-group">
            <h3>Alert thresholds</h3>
            <p className="hint">
              A score below its threshold is flagged as a breach on the dashboard and in the exported config.
            </p>
            {THRESHOLD_FIELDS.map(([key, label]) => (
              <label className="threshold" key={key}>
                <div className="top">
                  <span>{label}</span>
                  <span className="val">{state.thresholds[key]}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={state.thresholds[key]}
                  onChange={(e) => setThreshold(key, e.target.value)}
                />
              </label>
            ))}
          </div>

          <div className="field-group">
            <h3>PageSpeed Insights API key</h3>
            <p className="hint">
              Only used for "Live API" mode, stored in this browser only. Needed to call the Google API
              directly from here.
            </p>
            <input
              type="password"
              placeholder="AIza…"
              style={{ width: "100%" }}
              value={state.apiKey}
              onChange={(e) => update({ apiKey: e.target.value })}
            />
          </div>
        </div>

        <div>
          <div className="field-group">
            <h3>Email recipients</h3>
            <p className="hint">Reference list only — the backend script is what actually sends mail.</p>
            <RowList items={state.emails} onRemove={removeEmail} renderLabel={(e) => e} />
            <div className="add-row">
              <input
                type="email"
                placeholder="name@company.com"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
              />
              <button className="ghost" onClick={addEmail}>
                Add
              </button>
            </div>
          </div>

          <div className="field-group">
            <h3>WhatsApp numbers</h3>
            <p className="hint">
              Reference list only — synced into the exported config for whoever wires up the sender.
            </p>
            <RowList items={state.whatsapp} onRemove={removeWa} renderLabel={(w) => w} />
            <div className="add-row">
              <input
                type="text"
                placeholder="+91XXXXXXXXXX"
                value={newWa}
                onChange={(e) => setNewWa(e.target.value)}
              />
              <button className="ghost" onClick={addWa}>
                Add
              </button>
            </div>
          </div>

          <div className="field-group">
            <h3>Export as config.yaml</h3>
            <p className="hint">
              Copy this into the backend project's <span className="mono">config/config.yaml</span> so both
              sides stay in sync.
            </p>
            <textarea className="yaml" readOnly value={yaml} />
            <div className="copy-row">
              <button className="ghost" onClick={copyYaml}>
                {copied ? "Copied" : "Copy to clipboard"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
