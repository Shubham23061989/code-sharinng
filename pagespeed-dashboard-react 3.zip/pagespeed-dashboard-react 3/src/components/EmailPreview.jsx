import { useMemo } from "react";
import { band } from "./ScoreSwatch.jsx";
import { buildEmailReport, buildEmailHtml } from "../lib/emailTemplate.js";

export default function EmailPreview({ results, thresholds }) {
  const hasData = results.rows.length > 0 || results.errors.length > 0;

  const html = useMemo(() => {
    if (!hasData) return "";
    const report = buildEmailReport(results, thresholds, band);
    return buildEmailHtml(report, band);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [results, thresholds]);

  return (
    <section className="panel active">
      <div className="field-group" style={{ marginBottom: 18 }}>
        <h3>Email report preview</h3>
        <p className="hint">
          This is what the recipients in Config → Email recipients will actually receive from the backend
          script, built from the last run's data.
        </p>
      </div>

      {!hasData ? (
        <div className="empty">No run yet. Go to Dashboard and press "Run check now" to generate a preview.</div>
      ) : (
        <iframe
          title="Email preview"
          srcDoc={html}
          style={{
            display: "block",
            width: "100%",
            height: 900,
            border: "1px solid var(--line)",
            borderRadius: "var(--radius)",
            background: "#fff",
          }}
        />
      )}
    </section>
  );
}
