import { band } from "./ScoreSwatch.jsx";

const CATS = [
  ["performance", "Perf"],
  ["accessibility", "A11y"],
  ["best_practices", "Best Pr."],
  ["seo", "SEO"],
];

export default function History({ state, history }) {
  const keys = Object.keys(history)
    .filter((k) => history[k] && history[k].length)
    .sort();

  return (
    <section className="panel active">
      <div className="field-group" style={{ marginBottom: 18 }}>
        <h3>Past runs, per configured URL</h3>
        <p className="hint">
          Stored in this browser (last 20 runs per URL + strategy). Run checks from the Dashboard tab to
          build history over time.
        </p>
      </div>

      {!keys.length ? (
        <div className="empty">No history yet. Go to Dashboard and press "Run check now" a few times.</div>
      ) : (
        keys.map((key) => {
          const [label, strategy] = key.split("|");
          const records = [...history[key]].reverse();
          const urlEntry = state.urls.find((u) => u.label === label);

          return (
            <div className="field-group history-card" key={key}>
              <div className="history-card-title">
                <div>
                  <div className="label">{label}</div>
                  <div className="url">{urlEntry ? urlEntry.url : ""}</div>
                </div>
                <span className="strategy-tag">{strategy}</span>
              </div>
              <table className="history-table">
                <thead>
                  <tr>
                    <th>When</th>
                    {CATS.map(([k, l]) => (
                      <th key={k}>{l}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {records.map((r, i) => (
                    <tr key={i}>
                      <td className="when">{new Date(r.ts).toLocaleString()}</td>
                      {CATS.map(([k]) => {
                        const s = r.scores[k];
                        return (
                          <td key={k} className={`score-${band(s)}`}>
                            {s === null || s === undefined ? "—" : s}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          );
        })
      )}
    </section>
  );
}
