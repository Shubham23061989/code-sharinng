import { useState } from "react";
import Header from "./components/Header.jsx";
import Dashboard from "./components/Dashboard.jsx";
import ConfigPanel from "./components/ConfigPanel.jsx";
import History from "./components/History.jsx";
import EmailPreview from "./components/EmailPreview.jsx";
import { useLocalStorage } from "./hooks/useLocalStorage.js";

const DEFAULT_STATE = {
  urls: [
    { label: "Waterproofing Solutions", url: "https://beta.asianpaints.com/services/waterproofing-solutions.html" },
    { label: "Home Page", url: "https://www.asianpaints.com/" },
  ],
  thresholds: { performance: 70, accessibility: 80, best_practices: 80, seo: 80 },
  emails: ["shubham.example@company.com"],
  whatsapp: ["+91XXXXXXXXXX"],
  apiKey: "",
};

export default function App() {
  const [tab, setTab] = useState("dashboard");
  const [state, setState] = useLocalStorage("speedDeckState.v1", DEFAULT_STATE);
  const [history, setHistory] = useLocalStorage("speedDeckHistory.v1", {});
  const [results, setResults] = useState({ rows: [], errors: [] });

  return (
    <div className="shell">
      <Header tab={tab} setTab={setTab} />
      {tab === "dashboard" && (
        <Dashboard state={state} history={history} setHistory={setHistory} results={results} setResults={setResults} />
      )}
      {tab === "history" && <History state={state} history={history} />}
      {tab === "email" && <EmailPreview results={results} thresholds={state.thresholds} />}
      {tab === "config" && <ConfigPanel state={state} setState={setState} />}
    </div>
  );
}
