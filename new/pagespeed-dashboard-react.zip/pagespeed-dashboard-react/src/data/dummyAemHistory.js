// // export const DUMMY_AEM_HISTORY = [
// //   {
// //     "runId": "run-1",
// //     "startedAt": "2026-09-15T09:00:00",
// //     "completedAt": "2026-09-15T09:02:00",
// //     "results": [
// //       { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "DESKTOP", "performanceScore": 67.2, "accessibilityScore": 86.6, "bestPracticesScore": 89.2, "seoScore": 91.4, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "MOBILE", "performanceScore": 64.4, "accessibilityScore": 85.2, "bestPracticesScore": 88.3, "seoScore": 90.9, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "DESKTOP", "performanceScore": 72.4, "accessibilityScore": 89.2, "bestPracticesScore": 90.7, "seoScore": 92.5, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "MOBILE", "performanceScore": 63.2, "accessibilityScore": 84.6, "bestPracticesScore": 87.9, "seoScore": 90.6, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "DESKTOP", "performanceScore": 70.6, "accessibilityScore": 88.3, "bestPracticesScore": 90.2, "seoScore": 92.1, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "MOBILE", "performanceScore": 67.9, "accessibilityScore": 86.9, "bestPracticesScore": 89.4, "seoScore": 91.6, "status": "SUCCESS", "errorMessage": "" }
// //     ]
// //   },
// //   {
// //     "runId": "run-2",
// //     "startedAt": "2026-09-15T18:00:00",
// //     "completedAt": "2026-09-15T18:02:00",
// //     "results": [
// //       { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "DESKTOP", "performanceScore": 62.9, "accessibilityScore": 84.5, "bestPracticesScore": 87.9, "seoScore": 90.6, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "MOBILE", "performanceScore": 70.1, "accessibilityScore": 88.1, "bestPracticesScore": 90.0, "seoScore": 92.0, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "DESKTOP", "performanceScore": 62.6, "accessibilityScore": 84.3, "bestPracticesScore": 87.8, "seoScore": 90.5, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "MOBILE", "performanceScore": 68.9, "accessibilityScore": 87.5, "bestPracticesScore": 89.7, "seoScore": 91.8, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "DESKTOP", "performanceScore": 63.1, "accessibilityScore": 84.6, "bestPracticesScore": 87.9, "seoScore": 90.6, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "MOBILE", "performanceScore": 63.5, "accessibilityScore": 84.7, "bestPracticesScore": 88.0, "seoScore": 90.7, "status": "SUCCESS", "errorMessage": "" }
// //     ]
// //   },
// //   {
// //     "runId": "run-3",
// //     "startedAt": "2026-09-16T03:00:00",
// //     "completedAt": "2026-09-16T03:02:00",
// //     "results": [
// //       { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "DESKTOP", "performanceScore": 68.8, "accessibilityScore": 87.4, "bestPracticesScore": 89.6, "seoScore": 91.8, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "MOBILE", "performanceScore": 75.2, "accessibilityScore": 90.6, "bestPracticesScore": 91.6, "seoScore": 93.0, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "DESKTOP", "performanceScore": 64.0, "accessibilityScore": 85.0, "bestPracticesScore": 88.2, "seoScore": 90.8, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "MOBILE", "performanceScore": 65.6, "accessibilityScore": 85.8, "bestPracticesScore": 88.7, "seoScore": 91.1, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "DESKTOP", "performanceScore": 72.0, "accessibilityScore": 89.0, "bestPracticesScore": 90.6, "seoScore": 92.4, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "MOBILE", "performanceScore": 77.2, "accessibilityScore": 91.6, "bestPracticesScore": 92.1, "seoScore": 93.4, "status": "SUCCESS", "errorMessage": "" }
// //     ]
// //   },
// //   {
// //     "runId": "run-4",
// //     "startedAt": "2026-09-16T12:00:00",
// //     "completedAt": "2026-09-16T12:02:00",
// //     "results": [
// //       { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "DESKTOP", "performanceScore": 71.2, "accessibilityScore": 88.6, "bestPracticesScore": 90.4, "seoScore": 92.2, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "MOBILE", "performanceScore": 68.3, "accessibilityScore": 87.2, "bestPracticesScore": 89.5, "seoScore": 91.7, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "DESKTOP", "performanceScore": 77.6, "accessibilityScore": 91.8, "bestPracticesScore": 92.3, "seoScore": 93.5, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "MOBILE", "performanceScore": 62.7, "accessibilityScore": 84.4, "bestPracticesScore": 87.8, "seoScore": 90.5, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "DESKTOP", "performanceScore": 75.7, "accessibilityScore": 90.9, "bestPracticesScore": 91.7, "seoScore": 93.1, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "MOBILE", "performanceScore": 66.6, "accessibilityScore": 86.3, "bestPracticesScore": 89.0, "seoScore": 91.3, "status": "SUCCESS", "errorMessage": "" }
// //     ]
// //   },
// //   {
// //     "runId": "run-5",
// //     "startedAt": "2026-09-16T21:00:00",
// //     "completedAt": "2026-09-16T21:02:00",
// //     "results": [
// //       { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "DESKTOP", "performanceScore": 64.3, "accessibilityScore": 85.2, "bestPracticesScore": 88.3, "seoScore": 90.9, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "MOBILE", "performanceScore": 63.9, "accessibilityScore": 84.9, "bestPracticesScore": 88.2, "seoScore": 90.8, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "DESKTOP", "performanceScore": 66.9, "accessibilityScore": 86.5, "bestPracticesScore": 89.1, "seoScore": 91.4, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "MOBILE", "performanceScore": 75.1, "accessibilityScore": 90.5, "bestPracticesScore": 91.5, "seoScore": 93.0, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "DESKTOP", "performanceScore": 64.9, "accessibilityScore": 85.4, "bestPracticesScore": 88.5, "seoScore": 91.0, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "MOBILE", "performanceScore": 71.3, "accessibilityScore": 88.7, "bestPracticesScore": 90.4, "seoScore": 92.3, "status": "SUCCESS", "errorMessage": "" }
// //     ]
// //   },
// //   {
// //     "runId": "run-6",
// //     "startedAt": "2026-09-17T06:00:00",
// //     "completedAt": "2026-09-17T06:02:00",
// //     "results": [
// //       { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "DESKTOP", "performanceScore": 72.2, "accessibilityScore": 89.1, "bestPracticesScore": 90.7, "seoScore": 92.4, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "MOBILE", "performanceScore": 68.0, "accessibilityScore": 87.0, "bestPracticesScore": 89.4, "seoScore": 91.6, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "DESKTOP", "performanceScore": 70.8, "accessibilityScore": 88.4, "bestPracticesScore": 90.2, "seoScore": 92.2, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "MOBILE", "performanceScore": 63.0, "accessibilityScore": 84.5, "bestPracticesScore": 87.9, "seoScore": 90.6, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "DESKTOP", "performanceScore": 63.0, "accessibilityScore": 84.5, "bestPracticesScore": 87.9, "seoScore": 90.6, "status": "SUCCESS", "errorMessage": "" },
// //       { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "MOBILE", "performanceScore": 65.3, "accessibilityScore": 85.6, "bestPracticesScore": 88.6, "seoScore": 91.1, "status": "SUCCESS", "errorMessage": "" }
// //     ]
// //   }
// // ];

// // dummyAemHistory.js
// //
// // Sample shared by the AEM dev (2026-09-18) - this IS the confirmed
// // real response shape. The live endpoint will return data in this
// // exact format ("runs" wrapper, generatedAt, strategyMode, etc.),
// // so keeping this dummy data in the same shape means today's
// // USE_DUMMY_DATA=true testing behaves the same as tomorrow's live run.

// export const DUMMY_AEM_HISTORY = {
//   runs: [
//     {
//       reportId: "desktop-pagespeed-report-20260918-195110-389",
//       runId: "abb67e16-171c-45f2-83a3-950d03428e8c",
//       strategyMode: "BOTH",
//       generatedAt: "2026-09-18T14:21:10.389Z",
//       summary: { totalUrls: 1, totalResults: 2, successfulResults: 2, failedResults: 0, status: "SUCCESS" },
//       results: [
//         { url: "https://www.asianpaints.com/", strategy: "DESKTOP", performanceScore: 89.0, accessibilityScore: 100.0, bestPracticesScore: 100.0, seoScore: 91.0, largestContentfulPaintMs: 1421.1716767800162, cumulativeLayoutShift: 0.057471152037420536, status: "SUCCESS", errorMessage: "" },
//         { url: "https://www.asianpaints.com/", strategy: "MOBILE", performanceScore: 64.0, accessibilityScore: 93.0, bestPracticesScore: 96.0, seoScore: 92.0, largestContentfulPaintMs: 9237.652420587929, cumulativeLayoutShift: 0.0, status: "SUCCESS", errorMessage: "" },
//       ],
//     },
//     {
//       reportId: "desktop-pagespeed-report-20260918-173656-919",
//       runId: "7ce33053-af3b-44fb-96d4-55e7e3d199fd",
//       strategy: "DESKTOP",
//       generatedAt: "2026-09-18T12:06:56.919Z",
//       summary: { totalUrls: 3, successfulUrls: 3, failedUrls: 0, status: "SUCCESS" },
//       results: [
//         { url: "https://www.asianpaints.com/", strategy: "DESKTOP", performanceScore: 92.0, accessibilityScore: 100.0, bestPracticesScore: 100.0, seoScore: 91.0, largestContentfulPaintMs: 517.0550028178163, cumulativeLayoutShift: 0.056915746693544184, status: "SUCCESS", errorMessage: "" },
//         { url: "https://www.asianpaints.com/colour-catalogue.html", strategy: "DESKTOP", performanceScore: 27.0, accessibilityScore: 87.0, bestPracticesScore: 46.0, seoScore: 77.0, largestContentfulPaintMs: 2621.054144690537, cumulativeLayoutShift: 1.6319826511223785, status: "SUCCESS", errorMessage: "" },
//         { url: "https://www.asianpaints.com/products/paints-and-textures.html", strategy: "DESKTOP", performanceScore: 28.999999999999996, accessibilityScore: 94.0, bestPracticesScore: 50.0, seoScore: 77.0, largestContentfulPaintMs: 2711.4752021336717, cumulativeLayoutShift: 1.4432067583177461, status: "SUCCESS", errorMessage: "" },
//       ],
//     },
//     {
//       reportId: "desktop-pagespeed-report-20260918-173229-861",
//       runId: "ca43b8d4-74f4-404e-985b-a398a3ed1860",
//       strategy: "DESKTOP",
//       generatedAt: "2026-09-18T12:02:29.861Z",
//       summary: { totalUrls: 3, successfulUrls: 3, failedUrls: 0, status: "SUCCESS" },
//       results: [
//         { url: "https://www.asianpaints.com/", strategy: "DESKTOP", performanceScore: 99.0, accessibilityScore: 93.0, bestPracticesScore: 100.0, seoScore: 92.0, largestContentfulPaintMs: 841.1025104479904, cumulativeLayoutShift: 0.057260320961655904, status: "SUCCESS", errorMessage: "" },
//         { url: "https://www.asianpaints.com/colour-catalogue.html", strategy: "DESKTOP", performanceScore: 26.0, accessibilityScore: 87.0, bestPracticesScore: 46.0, seoScore: 77.0, largestContentfulPaintMs: 2117.359062673051, cumulativeLayoutShift: 0.8445547195073103, status: "SUCCESS", errorMessage: "" },
//         { url: "https://www.asianpaints.com/products/paints-and-textures.html", strategy: "DESKTOP", performanceScore: 24.0, accessibilityScore: 94.0, bestPracticesScore: 50.0, seoScore: 77.0, largestContentfulPaintMs: 2683.4634105032155, cumulativeLayoutShift: 1.263555565624426, status: "SUCCESS", errorMessage: "" },
//       ],
//     },
//     {
//       reportId: "desktop-pagespeed-report-20260918-172704-875",
//       runId: "cf2f81f4-5ae4-4be0-877f-388949c2b0eb",
//       strategy: "DESKTOP",
//       generatedAt: "2026-09-18T11:57:04.875Z",
//       summary: { totalUrls: 3, successfulUrls: 3, failedUrls: 0, status: "SUCCESS" },
//       results: [
//         { url: "https://www.asianpaints.com/", strategy: "DESKTOP", performanceScore: 97.0, accessibilityScore: 93.0, bestPracticesScore: 100.0, seoScore: 92.0, largestContentfulPaintMs: 477.04776399789625, cumulativeLayoutShift: 0.057471152037420536, status: "SUCCESS", errorMessage: "" },
//         { url: "https://www.asianpaints.com/colour-catalogue.html", strategy: "DESKTOP", performanceScore: 24.0, accessibilityScore: 87.0, bestPracticesScore: 46.0, seoScore: 77.0, largestContentfulPaintMs: 2657.6782832185904, cumulativeLayoutShift: 2.1977753261788315, status: "SUCCESS", errorMessage: "" },
//         { url: "https://www.asianpaints.com/products/paints-and-textures.html", strategy: "DESKTOP", performanceScore: 24.0, accessibilityScore: 94.0, bestPracticesScore: 50.0, seoScore: 77.0, largestContentfulPaintMs: 3876.943023024847, cumulativeLayoutShift: 1.2623228226462968, status: "SUCCESS", errorMessage: "" },
//       ],
//     },
//   ],
//   count: 4,
//   limit: 10,
//   availableRuns: 4,
//   skippedRuns: 0,
// };

// dummyAemHistory.datetest.js
// TEST DATA ONLY - 4 URLs, EVERY one has both DESKTOP and MOBILE
// (so side-by-side layout shows on every card), across 6 runs on
// 5 DIFFERENT CALENDAR DATES (16th has two runs, same day, to confirm
// both still show when that date is picked in the date filter):
//   2026-09-15, 2026-09-16 (x2), 2026-09-17, 2026-09-19, 2026-09-21
// Temporarily use this in place of dummyAemHistory.js to test.
// export const DUMMY_AEM_HISTORY = {
//   "runs": [
//     {
//       "reportId": "desktop-pagespeed-report-20260915-093000-470",
//       "runId": "run-1-5911",
//       "strategyMode": "BOTH",
//       "generatedAt": "2026-09-15T09:30:00.254Z",
//       "summary": {
//         "totalUrls": 4,
//         "totalResults": 8,
//         "successfulResults": 8,
//         "failedResults": 0,
//         "status": "SUCCESS"
//       },
//       "results": [
//         {
//           "url": "https://www.asianpaints.com/",
//           "strategy": "DESKTOP",
//           "performanceScore": 59.0,
//           "accessibilityScore": 90.0,
//           "bestPracticesScore": 91.0,
//           "seoScore": 76.0,
//           "largestContentfulPaintMs": 1083.817508,
//           "cumulativeLayoutShift": 1.071764,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/",
//           "strategy": "MOBILE",
//           "performanceScore": 66.0,
//           "accessibilityScore": 79.0,
//           "bestPracticesScore": 82.0,
//           "seoScore": 81.0,
//           "largestContentfulPaintMs": 778.087011,
//           "cumulativeLayoutShift": 0.867291,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/colour-catalogue.html",
//           "strategy": "DESKTOP",
//           "performanceScore": 46.0,
//           "accessibilityScore": 80.0,
//           "bestPracticesScore": 85.0,
//           "seoScore": 88.0,
//           "largestContentfulPaintMs": 967.216928,
//           "cumulativeLayoutShift": 1.130907,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/colour-catalogue.html",
//           "strategy": "MOBILE",
//           "performanceScore": 59.0,
//           "accessibilityScore": 98.0,
//           "bestPracticesScore": 87.0,
//           "seoScore": 76.0,
//           "largestContentfulPaintMs": 5499.6508,
//           "cumulativeLayoutShift": 0.793361,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/products/paints-and-textures.html",
//           "strategy": "DESKTOP",
//           "performanceScore": 50.0,
//           "accessibilityScore": 95.0,
//           "bestPracticesScore": 58.0,
//           "seoScore": 84.0,
//           "largestContentfulPaintMs": 4117.466631,
//           "cumulativeLayoutShift": 1.081372,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/products/paints-and-textures.html",
//           "strategy": "MOBILE",
//           "performanceScore": 70.0,
//           "accessibilityScore": 95.0,
//           "bestPracticesScore": 93.0,
//           "seoScore": 80.0,
//           "largestContentfulPaintMs": 1351.737484,
//           "cumulativeLayoutShift": 1.142409,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html",
//           "strategy": "DESKTOP",
//           "performanceScore": 58.0,
//           "accessibilityScore": 81.0,
//           "bestPracticesScore": 85.0,
//           "seoScore": 77.0,
//           "largestContentfulPaintMs": 5388.222565,
//           "cumulativeLayoutShift": 1.238019,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html",
//           "strategy": "MOBILE",
//           "performanceScore": 73.0,
//           "accessibilityScore": 91.0,
//           "bestPracticesScore": 99.0,
//           "seoScore": 85.0,
//           "largestContentfulPaintMs": 4524.016326,
//           "cumulativeLayoutShift": 1.846883,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         }
//       ]
//     },
//     {
//       "reportId": "desktop-pagespeed-report-20260916-080000-394",
//       "runId": "run-2-3119",
//       "strategyMode": "BOTH",
//       "generatedAt": "2026-09-16T08:00:00.756Z",
//       "summary": {
//         "totalUrls": 4,
//         "totalResults": 8,
//         "successfulResults": 8,
//         "failedResults": 0,
//         "status": "SUCCESS"
//       },
//       "results": [
//         {
//           "url": "https://www.asianpaints.com/",
//           "strategy": "DESKTOP",
//           "performanceScore": 90.0,
//           "accessibilityScore": 100.0,
//           "bestPracticesScore": 99.0,
//           "seoScore": 82.0,
//           "largestContentfulPaintMs": 1166.231344,
//           "cumulativeLayoutShift": 0.600498,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/",
//           "strategy": "MOBILE",
//           "performanceScore": 66.0,
//           "accessibilityScore": 92.0,
//           "bestPracticesScore": 68.0,
//           "seoScore": 94.0,
//           "largestContentfulPaintMs": 9026.529916,
//           "cumulativeLayoutShift": 0.236132,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/colour-catalogue.html",
//           "strategy": "DESKTOP",
//           "performanceScore": 66.0,
//           "accessibilityScore": 88.0,
//           "bestPracticesScore": 59.0,
//           "seoScore": 90.0,
//           "largestContentfulPaintMs": 4139.860602,
//           "cumulativeLayoutShift": 1.924038,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/colour-catalogue.html",
//           "strategy": "MOBILE",
//           "performanceScore": 46.0,
//           "accessibilityScore": 96.0,
//           "bestPracticesScore": 100.0,
//           "seoScore": 85.0,
//           "largestContentfulPaintMs": 3426.070669,
//           "cumulativeLayoutShift": 0.700357,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/products/paints-and-textures.html",
//           "strategy": "DESKTOP",
//           "performanceScore": 84.0,
//           "accessibilityScore": 92.0,
//           "bestPracticesScore": 54.0,
//           "seoScore": 77.0,
//           "largestContentfulPaintMs": 8715.959582,
//           "cumulativeLayoutShift": 0.948197,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/products/paints-and-textures.html",
//           "strategy": "MOBILE",
//           "performanceScore": 69.0,
//           "accessibilityScore": 79.0,
//           "bestPracticesScore": 96.0,
//           "seoScore": 84.0,
//           "largestContentfulPaintMs": 6112.377477,
//           "cumulativeLayoutShift": 1.986192,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html",
//           "strategy": "DESKTOP",
//           "performanceScore": 100.0,
//           "accessibilityScore": 87.0,
//           "bestPracticesScore": 95.0,
//           "seoScore": 87.0,
//           "largestContentfulPaintMs": 8211.602557,
//           "cumulativeLayoutShift": 0.694011,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html",
//           "strategy": "MOBILE",
//           "performanceScore": 65.0,
//           "accessibilityScore": 83.0,
//           "bestPracticesScore": 89.0,
//           "seoScore": 78.0,
//           "largestContentfulPaintMs": 4769.813702,
//           "cumulativeLayoutShift": 0.436416,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         }
//       ]
//     },
//     {
//       "reportId": "desktop-pagespeed-report-20260916-200000-715",
//       "runId": "run-3-1861",
//       "strategyMode": "BOTH",
//       "generatedAt": "2026-09-16T20:00:00.104Z",
//       "summary": {
//         "totalUrls": 4,
//         "totalResults": 8,
//         "successfulResults": 8,
//         "failedResults": 0,
//         "status": "SUCCESS"
//       },
//       "results": [
//         {
//           "url": "https://www.asianpaints.com/",
//           "strategy": "DESKTOP",
//           "performanceScore": 62.0,
//           "accessibilityScore": 90.0,
//           "bestPracticesScore": 81.0,
//           "seoScore": 77.0,
//           "largestContentfulPaintMs": 1905.704972,
//           "cumulativeLayoutShift": 0.803289,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/",
//           "strategy": "MOBILE",
//           "performanceScore": 46.0,
//           "accessibilityScore": 91.0,
//           "bestPracticesScore": 85.0,
//           "seoScore": 83.0,
//           "largestContentfulPaintMs": 6630.971208,
//           "cumulativeLayoutShift": 1.972934,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/colour-catalogue.html",
//           "strategy": "DESKTOP",
//           "performanceScore": 90.0,
//           "accessibilityScore": 85.0,
//           "bestPracticesScore": 59.0,
//           "seoScore": 77.0,
//           "largestContentfulPaintMs": 1991.905124,
//           "cumulativeLayoutShift": 0.463914,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/colour-catalogue.html",
//           "strategy": "MOBILE",
//           "performanceScore": 39.0,
//           "accessibilityScore": 93.0,
//           "bestPracticesScore": 87.0,
//           "seoScore": 80.0,
//           "largestContentfulPaintMs": 2749.032919,
//           "cumulativeLayoutShift": 0.008187,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/products/paints-and-textures.html",
//           "strategy": "DESKTOP",
//           "performanceScore": 78.0,
//           "accessibilityScore": 89.0,
//           "bestPracticesScore": 89.0,
//           "seoScore": 93.0,
//           "largestContentfulPaintMs": 3237.85221,
//           "cumulativeLayoutShift": 0.250983,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/products/paints-and-textures.html",
//           "strategy": "MOBILE",
//           "performanceScore": 76.0,
//           "accessibilityScore": 98.0,
//           "bestPracticesScore": 93.0,
//           "seoScore": 76.0,
//           "largestContentfulPaintMs": 4445.632569,
//           "cumulativeLayoutShift": 1.741959,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html",
//           "strategy": "DESKTOP",
//           "performanceScore": 95.0,
//           "accessibilityScore": 90.0,
//           "bestPracticesScore": 75.0,
//           "seoScore": 87.0,
//           "largestContentfulPaintMs": 3898.55014,
//           "cumulativeLayoutShift": 0.963046,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html",
//           "strategy": "MOBILE",
//           "performanceScore": 51.0,
//           "accessibilityScore": 84.0,
//           "bestPracticesScore": 54.0,
//           "seoScore": 81.0,
//           "largestContentfulPaintMs": 4305.485098,
//           "cumulativeLayoutShift": 0.219857,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         }
//       ]
//     },
//     {
//       "reportId": "desktop-pagespeed-report-20260917-111500-930",
//       "runId": "run-4-4197",
//       "strategyMode": "BOTH",
//       "generatedAt": "2026-09-17T11:15:00.825Z",
//       "summary": {
//         "totalUrls": 4,
//         "totalResults": 8,
//         "successfulResults": 8,
//         "failedResults": 0,
//         "status": "SUCCESS"
//       },
//       "results": [
//         {
//           "url": "https://www.asianpaints.com/",
//           "strategy": "DESKTOP",
//           "performanceScore": 53.0,
//           "accessibilityScore": 82.0,
//           "bestPracticesScore": 84.0,
//           "seoScore": 78.0,
//           "largestContentfulPaintMs": 8753.301637,
//           "cumulativeLayoutShift": 1.227475,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/",
//           "strategy": "MOBILE",
//           "performanceScore": 35.0,
//           "accessibilityScore": 97.0,
//           "bestPracticesScore": 74.0,
//           "seoScore": 79.0,
//           "largestContentfulPaintMs": 6001.083812,
//           "cumulativeLayoutShift": 1.910936,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/colour-catalogue.html",
//           "strategy": "DESKTOP",
//           "performanceScore": 84.0,
//           "accessibilityScore": 93.0,
//           "bestPracticesScore": 57.0,
//           "seoScore": 78.0,
//           "largestContentfulPaintMs": 7878.198107,
//           "cumulativeLayoutShift": 1.986205,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/colour-catalogue.html",
//           "strategy": "MOBILE",
//           "performanceScore": 69.0,
//           "accessibilityScore": 93.0,
//           "bestPracticesScore": 69.0,
//           "seoScore": 77.0,
//           "largestContentfulPaintMs": 1711.028039,
//           "cumulativeLayoutShift": 1.499348,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/products/paints-and-textures.html",
//           "strategy": "DESKTOP",
//           "performanceScore": 90.0,
//           "accessibilityScore": 93.0,
//           "bestPracticesScore": 94.0,
//           "seoScore": 80.0,
//           "largestContentfulPaintMs": 4967.927041,
//           "cumulativeLayoutShift": 0.41043,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/products/paints-and-textures.html",
//           "strategy": "MOBILE",
//           "performanceScore": 69.0,
//           "accessibilityScore": 82.0,
//           "bestPracticesScore": 94.0,
//           "seoScore": 92.0,
//           "largestContentfulPaintMs": 8448.775599,
//           "cumulativeLayoutShift": 1.516286,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html",
//           "strategy": "DESKTOP",
//           "performanceScore": 74.0,
//           "accessibilityScore": 80.0,
//           "bestPracticesScore": 94.0,
//           "seoScore": 83.0,
//           "largestContentfulPaintMs": 4985.9725,
//           "cumulativeLayoutShift": 1.816517,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html",
//           "strategy": "MOBILE",
//           "performanceScore": 54.0,
//           "accessibilityScore": 95.0,
//           "bestPracticesScore": 84.0,
//           "seoScore": 91.0,
//           "largestContentfulPaintMs": 3334.568707,
//           "cumulativeLayoutShift": 0.446083,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         }
//       ]
//     },
//     {
//       "reportId": "desktop-pagespeed-report-20260919-144500-946",
//       "runId": "run-5-8771",
//       "strategyMode": "BOTH",
//       "generatedAt": "2026-09-19T14:45:00.673Z",
//       "summary": {
//         "totalUrls": 4,
//         "totalResults": 8,
//         "successfulResults": 8,
//         "failedResults": 0,
//         "status": "SUCCESS"
//       },
//       "results": [
//         {
//           "url": "https://www.asianpaints.com/",
//           "strategy": "DESKTOP",
//           "performanceScore": 62.0,
//           "accessibilityScore": 85.0,
//           "bestPracticesScore": 62.0,
//           "seoScore": 91.0,
//           "largestContentfulPaintMs": 4761.841125,
//           "cumulativeLayoutShift": 1.462008,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/",
//           "strategy": "MOBILE",
//           "performanceScore": 34.0,
//           "accessibilityScore": 93.0,
//           "bestPracticesScore": 66.0,
//           "seoScore": 81.0,
//           "largestContentfulPaintMs": 6509.56699,
//           "cumulativeLayoutShift": 1.91303,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/colour-catalogue.html",
//           "strategy": "DESKTOP",
//           "performanceScore": 74.0,
//           "accessibilityScore": 89.0,
//           "bestPracticesScore": 55.0,
//           "seoScore": 82.0,
//           "largestContentfulPaintMs": 1343.87504,
//           "cumulativeLayoutShift": 0.94016,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/colour-catalogue.html",
//           "strategy": "MOBILE",
//           "performanceScore": 52.0,
//           "accessibilityScore": 93.0,
//           "bestPracticesScore": 89.0,
//           "seoScore": 94.0,
//           "largestContentfulPaintMs": 7803.810864,
//           "cumulativeLayoutShift": 0.958947,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/products/paints-and-textures.html",
//           "strategy": "DESKTOP",
//           "performanceScore": 87.0,
//           "accessibilityScore": 98.0,
//           "bestPracticesScore": 55.0,
//           "seoScore": 96.0,
//           "largestContentfulPaintMs": 1499.15677,
//           "cumulativeLayoutShift": 0.777071,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/products/paints-and-textures.html",
//           "strategy": "MOBILE",
//           "performanceScore": 76.0,
//           "accessibilityScore": 93.0,
//           "bestPracticesScore": 61.0,
//           "seoScore": 88.0,
//           "largestContentfulPaintMs": 7354.935021,
//           "cumulativeLayoutShift": 0.665034,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html",
//           "strategy": "DESKTOP",
//           "performanceScore": 98.0,
//           "accessibilityScore": 92.0,
//           "bestPracticesScore": 75.0,
//           "seoScore": 77.0,
//           "largestContentfulPaintMs": 6791.988324,
//           "cumulativeLayoutShift": 0.340007,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html",
//           "strategy": "MOBILE",
//           "performanceScore": 33.0,
//           "accessibilityScore": 82.0,
//           "bestPracticesScore": 87.0,
//           "seoScore": 89.0,
//           "largestContentfulPaintMs": 7506.892343,
//           "cumulativeLayoutShift": 0.292349,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         }
//       ]
//     },
//     {
//       "reportId": "desktop-pagespeed-report-20260921-090000-594",
//       "runId": "run-6-2738",
//       "strategyMode": "BOTH",
//       "generatedAt": "2026-09-21T09:00:00.904Z",
//       "summary": {
//         "totalUrls": 4,
//         "totalResults": 8,
//         "successfulResults": 8,
//         "failedResults": 0,
//         "status": "SUCCESS"
//       },
//       "results": [
//         {
//           "url": "https://www.asianpaints.com/",
//           "strategy": "DESKTOP",
//           "performanceScore": 61.0,
//           "accessibilityScore": 95.0,
//           "bestPracticesScore": 85.0,
//           "seoScore": 79.0,
//           "largestContentfulPaintMs": 637.2209,
//           "cumulativeLayoutShift": 1.598714,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/",
//           "strategy": "MOBILE",
//           "performanceScore": 91.0,
//           "accessibilityScore": 81.0,
//           "bestPracticesScore": 83.0,
//           "seoScore": 79.0,
//           "largestContentfulPaintMs": 4245.832572,
//           "cumulativeLayoutShift": 1.743486,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/colour-catalogue.html",
//           "strategy": "DESKTOP",
//           "performanceScore": 93.0,
//           "accessibilityScore": 78.0,
//           "bestPracticesScore": 66.0,
//           "seoScore": 81.0,
//           "largestContentfulPaintMs": 3013.458211,
//           "cumulativeLayoutShift": 0.481079,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/colour-catalogue.html",
//           "strategy": "MOBILE",
//           "performanceScore": 72.0,
//           "accessibilityScore": 86.0,
//           "bestPracticesScore": 84.0,
//           "seoScore": 88.0,
//           "largestContentfulPaintMs": 7749.206219,
//           "cumulativeLayoutShift": 0.121809,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/products/paints-and-textures.html",
//           "strategy": "DESKTOP",
//           "performanceScore": 93.0,
//           "accessibilityScore": 92.0,
//           "bestPracticesScore": 92.0,
//           "seoScore": 93.0,
//           "largestContentfulPaintMs": 7581.661534,
//           "cumulativeLayoutShift": 1.033522,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://www.asianpaints.com/products/paints-and-textures.html",
//           "strategy": "MOBILE",
//           "performanceScore": 61.0,
//           "accessibilityScore": 95.0,
//           "bestPracticesScore": 59.0,
//           "seoScore": 91.0,
//           "largestContentfulPaintMs": 4917.286357,
//           "cumulativeLayoutShift": 1.745611,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html",
//           "strategy": "DESKTOP",
//           "performanceScore": 89.0,
//           "accessibilityScore": 97.0,
//           "bestPracticesScore": 50.0,
//           "seoScore": 79.0,
//           "largestContentfulPaintMs": 1958.033732,
//           "cumulativeLayoutShift": 0.946986,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         },
//         {
//           "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html",
//           "strategy": "MOBILE",
//           "performanceScore": 74.0,
//           "accessibilityScore": 95.0,
//           "bestPracticesScore": 53.0,
//           "seoScore": 85.0,
//           "largestContentfulPaintMs": 6420.399441,
//           "cumulativeLayoutShift": 1.061453,
//           "status": "SUCCESS",
//           "errorMessage": ""
//         }
//       ]
//     }
//   ],
//   "count": 6,
//   "limit": 10,
//   "availableRuns": 6,
//   "skippedRuns": 0
// };

// dummyAemHistory.fulltest.js
// TEST DATA ONLY - 15 URLs, EVERY one has both DESKTOP and MOBILE
// (side-by-side layout on every card), across 3 runs on 3 DIFFERENT
// CALENDAR DATES: 2026-09-16, 2026-09-19, 2026-09-21.
// 15 URLs > MAX_SUGGESTIONS (8), so this also exercises the
// "+N more - keep typing to narrow" dropdown hint.
// Temporarily use this in place of dummyAemHistory.js to test.
export const DUMMY_AEM_HISTORY = {
  "runs": [
    {
      "reportId": "desktop-pagespeed-report-20260916-090000-616",
      "runId": "run-1-1928",
      "strategyMode": "BOTH",
      "generatedAt": "2026-09-16T09:00:00.809Z",
      "summary": {
        "totalUrls": 15,
        "totalResults": 30,
        "successfulResults": 30,
        "failedResults": 0,
        "status": "SUCCESS"
      },
      "results": [
        {
          "url": "https://www.asianpaints.com/",
          "strategy": "DESKTOP",
          "performanceScore": 58.0,
          "accessibilityScore": 100.0,
          "bestPracticesScore": 76.0,
          "seoScore": 95.0,
          "largestContentfulPaintMs": 2910.998812,
          "cumulativeLayoutShift": 1.686557,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/",
          "strategy": "MOBILE",
          "performanceScore": 90.0,
          "accessibilityScore": 94.0,
          "bestPracticesScore": 61.0,
          "seoScore": 91.0,
          "largestContentfulPaintMs": 5066.047495,
          "cumulativeLayoutShift": 1.576807,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/colour-catalogue.html",
          "strategy": "DESKTOP",
          "performanceScore": 46.0,
          "accessibilityScore": 96.0,
          "bestPracticesScore": 77.0,
          "seoScore": 77.0,
          "largestContentfulPaintMs": 1718.068427,
          "cumulativeLayoutShift": 1.50264,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/colour-catalogue.html",
          "strategy": "MOBILE",
          "performanceScore": 40.0,
          "accessibilityScore": 91.0,
          "bestPracticesScore": 97.0,
          "seoScore": 88.0,
          "largestContentfulPaintMs": 5839.038279,
          "cumulativeLayoutShift": 0.06814,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/products/paints-and-textures.html",
          "strategy": "DESKTOP",
          "performanceScore": 73.0,
          "accessibilityScore": 93.0,
          "bestPracticesScore": 94.0,
          "seoScore": 78.0,
          "largestContentfulPaintMs": 6127.141665,
          "cumulativeLayoutShift": 1.875821,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/products/paints-and-textures.html",
          "strategy": "MOBILE",
          "performanceScore": 30.0,
          "accessibilityScore": 80.0,
          "bestPracticesScore": 57.0,
          "seoScore": 75.0,
          "largestContentfulPaintMs": 4414.866448,
          "cumulativeLayoutShift": 1.104006,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/products/waterproofing.html",
          "strategy": "DESKTOP",
          "performanceScore": 68.0,
          "accessibilityScore": 93.0,
          "bestPracticesScore": 59.0,
          "seoScore": 80.0,
          "largestContentfulPaintMs": 6269.695874,
          "cumulativeLayoutShift": 0.939884,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/products/waterproofing.html",
          "strategy": "MOBILE",
          "performanceScore": 42.0,
          "accessibilityScore": 84.0,
          "bestPracticesScore": 63.0,
          "seoScore": 96.0,
          "largestContentfulPaintMs": 8926.728728,
          "cumulativeLayoutShift": 1.787932,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/products/wood-finishes.html",
          "strategy": "DESKTOP",
          "performanceScore": 100.0,
          "accessibilityScore": 80.0,
          "bestPracticesScore": 57.0,
          "seoScore": 92.0,
          "largestContentfulPaintMs": 4617.847158,
          "cumulativeLayoutShift": 1.654036,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/products/wood-finishes.html",
          "strategy": "MOBILE",
          "performanceScore": 47.0,
          "accessibilityScore": 82.0,
          "bestPracticesScore": 84.0,
          "seoScore": 88.0,
          "largestContentfulPaintMs": 3004.888833,
          "cumulativeLayoutShift": 1.909017,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/services/home-painting.html",
          "strategy": "DESKTOP",
          "performanceScore": 79.0,
          "accessibilityScore": 88.0,
          "bestPracticesScore": 81.0,
          "seoScore": 87.0,
          "largestContentfulPaintMs": 2774.915595,
          "cumulativeLayoutShift": 1.668241,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/services/home-painting.html",
          "strategy": "MOBILE",
          "performanceScore": 50.0,
          "accessibilityScore": 78.0,
          "bestPracticesScore": 81.0,
          "seoScore": 77.0,
          "largestContentfulPaintMs": 5266.270361,
          "cumulativeLayoutShift": 1.496352,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/services/interior-design.html",
          "strategy": "DESKTOP",
          "performanceScore": 67.0,
          "accessibilityScore": 97.0,
          "bestPracticesScore": 70.0,
          "seoScore": 92.0,
          "largestContentfulPaintMs": 9024.957376,
          "cumulativeLayoutShift": 0.225419,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/services/interior-design.html",
          "strategy": "MOBILE",
          "performanceScore": 72.0,
          "accessibilityScore": 98.0,
          "bestPracticesScore": 72.0,
          "seoScore": 85.0,
          "largestContentfulPaintMs": 3482.867427,
          "cumulativeLayoutShift": 1.194473,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/store-locator.html",
          "strategy": "DESKTOP",
          "performanceScore": 61.0,
          "accessibilityScore": 81.0,
          "bestPracticesScore": 60.0,
          "seoScore": 77.0,
          "largestContentfulPaintMs": 8527.385516,
          "cumulativeLayoutShift": 0.348036,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/store-locator.html",
          "strategy": "MOBILE",
          "performanceScore": 63.0,
          "accessibilityScore": 83.0,
          "bestPracticesScore": 93.0,
          "seoScore": 76.0,
          "largestContentfulPaintMs": 6364.140592,
          "cumulativeLayoutShift": 1.797395,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/colour-next.html",
          "strategy": "DESKTOP",
          "performanceScore": 63.0,
          "accessibilityScore": 83.0,
          "bestPracticesScore": 97.0,
          "seoScore": 93.0,
          "largestContentfulPaintMs": 574.799257,
          "cumulativeLayoutShift": 0.693219,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/colour-next.html",
          "strategy": "MOBILE",
          "performanceScore": 69.0,
          "accessibilityScore": 99.0,
          "bestPracticesScore": 65.0,
          "seoScore": 82.0,
          "largestContentfulPaintMs": 1870.059958,
          "cumulativeLayoutShift": 0.13867,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/inspiration-gallery.html",
          "strategy": "DESKTOP",
          "performanceScore": 99.0,
          "accessibilityScore": 93.0,
          "bestPracticesScore": 53.0,
          "seoScore": 84.0,
          "largestContentfulPaintMs": 906.519248,
          "cumulativeLayoutShift": 0.515953,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/inspiration-gallery.html",
          "strategy": "MOBILE",
          "performanceScore": 44.0,
          "accessibilityScore": 91.0,
          "bestPracticesScore": 65.0,
          "seoScore": 80.0,
          "largestContentfulPaintMs": 3902.096158,
          "cumulativeLayoutShift": 1.740771,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html",
          "strategy": "DESKTOP",
          "performanceScore": 80.0,
          "accessibilityScore": 82.0,
          "bestPracticesScore": 97.0,
          "seoScore": 90.0,
          "largestContentfulPaintMs": 882.268416,
          "cumulativeLayoutShift": 0.279177,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html",
          "strategy": "MOBILE",
          "performanceScore": 82.0,
          "accessibilityScore": 93.0,
          "bestPracticesScore": 51.0,
          "seoScore": 81.0,
          "largestContentfulPaintMs": 8320.090454,
          "cumulativeLayoutShift": 0.73145,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/where-to-buy.html",
          "strategy": "DESKTOP",
          "performanceScore": 55.0,
          "accessibilityScore": 97.0,
          "bestPracticesScore": 99.0,
          "seoScore": 88.0,
          "largestContentfulPaintMs": 4689.012097,
          "cumulativeLayoutShift": 1.805178,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/where-to-buy.html",
          "strategy": "MOBILE",
          "performanceScore": 64.0,
          "accessibilityScore": 82.0,
          "bestPracticesScore": 84.0,
          "seoScore": 93.0,
          "largestContentfulPaintMs": 2864.840813,
          "cumulativeLayoutShift": 1.536512,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/about-us.html",
          "strategy": "DESKTOP",
          "performanceScore": 47.0,
          "accessibilityScore": 99.0,
          "bestPracticesScore": 58.0,
          "seoScore": 75.0,
          "largestContentfulPaintMs": 2763.683994,
          "cumulativeLayoutShift": 0.652339,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/about-us.html",
          "strategy": "MOBILE",
          "performanceScore": 58.0,
          "accessibilityScore": 91.0,
          "bestPracticesScore": 66.0,
          "seoScore": 96.0,
          "largestContentfulPaintMs": 3999.055236,
          "cumulativeLayoutShift": 1.917426,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/careers.html",
          "strategy": "DESKTOP",
          "performanceScore": 47.0,
          "accessibilityScore": 82.0,
          "bestPracticesScore": 56.0,
          "seoScore": 87.0,
          "largestContentfulPaintMs": 1271.964753,
          "cumulativeLayoutShift": 0.050634,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/careers.html",
          "strategy": "MOBILE",
          "performanceScore": 57.0,
          "accessibilityScore": 80.0,
          "bestPracticesScore": 57.0,
          "seoScore": 95.0,
          "largestContentfulPaintMs": 2911.723535,
          "cumulativeLayoutShift": 0.608052,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/sustainability.html",
          "strategy": "DESKTOP",
          "performanceScore": 67.0,
          "accessibilityScore": 93.0,
          "bestPracticesScore": 64.0,
          "seoScore": 94.0,
          "largestContentfulPaintMs": 1903.203906,
          "cumulativeLayoutShift": 0.367886,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/sustainability.html",
          "strategy": "MOBILE",
          "performanceScore": 55.0,
          "accessibilityScore": 100.0,
          "bestPracticesScore": 97.0,
          "seoScore": 92.0,
          "largestContentfulPaintMs": 7074.241223,
          "cumulativeLayoutShift": 1.207796,
          "status": "SUCCESS",
          "errorMessage": ""
        }
      ]
    },
    {
      "reportId": "desktop-pagespeed-report-20260919-153000-742",
      "runId": "run-2-1151",
      "strategyMode": "BOTH",
      "generatedAt": "2026-09-19T15:30:00.911Z",
      "summary": {
        "totalUrls": 15,
        "totalResults": 30,
        "successfulResults": 30,
        "failedResults": 0,
        "status": "SUCCESS"
      },
      "results": [
        {
          "url": "https://www.asianpaints.com/",
          "strategy": "DESKTOP",
          "performanceScore": 47.0,
          "accessibilityScore": 92.0,
          "bestPracticesScore": 54.0,
          "seoScore": 87.0,
          "largestContentfulPaintMs": 7134.300834,
          "cumulativeLayoutShift": 0.350594,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/",
          "strategy": "MOBILE",
          "performanceScore": 77.0,
          "accessibilityScore": 86.0,
          "bestPracticesScore": 94.0,
          "seoScore": 94.0,
          "largestContentfulPaintMs": 3194.151198,
          "cumulativeLayoutShift": 0.083822,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/colour-catalogue.html",
          "strategy": "DESKTOP",
          "performanceScore": 63.0,
          "accessibilityScore": 87.0,
          "bestPracticesScore": 96.0,
          "seoScore": 84.0,
          "largestContentfulPaintMs": 7604.019303,
          "cumulativeLayoutShift": 1.606147,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/colour-catalogue.html",
          "strategy": "MOBILE",
          "performanceScore": 74.0,
          "accessibilityScore": 81.0,
          "bestPracticesScore": 84.0,
          "seoScore": 94.0,
          "largestContentfulPaintMs": 975.446819,
          "cumulativeLayoutShift": 1.189528,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/products/paints-and-textures.html",
          "strategy": "DESKTOP",
          "performanceScore": 71.0,
          "accessibilityScore": 87.0,
          "bestPracticesScore": 68.0,
          "seoScore": 94.0,
          "largestContentfulPaintMs": 5050.633265,
          "cumulativeLayoutShift": 1.121354,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/products/paints-and-textures.html",
          "strategy": "MOBILE",
          "performanceScore": 48.0,
          "accessibilityScore": 88.0,
          "bestPracticesScore": 62.0,
          "seoScore": 86.0,
          "largestContentfulPaintMs": 1021.505495,
          "cumulativeLayoutShift": 1.315919,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/products/waterproofing.html",
          "strategy": "DESKTOP",
          "performanceScore": 64.0,
          "accessibilityScore": 80.0,
          "bestPracticesScore": 91.0,
          "seoScore": 77.0,
          "largestContentfulPaintMs": 5932.287032,
          "cumulativeLayoutShift": 1.615347,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/products/waterproofing.html",
          "strategy": "MOBILE",
          "performanceScore": 69.0,
          "accessibilityScore": 97.0,
          "bestPracticesScore": 51.0,
          "seoScore": 96.0,
          "largestContentfulPaintMs": 6090.659034,
          "cumulativeLayoutShift": 0.885273,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/products/wood-finishes.html",
          "strategy": "DESKTOP",
          "performanceScore": 84.0,
          "accessibilityScore": 90.0,
          "bestPracticesScore": 75.0,
          "seoScore": 77.0,
          "largestContentfulPaintMs": 2423.001875,
          "cumulativeLayoutShift": 0.09764,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/products/wood-finishes.html",
          "strategy": "MOBILE",
          "performanceScore": 53.0,
          "accessibilityScore": 85.0,
          "bestPracticesScore": 67.0,
          "seoScore": 93.0,
          "largestContentfulPaintMs": 7601.341772,
          "cumulativeLayoutShift": 1.447519,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/services/home-painting.html",
          "strategy": "DESKTOP",
          "performanceScore": 71.0,
          "accessibilityScore": 90.0,
          "bestPracticesScore": 74.0,
          "seoScore": 85.0,
          "largestContentfulPaintMs": 4709.365654,
          "cumulativeLayoutShift": 1.263647,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/services/home-painting.html",
          "strategy": "MOBILE",
          "performanceScore": 68.0,
          "accessibilityScore": 79.0,
          "bestPracticesScore": 80.0,
          "seoScore": 80.0,
          "largestContentfulPaintMs": 4753.992983,
          "cumulativeLayoutShift": 1.434347,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/services/interior-design.html",
          "strategy": "DESKTOP",
          "performanceScore": 62.0,
          "accessibilityScore": 98.0,
          "bestPracticesScore": 90.0,
          "seoScore": 94.0,
          "largestContentfulPaintMs": 6295.251019,
          "cumulativeLayoutShift": 1.717812,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/services/interior-design.html",
          "strategy": "MOBILE",
          "performanceScore": 77.0,
          "accessibilityScore": 85.0,
          "bestPracticesScore": 80.0,
          "seoScore": 90.0,
          "largestContentfulPaintMs": 3827.085199,
          "cumulativeLayoutShift": 1.229419,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/store-locator.html",
          "strategy": "DESKTOP",
          "performanceScore": 100.0,
          "accessibilityScore": 100.0,
          "bestPracticesScore": 50.0,
          "seoScore": 80.0,
          "largestContentfulPaintMs": 3185.392278,
          "cumulativeLayoutShift": 0.623465,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/store-locator.html",
          "strategy": "MOBILE",
          "performanceScore": 54.0,
          "accessibilityScore": 80.0,
          "bestPracticesScore": 85.0,
          "seoScore": 80.0,
          "largestContentfulPaintMs": 1145.771628,
          "cumulativeLayoutShift": 0.605205,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/colour-next.html",
          "strategy": "DESKTOP",
          "performanceScore": 73.0,
          "accessibilityScore": 81.0,
          "bestPracticesScore": 60.0,
          "seoScore": 88.0,
          "largestContentfulPaintMs": 2250.912672,
          "cumulativeLayoutShift": 0.670587,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/colour-next.html",
          "strategy": "MOBILE",
          "performanceScore": 84.0,
          "accessibilityScore": 99.0,
          "bestPracticesScore": 62.0,
          "seoScore": 83.0,
          "largestContentfulPaintMs": 1167.460575,
          "cumulativeLayoutShift": 0.057182,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/inspiration-gallery.html",
          "strategy": "DESKTOP",
          "performanceScore": 75.0,
          "accessibilityScore": 82.0,
          "bestPracticesScore": 93.0,
          "seoScore": 91.0,
          "largestContentfulPaintMs": 2198.959112,
          "cumulativeLayoutShift": 1.195938,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/inspiration-gallery.html",
          "strategy": "MOBILE",
          "performanceScore": 54.0,
          "accessibilityScore": 83.0,
          "bestPracticesScore": 75.0,
          "seoScore": 89.0,
          "largestContentfulPaintMs": 3964.730149,
          "cumulativeLayoutShift": 0.921437,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html",
          "strategy": "DESKTOP",
          "performanceScore": 85.0,
          "accessibilityScore": 99.0,
          "bestPracticesScore": 61.0,
          "seoScore": 96.0,
          "largestContentfulPaintMs": 3815.550892,
          "cumulativeLayoutShift": 0.544804,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html",
          "strategy": "MOBILE",
          "performanceScore": 43.0,
          "accessibilityScore": 79.0,
          "bestPracticesScore": 72.0,
          "seoScore": 95.0,
          "largestContentfulPaintMs": 8629.060976,
          "cumulativeLayoutShift": 1.409198,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/where-to-buy.html",
          "strategy": "DESKTOP",
          "performanceScore": 38.0,
          "accessibilityScore": 94.0,
          "bestPracticesScore": 87.0,
          "seoScore": 76.0,
          "largestContentfulPaintMs": 3933.82829,
          "cumulativeLayoutShift": 0.882472,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/where-to-buy.html",
          "strategy": "MOBILE",
          "performanceScore": 60.0,
          "accessibilityScore": 78.0,
          "bestPracticesScore": 84.0,
          "seoScore": 79.0,
          "largestContentfulPaintMs": 1277.040242,
          "cumulativeLayoutShift": 0.617925,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/about-us.html",
          "strategy": "DESKTOP",
          "performanceScore": 75.0,
          "accessibilityScore": 78.0,
          "bestPracticesScore": 73.0,
          "seoScore": 80.0,
          "largestContentfulPaintMs": 1630.83246,
          "cumulativeLayoutShift": 1.583428,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/about-us.html",
          "strategy": "MOBILE",
          "performanceScore": 68.0,
          "accessibilityScore": 79.0,
          "bestPracticesScore": 69.0,
          "seoScore": 81.0,
          "largestContentfulPaintMs": 4099.95377,
          "cumulativeLayoutShift": 1.765078,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/careers.html",
          "strategy": "DESKTOP",
          "performanceScore": 57.0,
          "accessibilityScore": 96.0,
          "bestPracticesScore": 87.0,
          "seoScore": 89.0,
          "largestContentfulPaintMs": 8181.115972,
          "cumulativeLayoutShift": 0.035211,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/careers.html",
          "strategy": "MOBILE",
          "performanceScore": 64.0,
          "accessibilityScore": 80.0,
          "bestPracticesScore": 77.0,
          "seoScore": 96.0,
          "largestContentfulPaintMs": 2097.56802,
          "cumulativeLayoutShift": 0.119291,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/sustainability.html",
          "strategy": "DESKTOP",
          "performanceScore": 100.0,
          "accessibilityScore": 97.0,
          "bestPracticesScore": 84.0,
          "seoScore": 94.0,
          "largestContentfulPaintMs": 4749.694908,
          "cumulativeLayoutShift": 1.358449,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/sustainability.html",
          "strategy": "MOBILE",
          "performanceScore": 78.0,
          "accessibilityScore": 82.0,
          "bestPracticesScore": 67.0,
          "seoScore": 79.0,
          "largestContentfulPaintMs": 3539.854969,
          "cumulativeLayoutShift": 0.595976,
          "status": "SUCCESS",
          "errorMessage": ""
        }
      ]
    },
    {
      "reportId": "desktop-pagespeed-report-20260921-084500-661",
      "runId": "run-3-7125",
      "strategyMode": "BOTH",
      "generatedAt": "2026-09-21T08:45:00.442Z",
      "summary": {
        "totalUrls": 15,
        "totalResults": 30,
        "successfulResults": 30,
        "failedResults": 0,
        "status": "SUCCESS"
      },
      "results": [
        {
          "url": "https://www.asianpaints.com/",
          "strategy": "DESKTOP",
          "performanceScore": 88.0,
          "accessibilityScore": 99.0,
          "bestPracticesScore": 54.0,
          "seoScore": 80.0,
          "largestContentfulPaintMs": 4927.862098,
          "cumulativeLayoutShift": 1.356018,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/",
          "strategy": "MOBILE",
          "performanceScore": 48.0,
          "accessibilityScore": 86.0,
          "bestPracticesScore": 72.0,
          "seoScore": 76.0,
          "largestContentfulPaintMs": 1868.374695,
          "cumulativeLayoutShift": 1.170559,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/colour-catalogue.html",
          "strategy": "DESKTOP",
          "performanceScore": 72.0,
          "accessibilityScore": 90.0,
          "bestPracticesScore": 60.0,
          "seoScore": 76.0,
          "largestContentfulPaintMs": 1360.953475,
          "cumulativeLayoutShift": 1.86173,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/colour-catalogue.html",
          "strategy": "MOBILE",
          "performanceScore": 67.0,
          "accessibilityScore": 91.0,
          "bestPracticesScore": 62.0,
          "seoScore": 81.0,
          "largestContentfulPaintMs": 6818.384396,
          "cumulativeLayoutShift": 1.04916,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/products/paints-and-textures.html",
          "strategy": "DESKTOP",
          "performanceScore": 50.0,
          "accessibilityScore": 85.0,
          "bestPracticesScore": 63.0,
          "seoScore": 91.0,
          "largestContentfulPaintMs": 804.180775,
          "cumulativeLayoutShift": 0.704546,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/products/paints-and-textures.html",
          "strategy": "MOBILE",
          "performanceScore": 79.0,
          "accessibilityScore": 98.0,
          "bestPracticesScore": 91.0,
          "seoScore": 80.0,
          "largestContentfulPaintMs": 634.149006,
          "cumulativeLayoutShift": 0.736989,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/products/waterproofing.html",
          "strategy": "DESKTOP",
          "performanceScore": 70.0,
          "accessibilityScore": 92.0,
          "bestPracticesScore": 51.0,
          "seoScore": 83.0,
          "largestContentfulPaintMs": 6395.437042,
          "cumulativeLayoutShift": 0.434627,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/products/waterproofing.html",
          "strategy": "MOBILE",
          "performanceScore": 94.0,
          "accessibilityScore": 97.0,
          "bestPracticesScore": 84.0,
          "seoScore": 94.0,
          "largestContentfulPaintMs": 8399.128978,
          "cumulativeLayoutShift": 1.940353,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/products/wood-finishes.html",
          "strategy": "DESKTOP",
          "performanceScore": 65.0,
          "accessibilityScore": 92.0,
          "bestPracticesScore": 94.0,
          "seoScore": 86.0,
          "largestContentfulPaintMs": 548.396525,
          "cumulativeLayoutShift": 0.703837,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/products/wood-finishes.html",
          "strategy": "MOBILE",
          "performanceScore": 72.0,
          "accessibilityScore": 97.0,
          "bestPracticesScore": 51.0,
          "seoScore": 87.0,
          "largestContentfulPaintMs": 6110.024101,
          "cumulativeLayoutShift": 0.322948,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/services/home-painting.html",
          "strategy": "DESKTOP",
          "performanceScore": 85.0,
          "accessibilityScore": 91.0,
          "bestPracticesScore": 63.0,
          "seoScore": 82.0,
          "largestContentfulPaintMs": 9183.028514,
          "cumulativeLayoutShift": 1.109719,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/services/home-painting.html",
          "strategy": "MOBILE",
          "performanceScore": 88.0,
          "accessibilityScore": 89.0,
          "bestPracticesScore": 55.0,
          "seoScore": 82.0,
          "largestContentfulPaintMs": 3998.773659,
          "cumulativeLayoutShift": 0.356532,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/services/interior-design.html",
          "strategy": "DESKTOP",
          "performanceScore": 80.0,
          "accessibilityScore": 96.0,
          "bestPracticesScore": 58.0,
          "seoScore": 75.0,
          "largestContentfulPaintMs": 8427.257315,
          "cumulativeLayoutShift": 1.909238,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/services/interior-design.html",
          "strategy": "MOBILE",
          "performanceScore": 73.0,
          "accessibilityScore": 99.0,
          "bestPracticesScore": 97.0,
          "seoScore": 81.0,
          "largestContentfulPaintMs": 6940.267084,
          "cumulativeLayoutShift": 0.425352,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/store-locator.html",
          "strategy": "DESKTOP",
          "performanceScore": 85.0,
          "accessibilityScore": 89.0,
          "bestPracticesScore": 82.0,
          "seoScore": 84.0,
          "largestContentfulPaintMs": 1524.91457,
          "cumulativeLayoutShift": 0.480094,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/store-locator.html",
          "strategy": "MOBILE",
          "performanceScore": 71.0,
          "accessibilityScore": 98.0,
          "bestPracticesScore": 79.0,
          "seoScore": 90.0,
          "largestContentfulPaintMs": 7024.575764,
          "cumulativeLayoutShift": 1.301558,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/colour-next.html",
          "strategy": "DESKTOP",
          "performanceScore": 56.0,
          "accessibilityScore": 91.0,
          "bestPracticesScore": 74.0,
          "seoScore": 82.0,
          "largestContentfulPaintMs": 4733.80702,
          "cumulativeLayoutShift": 0.530974,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/colour-next.html",
          "strategy": "MOBILE",
          "performanceScore": 73.0,
          "accessibilityScore": 84.0,
          "bestPracticesScore": 52.0,
          "seoScore": 85.0,
          "largestContentfulPaintMs": 5581.361215,
          "cumulativeLayoutShift": 1.605505,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/inspiration-gallery.html",
          "strategy": "DESKTOP",
          "performanceScore": 86.0,
          "accessibilityScore": 85.0,
          "bestPracticesScore": 60.0,
          "seoScore": 87.0,
          "largestContentfulPaintMs": 1695.084496,
          "cumulativeLayoutShift": 0.065496,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/inspiration-gallery.html",
          "strategy": "MOBILE",
          "performanceScore": 92.0,
          "accessibilityScore": 87.0,
          "bestPracticesScore": 86.0,
          "seoScore": 89.0,
          "largestContentfulPaintMs": 2173.128263,
          "cumulativeLayoutShift": 0.454539,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html",
          "strategy": "DESKTOP",
          "performanceScore": 98.0,
          "accessibilityScore": 93.0,
          "bestPracticesScore": 93.0,
          "seoScore": 76.0,
          "largestContentfulPaintMs": 687.019123,
          "cumulativeLayoutShift": 1.832793,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html",
          "strategy": "MOBILE",
          "performanceScore": 48.0,
          "accessibilityScore": 88.0,
          "bestPracticesScore": 79.0,
          "seoScore": 86.0,
          "largestContentfulPaintMs": 3857.704019,
          "cumulativeLayoutShift": 1.256951,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/where-to-buy.html",
          "strategy": "DESKTOP",
          "performanceScore": 75.0,
          "accessibilityScore": 86.0,
          "bestPracticesScore": 98.0,
          "seoScore": 78.0,
          "largestContentfulPaintMs": 3730.507564,
          "cumulativeLayoutShift": 0.500786,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/where-to-buy.html",
          "strategy": "MOBILE",
          "performanceScore": 89.0,
          "accessibilityScore": 81.0,
          "bestPracticesScore": 62.0,
          "seoScore": 94.0,
          "largestContentfulPaintMs": 7867.312761,
          "cumulativeLayoutShift": 1.781196,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/about-us.html",
          "strategy": "DESKTOP",
          "performanceScore": 48.0,
          "accessibilityScore": 85.0,
          "bestPracticesScore": 90.0,
          "seoScore": 79.0,
          "largestContentfulPaintMs": 1728.901019,
          "cumulativeLayoutShift": 1.662319,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/about-us.html",
          "strategy": "MOBILE",
          "performanceScore": 44.0,
          "accessibilityScore": 99.0,
          "bestPracticesScore": 89.0,
          "seoScore": 84.0,
          "largestContentfulPaintMs": 6102.295486,
          "cumulativeLayoutShift": 1.02792,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/careers.html",
          "strategy": "DESKTOP",
          "performanceScore": 58.0,
          "accessibilityScore": 100.0,
          "bestPracticesScore": 81.0,
          "seoScore": 81.0,
          "largestContentfulPaintMs": 731.412488,
          "cumulativeLayoutShift": 1.800897,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/careers.html",
          "strategy": "MOBILE",
          "performanceScore": 82.0,
          "accessibilityScore": 89.0,
          "bestPracticesScore": 50.0,
          "seoScore": 81.0,
          "largestContentfulPaintMs": 7824.267587,
          "cumulativeLayoutShift": 0.567454,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/sustainability.html",
          "strategy": "DESKTOP",
          "performanceScore": 64.0,
          "accessibilityScore": 79.0,
          "bestPracticesScore": 57.0,
          "seoScore": 94.0,
          "largestContentfulPaintMs": 6179.474459,
          "cumulativeLayoutShift": 0.042312,
          "status": "SUCCESS",
          "errorMessage": ""
        },
        {
          "url": "https://www.asianpaints.com/sustainability.html",
          "strategy": "MOBILE",
          "performanceScore": 78.0,
          "accessibilityScore": 97.0,
          "bestPracticesScore": 95.0,
          "seoScore": 89.0,
          "largestContentfulPaintMs": 4719.319405,
          "cumulativeLayoutShift": 1.075054,
          "status": "SUCCESS",
          "errorMessage": ""
        }
      ]
    }
  ],
  "count": 3,
  "limit": 10,
  "availableRuns": 3,
  "skippedRuns": 0
};