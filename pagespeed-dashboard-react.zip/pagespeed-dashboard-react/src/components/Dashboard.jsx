
// import { useState, useEffect, useCallback, useMemo } from "react";
// import ScoreSwatch, { band } from "./ScoreSwatch.jsx";
// import Sparkline from "./Sparkline.jsx";
// import MetricsRow from "./MetricsRow.jsx";
// import { fetchReport } from "../lib/backendApi.js";
// import { THRESHOLDS } from "../config.js";

// const CATS = [
//   ["performance", "Perf"],
//   ["accessibility", "A11y"],
//   ["best_practices", "Best Pr."],
//   ["seo", "SEO"],
// ];
// const MAX_HISTORY = 20;
// const DEFAULT_VISIBLE = 10; // how many cards show by default, before filtering or "Show all"

// function computeBreaches(row) {
//   return Object.keys(THRESHOLDS).filter((k) => {
//     const s = row.scores[k];
//     return s !== null && s !== undefined && s < THRESHOLDS[k];
//   });
// }

// function meanScore(scores) {
//   const vals = Object.values(scores).filter((v) => v !== null && v !== undefined);
//   return vals.length ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length) : null;
// }

// export default function Dashboard({ history, setHistory }) {
//   const [results, setResults] = useState({ rows: [], errors: [] });
//   const [running, setRunning] = useState(false);
//   const [statusText, setStatusText] = useState("Loading…");
//   const [query, setQuery] = useState("");
//   const [showAll, setShowAll] = useState(false);

//   function pushHistory(row, nextHistory) {
//     const key = `${row.label}|${row.strategy}`;
//     const list = nextHistory[key] ? [...nextHistory[key]] : [];
//     list.push({ ts: new Date().toISOString(), scores: row.scores });
//     nextHistory[key] = list.length > MAX_HISTORY ? list.slice(-MAX_HISTORY) : list;
//   }

//   const runCheck = useCallback(async () => {
//     setRunning(true);
//     setStatusText("Fetching latest report…");
//     try {
//       const data = await fetchReport();
//       const rows = data.rows || [];
//       const errors = data.errors || [];
//       const nextHistory = { ...history };
//       rows.forEach((row) => pushHistory(row, nextHistory));
//       setResults({ rows, errors });
//       setHistory(nextHistory);
//       setStatusText(
//         `Last updated: ${new Date().toLocaleString()}${
//           data.generatedAt ? ` (data generated ${new Date(data.generatedAt).toLocaleString()})` : ""
//         }`
//       );
//     } catch (err) {
//       setStatusText(`Fetch failed: ${err.message || err}. Check USE_DUMMY_DATA / REPORT_URL in src/config.js.`);
//     }
//     setRunning(false);
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [history]);

//   // Fetch once on load.
//   useEffect(() => {
//     runCheck();
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, []);

//   const breachCount = results.rows.filter((r) => computeBreaches(r).length).length;

//   // Filter by label/URL text; when no filter is active, cap the initial
//   // view to DEFAULT_VISIBLE cards so 100 configured URLs don't turn into
//   // 100 tiles on load. Typing a filter (or pressing "Show all") lifts the cap.
//   const filteredRows = useMemo(() => {
//     const q = query.trim().toLowerCase();
//     if (!q) return results.rows;
//     return results.rows.filter(
//       (r) => r.label.toLowerCase().includes(q) || r.url.toLowerCase().includes(q)
//     );
//   }, [results.rows, query]);

//   const isFiltering = query.trim().length > 0;
//   const visibleRows = isFiltering || showAll ? filteredRows : filteredRows.slice(0, DEFAULT_VISIBLE);
//   const hiddenCount = filteredRows.length - visibleRows.length;

//   return (
//     <section className="panel active">
//       <div className="toolbar">
//         <button className="primary" onClick={runCheck} disabled={running}>
//           Refresh
//         </button>
//         <input
//           type="text"
//           placeholder="Filter by URL or label…"
//           value={query}
//           onChange={(e) => setQuery(e.target.value)}
//           style={{ minWidth: 220 }}
//         />
//         <span className="status">{statusText}</span>
//       </div>

//       <div className="stat-ribbon">
//         <div className="stat-item accent">
//           <div className="n">{results.rows.length || "—"}</div>
//           <div className="l">URLs checked</div>
//         </div>
//         <div className={`stat-item ${breachCount > 0 ? "warn" : results.rows.length ? "ok" : ""}`}>
//           <div className="n">{results.rows.length ? breachCount : "—"}</div>
//           <div className="l">Threshold breaches</div>
//         </div>
//         <div className={`stat-item ${results.errors.length > 0 ? "warn" : ""}`}>
//           <div className="n">{results.rows.length || results.errors.length ? results.errors.length : "—"}</div>
//           <div className="l">Fetch errors</div>
//         </div>
//       </div>

//       {!results.rows.length && !results.errors.length ? (
//         <div className="empty">No data yet.</div>
//       ) : !filteredRows.length ? (
//         <div className="empty">No URLs match "{query}".</div>
//       ) : (
//         <div className="grid">
//           {visibleRows.map((row) => {
//             const breaches = computeBreaches(row);
//             const key = `${row.label}|${row.strategy}`;
//             const histRecords = history[key] || [];
//             const histMeans = histRecords.map((r) => meanScore(r.scores));
//             let worstBand = "fresh";
//             Object.values(row.scores).forEach((s) => {
//               const b = band(s);
//               if (b === "terracotta") worstBand = "terracotta";
//               else if (b === "honey" && worstBand !== "terracotta") worstBand = "honey";
//             });
//             return (
//               <div className={`card status-${worstBand}`} key={key}>
//                 <div className="head">
//                   <div>
//                     <div className="label">{row.label}</div>
//                     <div className="url">{row.url}</div>
//                   </div>
//                   <span className="strategy-tag">{row.strategy}</span>
//                 </div>
//                 <div className="swatches">
//                   {CATS.map(([k, lbl]) => (
//                     <ScoreSwatch key={k} label={lbl} score={row.scores[k]} />
//                   ))}
//                 </div>
//                 <MetricsRow metrics={row.metrics} />
//                 {breaches.length > 0 && (
//                   <div className="breach-note">Below threshold: {breaches.join(", ")}</div>
//                 )}
//                 {/* {histMeans.length >= 2 && (
//                   <div className="sparkline">
//                     <Sparkline points={histMeans} />
//                     <span>last {histMeans.length} runs</span>
//                   </div>
//                 )} */}
//               </div>
//             );
//           })}

//           {results.errors.map((err, i) => (
//             <div className="card" key={`err-${i}`}>
//               <div className="head">
//                 <div>
//                   <div className="label">{err.label}</div>
//                   <div className="url">{err.url}</div>
//                 </div>
//               </div>
//               <div className="breach-note">
//                 Fetch error ({err.strategy}): {err.error}
//               </div>
//             </div>
//           ))}
//         </div>
//       )}

//       {!isFiltering && hiddenCount > 0 && (
//         <div style={{ textAlign: "center", marginTop: 16 }}>
//           <button className="ghost" onClick={() => setShowAll(true)}>
//             Show all ({filteredRows.length})
//           </button>
//         </div>
//       )}
//       {!isFiltering && showAll && filteredRows.length > DEFAULT_VISIBLE && (
//         <div style={{ textAlign: "center", marginTop: 16 }}>
//           <button className="ghost" onClick={() => setShowAll(false)}>
//             Show first {DEFAULT_VISIBLE} only
//           </button>
//         </div>
//       )}
//     </section>
//   );
// }
import { useState, useEffect, useCallback, useMemo } from "react";
import ScoreSwatch, { band } from "./ScoreSwatch.jsx";
import Sparkline from "./Sparkline.jsx";
import MetricsRow from "./MetricsRow.jsx";
import { fetchReport } from "../lib/backendApi.js";
import { THRESHOLDS } from "../config.js";

const CATS = [
  ["performance", "performance"],
  ["accessibility", "WCAG"],
  ["best_practices", "Best Practice"],
  ["seo", "SEO"],
];
const MAX_HISTORY = 20;
const DEFAULT_VISIBLE = 5; // how many URL cards show by default, before "Show all"
const STRATEGY_ORDER = { mobile: 0, desktop: 1 };

function computeBreaches(row) {
  return Object.keys(THRESHOLDS).filter((k) => {
    const s = row.scores[k];
    return s !== null && s !== undefined && s < THRESHOLDS[k];
  });
}

function meanScore(scores) {
  const vals = Object.values(scores).filter((v) => v !== null && v !== undefined);
  return vals.length ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length) : null;
}

function worstBandFor(row) {
  let worst = "fresh";
  Object.values(row.scores).forEach((s) => {
    const b = band(s);
    if (b === "terracotta") worst = "terracotta";
    else if (b === "honey" && worst !== "terracotta") worst = "honey";
  });
  return worst;
}

// Combines the per-entry worst bands (mobile + desktop) into one overall
// status for the merged card - worst of the two wins.
function combineBand(a, b) {
  const rank = { fresh: 0, honey: 1, terracotta: 2 };
  return rank[b] > rank[a] ? b : a;
}

export default function Dashboard({ history, setHistory }) {
  const [results, setResults] = useState({ rows: [], errors: [] });
  const [running, setRunning] = useState(false);
  const [statusText, setStatusText] = useState("Loading…");
  const [query, setQuery] = useState("");
  const [showAll, setShowAll] = useState(false);

  function pushHistory(row, nextHistory) {
    const key = `${row.label}|${row.strategy}`;
    const list = nextHistory[key] ? [...nextHistory[key]] : [];
    list.push({ ts: new Date().toISOString(), scores: row.scores });
    nextHistory[key] = list.length > MAX_HISTORY ? list.slice(-MAX_HISTORY) : list;
  }

  const runCheck = useCallback(async () => {
    setRunning(true);
    setStatusText("Fetching latest report…");
    try {
      const data = await fetchReport();
      const rows = data.rows || [];
      const errors = data.errors || [];
      const nextHistory = { ...history };
      rows.forEach((row) => pushHistory(row, nextHistory));
      setResults({ rows, errors });
      setHistory(nextHistory);
      setStatusText(
        `Last updated: ${new Date().toLocaleString()}${
          data.generatedAt ? ` (data generated ${new Date(data.generatedAt).toLocaleString()})` : ""
        }`
      );
    } catch (err) {
      setStatusText(`Fetch failed: ${err.message || err}. Check USE_DUMMY_DATA / REPORT_URL in src/config.js.`);
    }
    setRunning(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [history]);

  // Fetch once on load.
  useEffect(() => {
    runCheck();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const breachCount = results.rows.filter((r) => computeBreaches(r).length).length;

  // Filter by label/URL text (typed or picked from the datalist below).
  const filteredRows = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return results.rows;
    return results.rows.filter(
      (r) => r.label.toLowerCase().includes(q) || r.url.toLowerCase().includes(q)
    );
  }, [results.rows, query]);

  // Group mobile + desktop entries for the same URL into ONE card.
  const groups = useMemo(() => {
    const map = new Map();
    filteredRows.forEach((row) => {
           const key = `${row.label.toLowerCase()}|${row.url.toLowerCase()}`;
      if (!map.has(key)) map.set(key, { key, label: row.label, url: row.url, entries: [] });
      map.get(key).entries.push(row);
    });
    map.forEach((g) => {
      g.entries.sort((a, b) => (STRATEGY_ORDER[a.strategy] ?? 2) - (STRATEGY_ORDER[b.strategy] ?? 2));
    });
    return [...map.values()];
  }, [filteredRows]);

  const isFiltering = query.trim().length > 0;
  const visibleGroups = isFiltering || showAll ? groups : groups.slice(0, DEFAULT_VISIBLE);
  const hiddenCount = groups.length - visibleGroups.length;

  // Unique labels for the filter box's autocomplete dropdown.
  const suggestionLabels = useMemo(() => {
    return [...new Set(results.rows.map((r) => r.label))];
  }, [results.rows]);

  return (
    <section className="panel active">
      <div>

      
            <div className="toolbar">
        <button className="primary" onClick={runCheck} disabled={running}>
          Refresh
        </button>

        <span className="url-count-badge">
          <span className="badge-dot" aria-hidden="true" />
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path
              d="M10 13a5 5 0 007.07 0l1.93-1.93a5 5 0 00-7.07-7.07L10.5 5.5M14 11a5 5 0 00-7.07 0L5 12.93a5 5 0 007.07 7.07L13.5 18.5"
              stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"
            />
          </svg>
          {results.rows.length ? `${groups.length} URL${groups.length === 1 ? "" : "s"} checked` : "—"}
        </span>

        <div className="search-wrap">
          <input
            type="text"
            list="url-suggestions"
            placeholder="Search / select a URL…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={(e) => e.target.select()}
            style={{ width: "100%", paddingRight: query ? 28 : undefined }}
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery("")}
              title="Clear filter"
              style={{
                position: "absolute", right: 6, top: "50%", transform: "translateY(-50%)",
                border: "none", background: "transparent", cursor: "pointer",
                color: "var(--ink-faint)", fontSize: 14, lineHeight: 1, padding: 4,
              }}
            >
              ✕
            </button>
          )}
        </div>
        <datalist id="url-suggestions">
          {suggestionLabels.map((label) => (
            <option key={label} value={label} />
          ))}
        </datalist>
      </div>
</div>
      {!results.rows.length && !results.errors.length ? (
        <div className="empty">No data yet.</div>
      ) : !groups.length ? (
        <div className="empty">No URLs match "{query}".</div>
      ) : (
        <div className="grid">
          {visibleGroups.map((group) => {
            let overallBand = "fresh";
            group.entries.forEach((row) => {
              overallBand = combineBand(overallBand, worstBandFor(row));
            });

            return (
              <div className={`card status-${overallBand}`} key={group.key}>
                <div className="head">
                  <div>
                    <div className="label">{group.label}</div>
                    <div className="url">{group.url}</div>
                  </div>
                </div>

                {group.entries.map((row, i) => {
                  const breaches = computeBreaches(row);
                  const histKey = `${row.label}|${row.strategy}`;
                  const histRecords = history[histKey] || [];
                  const histMeans = histRecords.map((r) => meanScore(r.scores));

                  return (
                    <div
                      key={row.strategy}
                      style={i > 0 ? { borderTop: "1px solid var(--line-soft)", paddingTop: 10, marginTop: 2 } : undefined}
                    >
                      <span className="strategy-tag">{row.strategy}</span>
                      <div className="swatches">
                        {CATS.map(([k, lbl]) => (
                          <ScoreSwatch key={k} label={lbl} score={row.scores[k]} />
                        ))}
                      </div>
                      <MetricsRow metrics={row.metrics} />
                      {breaches.length > 0 && (
                        <div className="breach-note">Below threshold: {breaches.join(", ")}</div>
                      )}
                      {/* {histMeans.length >= 2 && (
                        <div className="sparkline">
                          <Sparkline points={histMeans} />
                          <span>last {histMeans.length} runs</span>
                        </div>
                      )} */}
                    </div>
                  );
                })}
              </div>
            );
          })}

          {results.errors.map((err, i) => (
            <div className="card" key={`err-${i}`}>
              <div className="head">
                <div>
                  <div className="label">{err.label}</div>
                  <div className="url">{err.url}</div>
                </div>
              </div>
              <div className="breach-note">
                Fetch error ({err.strategy}): {err.error}
              </div>
            </div>
          ))}
        </div>
      )}

      {!isFiltering && hiddenCount > 0 && (
        <div style={{ textAlign: "center", marginTop: 16 }}>
          <button className="ghost" onClick={() => setShowAll(true)}>
            Show all ({groups.length})
          </button>
        </div>
      )}
      {!isFiltering && showAll && groups.length > DEFAULT_VISIBLE && (
        <div style={{ textAlign: "center", marginTop: 16 }}>
          <button className="ghost" onClick={() => setShowAll(false)}>
            Show first {DEFAULT_VISIBLE} only
          </button>
        </div>
      )}
    </section>
  );
}