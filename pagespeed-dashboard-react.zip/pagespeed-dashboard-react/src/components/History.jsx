// import { useState, useEffect, useMemo, useCallback } from "react";
// import { band } from "./ScoreSwatch.jsx";
// import { fetchHistory } from "../lib/backendApi.js";
// import { SHOW_HISTORY_TAB } from "../config.js";

// const CATS = [
//   ["performance", "Perf"],
//   ["accessibility", "A11y"],
//   ["best_practices", "Best Pr."],
//   ["seo", "SEO"],
// ];

// // "2026-09-18" style key from a record's timestamp, in local time -
// // matches what an <input type="date"> value looks like.
// function dateKey(ts) {
//   const d = new Date(ts);
//   const y = d.getFullYear();
//   const m = String(d.getMonth() + 1).padStart(2, "0");
//   const day = String(d.getDate()).padStart(2, "0");
//   return `${y}-${m}-${day}`;
// }

// export default function History({ tab, setTab }) {
//   const [serverHistory, setServerHistory] = useState({});
//   const [loading, setLoading] = useState(true);
//   const [statusText, setStatusText] = useState("Loading…");
//   const [selectedDate, setSelectedDate] = useState("");

//   const loadHistory = useCallback(async () => {
//     setLoading(true);
//     setStatusText("Fetching history…");
//     try {
//       const data = await fetchHistory();
//       setServerHistory(data);
//       setStatusText(`Last updated: ${new Date().toLocaleString()}`);
//     } catch (err) {
//       setStatusText(`Fetch failed: ${err.message || err}. Check USE_DUMMY_DATA / HISTORY_URL in src/config.js.`);
//     }
//     setLoading(false);
//   }, []);

//   useEffect(() => {
//     loadHistory();
//   }, [loadHistory]);

//   const allKeys = Object.keys(serverHistory).filter((k) => serverHistory[k] && serverHistory[k].length).sort();

//   const filteredGroups = useMemo(() => {
//     return allKeys
//       .map((key) => {
//         const records = selectedDate
//           ? serverHistory[key].filter((r) => dateKey(r.ts) === selectedDate)
//           : serverHistory[key];
//         return { key, records: [...records].reverse() };
//       })
//       .filter((g) => g.records.length > 0);
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [serverHistory, selectedDate]);

//   return (
//     <section className="panel active">
//       <div className="toolbar">
//         {/* {SHOW_HISTORY_TAB && (
//           <nav className="tabs-inline">
//             <button className={tab === "dashboard" ? "active" : ""} onClick={() => setTab("dashboard")}>
//               Dashboard
//             </button>
//             <button className={tab === "history" ? "active" : ""} onClick={() => setTab("history")}>
//               History
//             </button>
//           </nav>
//         )} */}
//         <button className="ghost" onClick={loadHistory} disabled={loading}>
//           Refresh
//         </button>
//                   <div className="date-picker-wrap">
//           <svg className="cal-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true">
//             <rect x="3" y="5" width="18" height="16" rx="4" stroke="currentColor" strokeWidth="1.8" />
//             <path d="M3 9.5h18M8 3v4M16 3v4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
//             <circle cx="8" cy="14" r="1.2" fill="currentColor" />
//             <circle cx="12" cy="14" r="1.2" fill="currentColor" />
//             <circle cx="16" cy="14" r="1.2" fill="currentColor" />
//           </svg>
//           <input
//             type="date"
//             value={selectedDate}
//            onChange={(e) => setSelectedDate(e.target.value)}
//             onClick={(e) => {
//               try {
//                 e.target.showPicker();
//               } catch {
//                 // showPicker() not supported in this browser (e.g. older Safari) -
//                 // the input's own default click-to-open behavior still works.
//               }
//             }}
//           />
//         </div>
//         {selectedDate && (
//           <button className="ghost" onClick={() => setSelectedDate("")}>
//             Clear date
//           </button>
//         )}
//       </div>

//       {/* <div className="field-group" style={{ marginBottom: 18 }}>
//         <h3>Past runs</h3>
//         <p className="hint">
//           {statusText}
//           {selectedDate ? " · Showing only runs from the picked date." : ""}
//         </p>
//       </div> */}

//       {!allKeys.length ? (
//         <div className="empty">{loading ? "Loading…" : "No history data yet."}</div>
//       ) : !filteredGroups.length ? (
//         <div className="empty">No runs recorded on {selectedDate}.</div>
//       ) : (
//         filteredGroups.map(({ key, records }) => {
//           const [label, strategy] = key.split("|");

//           return (
//             <div className="field-group history-card" key={key}>
//               <div className="history-card-title">
//                 <div className="label">{label}</div>
//                 <span className="strategy-tag">{strategy}</span>
//               </div>
//               <table className="history-table">
//                 <thead>
//                   <tr>
//                     <th>When</th>
//                     {CATS.map(([k, l]) => (
//                       <th key={k}>{l}</th>
//                     ))}
//                   </tr>
//                 </thead>
//                 <tbody>
//                   {records.map((r, i) => (
//                     <tr key={i}>
//                       <td className="when">{new Date(r.ts).toLocaleString()}</td>
//                       {CATS.map(([k]) => {
//                         const s = r.scores[k];
//                         return (
//                           <td key={k} className={`score-${band(s)}`}>
//                             {s === null || s === undefined ? "—" : s}
//                           </td>
//                         );
//                       })}
//                     </tr>
//                   ))}
//                 </tbody>
//               </table>
//             </div>
//           );
//         })
//       )}
//     </section>
//   );
// }



import { useState, useEffect, useMemo, useCallback } from "react";
import { band } from "./ScoreSwatch.jsx";
import { fetchHistory } from "../lib/backendApi.js";
import { SHOW_HISTORY_TAB } from "../config.js";

const CATS = [
  ["performance", "Perf"],
  ["accessibility", "A11y"],
  ["best_practices", "Best Pr."],
  ["seo", "SEO"],
];
const DEFAULT_VISIBLE = 5; // how many URL cards show by default, before "Show all"

// "2026-09-18" style key from a record's timestamp, in local time -
// matches what an <input type="date"> value looks like.
function dateKey(ts) {
  const d = new Date(ts);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export default function History({ tab, setTab }) {
  const [serverHistory, setServerHistory] = useState({});
  const [loading, setLoading] = useState(true);
  const [statusText, setStatusText] = useState("Loading…");
  const [selectedDate, setSelectedDate] = useState("");
  const [query, setQuery] = useState("");
  const [showAll, setShowAll] = useState(false);

  const loadHistory = useCallback(async () => {
    setLoading(true);
    setStatusText("Fetching history…");
    try {
      const data = await fetchHistory();
      setServerHistory(data);
      setStatusText(`Last updated: ${new Date().toLocaleString()}`);
    } catch (err) {
      setStatusText(`Fetch failed: ${err.message || err}. Check USE_DUMMY_DATA / HISTORY_URL in src/config.js.`);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    loadHistory();
  }, [loadHistory]);

  const allKeys = Object.keys(serverHistory).filter((k) => serverHistory[k] && serverHistory[k].length).sort();

  // Unique labels for the search box's autocomplete dropdown.
  const suggestionLabels = useMemo(() => {
    return [...new Set(allKeys.map((k) => k.split("|")[0]))];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [serverHistory]);

  // Text filter (label match) + date filter, applied together.
  const filteredGroups = useMemo(() => {
    const q = query.trim().toLowerCase();
    return allKeys
      .filter((key) => !q || key.split("|")[0].toLowerCase().includes(q))
      .map((key) => {
        const records = selectedDate
          ? serverHistory[key].filter((r) => dateKey(r.ts) === selectedDate)
          : serverHistory[key];
        return { key, records: [...records].reverse() };
      })
      .filter((g) => g.records.length > 0);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [serverHistory, selectedDate, query]);

  const isFiltering = query.trim().length > 0;
  const visibleGroups = isFiltering || showAll ? filteredGroups : filteredGroups.slice(0, DEFAULT_VISIBLE);
  const hiddenCount = filteredGroups.length - visibleGroups.length;

  return (
    <section className="panel active">
      <div className="toolbar">
        {/* {SHOW_HISTORY_TAB && (
          <nav className="tabs-inline">
            <button className={tab === "dashboard" ? "active" : ""} onClick={() => setTab("dashboard")}>
              Dashboard
            </button>
            <button className={tab === "history" ? "active" : ""} onClick={() => setTab("history")}>
              History
            </button>
          </nav>
        )} */}
        <button className="ghost hiddeen-small" onClick={loadHistory} disabled={loading}>
          Refresh
        </button>

        <div style={{ position: "relative", flex: "0 1 220px" }} className="search-box-wrapper">
          <input
            type="text"
            list="history-url-suggestions"
            placeholder="Filter by URL…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={(e) => e.target.select()}
            style={{ width: "100%", paddingRight: query ? 28 : undefined }}
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery("")}
              title="Clear filter"
              style={{
                position: "absolute", right: 6, top: "50%", transform: "translateY(-50%)",
                border: "none", background: "transparent", cursor: "pointer",
                color: "var(--ink-faint)", fontSize: 14, lineHeight: 1, padding: 4,
              }}
            >
              ✕
            </button>
          )}
        </div>
        <datalist id="history-url-suggestions">
          {suggestionLabels.map((label) => (
            <option key={label} value={label} />
          ))}
        </datalist>
          <button className="ghost hidden-desktop" onClick={loadHistory} disabled={loading}>
          Refresh
        </button>
        <div className="date-picker-wrap" style={{ marginLeft: "auto" }}>
          <svg className="cal-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <rect x="3" y="5" width="18" height="16" rx="4" stroke="currentColor" strokeWidth="1.8" />
            <path d="M3 9.5h18M8 3v4M16 3v4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
            <circle cx="8" cy="14" r="1.2" fill="currentColor" />
            <circle cx="12" cy="14" r="1.2" fill="currentColor" />
            <circle cx="16" cy="14" r="1.2" fill="currentColor" />
          </svg>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            onClick={(e) => {
              try {
                e.target.showPicker();
              } catch {
                // showPicker() not supported in this browser (e.g. older Safari) -
                // the input's own default click-to-open behavior still works.
              }
            }}
          />
        </div>
        {selectedDate && (
          <button className="ghost" onClick={() => setSelectedDate("")}>
            Clear date
          </button>
        )}
      </div>

      {/* <div className="field-group" style={{ marginBottom: 18 }}>
        <h3>Past runs</h3>
        <p className="hint">
          {statusText}
          {selectedDate ? " · Showing only runs from the picked date." : ""}
        </p>
      </div> */}

      {!allKeys.length ? (
        <div className="empty">{loading ? "Loading…" : "No history data yet."}</div>
      ) : !filteredGroups.length ? (
        <div className="empty">
          {selectedDate ? `No runs recorded on ${selectedDate}.` : `No URLs match "${query}".`}
        </div>
      ) : (
        <>
          {visibleGroups.map(({ key, records }) => {
            const [label, strategy] = key.split("|");

            return (
              <div className="field-group history-card" key={key}>
                <div className="history-card-title">
                  <div className="label">{label}</div>
                  <span className="strategy-tag">{strategy}</span>
                </div>
                <table className="history-table">
                  <thead>
                    <tr>
                      <th>When</th>
                      {CATS.map(([k, l]) => (
                        <th key={k}>{l}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {records.map((r, i) => (
                      <tr key={i}>
                        <td className="when">{new Date(r.ts).toLocaleString()}</td>
                        {CATS.map(([k]) => {
                          const s = r.scores[k];
                          return (
                            <td key={k} className={`score-${band(s)}`}>
                              {s === null || s === undefined ? "—" : s}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            );
          })}

          {!isFiltering && hiddenCount > 0 && (
            <div style={{ textAlign: "center", marginTop: 16 }}>
              <button className="ghost" onClick={() => setShowAll(true)}>
                Show all ({filteredGroups.length})
              </button>
            </div>
          )}
          {!isFiltering && showAll && filteredGroups.length > DEFAULT_VISIBLE && (
            <div style={{ textAlign: "center", marginTop: 16 }}>
              <button className="ghost" onClick={() => setShowAll(false)}>
                Show first {DEFAULT_VISIBLE} only
              </button>
            </div>
          )}
        </>
      )}
    </section>
  );
}