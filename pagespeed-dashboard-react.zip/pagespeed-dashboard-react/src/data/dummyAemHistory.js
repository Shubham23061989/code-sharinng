export const DUMMY_AEM_HISTORY = [
  {
    "runId": "run-1",
    "startedAt": "2026-09-15T09:00:00",
    "completedAt": "2026-09-15T09:02:00",
    "results": [
      { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "DESKTOP", "performanceScore": 67.2, "accessibilityScore": 86.6, "bestPracticesScore": 89.2, "seoScore": 91.4, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "MOBILE", "performanceScore": 64.4, "accessibilityScore": 85.2, "bestPracticesScore": 88.3, "seoScore": 90.9, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "DESKTOP", "performanceScore": 72.4, "accessibilityScore": 89.2, "bestPracticesScore": 90.7, "seoScore": 92.5, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "MOBILE", "performanceScore": 63.2, "accessibilityScore": 84.6, "bestPracticesScore": 87.9, "seoScore": 90.6, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "DESKTOP", "performanceScore": 70.6, "accessibilityScore": 88.3, "bestPracticesScore": 90.2, "seoScore": 92.1, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "MOBILE", "performanceScore": 67.9, "accessibilityScore": 86.9, "bestPracticesScore": 89.4, "seoScore": 91.6, "status": "SUCCESS", "errorMessage": "" }
    ]
  },
  {
    "runId": "run-2",
    "startedAt": "2026-09-15T18:00:00",
    "completedAt": "2026-09-15T18:02:00",
    "results": [
      { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "DESKTOP", "performanceScore": 62.9, "accessibilityScore": 84.5, "bestPracticesScore": 87.9, "seoScore": 90.6, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "MOBILE", "performanceScore": 70.1, "accessibilityScore": 88.1, "bestPracticesScore": 90.0, "seoScore": 92.0, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "DESKTOP", "performanceScore": 62.6, "accessibilityScore": 84.3, "bestPracticesScore": 87.8, "seoScore": 90.5, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "MOBILE", "performanceScore": 68.9, "accessibilityScore": 87.5, "bestPracticesScore": 89.7, "seoScore": 91.8, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "DESKTOP", "performanceScore": 63.1, "accessibilityScore": 84.6, "bestPracticesScore": 87.9, "seoScore": 90.6, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "MOBILE", "performanceScore": 63.5, "accessibilityScore": 84.7, "bestPracticesScore": 88.0, "seoScore": 90.7, "status": "SUCCESS", "errorMessage": "" }
    ]
  },
  {
    "runId": "run-3",
    "startedAt": "2026-09-16T03:00:00",
    "completedAt": "2026-09-16T03:02:00",
    "results": [
      { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "DESKTOP", "performanceScore": 68.8, "accessibilityScore": 87.4, "bestPracticesScore": 89.6, "seoScore": 91.8, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "MOBILE", "performanceScore": 75.2, "accessibilityScore": 90.6, "bestPracticesScore": 91.6, "seoScore": 93.0, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "DESKTOP", "performanceScore": 64.0, "accessibilityScore": 85.0, "bestPracticesScore": 88.2, "seoScore": 90.8, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "MOBILE", "performanceScore": 65.6, "accessibilityScore": 85.8, "bestPracticesScore": 88.7, "seoScore": 91.1, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "DESKTOP", "performanceScore": 72.0, "accessibilityScore": 89.0, "bestPracticesScore": 90.6, "seoScore": 92.4, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "MOBILE", "performanceScore": 77.2, "accessibilityScore": 91.6, "bestPracticesScore": 92.1, "seoScore": 93.4, "status": "SUCCESS", "errorMessage": "" }
    ]
  },
  {
    "runId": "run-4",
    "startedAt": "2026-09-16T12:00:00",
    "completedAt": "2026-09-16T12:02:00",
    "results": [
      { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "DESKTOP", "performanceScore": 71.2, "accessibilityScore": 88.6, "bestPracticesScore": 90.4, "seoScore": 92.2, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "MOBILE", "performanceScore": 68.3, "accessibilityScore": 87.2, "bestPracticesScore": 89.5, "seoScore": 91.7, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "DESKTOP", "performanceScore": 77.6, "accessibilityScore": 91.8, "bestPracticesScore": 92.3, "seoScore": 93.5, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "MOBILE", "performanceScore": 62.7, "accessibilityScore": 84.4, "bestPracticesScore": 87.8, "seoScore": 90.5, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "DESKTOP", "performanceScore": 75.7, "accessibilityScore": 90.9, "bestPracticesScore": 91.7, "seoScore": 93.1, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "MOBILE", "performanceScore": 66.6, "accessibilityScore": 86.3, "bestPracticesScore": 89.0, "seoScore": 91.3, "status": "SUCCESS", "errorMessage": "" }
    ]
  },
  {
    "runId": "run-5",
    "startedAt": "2026-09-16T21:00:00",
    "completedAt": "2026-09-16T21:02:00",
    "results": [
      { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "DESKTOP", "performanceScore": 64.3, "accessibilityScore": 85.2, "bestPracticesScore": 88.3, "seoScore": 90.9, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "MOBILE", "performanceScore": 63.9, "accessibilityScore": 84.9, "bestPracticesScore": 88.2, "seoScore": 90.8, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "DESKTOP", "performanceScore": 66.9, "accessibilityScore": 86.5, "bestPracticesScore": 89.1, "seoScore": 91.4, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "MOBILE", "performanceScore": 75.1, "accessibilityScore": 90.5, "bestPracticesScore": 91.5, "seoScore": 93.0, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "DESKTOP", "performanceScore": 64.9, "accessibilityScore": 85.4, "bestPracticesScore": 88.5, "seoScore": 91.0, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "MOBILE", "performanceScore": 71.3, "accessibilityScore": 88.7, "bestPracticesScore": 90.4, "seoScore": 92.3, "status": "SUCCESS", "errorMessage": "" }
    ]
  },
  {
    "runId": "run-6",
    "startedAt": "2026-09-17T06:00:00",
    "completedAt": "2026-09-17T06:02:00",
    "results": [
      { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "DESKTOP", "performanceScore": 72.2, "accessibilityScore": 89.1, "bestPracticesScore": 90.7, "seoScore": 92.4, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://www.asianpaints.com/shubham-test1", "strategy": "MOBILE", "performanceScore": 68.0, "accessibilityScore": 87.0, "bestPracticesScore": 89.4, "seoScore": 91.6, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "DESKTOP", "performanceScore": 70.8, "accessibilityScore": 88.4, "bestPracticesScore": 90.2, "seoScore": 92.2, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://www.asianpaints.com/shubham-test2", "strategy": "MOBILE", "performanceScore": 63.0, "accessibilityScore": 84.5, "bestPracticesScore": 87.9, "seoScore": 90.6, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "DESKTOP", "performanceScore": 63.0, "accessibilityScore": 84.5, "bestPracticesScore": 87.9, "seoScore": 90.6, "status": "SUCCESS", "errorMessage": "" },
      { "url": "https://beta.asianpaints.com/services/waterproofing-solutions.html", "strategy": "MOBILE", "performanceScore": 65.3, "accessibilityScore": 85.6, "bestPracticesScore": 88.6, "seoScore": 91.1, "status": "SUCCESS", "errorMessage": "" }
    ]
  }
];