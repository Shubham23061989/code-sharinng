(function() {
	var __vite_style__ = document.createElement("style");
	__vite_style__.textContent = "*, ::before, ::after {\n  --tw-border-spacing-x: 0;\n  --tw-border-spacing-y: 0;\n  --tw-translate-x: 0;\n  --tw-translate-y: 0;\n  --tw-rotate: 0;\n  --tw-skew-x: 0;\n  --tw-skew-y: 0;\n  --tw-scale-x: 1;\n  --tw-scale-y: 1;\n  --tw-pan-x:  ;\n  --tw-pan-y:  ;\n  --tw-pinch-zoom:  ;\n  --tw-scroll-snap-strictness: proximity;\n  --tw-gradient-from-position:  ;\n  --tw-gradient-via-position:  ;\n  --tw-gradient-to-position:  ;\n  --tw-ordinal:  ;\n  --tw-slashed-zero:  ;\n  --tw-numeric-figure:  ;\n  --tw-numeric-spacing:  ;\n  --tw-numeric-fraction:  ;\n  --tw-ring-inset:  ;\n  --tw-ring-offset-width: 0px;\n  --tw-ring-offset-color: #fff;\n  --tw-ring-color: rgb(59 130 246 / 0.5);\n  --tw-ring-offset-shadow: 0 0 #0000;\n  --tw-ring-shadow: 0 0 #0000;\n  --tw-shadow: 0 0 #0000;\n  --tw-shadow-colored: 0 0 #0000;\n  --tw-blur:  ;\n  --tw-brightness:  ;\n  --tw-contrast:  ;\n  --tw-grayscale:  ;\n  --tw-hue-rotate:  ;\n  --tw-invert:  ;\n  --tw-saturate:  ;\n  --tw-sepia:  ;\n  --tw-drop-shadow:  ;\n  --tw-backdrop-blur:  ;\n  --tw-backdrop-brightness:  ;\n  --tw-backdrop-contrast:  ;\n  --tw-backdrop-grayscale:  ;\n  --tw-backdrop-hue-rotate:  ;\n  --tw-backdrop-invert:  ;\n  --tw-backdrop-opacity:  ;\n  --tw-backdrop-saturate:  ;\n  --tw-backdrop-sepia:  ;\n  --tw-contain-size:  ;\n  --tw-contain-layout:  ;\n  --tw-contain-paint:  ;\n  --tw-contain-style:  ;\n}\n\n::backdrop {\n  --tw-border-spacing-x: 0;\n  --tw-border-spacing-y: 0;\n  --tw-translate-x: 0;\n  --tw-translate-y: 0;\n  --tw-rotate: 0;\n  --tw-skew-x: 0;\n  --tw-skew-y: 0;\n  --tw-scale-x: 1;\n  --tw-scale-y: 1;\n  --tw-pan-x:  ;\n  --tw-pan-y:  ;\n  --tw-pinch-zoom:  ;\n  --tw-scroll-snap-strictness: proximity;\n  --tw-gradient-from-position:  ;\n  --tw-gradient-via-position:  ;\n  --tw-gradient-to-position:  ;\n  --tw-ordinal:  ;\n  --tw-slashed-zero:  ;\n  --tw-numeric-figure:  ;\n  --tw-numeric-spacing:  ;\n  --tw-numeric-fraction:  ;\n  --tw-ring-inset:  ;\n  --tw-ring-offset-width: 0px;\n  --tw-ring-offset-color: #fff;\n  --tw-ring-color: rgb(59 130 246 / 0.5);\n  --tw-ring-offset-shadow: 0 0 #0000;\n  --tw-ring-shadow: 0 0 #0000;\n  --tw-shadow: 0 0 #0000;\n  --tw-shadow-colored: 0 0 #0000;\n  --tw-blur:  ;\n  --tw-brightness:  ;\n  --tw-contrast:  ;\n  --tw-grayscale:  ;\n  --tw-hue-rotate:  ;\n  --tw-invert:  ;\n  --tw-saturate:  ;\n  --tw-sepia:  ;\n  --tw-drop-shadow:  ;\n  --tw-backdrop-blur:  ;\n  --tw-backdrop-brightness:  ;\n  --tw-backdrop-contrast:  ;\n  --tw-backdrop-grayscale:  ;\n  --tw-backdrop-hue-rotate:  ;\n  --tw-backdrop-invert:  ;\n  --tw-backdrop-opacity:  ;\n  --tw-backdrop-saturate:  ;\n  --tw-backdrop-sepia:  ;\n  --tw-contain-size:  ;\n  --tw-contain-layout:  ;\n  --tw-contain-paint:  ;\n  --tw-contain-style:  ;\n}/*\n! tailwindcss v3.4.19 | MIT License | https://tailwindcss.com\n*//*\n1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)\n2. Allow adding a border to an element by just adding a border-width. (https://github.com/tailwindcss/tailwindcss/pull/116)\n*/\n\n*,\n::before,\n::after {\n  box-sizing: border-box; /* 1 */\n  border-width: 0; /* 2 */\n  border-style: solid; /* 2 */\n  border-color: #e5e7eb; /* 2 */\n}\n\n::before,\n::after {\n  --tw-content: '';\n}\n\n/*\n1. Use a consistent sensible line-height in all browsers.\n2. Prevent adjustments of font size after orientation changes in iOS.\n3. Use a more readable tab size.\n4. Use the user's configured `sans` font-family by default.\n5. Use the user's configured `sans` font-feature-settings by default.\n6. Use the user's configured `sans` font-variation-settings by default.\n7. Disable tap highlights on iOS\n*/\n\nhtml,\n:host {\n  line-height: 1.5; /* 1 */\n  -webkit-text-size-adjust: 100%; /* 2 */\n  -moz-tab-size: 4; /* 3 */\n  -o-tab-size: 4;\n     tab-size: 4; /* 3 */\n  font-family: Inter, system-ui, sans-serif; /* 4 */\n  font-feature-settings: normal; /* 5 */\n  font-variation-settings: normal; /* 6 */\n  -webkit-tap-highlight-color: transparent; /* 7 */\n}\n\n/*\n1. Remove the margin in all browsers.\n2. Inherit line-height from `html` so users can set them as a class directly on the `html` element.\n*/\n\nbody {\n  margin: 0; /* 1 */\n  line-height: inherit; /* 2 */\n}\n\n/*\n1. Add the correct height in Firefox.\n2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)\n3. Ensure horizontal rules are visible by default.\n*/\n\nhr {\n  height: 0; /* 1 */\n  color: inherit; /* 2 */\n  border-top-width: 1px; /* 3 */\n}\n\n/*\nAdd the correct text decoration in Chrome, Edge, and Safari.\n*/\n\nabbr:where([title]) {\n  -webkit-text-decoration: underline dotted;\n          text-decoration: underline dotted;\n}\n\n/*\nRemove the default font size and weight for headings.\n*/\n\nh1,\nh2,\nh3,\nh4,\nh5,\nh6 {\n  font-size: inherit;\n  font-weight: inherit;\n}\n\n/*\nReset links to optimize for opt-in styling instead of opt-out.\n*/\n\na {\n  color: inherit;\n  text-decoration: inherit;\n}\n\n/*\nAdd the correct font weight in Edge and Safari.\n*/\n\nb,\nstrong {\n  font-weight: bolder;\n}\n\n/*\n1. Use the user's configured `mono` font-family by default.\n2. Use the user's configured `mono` font-feature-settings by default.\n3. Use the user's configured `mono` font-variation-settings by default.\n4. Correct the odd `em` font sizing in all browsers.\n*/\n\ncode,\nkbd,\nsamp,\npre {\n  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace; /* 1 */\n  font-feature-settings: normal; /* 2 */\n  font-variation-settings: normal; /* 3 */\n  font-size: 1em; /* 4 */\n}\n\n/*\nAdd the correct font size in all browsers.\n*/\n\nsmall {\n  font-size: 80%;\n}\n\n/*\nPrevent `sub` and `sup` elements from affecting the line height in all browsers.\n*/\n\nsub,\nsup {\n  font-size: 75%;\n  line-height: 0;\n  position: relative;\n  vertical-align: baseline;\n}\n\nsub {\n  bottom: -0.25em;\n}\n\nsup {\n  top: -0.5em;\n}\n\n/*\n1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)\n2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)\n3. Remove gaps between table borders by default.\n*/\n\ntable {\n  text-indent: 0; /* 1 */\n  border-color: inherit; /* 2 */\n  border-collapse: collapse; /* 3 */\n}\n\n/*\n1. Change the font styles in all browsers.\n2. Remove the margin in Firefox and Safari.\n3. Remove default padding in all browsers.\n*/\n\nbutton,\ninput,\noptgroup,\nselect,\ntextarea {\n  font-family: inherit; /* 1 */\n  font-feature-settings: inherit; /* 1 */\n  font-variation-settings: inherit; /* 1 */\n  font-size: 100%; /* 1 */\n  font-weight: inherit; /* 1 */\n  line-height: inherit; /* 1 */\n  letter-spacing: inherit; /* 1 */\n  color: inherit; /* 1 */\n  margin: 0; /* 2 */\n  padding: 0; /* 3 */\n}\n\n/*\nRemove the inheritance of text transform in Edge and Firefox.\n*/\n\nbutton,\nselect {\n  text-transform: none;\n}\n\n/*\n1. Correct the inability to style clickable types in iOS and Safari.\n2. Remove default button styles.\n*/\n\nbutton,\ninput:where([type='button']),\ninput:where([type='reset']),\ninput:where([type='submit']) {\n  -webkit-appearance: button; /* 1 */\n  background-color: transparent; /* 2 */\n  background-image: none; /* 2 */\n}\n\n/*\nUse the modern Firefox focus style for all focusable elements.\n*/\n\n:-moz-focusring {\n  outline: auto;\n}\n\n/*\nRemove the additional `:invalid` styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)\n*/\n\n:-moz-ui-invalid {\n  box-shadow: none;\n}\n\n/*\nAdd the correct vertical alignment in Chrome and Firefox.\n*/\n\nprogress {\n  vertical-align: baseline;\n}\n\n/*\nCorrect the cursor style of increment and decrement buttons in Safari.\n*/\n\n::-webkit-inner-spin-button,\n::-webkit-outer-spin-button {\n  height: auto;\n}\n\n/*\n1. Correct the odd appearance in Chrome and Safari.\n2. Correct the outline style in Safari.\n*/\n\n[type='search'] {\n  -webkit-appearance: textfield; /* 1 */\n  outline-offset: -2px; /* 2 */\n}\n\n/*\nRemove the inner padding in Chrome and Safari on macOS.\n*/\n\n::-webkit-search-decoration {\n  -webkit-appearance: none;\n}\n\n/*\n1. Correct the inability to style clickable types in iOS and Safari.\n2. Change font properties to `inherit` in Safari.\n*/\n\n::-webkit-file-upload-button {\n  -webkit-appearance: button; /* 1 */\n  font: inherit; /* 2 */\n}\n\n/*\nAdd the correct display in Chrome and Safari.\n*/\n\nsummary {\n  display: list-item;\n}\n\n/*\nRemoves the default spacing and border for appropriate elements.\n*/\n\nblockquote,\ndl,\ndd,\nh1,\nh2,\nh3,\nh4,\nh5,\nh6,\nhr,\nfigure,\np,\npre {\n  margin: 0;\n}\n\nfieldset {\n  margin: 0;\n  padding: 0;\n}\n\nlegend {\n  padding: 0;\n}\n\nol,\nul,\nmenu {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n}\n\n/*\nReset default styling for dialogs.\n*/\ndialog {\n  padding: 0;\n}\n\n/*\nPrevent resizing textareas horizontally by default.\n*/\n\ntextarea {\n  resize: vertical;\n}\n\n/*\n1. Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)\n2. Set the default placeholder color to the user's configured gray 400 color.\n*/\n\ninput::-moz-placeholder, textarea::-moz-placeholder {\n  opacity: 1; /* 1 */\n  color: #9ca3af; /* 2 */\n}\n\ninput::placeholder,\ntextarea::placeholder {\n  opacity: 1; /* 1 */\n  color: #9ca3af; /* 2 */\n}\n\n/*\nSet the default cursor for buttons.\n*/\n\nbutton,\n[role=\"button\"] {\n  cursor: pointer;\n}\n\n/*\nMake sure disabled buttons don't get the pointer cursor.\n*/\n:disabled {\n  cursor: default;\n}\n\n/*\n1. Make replaced elements `display: block` by default. (https://github.com/mozdevs/cssremedy/issues/14)\n2. Add `vertical-align: middle` to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)\n   This can trigger a poorly considered lint error in some tools but is included by design.\n*/\n\nimg,\nsvg,\nvideo,\ncanvas,\naudio,\niframe,\nembed,\nobject {\n  display: block; /* 1 */\n  vertical-align: middle; /* 2 */\n}\n\n/*\nConstrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)\n*/\n\nimg,\nvideo {\n  max-width: 100%;\n  height: auto;\n}\n\n/* Make elements with the HTML hidden attribute stay hidden by default */\n[hidden]:where(:not([hidden=\"until-found\"])) {\n  display: none;\n}\r\n.container {\n  width: 100%;\n}\r\n@media (min-width: 640px) {\n\n  .container {\n    max-width: 640px;\n  }\n}\r\n@media (min-width: 768px) {\n\n  .container {\n    max-width: 768px;\n  }\n}\r\n@media (min-width: 1024px) {\n\n  .container {\n    max-width: 1024px;\n  }\n}\r\n@media (min-width: 1280px) {\n\n  .container {\n    max-width: 1280px;\n  }\n}\r\n@media (min-width: 1536px) {\n\n  .container {\n    max-width: 1536px;\n  }\n}\r\n.static {\n  position: static;\n}\r\n.fixed {\n  position: fixed;\n}\r\n.absolute {\n  position: absolute;\n}\r\n.relative {\n  position: relative;\n}\r\n.sticky {\n  position: sticky;\n}\r\n.inset-0 {\n  inset: 0px;\n}\r\n.-right-1 {\n  right: -0.25rem;\n}\r\n.-top-1 {\n  top: -0.25rem;\n}\r\n.bottom-0 {\n  bottom: 0px;\n}\r\n.bottom-4 {\n  bottom: 1rem;\n}\r\n.bottom-6 {\n  bottom: 1.5rem;\n}\r\n.left-0 {\n  left: 0px;\n}\r\n.left-1\\/2 {\n  left: 50%;\n}\r\n.left-\\[10\\%\\] {\n  left: 10%;\n}\r\n.left-\\[25\\%\\] {\n  left: 25%;\n}\r\n.left-\\[40\\%\\] {\n  left: 40%;\n}\r\n.right-0 {\n  right: 0px;\n}\r\n.right-4 {\n  right: 1rem;\n}\r\n.right-\\[20\\%\\] {\n  right: 20%;\n}\r\n.right-\\[35\\%\\] {\n  right: 35%;\n}\r\n.right-\\[5\\%\\] {\n  right: 5%;\n}\r\n.top-0 {\n  top: 0px;\n}\r\n.top-10 {\n  top: 2.5rem;\n}\r\n.top-4 {\n  top: 1rem;\n}\r\n.top-\\[12\\%\\] {\n  top: 12%;\n}\r\n.top-\\[15\\%\\] {\n  top: 15%;\n}\r\n.top-\\[16\\%\\] {\n  top: 16%;\n}\r\n.top-\\[18\\%\\] {\n  top: 18%;\n}\r\n.top-\\[20\\%\\] {\n  top: 20%;\n}\r\n.top-full {\n  top: 100%;\n}\r\n.z-10 {\n  z-index: 10;\n}\r\n.z-20 {\n  z-index: 20;\n}\r\n.z-30 {\n  z-index: 30;\n}\r\n.z-40 {\n  z-index: 40;\n}\r\n.z-50 {\n  z-index: 50;\n}\r\n.mx-auto {\n  margin-left: auto;\n  margin-right: auto;\n}\r\n.mb-2 {\n  margin-bottom: 0.5rem;\n}\r\n.mb-4 {\n  margin-bottom: 1rem;\n}\r\n.mb-6 {\n  margin-bottom: 1.5rem;\n}\r\n.ml-0\\.5 {\n  margin-left: 0.125rem;\n}\r\n.ml-2 {\n  margin-left: 0.5rem;\n}\r\n.ml-3 {\n  margin-left: 0.75rem;\n}\r\n.mt-0\\.5 {\n  margin-top: 0.125rem;\n}\r\n.mt-1 {\n  margin-top: 0.25rem;\n}\r\n.mt-1\\.5 {\n  margin-top: 0.375rem;\n}\r\n.mt-10 {\n  margin-top: 2.5rem;\n}\r\n.mt-12 {\n  margin-top: 3rem;\n}\r\n.mt-2 {\n  margin-top: 0.5rem;\n}\r\n.mt-20 {\n  margin-top: 5rem;\n}\r\n.mt-3 {\n  margin-top: 0.75rem;\n}\r\n.mt-4 {\n  margin-top: 1rem;\n}\r\n.mt-6 {\n  margin-top: 1.5rem;\n}\r\n.mt-8 {\n  margin-top: 2rem;\n}\r\n.block {\n  display: block;\n}\r\n.inline-block {\n  display: inline-block;\n}\r\n.inline {\n  display: inline;\n}\r\n.flex {\n  display: flex;\n}\r\n.inline-flex {\n  display: inline-flex;\n}\r\n.grid {\n  display: grid;\n}\r\n.hidden {\n  display: none;\n}\r\n.h-10 {\n  height: 2.5rem;\n}\r\n.h-12 {\n  height: 3rem;\n}\r\n.h-14 {\n  height: 3.5rem;\n}\r\n.h-16 {\n  height: 4rem;\n}\r\n.h-2 {\n  height: 0.5rem;\n}\r\n.h-24 {\n  height: 6rem;\n}\r\n.h-3 {\n  height: 0.75rem;\n}\r\n.h-32 {\n  height: 8rem;\n}\r\n.h-36 {\n  height: 9rem;\n}\r\n.h-4 {\n  height: 1rem;\n}\r\n.h-6 {\n  height: 1.5rem;\n}\r\n.h-7 {\n  height: 1.75rem;\n}\r\n.h-8 {\n  height: 2rem;\n}\r\n.h-full {\n  height: 100%;\n}\r\n.h-screen {\n  height: 100vh;\n}\r\n.min-h-0 {\n  min-height: 0px;\n}\r\n.min-h-\\[120px\\] {\n  min-height: 120px;\n}\r\n.min-h-\\[25\\%\\] {\n  min-height: 25%;\n}\r\n.min-h-\\[400px\\] {\n  min-height: 400px;\n}\r\n.min-h-\\[50vh\\] {\n  min-height: 50vh;\n}\r\n.min-h-\\[80vh\\] {\n  min-height: 80vh;\n}\r\n.min-h-screen {\n  min-height: 100vh;\n}\r\n.w-10 {\n  width: 2.5rem;\n}\r\n.w-12 {\n  width: 3rem;\n}\r\n.w-14 {\n  width: 3.5rem;\n}\r\n.w-16 {\n  width: 4rem;\n}\r\n.w-20 {\n  width: 5rem;\n}\r\n.w-24 {\n  width: 6rem;\n}\r\n.w-3 {\n  width: 0.75rem;\n}\r\n.w-32 {\n  width: 8rem;\n}\r\n.w-4 {\n  width: 1rem;\n}\r\n.w-40 {\n  width: 10rem;\n}\r\n.w-6 {\n  width: 1.5rem;\n}\r\n.w-72 {\n  width: 18rem;\n}\r\n.w-8 {\n  width: 2rem;\n}\r\n.w-auto {\n  width: auto;\n}\r\n.w-full {\n  width: 100%;\n}\r\n.min-w-0 {\n  min-width: 0px;\n}\r\n.max-w-4xl {\n  max-width: 56rem;\n}\r\n.max-w-5xl {\n  max-width: 64rem;\n}\r\n.max-w-6xl {\n  max-width: 72rem;\n}\r\n.max-w-7xl {\n  max-width: 80rem;\n}\r\n.max-w-sm {\n  max-width: 24rem;\n}\r\n.max-w-xl {\n  max-width: 36rem;\n}\r\n.flex-1 {\n  flex: 1 1 0%;\n}\r\n.shrink-0 {\n  flex-shrink: 0;\n}\r\n.-translate-x-1\\/2 {\n  --tw-translate-x: -50%;\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\n}\r\n.translate-y-1\\/2 {\n  --tw-translate-y: 50%;\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\n}\r\n.rotate-\\[-15deg\\] {\n  --tw-rotate: -15deg;\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\n}\r\n.rotate-\\[-8deg\\] {\n  --tw-rotate: -8deg;\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\n}\r\n.rotate-\\[10deg\\] {\n  --tw-rotate: 10deg;\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\n}\r\n.rotate-\\[18deg\\] {\n  --tw-rotate: 18deg;\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\n}\r\n.rotate-\\[25deg\\] {\n  --tw-rotate: 25deg;\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\n}\r\n.rotate-\\[3deg\\] {\n  --tw-rotate: 3deg;\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\n}\r\n.transform {\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\n}\r\n@keyframes pulse {\n\n  50% {\n    opacity: .5;\n  }\n}\r\n.animate-pulse {\n  animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;\n}\r\n@keyframes spin {\n\n  to {\n    transform: rotate(360deg);\n  }\n}\r\n.animate-spin {\n  animation: spin 1s linear infinite;\n}\r\n.cursor-grab {\n  cursor: grab;\n}\r\n.cursor-pointer {\n  cursor: pointer;\n}\r\n.select-none {\n  -webkit-user-select: none;\n     -moz-user-select: none;\n          user-select: none;\n}\r\n.resize {\n  resize: both;\n}\r\n.grid-cols-3 {\n  grid-template-columns: repeat(3, minmax(0, 1fr));\n}\r\n.flex-col {\n  flex-direction: column;\n}\r\n.flex-wrap {\n  flex-wrap: wrap;\n}\r\n.items-end {\n  align-items: flex-end;\n}\r\n.items-center {\n  align-items: center;\n}\r\n.justify-center {\n  justify-content: center;\n}\r\n.justify-between {\n  justify-content: space-between;\n}\r\n.gap-1 {\n  gap: 0.25rem;\n}\r\n.gap-1\\.5 {\n  gap: 0.375rem;\n}\r\n.gap-2 {\n  gap: 0.5rem;\n}\r\n.gap-3 {\n  gap: 0.75rem;\n}\r\n.gap-4 {\n  gap: 1rem;\n}\r\n.gap-8 {\n  gap: 2rem;\n}\r\n.space-y-6 > :not([hidden]) ~ :not([hidden]) {\n  --tw-space-y-reverse: 0;\n  margin-top: calc(1.5rem * calc(1 - var(--tw-space-y-reverse)));\n  margin-bottom: calc(1.5rem * var(--tw-space-y-reverse));\n}\r\n.overflow-hidden {\n  overflow: hidden;\n}\r\n.overflow-x-auto {\n  overflow-x: auto;\n}\r\n.overflow-y-auto {\n  overflow-y: auto;\n}\r\n.truncate {\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\r\n.whitespace-nowrap {\n  white-space: nowrap;\n}\r\n.rounded-2xl {\n  border-radius: 1rem;\n}\r\n.rounded-full {\n  border-radius: 9999px;\n}\r\n.rounded-lg {\n  border-radius: 0.5rem;\n}\r\n.rounded-xl {\n  border-radius: 0.75rem;\n}\r\n.rounded-t-xl {\n  border-top-left-radius: 0.75rem;\n  border-top-right-radius: 0.75rem;\n}\r\n.border {\n  border-width: 1px;\n}\r\n.border-2 {\n  border-width: 2px;\n}\r\n.border-4 {\n  border-width: 4px;\n}\r\n.border-b {\n  border-bottom-width: 1px;\n}\r\n.border-gray-100 {\n  --tw-border-opacity: 1;\n  border-color: rgb(243 244 246 / var(--tw-border-opacity, 1));\n}\r\n.border-gray-200 {\n  --tw-border-opacity: 1;\n  border-color: rgb(229 231 235 / var(--tw-border-opacity, 1));\n}\r\n.border-gray-300 {\n  --tw-border-opacity: 1;\n  border-color: rgb(209 213 219 / var(--tw-border-opacity, 1));\n}\r\n.border-white {\n  --tw-border-opacity: 1;\n  border-color: rgb(255 255 255 / var(--tw-border-opacity, 1));\n}\r\n.border-t-brand-red {\n  --tw-border-opacity: 1;\n  border-top-color: rgb(238 49 36 / var(--tw-border-opacity, 1));\n}\r\n.bg-black\\/10 {\n  background-color: rgb(0 0 0 / 0.1);\n}\r\n.bg-black\\/20 {\n  background-color: rgb(0 0 0 / 0.2);\n}\r\n.bg-black\\/40 {\n  background-color: rgb(0 0 0 / 0.4);\n}\r\n.bg-blue-500 {\n  --tw-bg-opacity: 1;\n  background-color: rgb(59 130 246 / var(--tw-bg-opacity, 1));\n}\r\n.bg-brand-charcoal {\n  --tw-bg-opacity: 1;\n  background-color: rgb(43 43 43 / var(--tw-bg-opacity, 1));\n}\r\n.bg-brand-offwhite {\n  --tw-bg-opacity: 1;\n  background-color: rgb(250 247 242 / var(--tw-bg-opacity, 1));\n}\r\n.bg-brand-red {\n  --tw-bg-opacity: 1;\n  background-color: rgb(238 49 36 / var(--tw-bg-opacity, 1));\n}\r\n.bg-gray-100 {\n  --tw-bg-opacity: 1;\n  background-color: rgb(243 244 246 / var(--tw-bg-opacity, 1));\n}\r\n.bg-gray-200 {\n  --tw-bg-opacity: 1;\n  background-color: rgb(229 231 235 / var(--tw-bg-opacity, 1));\n}\r\n.bg-gray-50 {\n  --tw-bg-opacity: 1;\n  background-color: rgb(249 250 251 / var(--tw-bg-opacity, 1));\n}\r\n.bg-green-50 {\n  --tw-bg-opacity: 1;\n  background-color: rgb(240 253 244 / var(--tw-bg-opacity, 1));\n}\r\n.bg-green-500 {\n  --tw-bg-opacity: 1;\n  background-color: rgb(34 197 94 / var(--tw-bg-opacity, 1));\n}\r\n.bg-green-600 {\n  --tw-bg-opacity: 1;\n  background-color: rgb(22 163 74 / var(--tw-bg-opacity, 1));\n}\r\n.bg-orange-500 {\n  --tw-bg-opacity: 1;\n  background-color: rgb(249 115 22 / var(--tw-bg-opacity, 1));\n}\r\n.bg-purple-500 {\n  --tw-bg-opacity: 1;\n  background-color: rgb(168 85 247 / var(--tw-bg-opacity, 1));\n}\r\n.bg-red-500 {\n  --tw-bg-opacity: 1;\n  background-color: rgb(239 68 68 / var(--tw-bg-opacity, 1));\n}\r\n.bg-transparent {\n  background-color: transparent;\n}\r\n.bg-white {\n  --tw-bg-opacity: 1;\n  background-color: rgb(255 255 255 / var(--tw-bg-opacity, 1));\n}\r\n.bg-white\\/20 {\n  background-color: rgb(255 255 255 / 0.2);\n}\r\n.bg-white\\/30 {\n  background-color: rgb(255 255 255 / 0.3);\n}\r\n.bg-white\\/80 {\n  background-color: rgb(255 255 255 / 0.8);\n}\r\n.bg-white\\/90 {\n  background-color: rgb(255 255 255 / 0.9);\n}\r\n.bg-yellow-500 {\n  --tw-bg-opacity: 1;\n  background-color: rgb(234 179 8 / var(--tw-bg-opacity, 1));\n}\r\n.bg-gradient-to-r {\n  background-image: linear-gradient(to right, var(--tw-gradient-stops));\n}\r\n.from-blue-600 {\n  --tw-gradient-from: #2563eb var(--tw-gradient-from-position);\n  --tw-gradient-to: rgb(37 99 235 / 0) var(--tw-gradient-to-position);\n  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);\n}\r\n.from-purple-600 {\n  --tw-gradient-from: #9333ea var(--tw-gradient-from-position);\n  --tw-gradient-to: rgb(147 51 234 / 0) var(--tw-gradient-to-position);\n  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);\n}\r\n.from-red-600 {\n  --tw-gradient-from: #dc2626 var(--tw-gradient-from-position);\n  --tw-gradient-to: rgb(220 38 38 / 0) var(--tw-gradient-to-position);\n  --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);\n}\r\n.to-cyan-400 {\n  --tw-gradient-to: #22d3ee var(--tw-gradient-to-position);\n}\r\n.to-pink-400 {\n  --tw-gradient-to: #f472b6 var(--tw-gradient-to-position);\n}\r\n.to-rose-400 {\n  --tw-gradient-to: #fb7185 var(--tw-gradient-to-position);\n}\r\n.p-3 {\n  padding: 0.75rem;\n}\r\n.p-4 {\n  padding: 1rem;\n}\r\n.p-6 {\n  padding: 1.5rem;\n}\r\n.p-8 {\n  padding: 2rem;\n}\r\n.px-1 {\n  padding-left: 0.25rem;\n  padding-right: 0.25rem;\n}\r\n.px-2 {\n  padding-left: 0.5rem;\n  padding-right: 0.5rem;\n}\r\n.px-2\\.5 {\n  padding-left: 0.625rem;\n  padding-right: 0.625rem;\n}\r\n.px-3 {\n  padding-left: 0.75rem;\n  padding-right: 0.75rem;\n}\r\n.px-4 {\n  padding-left: 1rem;\n  padding-right: 1rem;\n}\r\n.px-6 {\n  padding-left: 1.5rem;\n  padding-right: 1.5rem;\n}\r\n.px-8 {\n  padding-left: 2rem;\n  padding-right: 2rem;\n}\r\n.py-0\\.5 {\n  padding-top: 0.125rem;\n  padding-bottom: 0.125rem;\n}\r\n.py-1 {\n  padding-top: 0.25rem;\n  padding-bottom: 0.25rem;\n}\r\n.py-1\\.5 {\n  padding-top: 0.375rem;\n  padding-bottom: 0.375rem;\n}\r\n.py-2 {\n  padding-top: 0.5rem;\n  padding-bottom: 0.5rem;\n}\r\n.py-2\\.5 {\n  padding-top: 0.625rem;\n  padding-bottom: 0.625rem;\n}\r\n.py-20 {\n  padding-top: 5rem;\n  padding-bottom: 5rem;\n}\r\n.py-3 {\n  padding-top: 0.75rem;\n  padding-bottom: 0.75rem;\n}\r\n.py-3\\.5 {\n  padding-top: 0.875rem;\n  padding-bottom: 0.875rem;\n}\r\n.py-4 {\n  padding-top: 1rem;\n  padding-bottom: 1rem;\n}\r\n.py-8 {\n  padding-top: 2rem;\n  padding-bottom: 2rem;\n}\r\n.pb-2 {\n  padding-bottom: 0.5rem;\n}\r\n.pb-3 {\n  padding-bottom: 0.75rem;\n}\r\n.pb-4 {\n  padding-bottom: 1rem;\n}\r\n.pt-2 {\n  padding-top: 0.5rem;\n}\r\n.pt-3 {\n  padding-top: 0.75rem;\n}\r\n.text-left {\n  text-align: left;\n}\r\n.text-center {\n  text-align: center;\n}\r\n.font-display {\n  font-family: Playfair Display, Georgia, serif;\n}\r\n.text-2xl {\n  font-size: 1.5rem;\n  line-height: 2rem;\n}\r\n.text-3xl {\n  font-size: 1.875rem;\n  line-height: 2.25rem;\n}\r\n.text-4xl {\n  font-size: 2.25rem;\n  line-height: 2.5rem;\n}\r\n.text-5xl {\n  font-size: 3rem;\n  line-height: 1;\n}\r\n.text-6xl {\n  font-size: 3.75rem;\n  line-height: 1;\n}\r\n.text-\\[10px\\] {\n  font-size: 10px;\n}\r\n.text-\\[11px\\] {\n  font-size: 11px;\n}\r\n.text-lg {\n  font-size: 1.125rem;\n  line-height: 1.75rem;\n}\r\n.text-sm {\n  font-size: 0.875rem;\n  line-height: 1.25rem;\n}\r\n.text-xl {\n  font-size: 1.25rem;\n  line-height: 1.75rem;\n}\r\n.text-xs {\n  font-size: 0.75rem;\n  line-height: 1rem;\n}\r\n.font-bold {\n  font-weight: 700;\n}\r\n.font-medium {\n  font-weight: 500;\n}\r\n.font-semibold {\n  font-weight: 600;\n}\r\n.uppercase {\n  text-transform: uppercase;\n}\r\n.capitalize {\n  text-transform: capitalize;\n}\r\n.leading-tight {\n  line-height: 1.25;\n}\r\n.tracking-wider {\n  letter-spacing: 0.05em;\n}\r\n.text-brand-charcoal {\n  --tw-text-opacity: 1;\n  color: rgb(43 43 43 / var(--tw-text-opacity, 1));\n}\r\n.text-brand-red {\n  --tw-text-opacity: 1;\n  color: rgb(238 49 36 / var(--tw-text-opacity, 1));\n}\r\n.text-brand-red\\/20 {\n  color: rgb(238 49 36 / 0.2);\n}\r\n.text-gray-300 {\n  --tw-text-opacity: 1;\n  color: rgb(209 213 219 / var(--tw-text-opacity, 1));\n}\r\n.text-gray-400 {\n  --tw-text-opacity: 1;\n  color: rgb(156 163 175 / var(--tw-text-opacity, 1));\n}\r\n.text-gray-500 {\n  --tw-text-opacity: 1;\n  color: rgb(107 114 128 / var(--tw-text-opacity, 1));\n}\r\n.text-gray-600 {\n  --tw-text-opacity: 1;\n  color: rgb(75 85 99 / var(--tw-text-opacity, 1));\n}\r\n.text-gray-800 {\n  --tw-text-opacity: 1;\n  color: rgb(31 41 55 / var(--tw-text-opacity, 1));\n}\r\n.text-green-600 {\n  --tw-text-opacity: 1;\n  color: rgb(22 163 74 / var(--tw-text-opacity, 1));\n}\r\n.text-green-700 {\n  --tw-text-opacity: 1;\n  color: rgb(21 128 61 / var(--tw-text-opacity, 1));\n}\r\n.text-red-500 {\n  --tw-text-opacity: 1;\n  color: rgb(239 68 68 / var(--tw-text-opacity, 1));\n}\r\n.text-white {\n  --tw-text-opacity: 1;\n  color: rgb(255 255 255 / var(--tw-text-opacity, 1));\n}\r\n.antialiased {\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\r\n.opacity-10 {\n  opacity: 0.1;\n}\r\n.opacity-5 {\n  opacity: 0.05;\n}\r\n.opacity-75 {\n  opacity: 0.75;\n}\r\n.opacity-\\[0\\.03\\] {\n  opacity: 0.03;\n}\r\n.shadow-2xl {\n  --tw-shadow: 0 25px 50px -12px rgb(0 0 0 / 0.25);\n  --tw-shadow-colored: 0 25px 50px -12px var(--tw-shadow-color);\n  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);\n}\r\n.shadow-lg {\n  --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);\n  --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);\n  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);\n}\r\n.shadow-md {\n  --tw-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);\n  --tw-shadow-colored: 0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);\n  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);\n}\r\n.shadow-sm {\n  --tw-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);\n  --tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);\n  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);\n}\r\n.shadow-xl {\n  --tw-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);\n  --tw-shadow-colored: 0 20px 25px -5px var(--tw-shadow-color), 0 8px 10px -6px var(--tw-shadow-color);\n  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);\n}\r\n.outline-none {\n  outline: 2px solid transparent;\n  outline-offset: 2px;\n}\r\n.ring-1 {\n  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);\n  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);\n  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);\n}\r\n.ring-2 {\n  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);\n  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);\n  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);\n}\r\n.ring-4 {\n  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);\n  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(4px + var(--tw-ring-offset-width)) var(--tw-ring-color);\n  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);\n}\r\n.ring-black\\/5 {\n  --tw-ring-color: rgb(0 0 0 / 0.05);\n}\r\n.ring-transparent {\n  --tw-ring-color: transparent;\n}\r\n.ring-white {\n  --tw-ring-opacity: 1;\n  --tw-ring-color: rgb(255 255 255 / var(--tw-ring-opacity, 1));\n}\r\n.filter {\n  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);\n}\r\n.backdrop-blur-md {\n  --tw-backdrop-blur: blur(12px);\n  backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);\n}\r\n.backdrop-blur-sm {\n  --tw-backdrop-blur: blur(4px);\n  backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);\n}\r\n.transition {\n  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;\n  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);\n  transition-duration: 150ms;\n}\r\n.transition-all {\n  transition-property: all;\n  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);\n  transition-duration: 150ms;\n}\r\n.transition-colors {\n  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;\n  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);\n  transition-duration: 150ms;\n}\r\n.transition-shadow {\n  transition-property: box-shadow;\n  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);\n  transition-duration: 150ms;\n}\r\n.transition-transform {\n  transition-property: transform;\n  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);\n  transition-duration: 150ms;\n}\r\n.duration-200 {\n  transition-duration: 200ms;\n}\r\n.duration-300 {\n  transition-duration: 300ms;\n}\r\n.ease-natural-decel {\n  transition-timing-function: cubic-bezier(0.16, 1, 0.3, 1);\n}\r\n.\\[-ms-overflow-style\\:none\\] {\n  -ms-overflow-style: none;\n}\r\n.\\[scrollbar-width\\:none\\] {\n  scrollbar-width: none;\n}\r\n:root {\r\n  --brand-red: #EE3124;\r\n  --brand-charcoal: #2B2B2B;\r\n  --brand-offwhite: #fffff;\r\n  --brand-white: #fffff;\r\n\r\n}\r\n\r\nbody {\r\n  font-family: 'Inter', system-ui, sans-serif;\r\n  background-color: var(--brand-white);\r\n  color: var(--brand-charcoal);\r\n}\r\n\r\n/* Custom scrollbar */\r\n::-webkit-scrollbar {\r\n  height: 6px;\r\n  width: 6px;\r\n}\r\n\r\n::-webkit-scrollbar-track {\r\n  background: transparent;\r\n}\r\n\r\n::-webkit-scrollbar-thumb {\r\n  background: #ccc;\r\n  border-radius: 3px;\r\n}\r\n\r\n::-webkit-scrollbar-thumb:hover {\r\n  background: #999;\r\n}\r\n\r\n/* Hide scrollbar on range selector */\r\n.hide-scrollbar {\r\n  -ms-overflow-style: none;\r\n  scrollbar-width: none;\r\n}\r\n\r\n.hide-scrollbar::-webkit-scrollbar {\r\n  display: none;\r\n}\r\n\r\n.color-cat-wrapper {\r\n  padding: 2px;\r\n}\r\n\r\n.similar-tiles-color {\r\n  margin: 3px;\r\n}\r\n\r\n.black-dot {\r\n  bottom: 24px;\r\n  z-index: 29;\r\n}\r\n\r\n.hot-spot {\r\n  bottom: 52px;\r\n  position: absolute;\r\n  display: none;\r\n}\r\n\r\n.detail-page-tiles-sm a,\r\ndiv.detail-page-tiles-sm {\r\n  padding: 3px;\r\n}\r\n\r\n.tiles-mob {\r\n  padding: 10px;\r\n}\r\n\r\n.tiles-mob-wrapper h1 {\r\n  padding: 5px;\r\n  text-align: center;\r\n}\r\n\r\n.cmpl-shades {\r\n  margin: 10px;\r\n}\r\n\r\n.arrows-wp {\r\n  padding-bottom: 10px;\r\n}\r\n\r\n@media screen and (max-width: 767px) {\r\n  .arrows-wrapper {\r\n    padding: 10px 0;\r\n  }\r\n\r\n  .arrows-wp {\r\n    padding-bottom: 0;\r\n  }\r\n\r\n  .black-dot {\r\n    bottom: 25px;\r\n    z-index: 29;\r\n    width: 15px;\r\n    height: 15px;\r\n  }\r\n}\r\n.shdow-md {\r\n  --tw-shadow: 0 10px 22px -9px rgb(0 0 0 / 0.1), 0 11px 13px 4px rgb(0 0 0 / 0.1) !important;\r\n}\r\n.placeholder\\:text-gray-400::-moz-placeholder {\n  --tw-text-opacity: 1;\n  color: rgb(156 163 175 / var(--tw-text-opacity, 1));\n}\r\n.placeholder\\:text-gray-400::placeholder {\n  --tw-text-opacity: 1;\n  color: rgb(156 163 175 / var(--tw-text-opacity, 1));\n}\r\n.focus-within\\:bg-white:focus-within {\n  --tw-bg-opacity: 1;\n  background-color: rgb(255 255 255 / var(--tw-bg-opacity, 1));\n}\r\n.focus-within\\:ring-2:focus-within {\n  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);\n  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);\n  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);\n}\r\n.focus-within\\:ring-brand-red\\/30:focus-within {\n  --tw-ring-color: rgb(238 49 36 / 0.3);\n}\r\n.hover\\:-translate-y-1:hover {\n  --tw-translate-y: -0.25rem;\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\n}\r\n.hover\\:scale-105:hover {\n  --tw-scale-x: 1.05;\n  --tw-scale-y: 1.05;\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\n}\r\n.hover\\:border-brand-charcoal:hover {\n  --tw-border-opacity: 1;\n  border-color: rgb(43 43 43 / var(--tw-border-opacity, 1));\n}\r\n.hover\\:border-gray-900:hover {\n  --tw-border-opacity: 1;\n  border-color: rgb(17 24 39 / var(--tw-border-opacity, 1));\n}\r\n.hover\\:bg-black\\/40:hover {\n  background-color: rgb(0 0 0 / 0.4);\n}\r\n.hover\\:bg-gray-100:hover {\n  --tw-bg-opacity: 1;\n  background-color: rgb(243 244 246 / var(--tw-bg-opacity, 1));\n}\r\n.hover\\:bg-gray-50:hover {\n  --tw-bg-opacity: 1;\n  background-color: rgb(249 250 251 / var(--tw-bg-opacity, 1));\n}\r\n.hover\\:bg-gray-700:hover {\n  --tw-bg-opacity: 1;\n  background-color: rgb(55 65 81 / var(--tw-bg-opacity, 1));\n}\r\n.hover\\:bg-gray-800:hover {\n  --tw-bg-opacity: 1;\n  background-color: rgb(31 41 55 / var(--tw-bg-opacity, 1));\n}\r\n.hover\\:bg-red-700:hover {\n  --tw-bg-opacity: 1;\n  background-color: rgb(185 28 28 / var(--tw-bg-opacity, 1));\n}\r\n.hover\\:text-brand-charcoal:hover {\n  --tw-text-opacity: 1;\n  color: rgb(43 43 43 / var(--tw-text-opacity, 1));\n}\r\n.hover\\:text-red-700:hover {\n  --tw-text-opacity: 1;\n  color: rgb(185 28 28 / var(--tw-text-opacity, 1));\n}\r\n.hover\\:shadow-2xl:hover {\n  --tw-shadow: 0 25px 50px -12px rgb(0 0 0 / 0.25);\n  --tw-shadow-colored: 0 25px 50px -12px var(--tw-shadow-color);\n  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);\n}\r\n.hover\\:shadow-lg:hover {\n  --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);\n  --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);\n  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);\n}\r\n.hover\\:shadow-xl:hover {\n  --tw-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);\n  --tw-shadow-colored: 0 20px 25px -5px var(--tw-shadow-color), 0 8px 10px -6px var(--tw-shadow-color);\n  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);\n}\r\n.hover\\:brightness-95:hover {\n  --tw-brightness: brightness(.95);\n  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);\n}\r\n.focus\\:outline-none:focus {\n  outline: 2px solid transparent;\n  outline-offset: 2px;\n}\r\n.focus\\:ring-4:focus {\n  --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);\n  --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(4px + var(--tw-ring-offset-width)) var(--tw-ring-color);\n  box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);\n}\r\n.focus\\:ring-red-300:focus {\n  --tw-ring-opacity: 1;\n  --tw-ring-color: rgb(252 165 165 / var(--tw-ring-opacity, 1));\n}\r\n.active\\:cursor-grabbing:active {\n  cursor: grabbing;\n}\r\n.disabled\\:opacity-30:disabled {\n  opacity: 0.3;\n}\r\n.disabled\\:shadow-none:disabled {\n  --tw-shadow: 0 0 #0000;\n  --tw-shadow-colored: 0 0 #0000;\n  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);\n}\r\n.group:hover .group-hover\\:translate-x-1 {\n  --tw-translate-x: 0.25rem;\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\n}\r\n.group:hover .group-hover\\:scale-\\[1\\.02\\] {\n  --tw-scale-x: 1.02;\n  --tw-scale-y: 1.02;\n  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\n}\r\n.group:hover .group-hover\\:border-gray-300 {\n  --tw-border-opacity: 1;\n  border-color: rgb(209 213 219 / var(--tw-border-opacity, 1));\n}\r\n.group:hover .group-hover\\:text-brand-red {\n  --tw-text-opacity: 1;\n  color: rgb(238 49 36 / var(--tw-text-opacity, 1));\n}\r\n.group:hover .group-hover\\:ring-brand-red {\n  --tw-ring-opacity: 1;\n  --tw-ring-color: rgb(238 49 36 / var(--tw-ring-opacity, 1));\n}\r\n@media (min-width: 640px) {\n\n  .sm\\:w-32 {\n    width: 8rem;\n  }\n\n  .sm\\:grid-cols-2 {\n    grid-template-columns: repeat(2, minmax(0, 1fr));\n  }\n\n  .sm\\:justify-start {\n    justify-content: flex-start;\n  }\n}\r\n@media (min-width: 768px) {\n\n  .md\\:bottom-6 {\n    bottom: 1.5rem;\n  }\n\n  .md\\:right-6 {\n    right: 1.5rem;\n  }\n\n  .md\\:ml-1 {\n    margin-left: 0.25rem;\n  }\n\n  .md\\:block {\n    display: block;\n  }\n\n  .md\\:hidden {\n    display: none;\n  }\n\n  .md\\:h-10 {\n    height: 2.5rem;\n  }\n\n  .md\\:h-12 {\n    height: 3rem;\n  }\n\n  .md\\:h-14 {\n    height: 3.5rem;\n  }\n\n  .md\\:h-28 {\n    height: 7rem;\n  }\n\n  .md\\:h-5 {\n    height: 1.25rem;\n  }\n\n  .md\\:h-8 {\n    height: 2rem;\n  }\n\n  .md\\:w-14 {\n    width: 3.5rem;\n  }\n\n  .md\\:w-28 {\n    width: 7rem;\n  }\n\n  .md\\:w-40 {\n    width: 10rem;\n  }\n\n  .md\\:w-48 {\n    width: 12rem;\n  }\n\n  .md\\:w-5 {\n    width: 1.25rem;\n  }\n\n  .md\\:w-8 {\n    width: 2rem;\n  }\n\n  .md\\:w-\\[440px\\] {\n    width: 440px;\n  }\n\n  .md\\:grid-cols-2 {\n    grid-template-columns: repeat(2, minmax(0, 1fr));\n  }\n\n  .md\\:grid-cols-3 {\n    grid-template-columns: repeat(3, minmax(0, 1fr));\n  }\n\n  .md\\:gap-2 {\n    gap: 0.5rem;\n  }\n\n  .md\\:gap-3 {\n    gap: 0.75rem;\n  }\n\n  .md\\:gap-4 {\n    gap: 1rem;\n  }\n\n  .md\\:px-1\\.5 {\n    padding-left: 0.375rem;\n    padding-right: 0.375rem;\n  }\n\n  .md\\:px-3 {\n    padding-left: 0.75rem;\n    padding-right: 0.75rem;\n  }\n\n  .md\\:px-4 {\n    padding-left: 1rem;\n    padding-right: 1rem;\n  }\n\n  .md\\:py-2 {\n    padding-top: 0.5rem;\n    padding-bottom: 0.5rem;\n  }\n\n  .md\\:py-3 {\n    padding-top: 0.75rem;\n    padding-bottom: 0.75rem;\n  }\n\n  .md\\:pt-4 {\n    padding-top: 1rem;\n  }\n\n  .md\\:text-3xl {\n    font-size: 1.875rem;\n    line-height: 2.25rem;\n  }\n\n  .md\\:text-4xl {\n    font-size: 2.25rem;\n    line-height: 2.5rem;\n  }\n\n  .md\\:text-7xl {\n    font-size: 4.5rem;\n    line-height: 1;\n  }\n\n  .md\\:text-sm {\n    font-size: 0.875rem;\n    line-height: 1.25rem;\n  }\n\n  .md\\:text-xl {\n    font-size: 1.25rem;\n    line-height: 1.75rem;\n  }\n\n  .md\\:text-xs {\n    font-size: 0.75rem;\n    line-height: 1rem;\n  }\n}\r\n@media (min-width: 1024px) {\n\n  .lg\\:grid-cols-3 {\n    grid-template-columns: repeat(3, minmax(0, 1fr));\n  }\n\n  .lg\\:text-8xl {\n    font-size: 6rem;\n    line-height: 1;\n  }\n}\r\n.\\[\\&\\:\\:-webkit-scrollbar\\]\\:hidden::-webkit-scrollbar {\n  display: none;\n}/*$vite$:1*/";
	document.head.appendChild(__vite_style__);
	//#region \0rolldown/runtime.js
	var __create = Object.create;
	var __defProp = Object.defineProperty;
	var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
	var __getOwnPropNames = Object.getOwnPropertyNames;
	var __getProtoOf = Object.getPrototypeOf;
	var __hasOwnProp = Object.prototype.hasOwnProperty;
	var __esmMin = (fn, res, err) => () => {
		if (err) throw err[0];
		try {
			return fn && (res = fn(fn = 0)), res;
		} catch (e) {
			throw err = [e], e;
		}
	};
	var __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod), cb = null), mod.exports);
	var __exportAll = (all, no_symbols) => {
		let target = {};
		for (var name in all) __defProp(target, name, {
			get: all[name],
			enumerable: true
		});
		if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
		return target;
	};
	var __copyProps = (to, from, except, desc) => {
		if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
			key = keys[i];
			if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
				get: ((k) => from[k]).bind(null, key),
				enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
			});
		}
		return to;
	};
	var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule || !__hasOwnProp.call(mod, "default") ? __defProp(target, "default", {
		value: mod,
		enumerable: true
	}) : target, mod));
	var __toCommonJS = (mod) => __hasOwnProp.call(mod, "module.exports") ? mod["module.exports"] : __copyProps(__defProp({}, "__esModule", { value: true }), mod);
	//#endregion
	//#region node_modules/react/cjs/react.production.min.js
	/**
	* @license React
	* react.production.min.js
	*
	* Copyright (c) Facebook, Inc. and its affiliates.
	*
	* This source code is licensed under the MIT license found in the
	* LICENSE file in the root directory of this source tree.
	*/
	var require_react_production_min = /* @__PURE__ */ __commonJSMin(((exports) => {
		var l = Symbol.for("react.element");
		var n = Symbol.for("react.portal");
		var p = Symbol.for("react.fragment");
		var q = Symbol.for("react.strict_mode");
		var r = Symbol.for("react.profiler");
		var t = Symbol.for("react.provider");
		var u = Symbol.for("react.context");
		var v = Symbol.for("react.forward_ref");
		var w = Symbol.for("react.suspense");
		var x = Symbol.for("react.memo");
		var y = Symbol.for("react.lazy");
		var z = Symbol.iterator;
		function A(a) {
			if (null === a || "object" !== typeof a) return null;
			a = z && a[z] || a["@@iterator"];
			return "function" === typeof a ? a : null;
		}
		var B = {
			isMounted: function() {
				return !1;
			},
			enqueueForceUpdate: function() {},
			enqueueReplaceState: function() {},
			enqueueSetState: function() {}
		};
		var C = Object.assign;
		var D = {};
		function E(a, b, e) {
			this.props = a;
			this.context = b;
			this.refs = D;
			this.updater = e || B;
		}
		E.prototype.isReactComponent = {};
		E.prototype.setState = function(a, b) {
			if ("object" !== typeof a && "function" !== typeof a && null != a) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
			this.updater.enqueueSetState(this, a, b, "setState");
		};
		E.prototype.forceUpdate = function(a) {
			this.updater.enqueueForceUpdate(this, a, "forceUpdate");
		};
		function F() {}
		F.prototype = E.prototype;
		function G(a, b, e) {
			this.props = a;
			this.context = b;
			this.refs = D;
			this.updater = e || B;
		}
		var H = G.prototype = new F();
		H.constructor = G;
		C(H, E.prototype);
		H.isPureReactComponent = !0;
		var I = Array.isArray;
		var J = Object.prototype.hasOwnProperty;
		var K = { current: null };
		var L = {
			key: !0,
			ref: !0,
			__self: !0,
			__source: !0
		};
		function M(a, b, e) {
			var d, c = {}, k = null, h = null;
			if (null != b) for (d in void 0 !== b.ref && (h = b.ref), void 0 !== b.key && (k = "" + b.key), b) J.call(b, d) && !L.hasOwnProperty(d) && (c[d] = b[d]);
			var g = arguments.length - 2;
			if (1 === g) c.children = e;
			else if (1 < g) {
				for (var f = Array(g), m = 0; m < g; m++) f[m] = arguments[m + 2];
				c.children = f;
			}
			if (a && a.defaultProps) for (d in g = a.defaultProps, g) void 0 === c[d] && (c[d] = g[d]);
			return {
				$$typeof: l,
				type: a,
				key: k,
				ref: h,
				props: c,
				_owner: K.current
			};
		}
		function N(a, b) {
			return {
				$$typeof: l,
				type: a.type,
				key: b,
				ref: a.ref,
				props: a.props,
				_owner: a._owner
			};
		}
		function O(a) {
			return "object" === typeof a && null !== a && a.$$typeof === l;
		}
		function escape(a) {
			var b = {
				"=": "=0",
				":": "=2"
			};
			return "$" + a.replace(/[=:]/g, function(a) {
				return b[a];
			});
		}
		var P = /\/+/g;
		function Q(a, b) {
			return "object" === typeof a && null !== a && null != a.key ? escape("" + a.key) : b.toString(36);
		}
		function R(a, b, e, d, c) {
			var k = typeof a;
			if ("undefined" === k || "boolean" === k) a = null;
			var h = !1;
			if (null === a) h = !0;
			else switch (k) {
				case "string":
				case "number":
					h = !0;
					break;
				case "object": switch (a.$$typeof) {
					case l:
					case n: h = !0;
				}
			}
			if (h) return h = a, c = c(h), a = "" === d ? "." + Q(h, 0) : d, I(c) ? (e = "", null != a && (e = a.replace(P, "$&/") + "/"), R(c, b, e, "", function(a) {
				return a;
			})) : null != c && (O(c) && (c = N(c, e + (!c.key || h && h.key === c.key ? "" : ("" + c.key).replace(P, "$&/") + "/") + a)), b.push(c)), 1;
			h = 0;
			d = "" === d ? "." : d + ":";
			if (I(a)) for (var g = 0; g < a.length; g++) {
				k = a[g];
				var f = d + Q(k, g);
				h += R(k, b, e, f, c);
			}
			else if (f = A(a), "function" === typeof f) for (a = f.call(a), g = 0; !(k = a.next()).done;) k = k.value, f = d + Q(k, g++), h += R(k, b, e, f, c);
			else if ("object" === k) throw b = String(a), Error("Objects are not valid as a React child (found: " + ("[object Object]" === b ? "object with keys {" + Object.keys(a).join(", ") + "}" : b) + "). If you meant to render a collection of children, use an array instead.");
			return h;
		}
		function S(a, b, e) {
			if (null == a) return a;
			var d = [], c = 0;
			R(a, d, "", "", function(a) {
				return b.call(e, a, c++);
			});
			return d;
		}
		function T(a) {
			if (-1 === a._status) {
				var b = a._result;
				b = b();
				b.then(function(b) {
					if (0 === a._status || -1 === a._status) a._status = 1, a._result = b;
				}, function(b) {
					if (0 === a._status || -1 === a._status) a._status = 2, a._result = b;
				});
				-1 === a._status && (a._status = 0, a._result = b);
			}
			if (1 === a._status) return a._result.default;
			throw a._result;
		}
		var U = { current: null };
		var V = { transition: null };
		var W = {
			ReactCurrentDispatcher: U,
			ReactCurrentBatchConfig: V,
			ReactCurrentOwner: K
		};
		function X() {
			throw Error("act(...) is not supported in production builds of React.");
		}
		exports.Children = {
			map: S,
			forEach: function(a, b, e) {
				S(a, function() {
					b.apply(this, arguments);
				}, e);
			},
			count: function(a) {
				var b = 0;
				S(a, function() {
					b++;
				});
				return b;
			},
			toArray: function(a) {
				return S(a, function(a) {
					return a;
				}) || [];
			},
			only: function(a) {
				if (!O(a)) throw Error("React.Children.only expected to receive a single React element child.");
				return a;
			}
		};
		exports.Component = E;
		exports.Fragment = p;
		exports.Profiler = r;
		exports.PureComponent = G;
		exports.StrictMode = q;
		exports.Suspense = w;
		exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = W;
		exports.act = X;
		exports.cloneElement = function(a, b, e) {
			if (null === a || void 0 === a) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + a + ".");
			var d = C({}, a.props), c = a.key, k = a.ref, h = a._owner;
			if (null != b) {
				void 0 !== b.ref && (k = b.ref, h = K.current);
				void 0 !== b.key && (c = "" + b.key);
				if (a.type && a.type.defaultProps) var g = a.type.defaultProps;
				for (f in b) J.call(b, f) && !L.hasOwnProperty(f) && (d[f] = void 0 === b[f] && void 0 !== g ? g[f] : b[f]);
			}
			var f = arguments.length - 2;
			if (1 === f) d.children = e;
			else if (1 < f) {
				g = Array(f);
				for (var m = 0; m < f; m++) g[m] = arguments[m + 2];
				d.children = g;
			}
			return {
				$$typeof: l,
				type: a.type,
				key: c,
				ref: k,
				props: d,
				_owner: h
			};
		};
		exports.createContext = function(a) {
			a = {
				$$typeof: u,
				_currentValue: a,
				_currentValue2: a,
				_threadCount: 0,
				Provider: null,
				Consumer: null,
				_defaultValue: null,
				_globalName: null
			};
			a.Provider = {
				$$typeof: t,
				_context: a
			};
			return a.Consumer = a;
		};
		exports.createElement = M;
		exports.createFactory = function(a) {
			var b = M.bind(null, a);
			b.type = a;
			return b;
		};
		exports.createRef = function() {
			return { current: null };
		};
		exports.forwardRef = function(a) {
			return {
				$$typeof: v,
				render: a
			};
		};
		exports.isValidElement = O;
		exports.lazy = function(a) {
			return {
				$$typeof: y,
				_payload: {
					_status: -1,
					_result: a
				},
				_init: T
			};
		};
		exports.memo = function(a, b) {
			return {
				$$typeof: x,
				type: a,
				compare: void 0 === b ? null : b
			};
		};
		exports.startTransition = function(a) {
			var b = V.transition;
			V.transition = {};
			try {
				a();
			} finally {
				V.transition = b;
			}
		};
		exports.unstable_act = X;
		exports.useCallback = function(a, b) {
			return U.current.useCallback(a, b);
		};
		exports.useContext = function(a) {
			return U.current.useContext(a);
		};
		exports.useDebugValue = function() {};
		exports.useDeferredValue = function(a) {
			return U.current.useDeferredValue(a);
		};
		exports.useEffect = function(a, b) {
			return U.current.useEffect(a, b);
		};
		exports.useId = function() {
			return U.current.useId();
		};
		exports.useImperativeHandle = function(a, b, e) {
			return U.current.useImperativeHandle(a, b, e);
		};
		exports.useInsertionEffect = function(a, b) {
			return U.current.useInsertionEffect(a, b);
		};
		exports.useLayoutEffect = function(a, b) {
			return U.current.useLayoutEffect(a, b);
		};
		exports.useMemo = function(a, b) {
			return U.current.useMemo(a, b);
		};
		exports.useReducer = function(a, b, e) {
			return U.current.useReducer(a, b, e);
		};
		exports.useRef = function(a) {
			return U.current.useRef(a);
		};
		exports.useState = function(a) {
			return U.current.useState(a);
		};
		exports.useSyncExternalStore = function(a, b, e) {
			return U.current.useSyncExternalStore(a, b, e);
		};
		exports.useTransition = function() {
			return U.current.useTransition();
		};
		exports.version = "18.3.1";
	}));
	//#endregion
	//#region node_modules/react/index.js
	var require_react = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		module.exports = require_react_production_min();
	}));
	//#endregion
	//#region node_modules/scheduler/cjs/scheduler.production.min.js
	/**
	* @license React
	* scheduler.production.min.js
	*
	* Copyright (c) Facebook, Inc. and its affiliates.
	*
	* This source code is licensed under the MIT license found in the
	* LICENSE file in the root directory of this source tree.
	*/
	var require_scheduler_production_min = /* @__PURE__ */ __commonJSMin(((exports) => {
		function f(a, b) {
			var c = a.length;
			a.push(b);
			a: for (; 0 < c;) {
				var d = c - 1 >>> 1, e = a[d];
				if (0 < g(e, b)) a[d] = b, a[c] = e, c = d;
				else break a;
			}
		}
		function h(a) {
			return 0 === a.length ? null : a[0];
		}
		function k(a) {
			if (0 === a.length) return null;
			var b = a[0], c = a.pop();
			if (c !== b) {
				a[0] = c;
				a: for (var d = 0, e = a.length, w = e >>> 1; d < w;) {
					var m = 2 * (d + 1) - 1, C = a[m], n = m + 1, x = a[n];
					if (0 > g(C, c)) n < e && 0 > g(x, C) ? (a[d] = x, a[n] = c, d = n) : (a[d] = C, a[m] = c, d = m);
					else if (n < e && 0 > g(x, c)) a[d] = x, a[n] = c, d = n;
					else break a;
				}
			}
			return b;
		}
		function g(a, b) {
			var c = a.sortIndex - b.sortIndex;
			return 0 !== c ? c : a.id - b.id;
		}
		if ("object" === typeof performance && "function" === typeof performance.now) {
			var l = performance;
			exports.unstable_now = function() {
				return l.now();
			};
		} else {
			var p = Date, q = p.now();
			exports.unstable_now = function() {
				return p.now() - q;
			};
		}
		var r = [];
		var t = [];
		var u = 1;
		var v = null;
		var y = 3;
		var z = !1;
		var A = !1;
		var B = !1;
		var D = "function" === typeof setTimeout ? setTimeout : null;
		var E = "function" === typeof clearTimeout ? clearTimeout : null;
		var F = "undefined" !== typeof setImmediate ? setImmediate : null;
		"undefined" !== typeof navigator && void 0 !== navigator.scheduling && void 0 !== navigator.scheduling.isInputPending && navigator.scheduling.isInputPending.bind(navigator.scheduling);
		function G(a) {
			for (var b = h(t); null !== b;) {
				if (null === b.callback) k(t);
				else if (b.startTime <= a) k(t), b.sortIndex = b.expirationTime, f(r, b);
				else break;
				b = h(t);
			}
		}
		function H(a) {
			B = !1;
			G(a);
			if (!A) if (null !== h(r)) A = !0, I(J);
			else {
				var b = h(t);
				null !== b && K(H, b.startTime - a);
			}
		}
		function J(a, b) {
			A = !1;
			B && (B = !1, E(L), L = -1);
			z = !0;
			var c = y;
			try {
				G(b);
				for (v = h(r); null !== v && (!(v.expirationTime > b) || a && !M());) {
					var d = v.callback;
					if ("function" === typeof d) {
						v.callback = null;
						y = v.priorityLevel;
						var e = d(v.expirationTime <= b);
						b = exports.unstable_now();
						"function" === typeof e ? v.callback = e : v === h(r) && k(r);
						G(b);
					} else k(r);
					v = h(r);
				}
				if (null !== v) var w = !0;
				else {
					var m = h(t);
					null !== m && K(H, m.startTime - b);
					w = !1;
				}
				return w;
			} finally {
				v = null, y = c, z = !1;
			}
		}
		var N = !1;
		var O = null;
		var L = -1;
		var P = 5;
		var Q = -1;
		function M() {
			return exports.unstable_now() - Q < P ? !1 : !0;
		}
		function R() {
			if (null !== O) {
				var a = exports.unstable_now();
				Q = a;
				var b = !0;
				try {
					b = O(!0, a);
				} finally {
					b ? S() : (N = !1, O = null);
				}
			} else N = !1;
		}
		var S;
		if ("function" === typeof F) S = function() {
			F(R);
		};
		else if ("undefined" !== typeof MessageChannel) {
			var T = new MessageChannel(), U = T.port2;
			T.port1.onmessage = R;
			S = function() {
				U.postMessage(null);
			};
		} else S = function() {
			D(R, 0);
		};
		function I(a) {
			O = a;
			N || (N = !0, S());
		}
		function K(a, b) {
			L = D(function() {
				a(exports.unstable_now());
			}, b);
		}
		exports.unstable_IdlePriority = 5;
		exports.unstable_ImmediatePriority = 1;
		exports.unstable_LowPriority = 4;
		exports.unstable_NormalPriority = 3;
		exports.unstable_Profiling = null;
		exports.unstable_UserBlockingPriority = 2;
		exports.unstable_cancelCallback = function(a) {
			a.callback = null;
		};
		exports.unstable_continueExecution = function() {
			A || z || (A = !0, I(J));
		};
		exports.unstable_forceFrameRate = function(a) {
			0 > a || 125 < a ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : P = 0 < a ? Math.floor(1e3 / a) : 5;
		};
		exports.unstable_getCurrentPriorityLevel = function() {
			return y;
		};
		exports.unstable_getFirstCallbackNode = function() {
			return h(r);
		};
		exports.unstable_next = function(a) {
			switch (y) {
				case 1:
				case 2:
				case 3:
					var b = 3;
					break;
				default: b = y;
			}
			var c = y;
			y = b;
			try {
				return a();
			} finally {
				y = c;
			}
		};
		exports.unstable_pauseExecution = function() {};
		exports.unstable_requestPaint = function() {};
		exports.unstable_runWithPriority = function(a, b) {
			switch (a) {
				case 1:
				case 2:
				case 3:
				case 4:
				case 5: break;
				default: a = 3;
			}
			var c = y;
			y = a;
			try {
				return b();
			} finally {
				y = c;
			}
		};
		exports.unstable_scheduleCallback = function(a, b, c) {
			var d = exports.unstable_now();
			"object" === typeof c && null !== c ? (c = c.delay, c = "number" === typeof c && 0 < c ? d + c : d) : c = d;
			switch (a) {
				case 1:
					var e = -1;
					break;
				case 2:
					e = 250;
					break;
				case 5:
					e = 1073741823;
					break;
				case 4:
					e = 1e4;
					break;
				default: e = 5e3;
			}
			e = c + e;
			a = {
				id: u++,
				callback: b,
				priorityLevel: a,
				startTime: c,
				expirationTime: e,
				sortIndex: -1
			};
			c > d ? (a.sortIndex = c, f(t, a), null === h(r) && a === h(t) && (B ? (E(L), L = -1) : B = !0, K(H, c - d))) : (a.sortIndex = e, f(r, a), A || z || (A = !0, I(J)));
			return a;
		};
		exports.unstable_shouldYield = M;
		exports.unstable_wrapCallback = function(a) {
			var b = y;
			return function() {
				var c = y;
				y = b;
				try {
					return a.apply(this, arguments);
				} finally {
					y = c;
				}
			};
		};
	}));
	//#endregion
	//#region node_modules/scheduler/index.js
	var require_scheduler = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		module.exports = require_scheduler_production_min();
	}));
	//#endregion
	//#region node_modules/react-dom/cjs/react-dom.production.min.js
	/**
	* @license React
	* react-dom.production.min.js
	*
	* Copyright (c) Facebook, Inc. and its affiliates.
	*
	* This source code is licensed under the MIT license found in the
	* LICENSE file in the root directory of this source tree.
	*/
	var require_react_dom_production_min = /* @__PURE__ */ __commonJSMin(((exports) => {
		var aa = require_react();
		var ca = require_scheduler();
		function p(a) {
			for (var b = "https://reactjs.org/docs/error-decoder.html?invariant=" + a, c = 1; c < arguments.length; c++) b += "&args[]=" + encodeURIComponent(arguments[c]);
			return "Minified React error #" + a + "; visit " + b + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
		}
		var da = /* @__PURE__ */ new Set();
		var ea = {};
		function fa(a, b) {
			ha(a, b);
			ha(a + "Capture", b);
		}
		function ha(a, b) {
			ea[a] = b;
			for (a = 0; a < b.length; a++) da.add(b[a]);
		}
		var ia = !("undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement);
		var ja = Object.prototype.hasOwnProperty;
		var ka = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/;
		var la = {};
		var ma = {};
		function oa(a) {
			if (ja.call(ma, a)) return !0;
			if (ja.call(la, a)) return !1;
			if (ka.test(a)) return ma[a] = !0;
			la[a] = !0;
			return !1;
		}
		function pa(a, b, c, d) {
			if (null !== c && 0 === c.type) return !1;
			switch (typeof b) {
				case "function":
				case "symbol": return !0;
				case "boolean":
					if (d) return !1;
					if (null !== c) return !c.acceptsBooleans;
					a = a.toLowerCase().slice(0, 5);
					return "data-" !== a && "aria-" !== a;
				default: return !1;
			}
		}
		function qa(a, b, c, d) {
			if (null === b || "undefined" === typeof b || pa(a, b, c, d)) return !0;
			if (d) return !1;
			if (null !== c) switch (c.type) {
				case 3: return !b;
				case 4: return !1 === b;
				case 5: return isNaN(b);
				case 6: return isNaN(b) || 1 > b;
			}
			return !1;
		}
		function v(a, b, c, d, e, f, g) {
			this.acceptsBooleans = 2 === b || 3 === b || 4 === b;
			this.attributeName = d;
			this.attributeNamespace = e;
			this.mustUseProperty = c;
			this.propertyName = a;
			this.type = b;
			this.sanitizeURL = f;
			this.removeEmptyString = g;
		}
		var z = {};
		"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(a) {
			z[a] = new v(a, 0, !1, a, null, !1, !1);
		});
		[
			["acceptCharset", "accept-charset"],
			["className", "class"],
			["htmlFor", "for"],
			["httpEquiv", "http-equiv"]
		].forEach(function(a) {
			var b = a[0];
			z[b] = new v(b, 1, !1, a[1], null, !1, !1);
		});
		[
			"contentEditable",
			"draggable",
			"spellCheck",
			"value"
		].forEach(function(a) {
			z[a] = new v(a, 2, !1, a.toLowerCase(), null, !1, !1);
		});
		[
			"autoReverse",
			"externalResourcesRequired",
			"focusable",
			"preserveAlpha"
		].forEach(function(a) {
			z[a] = new v(a, 2, !1, a, null, !1, !1);
		});
		"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(a) {
			z[a] = new v(a, 3, !1, a.toLowerCase(), null, !1, !1);
		});
		[
			"checked",
			"multiple",
			"muted",
			"selected"
		].forEach(function(a) {
			z[a] = new v(a, 3, !0, a, null, !1, !1);
		});
		["capture", "download"].forEach(function(a) {
			z[a] = new v(a, 4, !1, a, null, !1, !1);
		});
		[
			"cols",
			"rows",
			"size",
			"span"
		].forEach(function(a) {
			z[a] = new v(a, 6, !1, a, null, !1, !1);
		});
		["rowSpan", "start"].forEach(function(a) {
			z[a] = new v(a, 5, !1, a.toLowerCase(), null, !1, !1);
		});
		var ra = /[\-:]([a-z])/g;
		function sa(a) {
			return a[1].toUpperCase();
		}
		"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(a) {
			var b = a.replace(ra, sa);
			z[b] = new v(b, 1, !1, a, null, !1, !1);
		});
		"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(a) {
			var b = a.replace(ra, sa);
			z[b] = new v(b, 1, !1, a, "http://www.w3.org/1999/xlink", !1, !1);
		});
		[
			"xml:base",
			"xml:lang",
			"xml:space"
		].forEach(function(a) {
			var b = a.replace(ra, sa);
			z[b] = new v(b, 1, !1, a, "http://www.w3.org/XML/1998/namespace", !1, !1);
		});
		["tabIndex", "crossOrigin"].forEach(function(a) {
			z[a] = new v(a, 1, !1, a.toLowerCase(), null, !1, !1);
		});
		z.xlinkHref = new v("xlinkHref", 1, !1, "xlink:href", "http://www.w3.org/1999/xlink", !0, !1);
		[
			"src",
			"href",
			"action",
			"formAction"
		].forEach(function(a) {
			z[a] = new v(a, 1, !1, a.toLowerCase(), null, !0, !0);
		});
		function ta(a, b, c, d) {
			var e = z.hasOwnProperty(b) ? z[b] : null;
			if (null !== e ? 0 !== e.type : d || !(2 < b.length) || "o" !== b[0] && "O" !== b[0] || "n" !== b[1] && "N" !== b[1]) qa(b, c, e, d) && (c = null), d || null === e ? oa(b) && (null === c ? a.removeAttribute(b) : a.setAttribute(b, "" + c)) : e.mustUseProperty ? a[e.propertyName] = null === c ? 3 === e.type ? !1 : "" : c : (b = e.attributeName, d = e.attributeNamespace, null === c ? a.removeAttribute(b) : (e = e.type, c = 3 === e || 4 === e && !0 === c ? "" : "" + c, d ? a.setAttributeNS(d, b, c) : a.setAttribute(b, c)));
		}
		var ua = aa.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
		var va = Symbol.for("react.element");
		var wa = Symbol.for("react.portal");
		var ya = Symbol.for("react.fragment");
		var za = Symbol.for("react.strict_mode");
		var Aa = Symbol.for("react.profiler");
		var Ba = Symbol.for("react.provider");
		var Ca = Symbol.for("react.context");
		var Da = Symbol.for("react.forward_ref");
		var Ea = Symbol.for("react.suspense");
		var Fa = Symbol.for("react.suspense_list");
		var Ga = Symbol.for("react.memo");
		var Ha = Symbol.for("react.lazy");
		var Ia = Symbol.for("react.offscreen");
		var Ja = Symbol.iterator;
		function Ka(a) {
			if (null === a || "object" !== typeof a) return null;
			a = Ja && a[Ja] || a["@@iterator"];
			return "function" === typeof a ? a : null;
		}
		var A = Object.assign;
		var La;
		function Ma(a) {
			if (void 0 === La) try {
				throw Error();
			} catch (c) {
				var b = c.stack.trim().match(/\n( *(at )?)/);
				La = b && b[1] || "";
			}
			return "\n" + La + a;
		}
		var Na = !1;
		function Oa(a, b) {
			if (!a || Na) return "";
			Na = !0;
			var c = Error.prepareStackTrace;
			Error.prepareStackTrace = void 0;
			try {
				if (b) if (b = function() {
					throw Error();
				}, Object.defineProperty(b.prototype, "props", { set: function() {
					throw Error();
				} }), "object" === typeof Reflect && Reflect.construct) {
					try {
						Reflect.construct(b, []);
					} catch (l) {
						var d = l;
					}
					Reflect.construct(a, [], b);
				} else {
					try {
						b.call();
					} catch (l) {
						d = l;
					}
					a.call(b.prototype);
				}
				else {
					try {
						throw Error();
					} catch (l) {
						d = l;
					}
					a();
				}
			} catch (l) {
				if (l && d && "string" === typeof l.stack) {
					for (var e = l.stack.split("\n"), f = d.stack.split("\n"), g = e.length - 1, h = f.length - 1; 1 <= g && 0 <= h && e[g] !== f[h];) h--;
					for (; 1 <= g && 0 <= h; g--, h--) if (e[g] !== f[h]) {
						if (1 !== g || 1 !== h) do
							if (g--, h--, 0 > h || e[g] !== f[h]) {
								var k = "\n" + e[g].replace(" at new ", " at ");
								a.displayName && k.includes("<anonymous>") && (k = k.replace("<anonymous>", a.displayName));
								return k;
							}
						while (1 <= g && 0 <= h);
						break;
					}
				}
			} finally {
				Na = !1, Error.prepareStackTrace = c;
			}
			return (a = a ? a.displayName || a.name : "") ? Ma(a) : "";
		}
		function Pa(a) {
			switch (a.tag) {
				case 5: return Ma(a.type);
				case 16: return Ma("Lazy");
				case 13: return Ma("Suspense");
				case 19: return Ma("SuspenseList");
				case 0:
				case 2:
				case 15: return a = Oa(a.type, !1), a;
				case 11: return a = Oa(a.type.render, !1), a;
				case 1: return a = Oa(a.type, !0), a;
				default: return "";
			}
		}
		function Qa(a) {
			if (null == a) return null;
			if ("function" === typeof a) return a.displayName || a.name || null;
			if ("string" === typeof a) return a;
			switch (a) {
				case ya: return "Fragment";
				case wa: return "Portal";
				case Aa: return "Profiler";
				case za: return "StrictMode";
				case Ea: return "Suspense";
				case Fa: return "SuspenseList";
			}
			if ("object" === typeof a) switch (a.$$typeof) {
				case Ca: return (a.displayName || "Context") + ".Consumer";
				case Ba: return (a._context.displayName || "Context") + ".Provider";
				case Da:
					var b = a.render;
					a = a.displayName;
					a || (a = b.displayName || b.name || "", a = "" !== a ? "ForwardRef(" + a + ")" : "ForwardRef");
					return a;
				case Ga: return b = a.displayName || null, null !== b ? b : Qa(a.type) || "Memo";
				case Ha:
					b = a._payload;
					a = a._init;
					try {
						return Qa(a(b));
					} catch (c) {}
			}
			return null;
		}
		function Ra(a) {
			var b = a.type;
			switch (a.tag) {
				case 24: return "Cache";
				case 9: return (b.displayName || "Context") + ".Consumer";
				case 10: return (b._context.displayName || "Context") + ".Provider";
				case 18: return "DehydratedFragment";
				case 11: return a = b.render, a = a.displayName || a.name || "", b.displayName || ("" !== a ? "ForwardRef(" + a + ")" : "ForwardRef");
				case 7: return "Fragment";
				case 5: return b;
				case 4: return "Portal";
				case 3: return "Root";
				case 6: return "Text";
				case 16: return Qa(b);
				case 8: return b === za ? "StrictMode" : "Mode";
				case 22: return "Offscreen";
				case 12: return "Profiler";
				case 21: return "Scope";
				case 13: return "Suspense";
				case 19: return "SuspenseList";
				case 25: return "TracingMarker";
				case 1:
				case 0:
				case 17:
				case 2:
				case 14:
				case 15:
					if ("function" === typeof b) return b.displayName || b.name || null;
					if ("string" === typeof b) return b;
			}
			return null;
		}
		function Sa(a) {
			switch (typeof a) {
				case "boolean":
				case "number":
				case "string":
				case "undefined": return a;
				case "object": return a;
				default: return "";
			}
		}
		function Ta(a) {
			var b = a.type;
			return (a = a.nodeName) && "input" === a.toLowerCase() && ("checkbox" === b || "radio" === b);
		}
		function Ua(a) {
			var b = Ta(a) ? "checked" : "value", c = Object.getOwnPropertyDescriptor(a.constructor.prototype, b), d = "" + a[b];
			if (!a.hasOwnProperty(b) && "undefined" !== typeof c && "function" === typeof c.get && "function" === typeof c.set) {
				var e = c.get, f = c.set;
				Object.defineProperty(a, b, {
					configurable: !0,
					get: function() {
						return e.call(this);
					},
					set: function(a) {
						d = "" + a;
						f.call(this, a);
					}
				});
				Object.defineProperty(a, b, { enumerable: c.enumerable });
				return {
					getValue: function() {
						return d;
					},
					setValue: function(a) {
						d = "" + a;
					},
					stopTracking: function() {
						a._valueTracker = null;
						delete a[b];
					}
				};
			}
		}
		function Va(a) {
			a._valueTracker || (a._valueTracker = Ua(a));
		}
		function Wa(a) {
			if (!a) return !1;
			var b = a._valueTracker;
			if (!b) return !0;
			var c = b.getValue();
			var d = "";
			a && (d = Ta(a) ? a.checked ? "true" : "false" : a.value);
			a = d;
			return a !== c ? (b.setValue(a), !0) : !1;
		}
		function Xa(a) {
			a = a || ("undefined" !== typeof document ? document : void 0);
			if ("undefined" === typeof a) return null;
			try {
				return a.activeElement || a.body;
			} catch (b) {
				return a.body;
			}
		}
		function Ya(a, b) {
			var c = b.checked;
			return A({}, b, {
				defaultChecked: void 0,
				defaultValue: void 0,
				value: void 0,
				checked: null != c ? c : a._wrapperState.initialChecked
			});
		}
		function Za(a, b) {
			var c = null == b.defaultValue ? "" : b.defaultValue, d = null != b.checked ? b.checked : b.defaultChecked;
			c = Sa(null != b.value ? b.value : c);
			a._wrapperState = {
				initialChecked: d,
				initialValue: c,
				controlled: "checkbox" === b.type || "radio" === b.type ? null != b.checked : null != b.value
			};
		}
		function ab(a, b) {
			b = b.checked;
			null != b && ta(a, "checked", b, !1);
		}
		function bb(a, b) {
			ab(a, b);
			var c = Sa(b.value), d = b.type;
			if (null != c) if ("number" === d) {
				if (0 === c && "" === a.value || a.value != c) a.value = "" + c;
			} else a.value !== "" + c && (a.value = "" + c);
			else if ("submit" === d || "reset" === d) {
				a.removeAttribute("value");
				return;
			}
			b.hasOwnProperty("value") ? cb(a, b.type, c) : b.hasOwnProperty("defaultValue") && cb(a, b.type, Sa(b.defaultValue));
			null == b.checked && null != b.defaultChecked && (a.defaultChecked = !!b.defaultChecked);
		}
		function db(a, b, c) {
			if (b.hasOwnProperty("value") || b.hasOwnProperty("defaultValue")) {
				var d = b.type;
				if (!("submit" !== d && "reset" !== d || void 0 !== b.value && null !== b.value)) return;
				b = "" + a._wrapperState.initialValue;
				c || b === a.value || (a.value = b);
				a.defaultValue = b;
			}
			c = a.name;
			"" !== c && (a.name = "");
			a.defaultChecked = !!a._wrapperState.initialChecked;
			"" !== c && (a.name = c);
		}
		function cb(a, b, c) {
			if ("number" !== b || Xa(a.ownerDocument) !== a) null == c ? a.defaultValue = "" + a._wrapperState.initialValue : a.defaultValue !== "" + c && (a.defaultValue = "" + c);
		}
		var eb = Array.isArray;
		function fb(a, b, c, d) {
			a = a.options;
			if (b) {
				b = {};
				for (var e = 0; e < c.length; e++) b["$" + c[e]] = !0;
				for (c = 0; c < a.length; c++) e = b.hasOwnProperty("$" + a[c].value), a[c].selected !== e && (a[c].selected = e), e && d && (a[c].defaultSelected = !0);
			} else {
				c = "" + Sa(c);
				b = null;
				for (e = 0; e < a.length; e++) {
					if (a[e].value === c) {
						a[e].selected = !0;
						d && (a[e].defaultSelected = !0);
						return;
					}
					null !== b || a[e].disabled || (b = a[e]);
				}
				null !== b && (b.selected = !0);
			}
		}
		function gb(a, b) {
			if (null != b.dangerouslySetInnerHTML) throw Error(p(91));
			return A({}, b, {
				value: void 0,
				defaultValue: void 0,
				children: "" + a._wrapperState.initialValue
			});
		}
		function hb(a, b) {
			var c = b.value;
			if (null == c) {
				c = b.children;
				b = b.defaultValue;
				if (null != c) {
					if (null != b) throw Error(p(92));
					if (eb(c)) {
						if (1 < c.length) throw Error(p(93));
						c = c[0];
					}
					b = c;
				}
				null == b && (b = "");
				c = b;
			}
			a._wrapperState = { initialValue: Sa(c) };
		}
		function ib(a, b) {
			var c = Sa(b.value), d = Sa(b.defaultValue);
			null != c && (c = "" + c, c !== a.value && (a.value = c), null == b.defaultValue && a.defaultValue !== c && (a.defaultValue = c));
			null != d && (a.defaultValue = "" + d);
		}
		function jb(a) {
			var b = a.textContent;
			b === a._wrapperState.initialValue && "" !== b && null !== b && (a.value = b);
		}
		function kb(a) {
			switch (a) {
				case "svg": return "http://www.w3.org/2000/svg";
				case "math": return "http://www.w3.org/1998/Math/MathML";
				default: return "http://www.w3.org/1999/xhtml";
			}
		}
		function lb(a, b) {
			return null == a || "http://www.w3.org/1999/xhtml" === a ? kb(b) : "http://www.w3.org/2000/svg" === a && "foreignObject" === b ? "http://www.w3.org/1999/xhtml" : a;
		}
		var mb;
		var nb = function(a) {
			return "undefined" !== typeof MSApp && MSApp.execUnsafeLocalFunction ? function(b, c, d, e) {
				MSApp.execUnsafeLocalFunction(function() {
					return a(b, c, d, e);
				});
			} : a;
		}(function(a, b) {
			if ("http://www.w3.org/2000/svg" !== a.namespaceURI || "innerHTML" in a) a.innerHTML = b;
			else {
				mb = mb || document.createElement("div");
				mb.innerHTML = "<svg>" + b.valueOf().toString() + "</svg>";
				for (b = mb.firstChild; a.firstChild;) a.removeChild(a.firstChild);
				for (; b.firstChild;) a.appendChild(b.firstChild);
			}
		});
		function ob(a, b) {
			if (b) {
				var c = a.firstChild;
				if (c && c === a.lastChild && 3 === c.nodeType) {
					c.nodeValue = b;
					return;
				}
			}
			a.textContent = b;
		}
		var pb = {
			animationIterationCount: !0,
			aspectRatio: !0,
			borderImageOutset: !0,
			borderImageSlice: !0,
			borderImageWidth: !0,
			boxFlex: !0,
			boxFlexGroup: !0,
			boxOrdinalGroup: !0,
			columnCount: !0,
			columns: !0,
			flex: !0,
			flexGrow: !0,
			flexPositive: !0,
			flexShrink: !0,
			flexNegative: !0,
			flexOrder: !0,
			gridArea: !0,
			gridRow: !0,
			gridRowEnd: !0,
			gridRowSpan: !0,
			gridRowStart: !0,
			gridColumn: !0,
			gridColumnEnd: !0,
			gridColumnSpan: !0,
			gridColumnStart: !0,
			fontWeight: !0,
			lineClamp: !0,
			lineHeight: !0,
			opacity: !0,
			order: !0,
			orphans: !0,
			tabSize: !0,
			widows: !0,
			zIndex: !0,
			zoom: !0,
			fillOpacity: !0,
			floodOpacity: !0,
			stopOpacity: !0,
			strokeDasharray: !0,
			strokeDashoffset: !0,
			strokeMiterlimit: !0,
			strokeOpacity: !0,
			strokeWidth: !0
		};
		var qb = [
			"Webkit",
			"ms",
			"Moz",
			"O"
		];
		Object.keys(pb).forEach(function(a) {
			qb.forEach(function(b) {
				b = b + a.charAt(0).toUpperCase() + a.substring(1);
				pb[b] = pb[a];
			});
		});
		function rb(a, b, c) {
			return null == b || "boolean" === typeof b || "" === b ? "" : c || "number" !== typeof b || 0 === b || pb.hasOwnProperty(a) && pb[a] ? ("" + b).trim() : b + "px";
		}
		function sb(a, b) {
			a = a.style;
			for (var c in b) if (b.hasOwnProperty(c)) {
				var d = 0 === c.indexOf("--"), e = rb(c, b[c], d);
				"float" === c && (c = "cssFloat");
				d ? a.setProperty(c, e) : a[c] = e;
			}
		}
		var tb = A({ menuitem: !0 }, {
			area: !0,
			base: !0,
			br: !0,
			col: !0,
			embed: !0,
			hr: !0,
			img: !0,
			input: !0,
			keygen: !0,
			link: !0,
			meta: !0,
			param: !0,
			source: !0,
			track: !0,
			wbr: !0
		});
		function ub(a, b) {
			if (b) {
				if (tb[a] && (null != b.children || null != b.dangerouslySetInnerHTML)) throw Error(p(137, a));
				if (null != b.dangerouslySetInnerHTML) {
					if (null != b.children) throw Error(p(60));
					if ("object" !== typeof b.dangerouslySetInnerHTML || !("__html" in b.dangerouslySetInnerHTML)) throw Error(p(61));
				}
				if (null != b.style && "object" !== typeof b.style) throw Error(p(62));
			}
		}
		function vb(a, b) {
			if (-1 === a.indexOf("-")) return "string" === typeof b.is;
			switch (a) {
				case "annotation-xml":
				case "color-profile":
				case "font-face":
				case "font-face-src":
				case "font-face-uri":
				case "font-face-format":
				case "font-face-name":
				case "missing-glyph": return !1;
				default: return !0;
			}
		}
		var wb = null;
		function xb(a) {
			a = a.target || a.srcElement || window;
			a.correspondingUseElement && (a = a.correspondingUseElement);
			return 3 === a.nodeType ? a.parentNode : a;
		}
		var yb = null;
		var zb = null;
		var Ab = null;
		function Bb(a) {
			if (a = Cb(a)) {
				if ("function" !== typeof yb) throw Error(p(280));
				var b = a.stateNode;
				b && (b = Db(b), yb(a.stateNode, a.type, b));
			}
		}
		function Eb(a) {
			zb ? Ab ? Ab.push(a) : Ab = [a] : zb = a;
		}
		function Fb() {
			if (zb) {
				var a = zb, b = Ab;
				Ab = zb = null;
				Bb(a);
				if (b) for (a = 0; a < b.length; a++) Bb(b[a]);
			}
		}
		function Gb(a, b) {
			return a(b);
		}
		function Hb() {}
		var Ib = !1;
		function Jb(a, b, c) {
			if (Ib) return a(b, c);
			Ib = !0;
			try {
				return Gb(a, b, c);
			} finally {
				if (Ib = !1, null !== zb || null !== Ab) Hb(), Fb();
			}
		}
		function Kb(a, b) {
			var c = a.stateNode;
			if (null === c) return null;
			var d = Db(c);
			if (null === d) return null;
			c = d[b];
			a: switch (b) {
				case "onClick":
				case "onClickCapture":
				case "onDoubleClick":
				case "onDoubleClickCapture":
				case "onMouseDown":
				case "onMouseDownCapture":
				case "onMouseMove":
				case "onMouseMoveCapture":
				case "onMouseUp":
				case "onMouseUpCapture":
				case "onMouseEnter":
					(d = !d.disabled) || (a = a.type, d = !("button" === a || "input" === a || "select" === a || "textarea" === a));
					a = !d;
					break a;
				default: a = !1;
			}
			if (a) return null;
			if (c && "function" !== typeof c) throw Error(p(231, b, typeof c));
			return c;
		}
		var Lb = !1;
		if (ia) try {
			var Mb = {};
			Object.defineProperty(Mb, "passive", { get: function() {
				Lb = !0;
			} });
			window.addEventListener("test", Mb, Mb);
			window.removeEventListener("test", Mb, Mb);
		} catch (a) {
			Lb = !1;
		}
		function Nb(a, b, c, d, e, f, g, h, k) {
			var l = Array.prototype.slice.call(arguments, 3);
			try {
				b.apply(c, l);
			} catch (m) {
				this.onError(m);
			}
		}
		var Ob = !1;
		var Pb = null;
		var Qb = !1;
		var Rb = null;
		var Sb = { onError: function(a) {
			Ob = !0;
			Pb = a;
		} };
		function Tb(a, b, c, d, e, f, g, h, k) {
			Ob = !1;
			Pb = null;
			Nb.apply(Sb, arguments);
		}
		function Ub(a, b, c, d, e, f, g, h, k) {
			Tb.apply(this, arguments);
			if (Ob) {
				if (Ob) {
					var l = Pb;
					Ob = !1;
					Pb = null;
				} else throw Error(p(198));
				Qb || (Qb = !0, Rb = l);
			}
		}
		function Vb(a) {
			var b = a, c = a;
			if (a.alternate) for (; b.return;) b = b.return;
			else {
				a = b;
				do
					b = a, 0 !== (b.flags & 4098) && (c = b.return), a = b.return;
				while (a);
			}
			return 3 === b.tag ? c : null;
		}
		function Wb(a) {
			if (13 === a.tag) {
				var b = a.memoizedState;
				null === b && (a = a.alternate, null !== a && (b = a.memoizedState));
				if (null !== b) return b.dehydrated;
			}
			return null;
		}
		function Xb(a) {
			if (Vb(a) !== a) throw Error(p(188));
		}
		function Yb(a) {
			var b = a.alternate;
			if (!b) {
				b = Vb(a);
				if (null === b) throw Error(p(188));
				return b !== a ? null : a;
			}
			for (var c = a, d = b;;) {
				var e = c.return;
				if (null === e) break;
				var f = e.alternate;
				if (null === f) {
					d = e.return;
					if (null !== d) {
						c = d;
						continue;
					}
					break;
				}
				if (e.child === f.child) {
					for (f = e.child; f;) {
						if (f === c) return Xb(e), a;
						if (f === d) return Xb(e), b;
						f = f.sibling;
					}
					throw Error(p(188));
				}
				if (c.return !== d.return) c = e, d = f;
				else {
					for (var g = !1, h = e.child; h;) {
						if (h === c) {
							g = !0;
							c = e;
							d = f;
							break;
						}
						if (h === d) {
							g = !0;
							d = e;
							c = f;
							break;
						}
						h = h.sibling;
					}
					if (!g) {
						for (h = f.child; h;) {
							if (h === c) {
								g = !0;
								c = f;
								d = e;
								break;
							}
							if (h === d) {
								g = !0;
								d = f;
								c = e;
								break;
							}
							h = h.sibling;
						}
						if (!g) throw Error(p(189));
					}
				}
				if (c.alternate !== d) throw Error(p(190));
			}
			if (3 !== c.tag) throw Error(p(188));
			return c.stateNode.current === c ? a : b;
		}
		function Zb(a) {
			a = Yb(a);
			return null !== a ? $b(a) : null;
		}
		function $b(a) {
			if (5 === a.tag || 6 === a.tag) return a;
			for (a = a.child; null !== a;) {
				var b = $b(a);
				if (null !== b) return b;
				a = a.sibling;
			}
			return null;
		}
		var ac = ca.unstable_scheduleCallback;
		var bc = ca.unstable_cancelCallback;
		var cc = ca.unstable_shouldYield;
		var dc = ca.unstable_requestPaint;
		var B = ca.unstable_now;
		var ec = ca.unstable_getCurrentPriorityLevel;
		var fc = ca.unstable_ImmediatePriority;
		var gc = ca.unstable_UserBlockingPriority;
		var hc = ca.unstable_NormalPriority;
		var ic = ca.unstable_LowPriority;
		var jc = ca.unstable_IdlePriority;
		var kc = null;
		var lc = null;
		function mc(a) {
			if (lc && "function" === typeof lc.onCommitFiberRoot) try {
				lc.onCommitFiberRoot(kc, a, void 0, 128 === (a.current.flags & 128));
			} catch (b) {}
		}
		var oc = Math.clz32 ? Math.clz32 : nc;
		var pc = Math.log;
		var qc = Math.LN2;
		function nc(a) {
			a >>>= 0;
			return 0 === a ? 32 : 31 - (pc(a) / qc | 0) | 0;
		}
		var rc = 64;
		var sc = 4194304;
		function tc(a) {
			switch (a & -a) {
				case 1: return 1;
				case 2: return 2;
				case 4: return 4;
				case 8: return 8;
				case 16: return 16;
				case 32: return 32;
				case 64:
				case 128:
				case 256:
				case 512:
				case 1024:
				case 2048:
				case 4096:
				case 8192:
				case 16384:
				case 32768:
				case 65536:
				case 131072:
				case 262144:
				case 524288:
				case 1048576:
				case 2097152: return a & 4194240;
				case 4194304:
				case 8388608:
				case 16777216:
				case 33554432:
				case 67108864: return a & 130023424;
				case 134217728: return 134217728;
				case 268435456: return 268435456;
				case 536870912: return 536870912;
				case 1073741824: return 1073741824;
				default: return a;
			}
		}
		function uc(a, b) {
			var c = a.pendingLanes;
			if (0 === c) return 0;
			var d = 0, e = a.suspendedLanes, f = a.pingedLanes, g = c & 268435455;
			if (0 !== g) {
				var h = g & ~e;
				0 !== h ? d = tc(h) : (f &= g, 0 !== f && (d = tc(f)));
			} else g = c & ~e, 0 !== g ? d = tc(g) : 0 !== f && (d = tc(f));
			if (0 === d) return 0;
			if (0 !== b && b !== d && 0 === (b & e) && (e = d & -d, f = b & -b, e >= f || 16 === e && 0 !== (f & 4194240))) return b;
			0 !== (d & 4) && (d |= c & 16);
			b = a.entangledLanes;
			if (0 !== b) for (a = a.entanglements, b &= d; 0 < b;) c = 31 - oc(b), e = 1 << c, d |= a[c], b &= ~e;
			return d;
		}
		function vc(a, b) {
			switch (a) {
				case 1:
				case 2:
				case 4: return b + 250;
				case 8:
				case 16:
				case 32:
				case 64:
				case 128:
				case 256:
				case 512:
				case 1024:
				case 2048:
				case 4096:
				case 8192:
				case 16384:
				case 32768:
				case 65536:
				case 131072:
				case 262144:
				case 524288:
				case 1048576:
				case 2097152: return b + 5e3;
				case 4194304:
				case 8388608:
				case 16777216:
				case 33554432:
				case 67108864: return -1;
				case 134217728:
				case 268435456:
				case 536870912:
				case 1073741824: return -1;
				default: return -1;
			}
		}
		function wc(a, b) {
			for (var c = a.suspendedLanes, d = a.pingedLanes, e = a.expirationTimes, f = a.pendingLanes; 0 < f;) {
				var g = 31 - oc(f), h = 1 << g, k = e[g];
				if (-1 === k) {
					if (0 === (h & c) || 0 !== (h & d)) e[g] = vc(h, b);
				} else k <= b && (a.expiredLanes |= h);
				f &= ~h;
			}
		}
		function xc(a) {
			a = a.pendingLanes & -1073741825;
			return 0 !== a ? a : a & 1073741824 ? 1073741824 : 0;
		}
		function yc() {
			var a = rc;
			rc <<= 1;
			0 === (rc & 4194240) && (rc = 64);
			return a;
		}
		function zc(a) {
			for (var b = [], c = 0; 31 > c; c++) b.push(a);
			return b;
		}
		function Ac(a, b, c) {
			a.pendingLanes |= b;
			536870912 !== b && (a.suspendedLanes = 0, a.pingedLanes = 0);
			a = a.eventTimes;
			b = 31 - oc(b);
			a[b] = c;
		}
		function Bc(a, b) {
			var c = a.pendingLanes & ~b;
			a.pendingLanes = b;
			a.suspendedLanes = 0;
			a.pingedLanes = 0;
			a.expiredLanes &= b;
			a.mutableReadLanes &= b;
			a.entangledLanes &= b;
			b = a.entanglements;
			var d = a.eventTimes;
			for (a = a.expirationTimes; 0 < c;) {
				var e = 31 - oc(c), f = 1 << e;
				b[e] = 0;
				d[e] = -1;
				a[e] = -1;
				c &= ~f;
			}
		}
		function Cc(a, b) {
			var c = a.entangledLanes |= b;
			for (a = a.entanglements; c;) {
				var d = 31 - oc(c), e = 1 << d;
				e & b | a[d] & b && (a[d] |= b);
				c &= ~e;
			}
		}
		var C = 0;
		function Dc(a) {
			a &= -a;
			return 1 < a ? 4 < a ? 0 !== (a & 268435455) ? 16 : 536870912 : 4 : 1;
		}
		var Ec;
		var Fc;
		var Gc;
		var Hc;
		var Ic;
		var Jc = !1;
		var Kc = [];
		var Lc = null;
		var Mc = null;
		var Nc = null;
		var Oc = /* @__PURE__ */ new Map();
		var Pc = /* @__PURE__ */ new Map();
		var Qc = [];
		var Rc = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
		function Sc(a, b) {
			switch (a) {
				case "focusin":
				case "focusout":
					Lc = null;
					break;
				case "dragenter":
				case "dragleave":
					Mc = null;
					break;
				case "mouseover":
				case "mouseout":
					Nc = null;
					break;
				case "pointerover":
				case "pointerout":
					Oc.delete(b.pointerId);
					break;
				case "gotpointercapture":
				case "lostpointercapture": Pc.delete(b.pointerId);
			}
		}
		function Tc(a, b, c, d, e, f) {
			if (null === a || a.nativeEvent !== f) return a = {
				blockedOn: b,
				domEventName: c,
				eventSystemFlags: d,
				nativeEvent: f,
				targetContainers: [e]
			}, null !== b && (b = Cb(b), null !== b && Fc(b)), a;
			a.eventSystemFlags |= d;
			b = a.targetContainers;
			null !== e && -1 === b.indexOf(e) && b.push(e);
			return a;
		}
		function Uc(a, b, c, d, e) {
			switch (b) {
				case "focusin": return Lc = Tc(Lc, a, b, c, d, e), !0;
				case "dragenter": return Mc = Tc(Mc, a, b, c, d, e), !0;
				case "mouseover": return Nc = Tc(Nc, a, b, c, d, e), !0;
				case "pointerover":
					var f = e.pointerId;
					Oc.set(f, Tc(Oc.get(f) || null, a, b, c, d, e));
					return !0;
				case "gotpointercapture": return f = e.pointerId, Pc.set(f, Tc(Pc.get(f) || null, a, b, c, d, e)), !0;
			}
			return !1;
		}
		function Vc(a) {
			var b = Wc(a.target);
			if (null !== b) {
				var c = Vb(b);
				if (null !== c) {
					if (b = c.tag, 13 === b) {
						if (b = Wb(c), null !== b) {
							a.blockedOn = b;
							Ic(a.priority, function() {
								Gc(c);
							});
							return;
						}
					} else if (3 === b && c.stateNode.current.memoizedState.isDehydrated) {
						a.blockedOn = 3 === c.tag ? c.stateNode.containerInfo : null;
						return;
					}
				}
			}
			a.blockedOn = null;
		}
		function Xc(a) {
			if (null !== a.blockedOn) return !1;
			for (var b = a.targetContainers; 0 < b.length;) {
				var c = Yc(a.domEventName, a.eventSystemFlags, b[0], a.nativeEvent);
				if (null === c) {
					c = a.nativeEvent;
					var d = new c.constructor(c.type, c);
					wb = d;
					c.target.dispatchEvent(d);
					wb = null;
				} else return b = Cb(c), null !== b && Fc(b), a.blockedOn = c, !1;
				b.shift();
			}
			return !0;
		}
		function Zc(a, b, c) {
			Xc(a) && c.delete(b);
		}
		function $c() {
			Jc = !1;
			null !== Lc && Xc(Lc) && (Lc = null);
			null !== Mc && Xc(Mc) && (Mc = null);
			null !== Nc && Xc(Nc) && (Nc = null);
			Oc.forEach(Zc);
			Pc.forEach(Zc);
		}
		function ad(a, b) {
			a.blockedOn === b && (a.blockedOn = null, Jc || (Jc = !0, ca.unstable_scheduleCallback(ca.unstable_NormalPriority, $c)));
		}
		function bd(a) {
			function b(b) {
				return ad(b, a);
			}
			if (0 < Kc.length) {
				ad(Kc[0], a);
				for (var c = 1; c < Kc.length; c++) {
					var d = Kc[c];
					d.blockedOn === a && (d.blockedOn = null);
				}
			}
			null !== Lc && ad(Lc, a);
			null !== Mc && ad(Mc, a);
			null !== Nc && ad(Nc, a);
			Oc.forEach(b);
			Pc.forEach(b);
			for (c = 0; c < Qc.length; c++) d = Qc[c], d.blockedOn === a && (d.blockedOn = null);
			for (; 0 < Qc.length && (c = Qc[0], null === c.blockedOn);) Vc(c), null === c.blockedOn && Qc.shift();
		}
		var cd = ua.ReactCurrentBatchConfig;
		var dd = !0;
		function ed(a, b, c, d) {
			var e = C, f = cd.transition;
			cd.transition = null;
			try {
				C = 1, fd(a, b, c, d);
			} finally {
				C = e, cd.transition = f;
			}
		}
		function gd(a, b, c, d) {
			var e = C, f = cd.transition;
			cd.transition = null;
			try {
				C = 4, fd(a, b, c, d);
			} finally {
				C = e, cd.transition = f;
			}
		}
		function fd(a, b, c, d) {
			if (dd) {
				var e = Yc(a, b, c, d);
				if (null === e) hd(a, b, d, id, c), Sc(a, d);
				else if (Uc(e, a, b, c, d)) d.stopPropagation();
				else if (Sc(a, d), b & 4 && -1 < Rc.indexOf(a)) {
					for (; null !== e;) {
						var f = Cb(e);
						null !== f && Ec(f);
						f = Yc(a, b, c, d);
						null === f && hd(a, b, d, id, c);
						if (f === e) break;
						e = f;
					}
					null !== e && d.stopPropagation();
				} else hd(a, b, d, null, c);
			}
		}
		var id = null;
		function Yc(a, b, c, d) {
			id = null;
			a = xb(d);
			a = Wc(a);
			if (null !== a) if (b = Vb(a), null === b) a = null;
			else if (c = b.tag, 13 === c) {
				a = Wb(b);
				if (null !== a) return a;
				a = null;
			} else if (3 === c) {
				if (b.stateNode.current.memoizedState.isDehydrated) return 3 === b.tag ? b.stateNode.containerInfo : null;
				a = null;
			} else b !== a && (a = null);
			id = a;
			return null;
		}
		function jd(a) {
			switch (a) {
				case "cancel":
				case "click":
				case "close":
				case "contextmenu":
				case "copy":
				case "cut":
				case "auxclick":
				case "dblclick":
				case "dragend":
				case "dragstart":
				case "drop":
				case "focusin":
				case "focusout":
				case "input":
				case "invalid":
				case "keydown":
				case "keypress":
				case "keyup":
				case "mousedown":
				case "mouseup":
				case "paste":
				case "pause":
				case "play":
				case "pointercancel":
				case "pointerdown":
				case "pointerup":
				case "ratechange":
				case "reset":
				case "resize":
				case "seeked":
				case "submit":
				case "touchcancel":
				case "touchend":
				case "touchstart":
				case "volumechange":
				case "change":
				case "selectionchange":
				case "textInput":
				case "compositionstart":
				case "compositionend":
				case "compositionupdate":
				case "beforeblur":
				case "afterblur":
				case "beforeinput":
				case "blur":
				case "fullscreenchange":
				case "focus":
				case "hashchange":
				case "popstate":
				case "select":
				case "selectstart": return 1;
				case "drag":
				case "dragenter":
				case "dragexit":
				case "dragleave":
				case "dragover":
				case "mousemove":
				case "mouseout":
				case "mouseover":
				case "pointermove":
				case "pointerout":
				case "pointerover":
				case "scroll":
				case "toggle":
				case "touchmove":
				case "wheel":
				case "mouseenter":
				case "mouseleave":
				case "pointerenter":
				case "pointerleave": return 4;
				case "message": switch (ec()) {
					case fc: return 1;
					case gc: return 4;
					case hc:
					case ic: return 16;
					case jc: return 536870912;
					default: return 16;
				}
				default: return 16;
			}
		}
		var kd = null;
		var ld = null;
		var md = null;
		function nd() {
			if (md) return md;
			var a, b = ld, c = b.length, d, e = "value" in kd ? kd.value : kd.textContent, f = e.length;
			for (a = 0; a < c && b[a] === e[a]; a++);
			var g = c - a;
			for (d = 1; d <= g && b[c - d] === e[f - d]; d++);
			return md = e.slice(a, 1 < d ? 1 - d : void 0);
		}
		function od(a) {
			var b = a.keyCode;
			"charCode" in a ? (a = a.charCode, 0 === a && 13 === b && (a = 13)) : a = b;
			10 === a && (a = 13);
			return 32 <= a || 13 === a ? a : 0;
		}
		function pd() {
			return !0;
		}
		function qd() {
			return !1;
		}
		function rd(a) {
			function b(b, d, e, f, g) {
				this._reactName = b;
				this._targetInst = e;
				this.type = d;
				this.nativeEvent = f;
				this.target = g;
				this.currentTarget = null;
				for (var c in a) a.hasOwnProperty(c) && (b = a[c], this[c] = b ? b(f) : f[c]);
				this.isDefaultPrevented = (null != f.defaultPrevented ? f.defaultPrevented : !1 === f.returnValue) ? pd : qd;
				this.isPropagationStopped = qd;
				return this;
			}
			A(b.prototype, {
				preventDefault: function() {
					this.defaultPrevented = !0;
					var a = this.nativeEvent;
					a && (a.preventDefault ? a.preventDefault() : "unknown" !== typeof a.returnValue && (a.returnValue = !1), this.isDefaultPrevented = pd);
				},
				stopPropagation: function() {
					var a = this.nativeEvent;
					a && (a.stopPropagation ? a.stopPropagation() : "unknown" !== typeof a.cancelBubble && (a.cancelBubble = !0), this.isPropagationStopped = pd);
				},
				persist: function() {},
				isPersistent: pd
			});
			return b;
		}
		var sd = {
			eventPhase: 0,
			bubbles: 0,
			cancelable: 0,
			timeStamp: function(a) {
				return a.timeStamp || Date.now();
			},
			defaultPrevented: 0,
			isTrusted: 0
		};
		var td = rd(sd);
		var ud = A({}, sd, {
			view: 0,
			detail: 0
		});
		var vd = rd(ud);
		var wd;
		var xd;
		var yd;
		var Ad = A({}, ud, {
			screenX: 0,
			screenY: 0,
			clientX: 0,
			clientY: 0,
			pageX: 0,
			pageY: 0,
			ctrlKey: 0,
			shiftKey: 0,
			altKey: 0,
			metaKey: 0,
			getModifierState: zd,
			button: 0,
			buttons: 0,
			relatedTarget: function(a) {
				return void 0 === a.relatedTarget ? a.fromElement === a.srcElement ? a.toElement : a.fromElement : a.relatedTarget;
			},
			movementX: function(a) {
				if ("movementX" in a) return a.movementX;
				a !== yd && (yd && "mousemove" === a.type ? (wd = a.screenX - yd.screenX, xd = a.screenY - yd.screenY) : xd = wd = 0, yd = a);
				return wd;
			},
			movementY: function(a) {
				return "movementY" in a ? a.movementY : xd;
			}
		});
		var Bd = rd(Ad);
		var Dd = rd(A({}, Ad, { dataTransfer: 0 }));
		var Fd = rd(A({}, ud, { relatedTarget: 0 }));
		var Hd = rd(A({}, sd, {
			animationName: 0,
			elapsedTime: 0,
			pseudoElement: 0
		}));
		var Jd = rd(A({}, sd, { clipboardData: function(a) {
			return "clipboardData" in a ? a.clipboardData : window.clipboardData;
		} }));
		var Ld = rd(A({}, sd, { data: 0 }));
		var Md = {
			Esc: "Escape",
			Spacebar: " ",
			Left: "ArrowLeft",
			Up: "ArrowUp",
			Right: "ArrowRight",
			Down: "ArrowDown",
			Del: "Delete",
			Win: "OS",
			Menu: "ContextMenu",
			Apps: "ContextMenu",
			Scroll: "ScrollLock",
			MozPrintableKey: "Unidentified"
		};
		var Nd = {
			8: "Backspace",
			9: "Tab",
			12: "Clear",
			13: "Enter",
			16: "Shift",
			17: "Control",
			18: "Alt",
			19: "Pause",
			20: "CapsLock",
			27: "Escape",
			32: " ",
			33: "PageUp",
			34: "PageDown",
			35: "End",
			36: "Home",
			37: "ArrowLeft",
			38: "ArrowUp",
			39: "ArrowRight",
			40: "ArrowDown",
			45: "Insert",
			46: "Delete",
			112: "F1",
			113: "F2",
			114: "F3",
			115: "F4",
			116: "F5",
			117: "F6",
			118: "F7",
			119: "F8",
			120: "F9",
			121: "F10",
			122: "F11",
			123: "F12",
			144: "NumLock",
			145: "ScrollLock",
			224: "Meta"
		};
		var Od = {
			Alt: "altKey",
			Control: "ctrlKey",
			Meta: "metaKey",
			Shift: "shiftKey"
		};
		function Pd(a) {
			var b = this.nativeEvent;
			return b.getModifierState ? b.getModifierState(a) : (a = Od[a]) ? !!b[a] : !1;
		}
		function zd() {
			return Pd;
		}
		var Rd = rd(A({}, ud, {
			key: function(a) {
				if (a.key) {
					var b = Md[a.key] || a.key;
					if ("Unidentified" !== b) return b;
				}
				return "keypress" === a.type ? (a = od(a), 13 === a ? "Enter" : String.fromCharCode(a)) : "keydown" === a.type || "keyup" === a.type ? Nd[a.keyCode] || "Unidentified" : "";
			},
			code: 0,
			location: 0,
			ctrlKey: 0,
			shiftKey: 0,
			altKey: 0,
			metaKey: 0,
			repeat: 0,
			locale: 0,
			getModifierState: zd,
			charCode: function(a) {
				return "keypress" === a.type ? od(a) : 0;
			},
			keyCode: function(a) {
				return "keydown" === a.type || "keyup" === a.type ? a.keyCode : 0;
			},
			which: function(a) {
				return "keypress" === a.type ? od(a) : "keydown" === a.type || "keyup" === a.type ? a.keyCode : 0;
			}
		}));
		var Td = rd(A({}, Ad, {
			pointerId: 0,
			width: 0,
			height: 0,
			pressure: 0,
			tangentialPressure: 0,
			tiltX: 0,
			tiltY: 0,
			twist: 0,
			pointerType: 0,
			isPrimary: 0
		}));
		var Vd = rd(A({}, ud, {
			touches: 0,
			targetTouches: 0,
			changedTouches: 0,
			altKey: 0,
			metaKey: 0,
			ctrlKey: 0,
			shiftKey: 0,
			getModifierState: zd
		}));
		var Xd = rd(A({}, sd, {
			propertyName: 0,
			elapsedTime: 0,
			pseudoElement: 0
		}));
		var Zd = rd(A({}, Ad, {
			deltaX: function(a) {
				return "deltaX" in a ? a.deltaX : "wheelDeltaX" in a ? -a.wheelDeltaX : 0;
			},
			deltaY: function(a) {
				return "deltaY" in a ? a.deltaY : "wheelDeltaY" in a ? -a.wheelDeltaY : "wheelDelta" in a ? -a.wheelDelta : 0;
			},
			deltaZ: 0,
			deltaMode: 0
		}));
		var $d = [
			9,
			13,
			27,
			32
		];
		var ae = ia && "CompositionEvent" in window;
		var be = null;
		ia && "documentMode" in document && (be = document.documentMode);
		var ce = ia && "TextEvent" in window && !be;
		var de = ia && (!ae || be && 8 < be && 11 >= be);
		var ee = String.fromCharCode(32);
		var fe = !1;
		function ge(a, b) {
			switch (a) {
				case "keyup": return -1 !== $d.indexOf(b.keyCode);
				case "keydown": return 229 !== b.keyCode;
				case "keypress":
				case "mousedown":
				case "focusout": return !0;
				default: return !1;
			}
		}
		function he(a) {
			a = a.detail;
			return "object" === typeof a && "data" in a ? a.data : null;
		}
		var ie = !1;
		function je(a, b) {
			switch (a) {
				case "compositionend": return he(b);
				case "keypress":
					if (32 !== b.which) return null;
					fe = !0;
					return ee;
				case "textInput": return a = b.data, a === ee && fe ? null : a;
				default: return null;
			}
		}
		function ke(a, b) {
			if (ie) return "compositionend" === a || !ae && ge(a, b) ? (a = nd(), md = ld = kd = null, ie = !1, a) : null;
			switch (a) {
				case "paste": return null;
				case "keypress":
					if (!(b.ctrlKey || b.altKey || b.metaKey) || b.ctrlKey && b.altKey) {
						if (b.char && 1 < b.char.length) return b.char;
						if (b.which) return String.fromCharCode(b.which);
					}
					return null;
				case "compositionend": return de && "ko" !== b.locale ? null : b.data;
				default: return null;
			}
		}
		var le = {
			color: !0,
			date: !0,
			datetime: !0,
			"datetime-local": !0,
			email: !0,
			month: !0,
			number: !0,
			password: !0,
			range: !0,
			search: !0,
			tel: !0,
			text: !0,
			time: !0,
			url: !0,
			week: !0
		};
		function me(a) {
			var b = a && a.nodeName && a.nodeName.toLowerCase();
			return "input" === b ? !!le[a.type] : "textarea" === b ? !0 : !1;
		}
		function ne(a, b, c, d) {
			Eb(d);
			b = oe(b, "onChange");
			0 < b.length && (c = new td("onChange", "change", null, c, d), a.push({
				event: c,
				listeners: b
			}));
		}
		var pe = null;
		var qe = null;
		function re(a) {
			se(a, 0);
		}
		function te(a) {
			if (Wa(ue(a))) return a;
		}
		function ve(a, b) {
			if ("change" === a) return b;
		}
		var we = !1;
		if (ia) {
			var xe;
			if (ia) {
				var ye = "oninput" in document;
				if (!ye) {
					var ze = document.createElement("div");
					ze.setAttribute("oninput", "return;");
					ye = "function" === typeof ze.oninput;
				}
				xe = ye;
			} else xe = !1;
			we = xe && (!document.documentMode || 9 < document.documentMode);
		}
		function Ae() {
			pe && (pe.detachEvent("onpropertychange", Be), qe = pe = null);
		}
		function Be(a) {
			if ("value" === a.propertyName && te(qe)) {
				var b = [];
				ne(b, qe, a, xb(a));
				Jb(re, b);
			}
		}
		function Ce(a, b, c) {
			"focusin" === a ? (Ae(), pe = b, qe = c, pe.attachEvent("onpropertychange", Be)) : "focusout" === a && Ae();
		}
		function De(a) {
			if ("selectionchange" === a || "keyup" === a || "keydown" === a) return te(qe);
		}
		function Ee(a, b) {
			if ("click" === a) return te(b);
		}
		function Fe(a, b) {
			if ("input" === a || "change" === a) return te(b);
		}
		function Ge(a, b) {
			return a === b && (0 !== a || 1 / a === 1 / b) || a !== a && b !== b;
		}
		var He = "function" === typeof Object.is ? Object.is : Ge;
		function Ie(a, b) {
			if (He(a, b)) return !0;
			if ("object" !== typeof a || null === a || "object" !== typeof b || null === b) return !1;
			var c = Object.keys(a), d = Object.keys(b);
			if (c.length !== d.length) return !1;
			for (d = 0; d < c.length; d++) {
				var e = c[d];
				if (!ja.call(b, e) || !He(a[e], b[e])) return !1;
			}
			return !0;
		}
		function Je(a) {
			for (; a && a.firstChild;) a = a.firstChild;
			return a;
		}
		function Ke(a, b) {
			var c = Je(a);
			a = 0;
			for (var d; c;) {
				if (3 === c.nodeType) {
					d = a + c.textContent.length;
					if (a <= b && d >= b) return {
						node: c,
						offset: b - a
					};
					a = d;
				}
				a: {
					for (; c;) {
						if (c.nextSibling) {
							c = c.nextSibling;
							break a;
						}
						c = c.parentNode;
					}
					c = void 0;
				}
				c = Je(c);
			}
		}
		function Le(a, b) {
			return a && b ? a === b ? !0 : a && 3 === a.nodeType ? !1 : b && 3 === b.nodeType ? Le(a, b.parentNode) : "contains" in a ? a.contains(b) : a.compareDocumentPosition ? !!(a.compareDocumentPosition(b) & 16) : !1 : !1;
		}
		function Me() {
			for (var a = window, b = Xa(); b instanceof a.HTMLIFrameElement;) {
				try {
					var c = "string" === typeof b.contentWindow.location.href;
				} catch (d) {
					c = !1;
				}
				if (c) a = b.contentWindow;
				else break;
				b = Xa(a.document);
			}
			return b;
		}
		function Ne(a) {
			var b = a && a.nodeName && a.nodeName.toLowerCase();
			return b && ("input" === b && ("text" === a.type || "search" === a.type || "tel" === a.type || "url" === a.type || "password" === a.type) || "textarea" === b || "true" === a.contentEditable);
		}
		function Oe(a) {
			var b = Me(), c = a.focusedElem, d = a.selectionRange;
			if (b !== c && c && c.ownerDocument && Le(c.ownerDocument.documentElement, c)) {
				if (null !== d && Ne(c)) {
					if (b = d.start, a = d.end, void 0 === a && (a = b), "selectionStart" in c) c.selectionStart = b, c.selectionEnd = Math.min(a, c.value.length);
					else if (a = (b = c.ownerDocument || document) && b.defaultView || window, a.getSelection) {
						a = a.getSelection();
						var e = c.textContent.length, f = Math.min(d.start, e);
						d = void 0 === d.end ? f : Math.min(d.end, e);
						!a.extend && f > d && (e = d, d = f, f = e);
						e = Ke(c, f);
						var g = Ke(c, d);
						e && g && (1 !== a.rangeCount || a.anchorNode !== e.node || a.anchorOffset !== e.offset || a.focusNode !== g.node || a.focusOffset !== g.offset) && (b = b.createRange(), b.setStart(e.node, e.offset), a.removeAllRanges(), f > d ? (a.addRange(b), a.extend(g.node, g.offset)) : (b.setEnd(g.node, g.offset), a.addRange(b)));
					}
				}
				b = [];
				for (a = c; a = a.parentNode;) 1 === a.nodeType && b.push({
					element: a,
					left: a.scrollLeft,
					top: a.scrollTop
				});
				"function" === typeof c.focus && c.focus();
				for (c = 0; c < b.length; c++) a = b[c], a.element.scrollLeft = a.left, a.element.scrollTop = a.top;
			}
		}
		var Pe = ia && "documentMode" in document && 11 >= document.documentMode;
		var Qe = null;
		var Re = null;
		var Se = null;
		var Te = !1;
		function Ue(a, b, c) {
			var d = c.window === c ? c.document : 9 === c.nodeType ? c : c.ownerDocument;
			Te || null == Qe || Qe !== Xa(d) || (d = Qe, "selectionStart" in d && Ne(d) ? d = {
				start: d.selectionStart,
				end: d.selectionEnd
			} : (d = (d.ownerDocument && d.ownerDocument.defaultView || window).getSelection(), d = {
				anchorNode: d.anchorNode,
				anchorOffset: d.anchorOffset,
				focusNode: d.focusNode,
				focusOffset: d.focusOffset
			}), Se && Ie(Se, d) || (Se = d, d = oe(Re, "onSelect"), 0 < d.length && (b = new td("onSelect", "select", null, b, c), a.push({
				event: b,
				listeners: d
			}), b.target = Qe)));
		}
		function Ve(a, b) {
			var c = {};
			c[a.toLowerCase()] = b.toLowerCase();
			c["Webkit" + a] = "webkit" + b;
			c["Moz" + a] = "moz" + b;
			return c;
		}
		var We = {
			animationend: Ve("Animation", "AnimationEnd"),
			animationiteration: Ve("Animation", "AnimationIteration"),
			animationstart: Ve("Animation", "AnimationStart"),
			transitionend: Ve("Transition", "TransitionEnd")
		};
		var Xe = {};
		var Ye = {};
		ia && (Ye = document.createElement("div").style, "AnimationEvent" in window || (delete We.animationend.animation, delete We.animationiteration.animation, delete We.animationstart.animation), "TransitionEvent" in window || delete We.transitionend.transition);
		function Ze(a) {
			if (Xe[a]) return Xe[a];
			if (!We[a]) return a;
			var b = We[a], c;
			for (c in b) if (b.hasOwnProperty(c) && c in Ye) return Xe[a] = b[c];
			return a;
		}
		var $e = Ze("animationend");
		var af = Ze("animationiteration");
		var bf = Ze("animationstart");
		var cf = Ze("transitionend");
		var df = /* @__PURE__ */ new Map();
		var ef = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
		function ff(a, b) {
			df.set(a, b);
			fa(b, [a]);
		}
		for (var gf = 0; gf < ef.length; gf++) {
			var hf = ef[gf];
			ff(hf.toLowerCase(), "on" + (hf[0].toUpperCase() + hf.slice(1)));
		}
		ff($e, "onAnimationEnd");
		ff(af, "onAnimationIteration");
		ff(bf, "onAnimationStart");
		ff("dblclick", "onDoubleClick");
		ff("focusin", "onFocus");
		ff("focusout", "onBlur");
		ff(cf, "onTransitionEnd");
		ha("onMouseEnter", ["mouseout", "mouseover"]);
		ha("onMouseLeave", ["mouseout", "mouseover"]);
		ha("onPointerEnter", ["pointerout", "pointerover"]);
		ha("onPointerLeave", ["pointerout", "pointerover"]);
		fa("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
		fa("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
		fa("onBeforeInput", [
			"compositionend",
			"keypress",
			"textInput",
			"paste"
		]);
		fa("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
		fa("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
		fa("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
		var lf = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" ");
		var mf = new Set("cancel close invalid load scroll toggle".split(" ").concat(lf));
		function nf(a, b, c) {
			var d = a.type || "unknown-event";
			a.currentTarget = c;
			Ub(d, b, void 0, a);
			a.currentTarget = null;
		}
		function se(a, b) {
			b = 0 !== (b & 4);
			for (var c = 0; c < a.length; c++) {
				var d = a[c], e = d.event;
				d = d.listeners;
				a: {
					var f = void 0;
					if (b) for (var g = d.length - 1; 0 <= g; g--) {
						var h = d[g], k = h.instance, l = h.currentTarget;
						h = h.listener;
						if (k !== f && e.isPropagationStopped()) break a;
						nf(e, h, l);
						f = k;
					}
					else for (g = 0; g < d.length; g++) {
						h = d[g];
						k = h.instance;
						l = h.currentTarget;
						h = h.listener;
						if (k !== f && e.isPropagationStopped()) break a;
						nf(e, h, l);
						f = k;
					}
				}
			}
			if (Qb) throw a = Rb, Qb = !1, Rb = null, a;
		}
		function D(a, b) {
			var c = b[of];
			void 0 === c && (c = b[of] = /* @__PURE__ */ new Set());
			var d = a + "__bubble";
			c.has(d) || (pf(b, a, 2, !1), c.add(d));
		}
		function qf(a, b, c) {
			var d = 0;
			b && (d |= 4);
			pf(c, a, d, b);
		}
		var rf = "_reactListening" + Math.random().toString(36).slice(2);
		function sf(a) {
			if (!a[rf]) {
				a[rf] = !0;
				da.forEach(function(b) {
					"selectionchange" !== b && (mf.has(b) || qf(b, !1, a), qf(b, !0, a));
				});
				var b = 9 === a.nodeType ? a : a.ownerDocument;
				null === b || b[rf] || (b[rf] = !0, qf("selectionchange", !1, b));
			}
		}
		function pf(a, b, c, d) {
			switch (jd(b)) {
				case 1:
					var e = ed;
					break;
				case 4:
					e = gd;
					break;
				default: e = fd;
			}
			c = e.bind(null, b, c, a);
			e = void 0;
			!Lb || "touchstart" !== b && "touchmove" !== b && "wheel" !== b || (e = !0);
			d ? void 0 !== e ? a.addEventListener(b, c, {
				capture: !0,
				passive: e
			}) : a.addEventListener(b, c, !0) : void 0 !== e ? a.addEventListener(b, c, { passive: e }) : a.addEventListener(b, c, !1);
		}
		function hd(a, b, c, d, e) {
			var f = d;
			if (0 === (b & 1) && 0 === (b & 2) && null !== d) a: for (;;) {
				if (null === d) return;
				var g = d.tag;
				if (3 === g || 4 === g) {
					var h = d.stateNode.containerInfo;
					if (h === e || 8 === h.nodeType && h.parentNode === e) break;
					if (4 === g) for (g = d.return; null !== g;) {
						var k = g.tag;
						if (3 === k || 4 === k) {
							if (k = g.stateNode.containerInfo, k === e || 8 === k.nodeType && k.parentNode === e) return;
						}
						g = g.return;
					}
					for (; null !== h;) {
						g = Wc(h);
						if (null === g) return;
						k = g.tag;
						if (5 === k || 6 === k) {
							d = f = g;
							continue a;
						}
						h = h.parentNode;
					}
				}
				d = d.return;
			}
			Jb(function() {
				var d = f, e = xb(c), g = [];
				a: {
					var h = df.get(a);
					if (void 0 !== h) {
						var k = td, n = a;
						switch (a) {
							case "keypress": if (0 === od(c)) break a;
							case "keydown":
							case "keyup":
								k = Rd;
								break;
							case "focusin":
								n = "focus";
								k = Fd;
								break;
							case "focusout":
								n = "blur";
								k = Fd;
								break;
							case "beforeblur":
							case "afterblur":
								k = Fd;
								break;
							case "click": if (2 === c.button) break a;
							case "auxclick":
							case "dblclick":
							case "mousedown":
							case "mousemove":
							case "mouseup":
							case "mouseout":
							case "mouseover":
							case "contextmenu":
								k = Bd;
								break;
							case "drag":
							case "dragend":
							case "dragenter":
							case "dragexit":
							case "dragleave":
							case "dragover":
							case "dragstart":
							case "drop":
								k = Dd;
								break;
							case "touchcancel":
							case "touchend":
							case "touchmove":
							case "touchstart":
								k = Vd;
								break;
							case $e:
							case af:
							case bf:
								k = Hd;
								break;
							case cf:
								k = Xd;
								break;
							case "scroll":
								k = vd;
								break;
							case "wheel":
								k = Zd;
								break;
							case "copy":
							case "cut":
							case "paste":
								k = Jd;
								break;
							case "gotpointercapture":
							case "lostpointercapture":
							case "pointercancel":
							case "pointerdown":
							case "pointermove":
							case "pointerout":
							case "pointerover":
							case "pointerup": k = Td;
						}
						var t = 0 !== (b & 4), J = !t && "scroll" === a, x = t ? null !== h ? h + "Capture" : null : h;
						t = [];
						for (var w = d, u; null !== w;) {
							u = w;
							var F = u.stateNode;
							5 === u.tag && null !== F && (u = F, null !== x && (F = Kb(w, x), null != F && t.push(tf(w, F, u))));
							if (J) break;
							w = w.return;
						}
						0 < t.length && (h = new k(h, n, null, c, e), g.push({
							event: h,
							listeners: t
						}));
					}
				}
				if (0 === (b & 7)) {
					a: {
						h = "mouseover" === a || "pointerover" === a;
						k = "mouseout" === a || "pointerout" === a;
						if (h && c !== wb && (n = c.relatedTarget || c.fromElement) && (Wc(n) || n[uf])) break a;
						if (k || h) {
							h = e.window === e ? e : (h = e.ownerDocument) ? h.defaultView || h.parentWindow : window;
							if (k) {
								if (n = c.relatedTarget || c.toElement, k = d, n = n ? Wc(n) : null, null !== n && (J = Vb(n), n !== J || 5 !== n.tag && 6 !== n.tag)) n = null;
							} else k = null, n = d;
							if (k !== n) {
								t = Bd;
								F = "onMouseLeave";
								x = "onMouseEnter";
								w = "mouse";
								if ("pointerout" === a || "pointerover" === a) t = Td, F = "onPointerLeave", x = "onPointerEnter", w = "pointer";
								J = null == k ? h : ue(k);
								u = null == n ? h : ue(n);
								h = new t(F, w + "leave", k, c, e);
								h.target = J;
								h.relatedTarget = u;
								F = null;
								Wc(e) === d && (t = new t(x, w + "enter", n, c, e), t.target = u, t.relatedTarget = J, F = t);
								J = F;
								if (k && n) b: {
									t = k;
									x = n;
									w = 0;
									for (u = t; u; u = vf(u)) w++;
									u = 0;
									for (F = x; F; F = vf(F)) u++;
									for (; 0 < w - u;) t = vf(t), w--;
									for (; 0 < u - w;) x = vf(x), u--;
									for (; w--;) {
										if (t === x || null !== x && t === x.alternate) break b;
										t = vf(t);
										x = vf(x);
									}
									t = null;
								}
								else t = null;
								null !== k && wf(g, h, k, t, !1);
								null !== n && null !== J && wf(g, J, n, t, !0);
							}
						}
					}
					a: {
						h = d ? ue(d) : window;
						k = h.nodeName && h.nodeName.toLowerCase();
						if ("select" === k || "input" === k && "file" === h.type) var na = ve;
						else if (me(h)) if (we) na = Fe;
						else {
							na = De;
							var xa = Ce;
						}
						else (k = h.nodeName) && "input" === k.toLowerCase() && ("checkbox" === h.type || "radio" === h.type) && (na = Ee);
						if (na && (na = na(a, d))) {
							ne(g, na, c, e);
							break a;
						}
						xa && xa(a, h, d);
						"focusout" === a && (xa = h._wrapperState) && xa.controlled && "number" === h.type && cb(h, "number", h.value);
					}
					xa = d ? ue(d) : window;
					switch (a) {
						case "focusin":
							if (me(xa) || "true" === xa.contentEditable) Qe = xa, Re = d, Se = null;
							break;
						case "focusout":
							Se = Re = Qe = null;
							break;
						case "mousedown":
							Te = !0;
							break;
						case "contextmenu":
						case "mouseup":
						case "dragend":
							Te = !1;
							Ue(g, c, e);
							break;
						case "selectionchange": if (Pe) break;
						case "keydown":
						case "keyup": Ue(g, c, e);
					}
					var $a;
					if (ae) b: {
						switch (a) {
							case "compositionstart":
								var ba = "onCompositionStart";
								break b;
							case "compositionend":
								ba = "onCompositionEnd";
								break b;
							case "compositionupdate":
								ba = "onCompositionUpdate";
								break b;
						}
						ba = void 0;
					}
					else ie ? ge(a, c) && (ba = "onCompositionEnd") : "keydown" === a && 229 === c.keyCode && (ba = "onCompositionStart");
					ba && (de && "ko" !== c.locale && (ie || "onCompositionStart" !== ba ? "onCompositionEnd" === ba && ie && ($a = nd()) : (kd = e, ld = "value" in kd ? kd.value : kd.textContent, ie = !0)), xa = oe(d, ba), 0 < xa.length && (ba = new Ld(ba, a, null, c, e), g.push({
						event: ba,
						listeners: xa
					}), $a ? ba.data = $a : ($a = he(c), null !== $a && (ba.data = $a))));
					if ($a = ce ? je(a, c) : ke(a, c)) d = oe(d, "onBeforeInput"), 0 < d.length && (e = new Ld("onBeforeInput", "beforeinput", null, c, e), g.push({
						event: e,
						listeners: d
					}), e.data = $a);
				}
				se(g, b);
			});
		}
		function tf(a, b, c) {
			return {
				instance: a,
				listener: b,
				currentTarget: c
			};
		}
		function oe(a, b) {
			for (var c = b + "Capture", d = []; null !== a;) {
				var e = a, f = e.stateNode;
				5 === e.tag && null !== f && (e = f, f = Kb(a, c), null != f && d.unshift(tf(a, f, e)), f = Kb(a, b), null != f && d.push(tf(a, f, e)));
				a = a.return;
			}
			return d;
		}
		function vf(a) {
			if (null === a) return null;
			do
				a = a.return;
			while (a && 5 !== a.tag);
			return a ? a : null;
		}
		function wf(a, b, c, d, e) {
			for (var f = b._reactName, g = []; null !== c && c !== d;) {
				var h = c, k = h.alternate, l = h.stateNode;
				if (null !== k && k === d) break;
				5 === h.tag && null !== l && (h = l, e ? (k = Kb(c, f), null != k && g.unshift(tf(c, k, h))) : e || (k = Kb(c, f), null != k && g.push(tf(c, k, h))));
				c = c.return;
			}
			0 !== g.length && a.push({
				event: b,
				listeners: g
			});
		}
		var xf = /\r\n?/g;
		var yf = /\u0000|\uFFFD/g;
		function zf(a) {
			return ("string" === typeof a ? a : "" + a).replace(xf, "\n").replace(yf, "");
		}
		function Af(a, b, c) {
			b = zf(b);
			if (zf(a) !== b && c) throw Error(p(425));
		}
		function Bf() {}
		var Cf = null;
		var Df = null;
		function Ef(a, b) {
			return "textarea" === a || "noscript" === a || "string" === typeof b.children || "number" === typeof b.children || "object" === typeof b.dangerouslySetInnerHTML && null !== b.dangerouslySetInnerHTML && null != b.dangerouslySetInnerHTML.__html;
		}
		var Ff = "function" === typeof setTimeout ? setTimeout : void 0;
		var Gf = "function" === typeof clearTimeout ? clearTimeout : void 0;
		var Hf = "function" === typeof Promise ? Promise : void 0;
		var Jf = "function" === typeof queueMicrotask ? queueMicrotask : "undefined" !== typeof Hf ? function(a) {
			return Hf.resolve(null).then(a).catch(If);
		} : Ff;
		function If(a) {
			setTimeout(function() {
				throw a;
			});
		}
		function Kf(a, b) {
			var c = b, d = 0;
			do {
				var e = c.nextSibling;
				a.removeChild(c);
				if (e && 8 === e.nodeType) if (c = e.data, "/$" === c) {
					if (0 === d) {
						a.removeChild(e);
						bd(b);
						return;
					}
					d--;
				} else "$" !== c && "$?" !== c && "$!" !== c || d++;
				c = e;
			} while (c);
			bd(b);
		}
		function Lf(a) {
			for (; null != a; a = a.nextSibling) {
				var b = a.nodeType;
				if (1 === b || 3 === b) break;
				if (8 === b) {
					b = a.data;
					if ("$" === b || "$!" === b || "$?" === b) break;
					if ("/$" === b) return null;
				}
			}
			return a;
		}
		function Mf(a) {
			a = a.previousSibling;
			for (var b = 0; a;) {
				if (8 === a.nodeType) {
					var c = a.data;
					if ("$" === c || "$!" === c || "$?" === c) {
						if (0 === b) return a;
						b--;
					} else "/$" === c && b++;
				}
				a = a.previousSibling;
			}
			return null;
		}
		var Nf = Math.random().toString(36).slice(2);
		var Of = "__reactFiber$" + Nf;
		var Pf = "__reactProps$" + Nf;
		var uf = "__reactContainer$" + Nf;
		var of = "__reactEvents$" + Nf;
		var Qf = "__reactListeners$" + Nf;
		var Rf = "__reactHandles$" + Nf;
		function Wc(a) {
			var b = a[Of];
			if (b) return b;
			for (var c = a.parentNode; c;) {
				if (b = c[uf] || c[Of]) {
					c = b.alternate;
					if (null !== b.child || null !== c && null !== c.child) for (a = Mf(a); null !== a;) {
						if (c = a[Of]) return c;
						a = Mf(a);
					}
					return b;
				}
				a = c;
				c = a.parentNode;
			}
			return null;
		}
		function Cb(a) {
			a = a[Of] || a[uf];
			return !a || 5 !== a.tag && 6 !== a.tag && 13 !== a.tag && 3 !== a.tag ? null : a;
		}
		function ue(a) {
			if (5 === a.tag || 6 === a.tag) return a.stateNode;
			throw Error(p(33));
		}
		function Db(a) {
			return a[Pf] || null;
		}
		var Sf = [];
		var Tf = -1;
		function Uf(a) {
			return { current: a };
		}
		function E(a) {
			0 > Tf || (a.current = Sf[Tf], Sf[Tf] = null, Tf--);
		}
		function G(a, b) {
			Tf++;
			Sf[Tf] = a.current;
			a.current = b;
		}
		var Vf = {};
		var H = Uf(Vf);
		var Wf = Uf(!1);
		var Xf = Vf;
		function Yf(a, b) {
			var c = a.type.contextTypes;
			if (!c) return Vf;
			var d = a.stateNode;
			if (d && d.__reactInternalMemoizedUnmaskedChildContext === b) return d.__reactInternalMemoizedMaskedChildContext;
			var e = {}, f;
			for (f in c) e[f] = b[f];
			d && (a = a.stateNode, a.__reactInternalMemoizedUnmaskedChildContext = b, a.__reactInternalMemoizedMaskedChildContext = e);
			return e;
		}
		function Zf(a) {
			a = a.childContextTypes;
			return null !== a && void 0 !== a;
		}
		function $f() {
			E(Wf);
			E(H);
		}
		function ag(a, b, c) {
			if (H.current !== Vf) throw Error(p(168));
			G(H, b);
			G(Wf, c);
		}
		function bg(a, b, c) {
			var d = a.stateNode;
			b = b.childContextTypes;
			if ("function" !== typeof d.getChildContext) return c;
			d = d.getChildContext();
			for (var e in d) if (!(e in b)) throw Error(p(108, Ra(a) || "Unknown", e));
			return A({}, c, d);
		}
		function cg(a) {
			a = (a = a.stateNode) && a.__reactInternalMemoizedMergedChildContext || Vf;
			Xf = H.current;
			G(H, a);
			G(Wf, Wf.current);
			return !0;
		}
		function dg(a, b, c) {
			var d = a.stateNode;
			if (!d) throw Error(p(169));
			c ? (a = bg(a, b, Xf), d.__reactInternalMemoizedMergedChildContext = a, E(Wf), E(H), G(H, a)) : E(Wf);
			G(Wf, c);
		}
		var eg = null;
		var fg = !1;
		var gg = !1;
		function hg(a) {
			null === eg ? eg = [a] : eg.push(a);
		}
		function ig(a) {
			fg = !0;
			hg(a);
		}
		function jg() {
			if (!gg && null !== eg) {
				gg = !0;
				var a = 0, b = C;
				try {
					var c = eg;
					for (C = 1; a < c.length; a++) {
						var d = c[a];
						do
							d = d(!0);
						while (null !== d);
					}
					eg = null;
					fg = !1;
				} catch (e) {
					throw null !== eg && (eg = eg.slice(a + 1)), ac(fc, jg), e;
				} finally {
					C = b, gg = !1;
				}
			}
			return null;
		}
		var kg = [];
		var lg = 0;
		var mg = null;
		var ng = 0;
		var og = [];
		var pg = 0;
		var qg = null;
		var rg = 1;
		var sg = "";
		function tg(a, b) {
			kg[lg++] = ng;
			kg[lg++] = mg;
			mg = a;
			ng = b;
		}
		function ug(a, b, c) {
			og[pg++] = rg;
			og[pg++] = sg;
			og[pg++] = qg;
			qg = a;
			var d = rg;
			a = sg;
			var e = 32 - oc(d) - 1;
			d &= ~(1 << e);
			c += 1;
			var f = 32 - oc(b) + e;
			if (30 < f) {
				var g = e - e % 5;
				f = (d & (1 << g) - 1).toString(32);
				d >>= g;
				e -= g;
				rg = 1 << 32 - oc(b) + e | c << e | d;
				sg = f + a;
			} else rg = 1 << f | c << e | d, sg = a;
		}
		function vg(a) {
			null !== a.return && (tg(a, 1), ug(a, 1, 0));
		}
		function wg(a) {
			for (; a === mg;) mg = kg[--lg], kg[lg] = null, ng = kg[--lg], kg[lg] = null;
			for (; a === qg;) qg = og[--pg], og[pg] = null, sg = og[--pg], og[pg] = null, rg = og[--pg], og[pg] = null;
		}
		var xg = null;
		var yg = null;
		var I = !1;
		var zg = null;
		function Ag(a, b) {
			var c = Bg(5, null, null, 0);
			c.elementType = "DELETED";
			c.stateNode = b;
			c.return = a;
			b = a.deletions;
			null === b ? (a.deletions = [c], a.flags |= 16) : b.push(c);
		}
		function Cg(a, b) {
			switch (a.tag) {
				case 5:
					var c = a.type;
					b = 1 !== b.nodeType || c.toLowerCase() !== b.nodeName.toLowerCase() ? null : b;
					return null !== b ? (a.stateNode = b, xg = a, yg = Lf(b.firstChild), !0) : !1;
				case 6: return b = "" === a.pendingProps || 3 !== b.nodeType ? null : b, null !== b ? (a.stateNode = b, xg = a, yg = null, !0) : !1;
				case 13: return b = 8 !== b.nodeType ? null : b, null !== b ? (c = null !== qg ? {
					id: rg,
					overflow: sg
				} : null, a.memoizedState = {
					dehydrated: b,
					treeContext: c,
					retryLane: 1073741824
				}, c = Bg(18, null, null, 0), c.stateNode = b, c.return = a, a.child = c, xg = a, yg = null, !0) : !1;
				default: return !1;
			}
		}
		function Dg(a) {
			return 0 !== (a.mode & 1) && 0 === (a.flags & 128);
		}
		function Eg(a) {
			if (I) {
				var b = yg;
				if (b) {
					var c = b;
					if (!Cg(a, b)) {
						if (Dg(a)) throw Error(p(418));
						b = Lf(c.nextSibling);
						var d = xg;
						b && Cg(a, b) ? Ag(d, c) : (a.flags = a.flags & -4097 | 2, I = !1, xg = a);
					}
				} else {
					if (Dg(a)) throw Error(p(418));
					a.flags = a.flags & -4097 | 2;
					I = !1;
					xg = a;
				}
			}
		}
		function Fg(a) {
			for (a = a.return; null !== a && 5 !== a.tag && 3 !== a.tag && 13 !== a.tag;) a = a.return;
			xg = a;
		}
		function Gg(a) {
			if (a !== xg) return !1;
			if (!I) return Fg(a), I = !0, !1;
			var b;
			(b = 3 !== a.tag) && !(b = 5 !== a.tag) && (b = a.type, b = "head" !== b && "body" !== b && !Ef(a.type, a.memoizedProps));
			if (b && (b = yg)) {
				if (Dg(a)) throw Hg(), Error(p(418));
				for (; b;) Ag(a, b), b = Lf(b.nextSibling);
			}
			Fg(a);
			if (13 === a.tag) {
				a = a.memoizedState;
				a = null !== a ? a.dehydrated : null;
				if (!a) throw Error(p(317));
				a: {
					a = a.nextSibling;
					for (b = 0; a;) {
						if (8 === a.nodeType) {
							var c = a.data;
							if ("/$" === c) {
								if (0 === b) {
									yg = Lf(a.nextSibling);
									break a;
								}
								b--;
							} else "$" !== c && "$!" !== c && "$?" !== c || b++;
						}
						a = a.nextSibling;
					}
					yg = null;
				}
			} else yg = xg ? Lf(a.stateNode.nextSibling) : null;
			return !0;
		}
		function Hg() {
			for (var a = yg; a;) a = Lf(a.nextSibling);
		}
		function Ig() {
			yg = xg = null;
			I = !1;
		}
		function Jg(a) {
			null === zg ? zg = [a] : zg.push(a);
		}
		var Kg = ua.ReactCurrentBatchConfig;
		function Lg(a, b, c) {
			a = c.ref;
			if (null !== a && "function" !== typeof a && "object" !== typeof a) {
				if (c._owner) {
					c = c._owner;
					if (c) {
						if (1 !== c.tag) throw Error(p(309));
						var d = c.stateNode;
					}
					if (!d) throw Error(p(147, a));
					var e = d, f = "" + a;
					if (null !== b && null !== b.ref && "function" === typeof b.ref && b.ref._stringRef === f) return b.ref;
					b = function(a) {
						var b = e.refs;
						null === a ? delete b[f] : b[f] = a;
					};
					b._stringRef = f;
					return b;
				}
				if ("string" !== typeof a) throw Error(p(284));
				if (!c._owner) throw Error(p(290, a));
			}
			return a;
		}
		function Mg(a, b) {
			a = Object.prototype.toString.call(b);
			throw Error(p(31, "[object Object]" === a ? "object with keys {" + Object.keys(b).join(", ") + "}" : a));
		}
		function Ng(a) {
			var b = a._init;
			return b(a._payload);
		}
		function Og(a) {
			function b(b, c) {
				if (a) {
					var d = b.deletions;
					null === d ? (b.deletions = [c], b.flags |= 16) : d.push(c);
				}
			}
			function c(c, d) {
				if (!a) return null;
				for (; null !== d;) b(c, d), d = d.sibling;
				return null;
			}
			function d(a, b) {
				for (a = /* @__PURE__ */ new Map(); null !== b;) null !== b.key ? a.set(b.key, b) : a.set(b.index, b), b = b.sibling;
				return a;
			}
			function e(a, b) {
				a = Pg(a, b);
				a.index = 0;
				a.sibling = null;
				return a;
			}
			function f(b, c, d) {
				b.index = d;
				if (!a) return b.flags |= 1048576, c;
				d = b.alternate;
				if (null !== d) return d = d.index, d < c ? (b.flags |= 2, c) : d;
				b.flags |= 2;
				return c;
			}
			function g(b) {
				a && null === b.alternate && (b.flags |= 2);
				return b;
			}
			function h(a, b, c, d) {
				if (null === b || 6 !== b.tag) return b = Qg(c, a.mode, d), b.return = a, b;
				b = e(b, c);
				b.return = a;
				return b;
			}
			function k(a, b, c, d) {
				var f = c.type;
				if (f === ya) return m(a, b, c.props.children, d, c.key);
				if (null !== b && (b.elementType === f || "object" === typeof f && null !== f && f.$$typeof === Ha && Ng(f) === b.type)) return d = e(b, c.props), d.ref = Lg(a, b, c), d.return = a, d;
				d = Rg(c.type, c.key, c.props, null, a.mode, d);
				d.ref = Lg(a, b, c);
				d.return = a;
				return d;
			}
			function l(a, b, c, d) {
				if (null === b || 4 !== b.tag || b.stateNode.containerInfo !== c.containerInfo || b.stateNode.implementation !== c.implementation) return b = Sg(c, a.mode, d), b.return = a, b;
				b = e(b, c.children || []);
				b.return = a;
				return b;
			}
			function m(a, b, c, d, f) {
				if (null === b || 7 !== b.tag) return b = Tg(c, a.mode, d, f), b.return = a, b;
				b = e(b, c);
				b.return = a;
				return b;
			}
			function q(a, b, c) {
				if ("string" === typeof b && "" !== b || "number" === typeof b) return b = Qg("" + b, a.mode, c), b.return = a, b;
				if ("object" === typeof b && null !== b) {
					switch (b.$$typeof) {
						case va: return c = Rg(b.type, b.key, b.props, null, a.mode, c), c.ref = Lg(a, null, b), c.return = a, c;
						case wa: return b = Sg(b, a.mode, c), b.return = a, b;
						case Ha:
							var d = b._init;
							return q(a, d(b._payload), c);
					}
					if (eb(b) || Ka(b)) return b = Tg(b, a.mode, c, null), b.return = a, b;
					Mg(a, b);
				}
				return null;
			}
			function r(a, b, c, d) {
				var e = null !== b ? b.key : null;
				if ("string" === typeof c && "" !== c || "number" === typeof c) return null !== e ? null : h(a, b, "" + c, d);
				if ("object" === typeof c && null !== c) {
					switch (c.$$typeof) {
						case va: return c.key === e ? k(a, b, c, d) : null;
						case wa: return c.key === e ? l(a, b, c, d) : null;
						case Ha: return e = c._init, r(a, b, e(c._payload), d);
					}
					if (eb(c) || Ka(c)) return null !== e ? null : m(a, b, c, d, null);
					Mg(a, c);
				}
				return null;
			}
			function y(a, b, c, d, e) {
				if ("string" === typeof d && "" !== d || "number" === typeof d) return a = a.get(c) || null, h(b, a, "" + d, e);
				if ("object" === typeof d && null !== d) {
					switch (d.$$typeof) {
						case va: return a = a.get(null === d.key ? c : d.key) || null, k(b, a, d, e);
						case wa: return a = a.get(null === d.key ? c : d.key) || null, l(b, a, d, e);
						case Ha:
							var f = d._init;
							return y(a, b, c, f(d._payload), e);
					}
					if (eb(d) || Ka(d)) return a = a.get(c) || null, m(b, a, d, e, null);
					Mg(b, d);
				}
				return null;
			}
			function n(e, g, h, k) {
				for (var l = null, m = null, u = g, w = g = 0, x = null; null !== u && w < h.length; w++) {
					u.index > w ? (x = u, u = null) : x = u.sibling;
					var n = r(e, u, h[w], k);
					if (null === n) {
						null === u && (u = x);
						break;
					}
					a && u && null === n.alternate && b(e, u);
					g = f(n, g, w);
					null === m ? l = n : m.sibling = n;
					m = n;
					u = x;
				}
				if (w === h.length) return c(e, u), I && tg(e, w), l;
				if (null === u) {
					for (; w < h.length; w++) u = q(e, h[w], k), null !== u && (g = f(u, g, w), null === m ? l = u : m.sibling = u, m = u);
					I && tg(e, w);
					return l;
				}
				for (u = d(e, u); w < h.length; w++) x = y(u, e, w, h[w], k), null !== x && (a && null !== x.alternate && u.delete(null === x.key ? w : x.key), g = f(x, g, w), null === m ? l = x : m.sibling = x, m = x);
				a && u.forEach(function(a) {
					return b(e, a);
				});
				I && tg(e, w);
				return l;
			}
			function t(e, g, h, k) {
				var l = Ka(h);
				if ("function" !== typeof l) throw Error(p(150));
				h = l.call(h);
				if (null == h) throw Error(p(151));
				for (var u = l = null, m = g, w = g = 0, x = null, n = h.next(); null !== m && !n.done; w++, n = h.next()) {
					m.index > w ? (x = m, m = null) : x = m.sibling;
					var t = r(e, m, n.value, k);
					if (null === t) {
						null === m && (m = x);
						break;
					}
					a && m && null === t.alternate && b(e, m);
					g = f(t, g, w);
					null === u ? l = t : u.sibling = t;
					u = t;
					m = x;
				}
				if (n.done) return c(e, m), I && tg(e, w), l;
				if (null === m) {
					for (; !n.done; w++, n = h.next()) n = q(e, n.value, k), null !== n && (g = f(n, g, w), null === u ? l = n : u.sibling = n, u = n);
					I && tg(e, w);
					return l;
				}
				for (m = d(e, m); !n.done; w++, n = h.next()) n = y(m, e, w, n.value, k), null !== n && (a && null !== n.alternate && m.delete(null === n.key ? w : n.key), g = f(n, g, w), null === u ? l = n : u.sibling = n, u = n);
				a && m.forEach(function(a) {
					return b(e, a);
				});
				I && tg(e, w);
				return l;
			}
			function J(a, d, f, h) {
				"object" === typeof f && null !== f && f.type === ya && null === f.key && (f = f.props.children);
				if ("object" === typeof f && null !== f) {
					switch (f.$$typeof) {
						case va:
							a: {
								for (var k = f.key, l = d; null !== l;) {
									if (l.key === k) {
										k = f.type;
										if (k === ya) {
											if (7 === l.tag) {
												c(a, l.sibling);
												d = e(l, f.props.children);
												d.return = a;
												a = d;
												break a;
											}
										} else if (l.elementType === k || "object" === typeof k && null !== k && k.$$typeof === Ha && Ng(k) === l.type) {
											c(a, l.sibling);
											d = e(l, f.props);
											d.ref = Lg(a, l, f);
											d.return = a;
											a = d;
											break a;
										}
										c(a, l);
										break;
									} else b(a, l);
									l = l.sibling;
								}
								f.type === ya ? (d = Tg(f.props.children, a.mode, h, f.key), d.return = a, a = d) : (h = Rg(f.type, f.key, f.props, null, a.mode, h), h.ref = Lg(a, d, f), h.return = a, a = h);
							}
							return g(a);
						case wa:
							a: {
								for (l = f.key; null !== d;) {
									if (d.key === l) if (4 === d.tag && d.stateNode.containerInfo === f.containerInfo && d.stateNode.implementation === f.implementation) {
										c(a, d.sibling);
										d = e(d, f.children || []);
										d.return = a;
										a = d;
										break a;
									} else {
										c(a, d);
										break;
									}
									else b(a, d);
									d = d.sibling;
								}
								d = Sg(f, a.mode, h);
								d.return = a;
								a = d;
							}
							return g(a);
						case Ha: return l = f._init, J(a, d, l(f._payload), h);
					}
					if (eb(f)) return n(a, d, f, h);
					if (Ka(f)) return t(a, d, f, h);
					Mg(a, f);
				}
				return "string" === typeof f && "" !== f || "number" === typeof f ? (f = "" + f, null !== d && 6 === d.tag ? (c(a, d.sibling), d = e(d, f), d.return = a, a = d) : (c(a, d), d = Qg(f, a.mode, h), d.return = a, a = d), g(a)) : c(a, d);
			}
			return J;
		}
		var Ug = Og(!0);
		var Vg = Og(!1);
		var Wg = Uf(null);
		var Xg = null;
		var Yg = null;
		var Zg = null;
		function $g() {
			Zg = Yg = Xg = null;
		}
		function ah(a) {
			var b = Wg.current;
			E(Wg);
			a._currentValue = b;
		}
		function bh(a, b, c) {
			for (; null !== a;) {
				var d = a.alternate;
				(a.childLanes & b) !== b ? (a.childLanes |= b, null !== d && (d.childLanes |= b)) : null !== d && (d.childLanes & b) !== b && (d.childLanes |= b);
				if (a === c) break;
				a = a.return;
			}
		}
		function ch(a, b) {
			Xg = a;
			Zg = Yg = null;
			a = a.dependencies;
			null !== a && null !== a.firstContext && (0 !== (a.lanes & b) && (dh = !0), a.firstContext = null);
		}
		function eh(a) {
			var b = a._currentValue;
			if (Zg !== a) if (a = {
				context: a,
				memoizedValue: b,
				next: null
			}, null === Yg) {
				if (null === Xg) throw Error(p(308));
				Yg = a;
				Xg.dependencies = {
					lanes: 0,
					firstContext: a
				};
			} else Yg = Yg.next = a;
			return b;
		}
		var fh = null;
		function gh(a) {
			null === fh ? fh = [a] : fh.push(a);
		}
		function hh(a, b, c, d) {
			var e = b.interleaved;
			null === e ? (c.next = c, gh(b)) : (c.next = e.next, e.next = c);
			b.interleaved = c;
			return ih(a, d);
		}
		function ih(a, b) {
			a.lanes |= b;
			var c = a.alternate;
			null !== c && (c.lanes |= b);
			c = a;
			for (a = a.return; null !== a;) a.childLanes |= b, c = a.alternate, null !== c && (c.childLanes |= b), c = a, a = a.return;
			return 3 === c.tag ? c.stateNode : null;
		}
		var jh = !1;
		function kh(a) {
			a.updateQueue = {
				baseState: a.memoizedState,
				firstBaseUpdate: null,
				lastBaseUpdate: null,
				shared: {
					pending: null,
					interleaved: null,
					lanes: 0
				},
				effects: null
			};
		}
		function lh(a, b) {
			a = a.updateQueue;
			b.updateQueue === a && (b.updateQueue = {
				baseState: a.baseState,
				firstBaseUpdate: a.firstBaseUpdate,
				lastBaseUpdate: a.lastBaseUpdate,
				shared: a.shared,
				effects: a.effects
			});
		}
		function mh(a, b) {
			return {
				eventTime: a,
				lane: b,
				tag: 0,
				payload: null,
				callback: null,
				next: null
			};
		}
		function nh(a, b, c) {
			var d = a.updateQueue;
			if (null === d) return null;
			d = d.shared;
			if (0 !== (K & 2)) {
				var e = d.pending;
				null === e ? b.next = b : (b.next = e.next, e.next = b);
				d.pending = b;
				return ih(a, c);
			}
			e = d.interleaved;
			null === e ? (b.next = b, gh(d)) : (b.next = e.next, e.next = b);
			d.interleaved = b;
			return ih(a, c);
		}
		function oh(a, b, c) {
			b = b.updateQueue;
			if (null !== b && (b = b.shared, 0 !== (c & 4194240))) {
				var d = b.lanes;
				d &= a.pendingLanes;
				c |= d;
				b.lanes = c;
				Cc(a, c);
			}
		}
		function ph(a, b) {
			var c = a.updateQueue, d = a.alternate;
			if (null !== d && (d = d.updateQueue, c === d)) {
				var e = null, f = null;
				c = c.firstBaseUpdate;
				if (null !== c) {
					do {
						var g = {
							eventTime: c.eventTime,
							lane: c.lane,
							tag: c.tag,
							payload: c.payload,
							callback: c.callback,
							next: null
						};
						null === f ? e = f = g : f = f.next = g;
						c = c.next;
					} while (null !== c);
					null === f ? e = f = b : f = f.next = b;
				} else e = f = b;
				c = {
					baseState: d.baseState,
					firstBaseUpdate: e,
					lastBaseUpdate: f,
					shared: d.shared,
					effects: d.effects
				};
				a.updateQueue = c;
				return;
			}
			a = c.lastBaseUpdate;
			null === a ? c.firstBaseUpdate = b : a.next = b;
			c.lastBaseUpdate = b;
		}
		function qh(a, b, c, d) {
			var e = a.updateQueue;
			jh = !1;
			var f = e.firstBaseUpdate, g = e.lastBaseUpdate, h = e.shared.pending;
			if (null !== h) {
				e.shared.pending = null;
				var k = h, l = k.next;
				k.next = null;
				null === g ? f = l : g.next = l;
				g = k;
				var m = a.alternate;
				null !== m && (m = m.updateQueue, h = m.lastBaseUpdate, h !== g && (null === h ? m.firstBaseUpdate = l : h.next = l, m.lastBaseUpdate = k));
			}
			if (null !== f) {
				var q = e.baseState;
				g = 0;
				m = l = k = null;
				h = f;
				do {
					var r = h.lane, y = h.eventTime;
					if ((d & r) === r) {
						null !== m && (m = m.next = {
							eventTime: y,
							lane: 0,
							tag: h.tag,
							payload: h.payload,
							callback: h.callback,
							next: null
						});
						a: {
							var n = a, t = h;
							r = b;
							y = c;
							switch (t.tag) {
								case 1:
									n = t.payload;
									if ("function" === typeof n) {
										q = n.call(y, q, r);
										break a;
									}
									q = n;
									break a;
								case 3: n.flags = n.flags & -65537 | 128;
								case 0:
									n = t.payload;
									r = "function" === typeof n ? n.call(y, q, r) : n;
									if (null === r || void 0 === r) break a;
									q = A({}, q, r);
									break a;
								case 2: jh = !0;
							}
						}
						null !== h.callback && 0 !== h.lane && (a.flags |= 64, r = e.effects, null === r ? e.effects = [h] : r.push(h));
					} else y = {
						eventTime: y,
						lane: r,
						tag: h.tag,
						payload: h.payload,
						callback: h.callback,
						next: null
					}, null === m ? (l = m = y, k = q) : m = m.next = y, g |= r;
					h = h.next;
					if (null === h) if (h = e.shared.pending, null === h) break;
					else r = h, h = r.next, r.next = null, e.lastBaseUpdate = r, e.shared.pending = null;
				} while (1);
				null === m && (k = q);
				e.baseState = k;
				e.firstBaseUpdate = l;
				e.lastBaseUpdate = m;
				b = e.shared.interleaved;
				if (null !== b) {
					e = b;
					do
						g |= e.lane, e = e.next;
					while (e !== b);
				} else null === f && (e.shared.lanes = 0);
				rh |= g;
				a.lanes = g;
				a.memoizedState = q;
			}
		}
		function sh(a, b, c) {
			a = b.effects;
			b.effects = null;
			if (null !== a) for (b = 0; b < a.length; b++) {
				var d = a[b], e = d.callback;
				if (null !== e) {
					d.callback = null;
					d = c;
					if ("function" !== typeof e) throw Error(p(191, e));
					e.call(d);
				}
			}
		}
		var th = {};
		var uh = Uf(th);
		var vh = Uf(th);
		var wh = Uf(th);
		function xh(a) {
			if (a === th) throw Error(p(174));
			return a;
		}
		function yh(a, b) {
			G(wh, b);
			G(vh, a);
			G(uh, th);
			a = b.nodeType;
			switch (a) {
				case 9:
				case 11:
					b = (b = b.documentElement) ? b.namespaceURI : lb(null, "");
					break;
				default: a = 8 === a ? b.parentNode : b, b = a.namespaceURI || null, a = a.tagName, b = lb(b, a);
			}
			E(uh);
			G(uh, b);
		}
		function zh() {
			E(uh);
			E(vh);
			E(wh);
		}
		function Ah(a) {
			xh(wh.current);
			var b = xh(uh.current);
			var c = lb(b, a.type);
			b !== c && (G(vh, a), G(uh, c));
		}
		function Bh(a) {
			vh.current === a && (E(uh), E(vh));
		}
		var L = Uf(0);
		function Ch(a) {
			for (var b = a; null !== b;) {
				if (13 === b.tag) {
					var c = b.memoizedState;
					if (null !== c && (c = c.dehydrated, null === c || "$?" === c.data || "$!" === c.data)) return b;
				} else if (19 === b.tag && void 0 !== b.memoizedProps.revealOrder) {
					if (0 !== (b.flags & 128)) return b;
				} else if (null !== b.child) {
					b.child.return = b;
					b = b.child;
					continue;
				}
				if (b === a) break;
				for (; null === b.sibling;) {
					if (null === b.return || b.return === a) return null;
					b = b.return;
				}
				b.sibling.return = b.return;
				b = b.sibling;
			}
			return null;
		}
		var Dh = [];
		function Eh() {
			for (var a = 0; a < Dh.length; a++) Dh[a]._workInProgressVersionPrimary = null;
			Dh.length = 0;
		}
		var Fh = ua.ReactCurrentDispatcher;
		var Gh = ua.ReactCurrentBatchConfig;
		var Hh = 0;
		var M = null;
		var N = null;
		var O = null;
		var Ih = !1;
		var Jh = !1;
		var Kh = 0;
		var Lh = 0;
		function P() {
			throw Error(p(321));
		}
		function Mh(a, b) {
			if (null === b) return !1;
			for (var c = 0; c < b.length && c < a.length; c++) if (!He(a[c], b[c])) return !1;
			return !0;
		}
		function Nh(a, b, c, d, e, f) {
			Hh = f;
			M = b;
			b.memoizedState = null;
			b.updateQueue = null;
			b.lanes = 0;
			Fh.current = null === a || null === a.memoizedState ? Oh : Ph;
			a = c(d, e);
			if (Jh) {
				f = 0;
				do {
					Jh = !1;
					Kh = 0;
					if (25 <= f) throw Error(p(301));
					f += 1;
					O = N = null;
					b.updateQueue = null;
					Fh.current = Qh;
					a = c(d, e);
				} while (Jh);
			}
			Fh.current = Rh;
			b = null !== N && null !== N.next;
			Hh = 0;
			O = N = M = null;
			Ih = !1;
			if (b) throw Error(p(300));
			return a;
		}
		function Sh() {
			var a = 0 !== Kh;
			Kh = 0;
			return a;
		}
		function Th() {
			var a = {
				memoizedState: null,
				baseState: null,
				baseQueue: null,
				queue: null,
				next: null
			};
			null === O ? M.memoizedState = O = a : O = O.next = a;
			return O;
		}
		function Uh() {
			if (null === N) {
				var a = M.alternate;
				a = null !== a ? a.memoizedState : null;
			} else a = N.next;
			var b = null === O ? M.memoizedState : O.next;
			if (null !== b) O = b, N = a;
			else {
				if (null === a) throw Error(p(310));
				N = a;
				a = {
					memoizedState: N.memoizedState,
					baseState: N.baseState,
					baseQueue: N.baseQueue,
					queue: N.queue,
					next: null
				};
				null === O ? M.memoizedState = O = a : O = O.next = a;
			}
			return O;
		}
		function Vh(a, b) {
			return "function" === typeof b ? b(a) : b;
		}
		function Wh(a) {
			var b = Uh(), c = b.queue;
			if (null === c) throw Error(p(311));
			c.lastRenderedReducer = a;
			var d = N, e = d.baseQueue, f = c.pending;
			if (null !== f) {
				if (null !== e) {
					var g = e.next;
					e.next = f.next;
					f.next = g;
				}
				d.baseQueue = e = f;
				c.pending = null;
			}
			if (null !== e) {
				f = e.next;
				d = d.baseState;
				var h = g = null, k = null, l = f;
				do {
					var m = l.lane;
					if ((Hh & m) === m) null !== k && (k = k.next = {
						lane: 0,
						action: l.action,
						hasEagerState: l.hasEagerState,
						eagerState: l.eagerState,
						next: null
					}), d = l.hasEagerState ? l.eagerState : a(d, l.action);
					else {
						var q = {
							lane: m,
							action: l.action,
							hasEagerState: l.hasEagerState,
							eagerState: l.eagerState,
							next: null
						};
						null === k ? (h = k = q, g = d) : k = k.next = q;
						M.lanes |= m;
						rh |= m;
					}
					l = l.next;
				} while (null !== l && l !== f);
				null === k ? g = d : k.next = h;
				He(d, b.memoizedState) || (dh = !0);
				b.memoizedState = d;
				b.baseState = g;
				b.baseQueue = k;
				c.lastRenderedState = d;
			}
			a = c.interleaved;
			if (null !== a) {
				e = a;
				do
					f = e.lane, M.lanes |= f, rh |= f, e = e.next;
				while (e !== a);
			} else null === e && (c.lanes = 0);
			return [b.memoizedState, c.dispatch];
		}
		function Xh(a) {
			var b = Uh(), c = b.queue;
			if (null === c) throw Error(p(311));
			c.lastRenderedReducer = a;
			var d = c.dispatch, e = c.pending, f = b.memoizedState;
			if (null !== e) {
				c.pending = null;
				var g = e = e.next;
				do
					f = a(f, g.action), g = g.next;
				while (g !== e);
				He(f, b.memoizedState) || (dh = !0);
				b.memoizedState = f;
				null === b.baseQueue && (b.baseState = f);
				c.lastRenderedState = f;
			}
			return [f, d];
		}
		function Yh() {}
		function Zh(a, b) {
			var c = M, d = Uh(), e = b(), f = !He(d.memoizedState, e);
			f && (d.memoizedState = e, dh = !0);
			d = d.queue;
			$h(ai.bind(null, c, d, a), [a]);
			if (d.getSnapshot !== b || f || null !== O && O.memoizedState.tag & 1) {
				c.flags |= 2048;
				bi(9, ci.bind(null, c, d, e, b), void 0, null);
				if (null === Q) throw Error(p(349));
				0 !== (Hh & 30) || di(c, b, e);
			}
			return e;
		}
		function di(a, b, c) {
			a.flags |= 16384;
			a = {
				getSnapshot: b,
				value: c
			};
			b = M.updateQueue;
			null === b ? (b = {
				lastEffect: null,
				stores: null
			}, M.updateQueue = b, b.stores = [a]) : (c = b.stores, null === c ? b.stores = [a] : c.push(a));
		}
		function ci(a, b, c, d) {
			b.value = c;
			b.getSnapshot = d;
			ei(b) && fi(a);
		}
		function ai(a, b, c) {
			return c(function() {
				ei(b) && fi(a);
			});
		}
		function ei(a) {
			var b = a.getSnapshot;
			a = a.value;
			try {
				var c = b();
				return !He(a, c);
			} catch (d) {
				return !0;
			}
		}
		function fi(a) {
			var b = ih(a, 1);
			null !== b && gi(b, a, 1, -1);
		}
		function hi(a) {
			var b = Th();
			"function" === typeof a && (a = a());
			b.memoizedState = b.baseState = a;
			a = {
				pending: null,
				interleaved: null,
				lanes: 0,
				dispatch: null,
				lastRenderedReducer: Vh,
				lastRenderedState: a
			};
			b.queue = a;
			a = a.dispatch = ii.bind(null, M, a);
			return [b.memoizedState, a];
		}
		function bi(a, b, c, d) {
			a = {
				tag: a,
				create: b,
				destroy: c,
				deps: d,
				next: null
			};
			b = M.updateQueue;
			null === b ? (b = {
				lastEffect: null,
				stores: null
			}, M.updateQueue = b, b.lastEffect = a.next = a) : (c = b.lastEffect, null === c ? b.lastEffect = a.next = a : (d = c.next, c.next = a, a.next = d, b.lastEffect = a));
			return a;
		}
		function ji() {
			return Uh().memoizedState;
		}
		function ki(a, b, c, d) {
			var e = Th();
			M.flags |= a;
			e.memoizedState = bi(1 | b, c, void 0, void 0 === d ? null : d);
		}
		function li(a, b, c, d) {
			var e = Uh();
			d = void 0 === d ? null : d;
			var f = void 0;
			if (null !== N) {
				var g = N.memoizedState;
				f = g.destroy;
				if (null !== d && Mh(d, g.deps)) {
					e.memoizedState = bi(b, c, f, d);
					return;
				}
			}
			M.flags |= a;
			e.memoizedState = bi(1 | b, c, f, d);
		}
		function mi(a, b) {
			return ki(8390656, 8, a, b);
		}
		function $h(a, b) {
			return li(2048, 8, a, b);
		}
		function ni(a, b) {
			return li(4, 2, a, b);
		}
		function oi(a, b) {
			return li(4, 4, a, b);
		}
		function pi(a, b) {
			if ("function" === typeof b) return a = a(), b(a), function() {
				b(null);
			};
			if (null !== b && void 0 !== b) return a = a(), b.current = a, function() {
				b.current = null;
			};
		}
		function qi(a, b, c) {
			c = null !== c && void 0 !== c ? c.concat([a]) : null;
			return li(4, 4, pi.bind(null, b, a), c);
		}
		function ri() {}
		function si(a, b) {
			var c = Uh();
			b = void 0 === b ? null : b;
			var d = c.memoizedState;
			if (null !== d && null !== b && Mh(b, d[1])) return d[0];
			c.memoizedState = [a, b];
			return a;
		}
		function ti(a, b) {
			var c = Uh();
			b = void 0 === b ? null : b;
			var d = c.memoizedState;
			if (null !== d && null !== b && Mh(b, d[1])) return d[0];
			a = a();
			c.memoizedState = [a, b];
			return a;
		}
		function ui(a, b, c) {
			if (0 === (Hh & 21)) return a.baseState && (a.baseState = !1, dh = !0), a.memoizedState = c;
			He(c, b) || (c = yc(), M.lanes |= c, rh |= c, a.baseState = !0);
			return b;
		}
		function vi(a, b) {
			var c = C;
			C = 0 !== c && 4 > c ? c : 4;
			a(!0);
			var d = Gh.transition;
			Gh.transition = {};
			try {
				a(!1), b();
			} finally {
				C = c, Gh.transition = d;
			}
		}
		function wi() {
			return Uh().memoizedState;
		}
		function xi(a, b, c) {
			var d = yi(a);
			c = {
				lane: d,
				action: c,
				hasEagerState: !1,
				eagerState: null,
				next: null
			};
			if (zi(a)) Ai(b, c);
			else if (c = hh(a, b, c, d), null !== c) {
				var e = R();
				gi(c, a, d, e);
				Bi(c, b, d);
			}
		}
		function ii(a, b, c) {
			var d = yi(a), e = {
				lane: d,
				action: c,
				hasEagerState: !1,
				eagerState: null,
				next: null
			};
			if (zi(a)) Ai(b, e);
			else {
				var f = a.alternate;
				if (0 === a.lanes && (null === f || 0 === f.lanes) && (f = b.lastRenderedReducer, null !== f)) try {
					var g = b.lastRenderedState, h = f(g, c);
					e.hasEagerState = !0;
					e.eagerState = h;
					if (He(h, g)) {
						var k = b.interleaved;
						null === k ? (e.next = e, gh(b)) : (e.next = k.next, k.next = e);
						b.interleaved = e;
						return;
					}
				} catch (l) {}
				c = hh(a, b, e, d);
				null !== c && (e = R(), gi(c, a, d, e), Bi(c, b, d));
			}
		}
		function zi(a) {
			var b = a.alternate;
			return a === M || null !== b && b === M;
		}
		function Ai(a, b) {
			Jh = Ih = !0;
			var c = a.pending;
			null === c ? b.next = b : (b.next = c.next, c.next = b);
			a.pending = b;
		}
		function Bi(a, b, c) {
			if (0 !== (c & 4194240)) {
				var d = b.lanes;
				d &= a.pendingLanes;
				c |= d;
				b.lanes = c;
				Cc(a, c);
			}
		}
		var Rh = {
			readContext: eh,
			useCallback: P,
			useContext: P,
			useEffect: P,
			useImperativeHandle: P,
			useInsertionEffect: P,
			useLayoutEffect: P,
			useMemo: P,
			useReducer: P,
			useRef: P,
			useState: P,
			useDebugValue: P,
			useDeferredValue: P,
			useTransition: P,
			useMutableSource: P,
			useSyncExternalStore: P,
			useId: P,
			unstable_isNewReconciler: !1
		};
		var Oh = {
			readContext: eh,
			useCallback: function(a, b) {
				Th().memoizedState = [a, void 0 === b ? null : b];
				return a;
			},
			useContext: eh,
			useEffect: mi,
			useImperativeHandle: function(a, b, c) {
				c = null !== c && void 0 !== c ? c.concat([a]) : null;
				return ki(4194308, 4, pi.bind(null, b, a), c);
			},
			useLayoutEffect: function(a, b) {
				return ki(4194308, 4, a, b);
			},
			useInsertionEffect: function(a, b) {
				return ki(4, 2, a, b);
			},
			useMemo: function(a, b) {
				var c = Th();
				b = void 0 === b ? null : b;
				a = a();
				c.memoizedState = [a, b];
				return a;
			},
			useReducer: function(a, b, c) {
				var d = Th();
				b = void 0 !== c ? c(b) : b;
				d.memoizedState = d.baseState = b;
				a = {
					pending: null,
					interleaved: null,
					lanes: 0,
					dispatch: null,
					lastRenderedReducer: a,
					lastRenderedState: b
				};
				d.queue = a;
				a = a.dispatch = xi.bind(null, M, a);
				return [d.memoizedState, a];
			},
			useRef: function(a) {
				var b = Th();
				a = { current: a };
				return b.memoizedState = a;
			},
			useState: hi,
			useDebugValue: ri,
			useDeferredValue: function(a) {
				return Th().memoizedState = a;
			},
			useTransition: function() {
				var a = hi(!1), b = a[0];
				a = vi.bind(null, a[1]);
				Th().memoizedState = a;
				return [b, a];
			},
			useMutableSource: function() {},
			useSyncExternalStore: function(a, b, c) {
				var d = M, e = Th();
				if (I) {
					if (void 0 === c) throw Error(p(407));
					c = c();
				} else {
					c = b();
					if (null === Q) throw Error(p(349));
					0 !== (Hh & 30) || di(d, b, c);
				}
				e.memoizedState = c;
				var f = {
					value: c,
					getSnapshot: b
				};
				e.queue = f;
				mi(ai.bind(null, d, f, a), [a]);
				d.flags |= 2048;
				bi(9, ci.bind(null, d, f, c, b), void 0, null);
				return c;
			},
			useId: function() {
				var a = Th(), b = Q.identifierPrefix;
				if (I) {
					var c = sg;
					var d = rg;
					c = (d & ~(1 << 32 - oc(d) - 1)).toString(32) + c;
					b = ":" + b + "R" + c;
					c = Kh++;
					0 < c && (b += "H" + c.toString(32));
					b += ":";
				} else c = Lh++, b = ":" + b + "r" + c.toString(32) + ":";
				return a.memoizedState = b;
			},
			unstable_isNewReconciler: !1
		};
		var Ph = {
			readContext: eh,
			useCallback: si,
			useContext: eh,
			useEffect: $h,
			useImperativeHandle: qi,
			useInsertionEffect: ni,
			useLayoutEffect: oi,
			useMemo: ti,
			useReducer: Wh,
			useRef: ji,
			useState: function() {
				return Wh(Vh);
			},
			useDebugValue: ri,
			useDeferredValue: function(a) {
				return ui(Uh(), N.memoizedState, a);
			},
			useTransition: function() {
				return [Wh(Vh)[0], Uh().memoizedState];
			},
			useMutableSource: Yh,
			useSyncExternalStore: Zh,
			useId: wi,
			unstable_isNewReconciler: !1
		};
		var Qh = {
			readContext: eh,
			useCallback: si,
			useContext: eh,
			useEffect: $h,
			useImperativeHandle: qi,
			useInsertionEffect: ni,
			useLayoutEffect: oi,
			useMemo: ti,
			useReducer: Xh,
			useRef: ji,
			useState: function() {
				return Xh(Vh);
			},
			useDebugValue: ri,
			useDeferredValue: function(a) {
				var b = Uh();
				return null === N ? b.memoizedState = a : ui(b, N.memoizedState, a);
			},
			useTransition: function() {
				return [Xh(Vh)[0], Uh().memoizedState];
			},
			useMutableSource: Yh,
			useSyncExternalStore: Zh,
			useId: wi,
			unstable_isNewReconciler: !1
		};
		function Ci(a, b) {
			if (a && a.defaultProps) {
				b = A({}, b);
				a = a.defaultProps;
				for (var c in a) void 0 === b[c] && (b[c] = a[c]);
				return b;
			}
			return b;
		}
		function Di(a, b, c, d) {
			b = a.memoizedState;
			c = c(d, b);
			c = null === c || void 0 === c ? b : A({}, b, c);
			a.memoizedState = c;
			0 === a.lanes && (a.updateQueue.baseState = c);
		}
		var Ei = {
			isMounted: function(a) {
				return (a = a._reactInternals) ? Vb(a) === a : !1;
			},
			enqueueSetState: function(a, b, c) {
				a = a._reactInternals;
				var d = R(), e = yi(a), f = mh(d, e);
				f.payload = b;
				void 0 !== c && null !== c && (f.callback = c);
				b = nh(a, f, e);
				null !== b && (gi(b, a, e, d), oh(b, a, e));
			},
			enqueueReplaceState: function(a, b, c) {
				a = a._reactInternals;
				var d = R(), e = yi(a), f = mh(d, e);
				f.tag = 1;
				f.payload = b;
				void 0 !== c && null !== c && (f.callback = c);
				b = nh(a, f, e);
				null !== b && (gi(b, a, e, d), oh(b, a, e));
			},
			enqueueForceUpdate: function(a, b) {
				a = a._reactInternals;
				var c = R(), d = yi(a), e = mh(c, d);
				e.tag = 2;
				void 0 !== b && null !== b && (e.callback = b);
				b = nh(a, e, d);
				null !== b && (gi(b, a, d, c), oh(b, a, d));
			}
		};
		function Fi(a, b, c, d, e, f, g) {
			a = a.stateNode;
			return "function" === typeof a.shouldComponentUpdate ? a.shouldComponentUpdate(d, f, g) : b.prototype && b.prototype.isPureReactComponent ? !Ie(c, d) || !Ie(e, f) : !0;
		}
		function Gi(a, b, c) {
			var d = !1, e = Vf;
			var f = b.contextType;
			"object" === typeof f && null !== f ? f = eh(f) : (e = Zf(b) ? Xf : H.current, d = b.contextTypes, f = (d = null !== d && void 0 !== d) ? Yf(a, e) : Vf);
			b = new b(c, f);
			a.memoizedState = null !== b.state && void 0 !== b.state ? b.state : null;
			b.updater = Ei;
			a.stateNode = b;
			b._reactInternals = a;
			d && (a = a.stateNode, a.__reactInternalMemoizedUnmaskedChildContext = e, a.__reactInternalMemoizedMaskedChildContext = f);
			return b;
		}
		function Hi(a, b, c, d) {
			a = b.state;
			"function" === typeof b.componentWillReceiveProps && b.componentWillReceiveProps(c, d);
			"function" === typeof b.UNSAFE_componentWillReceiveProps && b.UNSAFE_componentWillReceiveProps(c, d);
			b.state !== a && Ei.enqueueReplaceState(b, b.state, null);
		}
		function Ii(a, b, c, d) {
			var e = a.stateNode;
			e.props = c;
			e.state = a.memoizedState;
			e.refs = {};
			kh(a);
			var f = b.contextType;
			"object" === typeof f && null !== f ? e.context = eh(f) : (f = Zf(b) ? Xf : H.current, e.context = Yf(a, f));
			e.state = a.memoizedState;
			f = b.getDerivedStateFromProps;
			"function" === typeof f && (Di(a, b, f, c), e.state = a.memoizedState);
			"function" === typeof b.getDerivedStateFromProps || "function" === typeof e.getSnapshotBeforeUpdate || "function" !== typeof e.UNSAFE_componentWillMount && "function" !== typeof e.componentWillMount || (b = e.state, "function" === typeof e.componentWillMount && e.componentWillMount(), "function" === typeof e.UNSAFE_componentWillMount && e.UNSAFE_componentWillMount(), b !== e.state && Ei.enqueueReplaceState(e, e.state, null), qh(a, c, e, d), e.state = a.memoizedState);
			"function" === typeof e.componentDidMount && (a.flags |= 4194308);
		}
		function Ji(a, b) {
			try {
				var c = "", d = b;
				do
					c += Pa(d), d = d.return;
				while (d);
				var e = c;
			} catch (f) {
				e = "\nError generating stack: " + f.message + "\n" + f.stack;
			}
			return {
				value: a,
				source: b,
				stack: e,
				digest: null
			};
		}
		function Ki(a, b, c) {
			return {
				value: a,
				source: null,
				stack: null != c ? c : null,
				digest: null != b ? b : null
			};
		}
		function Li(a, b) {
			try {
				console.error(b.value);
			} catch (c) {
				setTimeout(function() {
					throw c;
				});
			}
		}
		var Mi = "function" === typeof WeakMap ? WeakMap : Map;
		function Ni(a, b, c) {
			c = mh(-1, c);
			c.tag = 3;
			c.payload = { element: null };
			var d = b.value;
			c.callback = function() {
				Oi || (Oi = !0, Pi = d);
				Li(a, b);
			};
			return c;
		}
		function Qi(a, b, c) {
			c = mh(-1, c);
			c.tag = 3;
			var d = a.type.getDerivedStateFromError;
			if ("function" === typeof d) {
				var e = b.value;
				c.payload = function() {
					return d(e);
				};
				c.callback = function() {
					Li(a, b);
				};
			}
			var f = a.stateNode;
			null !== f && "function" === typeof f.componentDidCatch && (c.callback = function() {
				Li(a, b);
				"function" !== typeof d && (null === Ri ? Ri = /* @__PURE__ */ new Set([this]) : Ri.add(this));
				var c = b.stack;
				this.componentDidCatch(b.value, { componentStack: null !== c ? c : "" });
			});
			return c;
		}
		function Si(a, b, c) {
			var d = a.pingCache;
			if (null === d) {
				d = a.pingCache = new Mi();
				var e = /* @__PURE__ */ new Set();
				d.set(b, e);
			} else e = d.get(b), void 0 === e && (e = /* @__PURE__ */ new Set(), d.set(b, e));
			e.has(c) || (e.add(c), a = Ti.bind(null, a, b, c), b.then(a, a));
		}
		function Ui(a) {
			do {
				var b;
				if (b = 13 === a.tag) b = a.memoizedState, b = null !== b ? null !== b.dehydrated ? !0 : !1 : !0;
				if (b) return a;
				a = a.return;
			} while (null !== a);
			return null;
		}
		function Vi(a, b, c, d, e) {
			if (0 === (a.mode & 1)) return a === b ? a.flags |= 65536 : (a.flags |= 128, c.flags |= 131072, c.flags &= -52805, 1 === c.tag && (null === c.alternate ? c.tag = 17 : (b = mh(-1, 1), b.tag = 2, nh(c, b, 1))), c.lanes |= 1), a;
			a.flags |= 65536;
			a.lanes = e;
			return a;
		}
		var Wi = ua.ReactCurrentOwner;
		var dh = !1;
		function Xi(a, b, c, d) {
			b.child = null === a ? Vg(b, null, c, d) : Ug(b, a.child, c, d);
		}
		function Yi(a, b, c, d, e) {
			c = c.render;
			var f = b.ref;
			ch(b, e);
			d = Nh(a, b, c, d, f, e);
			c = Sh();
			if (null !== a && !dh) return b.updateQueue = a.updateQueue, b.flags &= -2053, a.lanes &= ~e, Zi(a, b, e);
			I && c && vg(b);
			b.flags |= 1;
			Xi(a, b, d, e);
			return b.child;
		}
		function $i(a, b, c, d, e) {
			if (null === a) {
				var f = c.type;
				if ("function" === typeof f && !aj(f) && void 0 === f.defaultProps && null === c.compare && void 0 === c.defaultProps) return b.tag = 15, b.type = f, bj(a, b, f, d, e);
				a = Rg(c.type, null, d, b, b.mode, e);
				a.ref = b.ref;
				a.return = b;
				return b.child = a;
			}
			f = a.child;
			if (0 === (a.lanes & e)) {
				var g = f.memoizedProps;
				c = c.compare;
				c = null !== c ? c : Ie;
				if (c(g, d) && a.ref === b.ref) return Zi(a, b, e);
			}
			b.flags |= 1;
			a = Pg(f, d);
			a.ref = b.ref;
			a.return = b;
			return b.child = a;
		}
		function bj(a, b, c, d, e) {
			if (null !== a) {
				var f = a.memoizedProps;
				if (Ie(f, d) && a.ref === b.ref) if (dh = !1, b.pendingProps = d = f, 0 !== (a.lanes & e)) 0 !== (a.flags & 131072) && (dh = !0);
				else return b.lanes = a.lanes, Zi(a, b, e);
			}
			return cj(a, b, c, d, e);
		}
		function dj(a, b, c) {
			var d = b.pendingProps, e = d.children, f = null !== a ? a.memoizedState : null;
			if ("hidden" === d.mode) if (0 === (b.mode & 1)) b.memoizedState = {
				baseLanes: 0,
				cachePool: null,
				transitions: null
			}, G(ej, fj), fj |= c;
			else {
				if (0 === (c & 1073741824)) return a = null !== f ? f.baseLanes | c : c, b.lanes = b.childLanes = 1073741824, b.memoizedState = {
					baseLanes: a,
					cachePool: null,
					transitions: null
				}, b.updateQueue = null, G(ej, fj), fj |= a, null;
				b.memoizedState = {
					baseLanes: 0,
					cachePool: null,
					transitions: null
				};
				d = null !== f ? f.baseLanes : c;
				G(ej, fj);
				fj |= d;
			}
			else null !== f ? (d = f.baseLanes | c, b.memoizedState = null) : d = c, G(ej, fj), fj |= d;
			Xi(a, b, e, c);
			return b.child;
		}
		function gj(a, b) {
			var c = b.ref;
			if (null === a && null !== c || null !== a && a.ref !== c) b.flags |= 512, b.flags |= 2097152;
		}
		function cj(a, b, c, d, e) {
			var f = Zf(c) ? Xf : H.current;
			f = Yf(b, f);
			ch(b, e);
			c = Nh(a, b, c, d, f, e);
			d = Sh();
			if (null !== a && !dh) return b.updateQueue = a.updateQueue, b.flags &= -2053, a.lanes &= ~e, Zi(a, b, e);
			I && d && vg(b);
			b.flags |= 1;
			Xi(a, b, c, e);
			return b.child;
		}
		function hj(a, b, c, d, e) {
			if (Zf(c)) {
				var f = !0;
				cg(b);
			} else f = !1;
			ch(b, e);
			if (null === b.stateNode) ij(a, b), Gi(b, c, d), Ii(b, c, d, e), d = !0;
			else if (null === a) {
				var g = b.stateNode, h = b.memoizedProps;
				g.props = h;
				var k = g.context, l = c.contextType;
				"object" === typeof l && null !== l ? l = eh(l) : (l = Zf(c) ? Xf : H.current, l = Yf(b, l));
				var m = c.getDerivedStateFromProps, q = "function" === typeof m || "function" === typeof g.getSnapshotBeforeUpdate;
				q || "function" !== typeof g.UNSAFE_componentWillReceiveProps && "function" !== typeof g.componentWillReceiveProps || (h !== d || k !== l) && Hi(b, g, d, l);
				jh = !1;
				var r = b.memoizedState;
				g.state = r;
				qh(b, d, g, e);
				k = b.memoizedState;
				h !== d || r !== k || Wf.current || jh ? ("function" === typeof m && (Di(b, c, m, d), k = b.memoizedState), (h = jh || Fi(b, c, h, d, r, k, l)) ? (q || "function" !== typeof g.UNSAFE_componentWillMount && "function" !== typeof g.componentWillMount || ("function" === typeof g.componentWillMount && g.componentWillMount(), "function" === typeof g.UNSAFE_componentWillMount && g.UNSAFE_componentWillMount()), "function" === typeof g.componentDidMount && (b.flags |= 4194308)) : ("function" === typeof g.componentDidMount && (b.flags |= 4194308), b.memoizedProps = d, b.memoizedState = k), g.props = d, g.state = k, g.context = l, d = h) : ("function" === typeof g.componentDidMount && (b.flags |= 4194308), d = !1);
			} else {
				g = b.stateNode;
				lh(a, b);
				h = b.memoizedProps;
				l = b.type === b.elementType ? h : Ci(b.type, h);
				g.props = l;
				q = b.pendingProps;
				r = g.context;
				k = c.contextType;
				"object" === typeof k && null !== k ? k = eh(k) : (k = Zf(c) ? Xf : H.current, k = Yf(b, k));
				var y = c.getDerivedStateFromProps;
				(m = "function" === typeof y || "function" === typeof g.getSnapshotBeforeUpdate) || "function" !== typeof g.UNSAFE_componentWillReceiveProps && "function" !== typeof g.componentWillReceiveProps || (h !== q || r !== k) && Hi(b, g, d, k);
				jh = !1;
				r = b.memoizedState;
				g.state = r;
				qh(b, d, g, e);
				var n = b.memoizedState;
				h !== q || r !== n || Wf.current || jh ? ("function" === typeof y && (Di(b, c, y, d), n = b.memoizedState), (l = jh || Fi(b, c, l, d, r, n, k) || !1) ? (m || "function" !== typeof g.UNSAFE_componentWillUpdate && "function" !== typeof g.componentWillUpdate || ("function" === typeof g.componentWillUpdate && g.componentWillUpdate(d, n, k), "function" === typeof g.UNSAFE_componentWillUpdate && g.UNSAFE_componentWillUpdate(d, n, k)), "function" === typeof g.componentDidUpdate && (b.flags |= 4), "function" === typeof g.getSnapshotBeforeUpdate && (b.flags |= 1024)) : ("function" !== typeof g.componentDidUpdate || h === a.memoizedProps && r === a.memoizedState || (b.flags |= 4), "function" !== typeof g.getSnapshotBeforeUpdate || h === a.memoizedProps && r === a.memoizedState || (b.flags |= 1024), b.memoizedProps = d, b.memoizedState = n), g.props = d, g.state = n, g.context = k, d = l) : ("function" !== typeof g.componentDidUpdate || h === a.memoizedProps && r === a.memoizedState || (b.flags |= 4), "function" !== typeof g.getSnapshotBeforeUpdate || h === a.memoizedProps && r === a.memoizedState || (b.flags |= 1024), d = !1);
			}
			return jj(a, b, c, d, f, e);
		}
		function jj(a, b, c, d, e, f) {
			gj(a, b);
			var g = 0 !== (b.flags & 128);
			if (!d && !g) return e && dg(b, c, !1), Zi(a, b, f);
			d = b.stateNode;
			Wi.current = b;
			var h = g && "function" !== typeof c.getDerivedStateFromError ? null : d.render();
			b.flags |= 1;
			null !== a && g ? (b.child = Ug(b, a.child, null, f), b.child = Ug(b, null, h, f)) : Xi(a, b, h, f);
			b.memoizedState = d.state;
			e && dg(b, c, !0);
			return b.child;
		}
		function kj(a) {
			var b = a.stateNode;
			b.pendingContext ? ag(a, b.pendingContext, b.pendingContext !== b.context) : b.context && ag(a, b.context, !1);
			yh(a, b.containerInfo);
		}
		function lj(a, b, c, d, e) {
			Ig();
			Jg(e);
			b.flags |= 256;
			Xi(a, b, c, d);
			return b.child;
		}
		var mj = {
			dehydrated: null,
			treeContext: null,
			retryLane: 0
		};
		function nj(a) {
			return {
				baseLanes: a,
				cachePool: null,
				transitions: null
			};
		}
		function oj(a, b, c) {
			var d = b.pendingProps, e = L.current, f = !1, g = 0 !== (b.flags & 128), h;
			(h = g) || (h = null !== a && null === a.memoizedState ? !1 : 0 !== (e & 2));
			if (h) f = !0, b.flags &= -129;
			else if (null === a || null !== a.memoizedState) e |= 1;
			G(L, e & 1);
			if (null === a) {
				Eg(b);
				a = b.memoizedState;
				if (null !== a && (a = a.dehydrated, null !== a)) return 0 === (b.mode & 1) ? b.lanes = 1 : "$!" === a.data ? b.lanes = 8 : b.lanes = 1073741824, null;
				g = d.children;
				a = d.fallback;
				return f ? (d = b.mode, f = b.child, g = {
					mode: "hidden",
					children: g
				}, 0 === (d & 1) && null !== f ? (f.childLanes = 0, f.pendingProps = g) : f = pj(g, d, 0, null), a = Tg(a, d, c, null), f.return = b, a.return = b, f.sibling = a, b.child = f, b.child.memoizedState = nj(c), b.memoizedState = mj, a) : qj(b, g);
			}
			e = a.memoizedState;
			if (null !== e && (h = e.dehydrated, null !== h)) return rj(a, b, g, d, h, e, c);
			if (f) {
				f = d.fallback;
				g = b.mode;
				e = a.child;
				h = e.sibling;
				var k = {
					mode: "hidden",
					children: d.children
				};
				0 === (g & 1) && b.child !== e ? (d = b.child, d.childLanes = 0, d.pendingProps = k, b.deletions = null) : (d = Pg(e, k), d.subtreeFlags = e.subtreeFlags & 14680064);
				null !== h ? f = Pg(h, f) : (f = Tg(f, g, c, null), f.flags |= 2);
				f.return = b;
				d.return = b;
				d.sibling = f;
				b.child = d;
				d = f;
				f = b.child;
				g = a.child.memoizedState;
				g = null === g ? nj(c) : {
					baseLanes: g.baseLanes | c,
					cachePool: null,
					transitions: g.transitions
				};
				f.memoizedState = g;
				f.childLanes = a.childLanes & ~c;
				b.memoizedState = mj;
				return d;
			}
			f = a.child;
			a = f.sibling;
			d = Pg(f, {
				mode: "visible",
				children: d.children
			});
			0 === (b.mode & 1) && (d.lanes = c);
			d.return = b;
			d.sibling = null;
			null !== a && (c = b.deletions, null === c ? (b.deletions = [a], b.flags |= 16) : c.push(a));
			b.child = d;
			b.memoizedState = null;
			return d;
		}
		function qj(a, b) {
			b = pj({
				mode: "visible",
				children: b
			}, a.mode, 0, null);
			b.return = a;
			return a.child = b;
		}
		function sj(a, b, c, d) {
			null !== d && Jg(d);
			Ug(b, a.child, null, c);
			a = qj(b, b.pendingProps.children);
			a.flags |= 2;
			b.memoizedState = null;
			return a;
		}
		function rj(a, b, c, d, e, f, g) {
			if (c) {
				if (b.flags & 256) return b.flags &= -257, d = Ki(Error(p(422))), sj(a, b, g, d);
				if (null !== b.memoizedState) return b.child = a.child, b.flags |= 128, null;
				f = d.fallback;
				e = b.mode;
				d = pj({
					mode: "visible",
					children: d.children
				}, e, 0, null);
				f = Tg(f, e, g, null);
				f.flags |= 2;
				d.return = b;
				f.return = b;
				d.sibling = f;
				b.child = d;
				0 !== (b.mode & 1) && Ug(b, a.child, null, g);
				b.child.memoizedState = nj(g);
				b.memoizedState = mj;
				return f;
			}
			if (0 === (b.mode & 1)) return sj(a, b, g, null);
			if ("$!" === e.data) {
				d = e.nextSibling && e.nextSibling.dataset;
				if (d) var h = d.dgst;
				d = h;
				f = Error(p(419));
				d = Ki(f, d, void 0);
				return sj(a, b, g, d);
			}
			h = 0 !== (g & a.childLanes);
			if (dh || h) {
				d = Q;
				if (null !== d) {
					switch (g & -g) {
						case 4:
							e = 2;
							break;
						case 16:
							e = 8;
							break;
						case 64:
						case 128:
						case 256:
						case 512:
						case 1024:
						case 2048:
						case 4096:
						case 8192:
						case 16384:
						case 32768:
						case 65536:
						case 131072:
						case 262144:
						case 524288:
						case 1048576:
						case 2097152:
						case 4194304:
						case 8388608:
						case 16777216:
						case 33554432:
						case 67108864:
							e = 32;
							break;
						case 536870912:
							e = 268435456;
							break;
						default: e = 0;
					}
					e = 0 !== (e & (d.suspendedLanes | g)) ? 0 : e;
					0 !== e && e !== f.retryLane && (f.retryLane = e, ih(a, e), gi(d, a, e, -1));
				}
				tj();
				d = Ki(Error(p(421)));
				return sj(a, b, g, d);
			}
			if ("$?" === e.data) return b.flags |= 128, b.child = a.child, b = uj.bind(null, a), e._reactRetry = b, null;
			a = f.treeContext;
			yg = Lf(e.nextSibling);
			xg = b;
			I = !0;
			zg = null;
			null !== a && (og[pg++] = rg, og[pg++] = sg, og[pg++] = qg, rg = a.id, sg = a.overflow, qg = b);
			b = qj(b, d.children);
			b.flags |= 4096;
			return b;
		}
		function vj(a, b, c) {
			a.lanes |= b;
			var d = a.alternate;
			null !== d && (d.lanes |= b);
			bh(a.return, b, c);
		}
		function wj(a, b, c, d, e) {
			var f = a.memoizedState;
			null === f ? a.memoizedState = {
				isBackwards: b,
				rendering: null,
				renderingStartTime: 0,
				last: d,
				tail: c,
				tailMode: e
			} : (f.isBackwards = b, f.rendering = null, f.renderingStartTime = 0, f.last = d, f.tail = c, f.tailMode = e);
		}
		function xj(a, b, c) {
			var d = b.pendingProps, e = d.revealOrder, f = d.tail;
			Xi(a, b, d.children, c);
			d = L.current;
			if (0 !== (d & 2)) d = d & 1 | 2, b.flags |= 128;
			else {
				if (null !== a && 0 !== (a.flags & 128)) a: for (a = b.child; null !== a;) {
					if (13 === a.tag) null !== a.memoizedState && vj(a, c, b);
					else if (19 === a.tag) vj(a, c, b);
					else if (null !== a.child) {
						a.child.return = a;
						a = a.child;
						continue;
					}
					if (a === b) break a;
					for (; null === a.sibling;) {
						if (null === a.return || a.return === b) break a;
						a = a.return;
					}
					a.sibling.return = a.return;
					a = a.sibling;
				}
				d &= 1;
			}
			G(L, d);
			if (0 === (b.mode & 1)) b.memoizedState = null;
			else switch (e) {
				case "forwards":
					c = b.child;
					for (e = null; null !== c;) a = c.alternate, null !== a && null === Ch(a) && (e = c), c = c.sibling;
					c = e;
					null === c ? (e = b.child, b.child = null) : (e = c.sibling, c.sibling = null);
					wj(b, !1, e, c, f);
					break;
				case "backwards":
					c = null;
					e = b.child;
					for (b.child = null; null !== e;) {
						a = e.alternate;
						if (null !== a && null === Ch(a)) {
							b.child = e;
							break;
						}
						a = e.sibling;
						e.sibling = c;
						c = e;
						e = a;
					}
					wj(b, !0, c, null, f);
					break;
				case "together":
					wj(b, !1, null, null, void 0);
					break;
				default: b.memoizedState = null;
			}
			return b.child;
		}
		function ij(a, b) {
			0 === (b.mode & 1) && null !== a && (a.alternate = null, b.alternate = null, b.flags |= 2);
		}
		function Zi(a, b, c) {
			null !== a && (b.dependencies = a.dependencies);
			rh |= b.lanes;
			if (0 === (c & b.childLanes)) return null;
			if (null !== a && b.child !== a.child) throw Error(p(153));
			if (null !== b.child) {
				a = b.child;
				c = Pg(a, a.pendingProps);
				b.child = c;
				for (c.return = b; null !== a.sibling;) a = a.sibling, c = c.sibling = Pg(a, a.pendingProps), c.return = b;
				c.sibling = null;
			}
			return b.child;
		}
		function yj(a, b, c) {
			switch (b.tag) {
				case 3:
					kj(b);
					Ig();
					break;
				case 5:
					Ah(b);
					break;
				case 1:
					Zf(b.type) && cg(b);
					break;
				case 4:
					yh(b, b.stateNode.containerInfo);
					break;
				case 10:
					var d = b.type._context, e = b.memoizedProps.value;
					G(Wg, d._currentValue);
					d._currentValue = e;
					break;
				case 13:
					d = b.memoizedState;
					if (null !== d) {
						if (null !== d.dehydrated) return G(L, L.current & 1), b.flags |= 128, null;
						if (0 !== (c & b.child.childLanes)) return oj(a, b, c);
						G(L, L.current & 1);
						a = Zi(a, b, c);
						return null !== a ? a.sibling : null;
					}
					G(L, L.current & 1);
					break;
				case 19:
					d = 0 !== (c & b.childLanes);
					if (0 !== (a.flags & 128)) {
						if (d) return xj(a, b, c);
						b.flags |= 128;
					}
					e = b.memoizedState;
					null !== e && (e.rendering = null, e.tail = null, e.lastEffect = null);
					G(L, L.current);
					if (d) break;
					else return null;
				case 22:
				case 23: return b.lanes = 0, dj(a, b, c);
			}
			return Zi(a, b, c);
		}
		var zj = function(a, b) {
			for (var c = b.child; null !== c;) {
				if (5 === c.tag || 6 === c.tag) a.appendChild(c.stateNode);
				else if (4 !== c.tag && null !== c.child) {
					c.child.return = c;
					c = c.child;
					continue;
				}
				if (c === b) break;
				for (; null === c.sibling;) {
					if (null === c.return || c.return === b) return;
					c = c.return;
				}
				c.sibling.return = c.return;
				c = c.sibling;
			}
		};
		var Bj = function(a, b, c, d) {
			var e = a.memoizedProps;
			if (e !== d) {
				a = b.stateNode;
				xh(uh.current);
				var f = null;
				switch (c) {
					case "input":
						e = Ya(a, e);
						d = Ya(a, d);
						f = [];
						break;
					case "select":
						e = A({}, e, { value: void 0 });
						d = A({}, d, { value: void 0 });
						f = [];
						break;
					case "textarea":
						e = gb(a, e);
						d = gb(a, d);
						f = [];
						break;
					default: "function" !== typeof e.onClick && "function" === typeof d.onClick && (a.onclick = Bf);
				}
				ub(c, d);
				var g;
				c = null;
				for (l in e) if (!d.hasOwnProperty(l) && e.hasOwnProperty(l) && null != e[l]) if ("style" === l) {
					var h = e[l];
					for (g in h) h.hasOwnProperty(g) && (c || (c = {}), c[g] = "");
				} else "dangerouslySetInnerHTML" !== l && "children" !== l && "suppressContentEditableWarning" !== l && "suppressHydrationWarning" !== l && "autoFocus" !== l && (ea.hasOwnProperty(l) ? f || (f = []) : (f = f || []).push(l, null));
				for (l in d) {
					var k = d[l];
					h = null != e ? e[l] : void 0;
					if (d.hasOwnProperty(l) && k !== h && (null != k || null != h)) if ("style" === l) if (h) {
						for (g in h) !h.hasOwnProperty(g) || k && k.hasOwnProperty(g) || (c || (c = {}), c[g] = "");
						for (g in k) k.hasOwnProperty(g) && h[g] !== k[g] && (c || (c = {}), c[g] = k[g]);
					} else c || (f || (f = []), f.push(l, c)), c = k;
					else "dangerouslySetInnerHTML" === l ? (k = k ? k.__html : void 0, h = h ? h.__html : void 0, null != k && h !== k && (f = f || []).push(l, k)) : "children" === l ? "string" !== typeof k && "number" !== typeof k || (f = f || []).push(l, "" + k) : "suppressContentEditableWarning" !== l && "suppressHydrationWarning" !== l && (ea.hasOwnProperty(l) ? (null != k && "onScroll" === l && D("scroll", a), f || h === k || (f = [])) : (f = f || []).push(l, k));
				}
				c && (f = f || []).push("style", c);
				var l = f;
				if (b.updateQueue = l) b.flags |= 4;
			}
		};
		var Cj = function(a, b, c, d) {
			c !== d && (b.flags |= 4);
		};
		function Dj(a, b) {
			if (!I) switch (a.tailMode) {
				case "hidden":
					b = a.tail;
					for (var c = null; null !== b;) null !== b.alternate && (c = b), b = b.sibling;
					null === c ? a.tail = null : c.sibling = null;
					break;
				case "collapsed":
					c = a.tail;
					for (var d = null; null !== c;) null !== c.alternate && (d = c), c = c.sibling;
					null === d ? b || null === a.tail ? a.tail = null : a.tail.sibling = null : d.sibling = null;
			}
		}
		function S(a) {
			var b = null !== a.alternate && a.alternate.child === a.child, c = 0, d = 0;
			if (b) for (var e = a.child; null !== e;) c |= e.lanes | e.childLanes, d |= e.subtreeFlags & 14680064, d |= e.flags & 14680064, e.return = a, e = e.sibling;
			else for (e = a.child; null !== e;) c |= e.lanes | e.childLanes, d |= e.subtreeFlags, d |= e.flags, e.return = a, e = e.sibling;
			a.subtreeFlags |= d;
			a.childLanes = c;
			return b;
		}
		function Ej(a, b, c) {
			var d = b.pendingProps;
			wg(b);
			switch (b.tag) {
				case 2:
				case 16:
				case 15:
				case 0:
				case 11:
				case 7:
				case 8:
				case 12:
				case 9:
				case 14: return S(b), null;
				case 1: return Zf(b.type) && $f(), S(b), null;
				case 3:
					d = b.stateNode;
					zh();
					E(Wf);
					E(H);
					Eh();
					d.pendingContext && (d.context = d.pendingContext, d.pendingContext = null);
					if (null === a || null === a.child) Gg(b) ? b.flags |= 4 : null === a || a.memoizedState.isDehydrated && 0 === (b.flags & 256) || (b.flags |= 1024, null !== zg && (Fj(zg), zg = null));
					S(b);
					return null;
				case 5:
					Bh(b);
					var e = xh(wh.current);
					c = b.type;
					if (null !== a && null != b.stateNode) Bj(a, b, c, d, e), a.ref !== b.ref && (b.flags |= 512, b.flags |= 2097152);
					else {
						if (!d) {
							if (null === b.stateNode) throw Error(p(166));
							S(b);
							return null;
						}
						a = xh(uh.current);
						if (Gg(b)) {
							d = b.stateNode;
							c = b.type;
							var f = b.memoizedProps;
							d[Of] = b;
							d[Pf] = f;
							a = 0 !== (b.mode & 1);
							switch (c) {
								case "dialog":
									D("cancel", d);
									D("close", d);
									break;
								case "iframe":
								case "object":
								case "embed":
									D("load", d);
									break;
								case "video":
								case "audio":
									for (e = 0; e < lf.length; e++) D(lf[e], d);
									break;
								case "source":
									D("error", d);
									break;
								case "img":
								case "image":
								case "link":
									D("error", d);
									D("load", d);
									break;
								case "details":
									D("toggle", d);
									break;
								case "input":
									Za(d, f);
									D("invalid", d);
									break;
								case "select":
									d._wrapperState = { wasMultiple: !!f.multiple };
									D("invalid", d);
									break;
								case "textarea": hb(d, f), D("invalid", d);
							}
							ub(c, f);
							e = null;
							for (var g in f) if (f.hasOwnProperty(g)) {
								var h = f[g];
								"children" === g ? "string" === typeof h ? d.textContent !== h && (!0 !== f.suppressHydrationWarning && Af(d.textContent, h, a), e = ["children", h]) : "number" === typeof h && d.textContent !== "" + h && (!0 !== f.suppressHydrationWarning && Af(d.textContent, h, a), e = ["children", "" + h]) : ea.hasOwnProperty(g) && null != h && "onScroll" === g && D("scroll", d);
							}
							switch (c) {
								case "input":
									Va(d);
									db(d, f, !0);
									break;
								case "textarea":
									Va(d);
									jb(d);
									break;
								case "select":
								case "option": break;
								default: "function" === typeof f.onClick && (d.onclick = Bf);
							}
							d = e;
							b.updateQueue = d;
							null !== d && (b.flags |= 4);
						} else {
							g = 9 === e.nodeType ? e : e.ownerDocument;
							"http://www.w3.org/1999/xhtml" === a && (a = kb(c));
							"http://www.w3.org/1999/xhtml" === a ? "script" === c ? (a = g.createElement("div"), a.innerHTML = "<script><\/script>", a = a.removeChild(a.firstChild)) : "string" === typeof d.is ? a = g.createElement(c, { is: d.is }) : (a = g.createElement(c), "select" === c && (g = a, d.multiple ? g.multiple = !0 : d.size && (g.size = d.size))) : a = g.createElementNS(a, c);
							a[Of] = b;
							a[Pf] = d;
							zj(a, b, !1, !1);
							b.stateNode = a;
							a: {
								g = vb(c, d);
								switch (c) {
									case "dialog":
										D("cancel", a);
										D("close", a);
										e = d;
										break;
									case "iframe":
									case "object":
									case "embed":
										D("load", a);
										e = d;
										break;
									case "video":
									case "audio":
										for (e = 0; e < lf.length; e++) D(lf[e], a);
										e = d;
										break;
									case "source":
										D("error", a);
										e = d;
										break;
									case "img":
									case "image":
									case "link":
										D("error", a);
										D("load", a);
										e = d;
										break;
									case "details":
										D("toggle", a);
										e = d;
										break;
									case "input":
										Za(a, d);
										e = Ya(a, d);
										D("invalid", a);
										break;
									case "option":
										e = d;
										break;
									case "select":
										a._wrapperState = { wasMultiple: !!d.multiple };
										e = A({}, d, { value: void 0 });
										D("invalid", a);
										break;
									case "textarea":
										hb(a, d);
										e = gb(a, d);
										D("invalid", a);
										break;
									default: e = d;
								}
								ub(c, e);
								h = e;
								for (f in h) if (h.hasOwnProperty(f)) {
									var k = h[f];
									"style" === f ? sb(a, k) : "dangerouslySetInnerHTML" === f ? (k = k ? k.__html : void 0, null != k && nb(a, k)) : "children" === f ? "string" === typeof k ? ("textarea" !== c || "" !== k) && ob(a, k) : "number" === typeof k && ob(a, "" + k) : "suppressContentEditableWarning" !== f && "suppressHydrationWarning" !== f && "autoFocus" !== f && (ea.hasOwnProperty(f) ? null != k && "onScroll" === f && D("scroll", a) : null != k && ta(a, f, k, g));
								}
								switch (c) {
									case "input":
										Va(a);
										db(a, d, !1);
										break;
									case "textarea":
										Va(a);
										jb(a);
										break;
									case "option":
										null != d.value && a.setAttribute("value", "" + Sa(d.value));
										break;
									case "select":
										a.multiple = !!d.multiple;
										f = d.value;
										null != f ? fb(a, !!d.multiple, f, !1) : null != d.defaultValue && fb(a, !!d.multiple, d.defaultValue, !0);
										break;
									default: "function" === typeof e.onClick && (a.onclick = Bf);
								}
								switch (c) {
									case "button":
									case "input":
									case "select":
									case "textarea":
										d = !!d.autoFocus;
										break a;
									case "img":
										d = !0;
										break a;
									default: d = !1;
								}
							}
							d && (b.flags |= 4);
						}
						null !== b.ref && (b.flags |= 512, b.flags |= 2097152);
					}
					S(b);
					return null;
				case 6:
					if (a && null != b.stateNode) Cj(a, b, a.memoizedProps, d);
					else {
						if ("string" !== typeof d && null === b.stateNode) throw Error(p(166));
						c = xh(wh.current);
						xh(uh.current);
						if (Gg(b)) {
							d = b.stateNode;
							c = b.memoizedProps;
							d[Of] = b;
							if (f = d.nodeValue !== c) {
								if (a = xg, null !== a) switch (a.tag) {
									case 3:
										Af(d.nodeValue, c, 0 !== (a.mode & 1));
										break;
									case 5: !0 !== a.memoizedProps.suppressHydrationWarning && Af(d.nodeValue, c, 0 !== (a.mode & 1));
								}
							}
							f && (b.flags |= 4);
						} else d = (9 === c.nodeType ? c : c.ownerDocument).createTextNode(d), d[Of] = b, b.stateNode = d;
					}
					S(b);
					return null;
				case 13:
					E(L);
					d = b.memoizedState;
					if (null === a || null !== a.memoizedState && null !== a.memoizedState.dehydrated) {
						if (I && null !== yg && 0 !== (b.mode & 1) && 0 === (b.flags & 128)) Hg(), Ig(), b.flags |= 98560, f = !1;
						else if (f = Gg(b), null !== d && null !== d.dehydrated) {
							if (null === a) {
								if (!f) throw Error(p(318));
								f = b.memoizedState;
								f = null !== f ? f.dehydrated : null;
								if (!f) throw Error(p(317));
								f[Of] = b;
							} else Ig(), 0 === (b.flags & 128) && (b.memoizedState = null), b.flags |= 4;
							S(b);
							f = !1;
						} else null !== zg && (Fj(zg), zg = null), f = !0;
						if (!f) return b.flags & 65536 ? b : null;
					}
					if (0 !== (b.flags & 128)) return b.lanes = c, b;
					d = null !== d;
					d !== (null !== a && null !== a.memoizedState) && d && (b.child.flags |= 8192, 0 !== (b.mode & 1) && (null === a || 0 !== (L.current & 1) ? 0 === T && (T = 3) : tj()));
					null !== b.updateQueue && (b.flags |= 4);
					S(b);
					return null;
				case 4: return zh(), null === a && sf(b.stateNode.containerInfo), S(b), null;
				case 10: return ah(b.type._context), S(b), null;
				case 17: return Zf(b.type) && $f(), S(b), null;
				case 19:
					E(L);
					f = b.memoizedState;
					if (null === f) return S(b), null;
					d = 0 !== (b.flags & 128);
					g = f.rendering;
					if (null === g) if (d) Dj(f, !1);
					else {
						if (0 !== T || null !== a && 0 !== (a.flags & 128)) for (a = b.child; null !== a;) {
							g = Ch(a);
							if (null !== g) {
								b.flags |= 128;
								Dj(f, !1);
								d = g.updateQueue;
								null !== d && (b.updateQueue = d, b.flags |= 4);
								b.subtreeFlags = 0;
								d = c;
								for (c = b.child; null !== c;) f = c, a = d, f.flags &= 14680066, g = f.alternate, null === g ? (f.childLanes = 0, f.lanes = a, f.child = null, f.subtreeFlags = 0, f.memoizedProps = null, f.memoizedState = null, f.updateQueue = null, f.dependencies = null, f.stateNode = null) : (f.childLanes = g.childLanes, f.lanes = g.lanes, f.child = g.child, f.subtreeFlags = 0, f.deletions = null, f.memoizedProps = g.memoizedProps, f.memoizedState = g.memoizedState, f.updateQueue = g.updateQueue, f.type = g.type, a = g.dependencies, f.dependencies = null === a ? null : {
									lanes: a.lanes,
									firstContext: a.firstContext
								}), c = c.sibling;
								G(L, L.current & 1 | 2);
								return b.child;
							}
							a = a.sibling;
						}
						null !== f.tail && B() > Gj && (b.flags |= 128, d = !0, Dj(f, !1), b.lanes = 4194304);
					}
					else {
						if (!d) if (a = Ch(g), null !== a) {
							if (b.flags |= 128, d = !0, c = a.updateQueue, null !== c && (b.updateQueue = c, b.flags |= 4), Dj(f, !0), null === f.tail && "hidden" === f.tailMode && !g.alternate && !I) return S(b), null;
						} else 2 * B() - f.renderingStartTime > Gj && 1073741824 !== c && (b.flags |= 128, d = !0, Dj(f, !1), b.lanes = 4194304);
						f.isBackwards ? (g.sibling = b.child, b.child = g) : (c = f.last, null !== c ? c.sibling = g : b.child = g, f.last = g);
					}
					if (null !== f.tail) return b = f.tail, f.rendering = b, f.tail = b.sibling, f.renderingStartTime = B(), b.sibling = null, c = L.current, G(L, d ? c & 1 | 2 : c & 1), b;
					S(b);
					return null;
				case 22:
				case 23: return Hj(), d = null !== b.memoizedState, null !== a && null !== a.memoizedState !== d && (b.flags |= 8192), d && 0 !== (b.mode & 1) ? 0 !== (fj & 1073741824) && (S(b), b.subtreeFlags & 6 && (b.flags |= 8192)) : S(b), null;
				case 24: return null;
				case 25: return null;
			}
			throw Error(p(156, b.tag));
		}
		function Ij(a, b) {
			wg(b);
			switch (b.tag) {
				case 1: return Zf(b.type) && $f(), a = b.flags, a & 65536 ? (b.flags = a & -65537 | 128, b) : null;
				case 3: return zh(), E(Wf), E(H), Eh(), a = b.flags, 0 !== (a & 65536) && 0 === (a & 128) ? (b.flags = a & -65537 | 128, b) : null;
				case 5: return Bh(b), null;
				case 13:
					E(L);
					a = b.memoizedState;
					if (null !== a && null !== a.dehydrated) {
						if (null === b.alternate) throw Error(p(340));
						Ig();
					}
					a = b.flags;
					return a & 65536 ? (b.flags = a & -65537 | 128, b) : null;
				case 19: return E(L), null;
				case 4: return zh(), null;
				case 10: return ah(b.type._context), null;
				case 22:
				case 23: return Hj(), null;
				case 24: return null;
				default: return null;
			}
		}
		var Jj = !1;
		var U = !1;
		var Kj = "function" === typeof WeakSet ? WeakSet : Set;
		var V = null;
		function Lj(a, b) {
			var c = a.ref;
			if (null !== c) if ("function" === typeof c) try {
				c(null);
			} catch (d) {
				W(a, b, d);
			}
			else c.current = null;
		}
		function Mj(a, b, c) {
			try {
				c();
			} catch (d) {
				W(a, b, d);
			}
		}
		var Nj = !1;
		function Oj(a, b) {
			Cf = dd;
			a = Me();
			if (Ne(a)) {
				if ("selectionStart" in a) var c = {
					start: a.selectionStart,
					end: a.selectionEnd
				};
				else a: {
					c = (c = a.ownerDocument) && c.defaultView || window;
					var d = c.getSelection && c.getSelection();
					if (d && 0 !== d.rangeCount) {
						c = d.anchorNode;
						var e = d.anchorOffset, f = d.focusNode;
						d = d.focusOffset;
						try {
							c.nodeType, f.nodeType;
						} catch (F) {
							c = null;
							break a;
						}
						var g = 0, h = -1, k = -1, l = 0, m = 0, q = a, r = null;
						b: for (;;) {
							for (var y;;) {
								q !== c || 0 !== e && 3 !== q.nodeType || (h = g + e);
								q !== f || 0 !== d && 3 !== q.nodeType || (k = g + d);
								3 === q.nodeType && (g += q.nodeValue.length);
								if (null === (y = q.firstChild)) break;
								r = q;
								q = y;
							}
							for (;;) {
								if (q === a) break b;
								r === c && ++l === e && (h = g);
								r === f && ++m === d && (k = g);
								if (null !== (y = q.nextSibling)) break;
								q = r;
								r = q.parentNode;
							}
							q = y;
						}
						c = -1 === h || -1 === k ? null : {
							start: h,
							end: k
						};
					} else c = null;
				}
				c = c || {
					start: 0,
					end: 0
				};
			} else c = null;
			Df = {
				focusedElem: a,
				selectionRange: c
			};
			dd = !1;
			for (V = b; null !== V;) if (b = V, a = b.child, 0 !== (b.subtreeFlags & 1028) && null !== a) a.return = b, V = a;
			else for (; null !== V;) {
				b = V;
				try {
					var n = b.alternate;
					if (0 !== (b.flags & 1024)) switch (b.tag) {
						case 0:
						case 11:
						case 15: break;
						case 1:
							if (null !== n) {
								var t = n.memoizedProps, J = n.memoizedState, x = b.stateNode;
								x.__reactInternalSnapshotBeforeUpdate = x.getSnapshotBeforeUpdate(b.elementType === b.type ? t : Ci(b.type, t), J);
							}
							break;
						case 3:
							var u = b.stateNode.containerInfo;
							1 === u.nodeType ? u.textContent = "" : 9 === u.nodeType && u.documentElement && u.removeChild(u.documentElement);
							break;
						case 5:
						case 6:
						case 4:
						case 17: break;
						default: throw Error(p(163));
					}
				} catch (F) {
					W(b, b.return, F);
				}
				a = b.sibling;
				if (null !== a) {
					a.return = b.return;
					V = a;
					break;
				}
				V = b.return;
			}
			n = Nj;
			Nj = !1;
			return n;
		}
		function Pj(a, b, c) {
			var d = b.updateQueue;
			d = null !== d ? d.lastEffect : null;
			if (null !== d) {
				var e = d = d.next;
				do {
					if ((e.tag & a) === a) {
						var f = e.destroy;
						e.destroy = void 0;
						void 0 !== f && Mj(b, c, f);
					}
					e = e.next;
				} while (e !== d);
			}
		}
		function Qj(a, b) {
			b = b.updateQueue;
			b = null !== b ? b.lastEffect : null;
			if (null !== b) {
				var c = b = b.next;
				do {
					if ((c.tag & a) === a) {
						var d = c.create;
						c.destroy = d();
					}
					c = c.next;
				} while (c !== b);
			}
		}
		function Rj(a) {
			var b = a.ref;
			if (null !== b) {
				var c = a.stateNode;
				switch (a.tag) {
					case 5:
						a = c;
						break;
					default: a = c;
				}
				"function" === typeof b ? b(a) : b.current = a;
			}
		}
		function Sj(a) {
			var b = a.alternate;
			null !== b && (a.alternate = null, Sj(b));
			a.child = null;
			a.deletions = null;
			a.sibling = null;
			5 === a.tag && (b = a.stateNode, null !== b && (delete b[Of], delete b[Pf], delete b[of], delete b[Qf], delete b[Rf]));
			a.stateNode = null;
			a.return = null;
			a.dependencies = null;
			a.memoizedProps = null;
			a.memoizedState = null;
			a.pendingProps = null;
			a.stateNode = null;
			a.updateQueue = null;
		}
		function Tj(a) {
			return 5 === a.tag || 3 === a.tag || 4 === a.tag;
		}
		function Uj(a) {
			a: for (;;) {
				for (; null === a.sibling;) {
					if (null === a.return || Tj(a.return)) return null;
					a = a.return;
				}
				a.sibling.return = a.return;
				for (a = a.sibling; 5 !== a.tag && 6 !== a.tag && 18 !== a.tag;) {
					if (a.flags & 2) continue a;
					if (null === a.child || 4 === a.tag) continue a;
					else a.child.return = a, a = a.child;
				}
				if (!(a.flags & 2)) return a.stateNode;
			}
		}
		function Vj(a, b, c) {
			var d = a.tag;
			if (5 === d || 6 === d) a = a.stateNode, b ? 8 === c.nodeType ? c.parentNode.insertBefore(a, b) : c.insertBefore(a, b) : (8 === c.nodeType ? (b = c.parentNode, b.insertBefore(a, c)) : (b = c, b.appendChild(a)), c = c._reactRootContainer, null !== c && void 0 !== c || null !== b.onclick || (b.onclick = Bf));
			else if (4 !== d && (a = a.child, null !== a)) for (Vj(a, b, c), a = a.sibling; null !== a;) Vj(a, b, c), a = a.sibling;
		}
		function Wj(a, b, c) {
			var d = a.tag;
			if (5 === d || 6 === d) a = a.stateNode, b ? c.insertBefore(a, b) : c.appendChild(a);
			else if (4 !== d && (a = a.child, null !== a)) for (Wj(a, b, c), a = a.sibling; null !== a;) Wj(a, b, c), a = a.sibling;
		}
		var X = null;
		var Xj = !1;
		function Yj(a, b, c) {
			for (c = c.child; null !== c;) Zj(a, b, c), c = c.sibling;
		}
		function Zj(a, b, c) {
			if (lc && "function" === typeof lc.onCommitFiberUnmount) try {
				lc.onCommitFiberUnmount(kc, c);
			} catch (h) {}
			switch (c.tag) {
				case 5: U || Lj(c, b);
				case 6:
					var d = X, e = Xj;
					X = null;
					Yj(a, b, c);
					X = d;
					Xj = e;
					null !== X && (Xj ? (a = X, c = c.stateNode, 8 === a.nodeType ? a.parentNode.removeChild(c) : a.removeChild(c)) : X.removeChild(c.stateNode));
					break;
				case 18:
					null !== X && (Xj ? (a = X, c = c.stateNode, 8 === a.nodeType ? Kf(a.parentNode, c) : 1 === a.nodeType && Kf(a, c), bd(a)) : Kf(X, c.stateNode));
					break;
				case 4:
					d = X;
					e = Xj;
					X = c.stateNode.containerInfo;
					Xj = !0;
					Yj(a, b, c);
					X = d;
					Xj = e;
					break;
				case 0:
				case 11:
				case 14:
				case 15:
					if (!U && (d = c.updateQueue, null !== d && (d = d.lastEffect, null !== d))) {
						e = d = d.next;
						do {
							var f = e, g = f.destroy;
							f = f.tag;
							void 0 !== g && (0 !== (f & 2) ? Mj(c, b, g) : 0 !== (f & 4) && Mj(c, b, g));
							e = e.next;
						} while (e !== d);
					}
					Yj(a, b, c);
					break;
				case 1:
					if (!U && (Lj(c, b), d = c.stateNode, "function" === typeof d.componentWillUnmount)) try {
						d.props = c.memoizedProps, d.state = c.memoizedState, d.componentWillUnmount();
					} catch (h) {
						W(c, b, h);
					}
					Yj(a, b, c);
					break;
				case 21:
					Yj(a, b, c);
					break;
				case 22:
					c.mode & 1 ? (U = (d = U) || null !== c.memoizedState, Yj(a, b, c), U = d) : Yj(a, b, c);
					break;
				default: Yj(a, b, c);
			}
		}
		function ak(a) {
			var b = a.updateQueue;
			if (null !== b) {
				a.updateQueue = null;
				var c = a.stateNode;
				null === c && (c = a.stateNode = new Kj());
				b.forEach(function(b) {
					var d = bk.bind(null, a, b);
					c.has(b) || (c.add(b), b.then(d, d));
				});
			}
		}
		function ck(a, b) {
			var c = b.deletions;
			if (null !== c) for (var d = 0; d < c.length; d++) {
				var e = c[d];
				try {
					var f = a, g = b, h = g;
					a: for (; null !== h;) {
						switch (h.tag) {
							case 5:
								X = h.stateNode;
								Xj = !1;
								break a;
							case 3:
								X = h.stateNode.containerInfo;
								Xj = !0;
								break a;
							case 4:
								X = h.stateNode.containerInfo;
								Xj = !0;
								break a;
						}
						h = h.return;
					}
					if (null === X) throw Error(p(160));
					Zj(f, g, e);
					X = null;
					Xj = !1;
					var k = e.alternate;
					null !== k && (k.return = null);
					e.return = null;
				} catch (l) {
					W(e, b, l);
				}
			}
			if (b.subtreeFlags & 12854) for (b = b.child; null !== b;) dk(b, a), b = b.sibling;
		}
		function dk(a, b) {
			var c = a.alternate, d = a.flags;
			switch (a.tag) {
				case 0:
				case 11:
				case 14:
				case 15:
					ck(b, a);
					ek(a);
					if (d & 4) {
						try {
							Pj(3, a, a.return), Qj(3, a);
						} catch (t) {
							W(a, a.return, t);
						}
						try {
							Pj(5, a, a.return);
						} catch (t) {
							W(a, a.return, t);
						}
					}
					break;
				case 1:
					ck(b, a);
					ek(a);
					d & 512 && null !== c && Lj(c, c.return);
					break;
				case 5:
					ck(b, a);
					ek(a);
					d & 512 && null !== c && Lj(c, c.return);
					if (a.flags & 32) {
						var e = a.stateNode;
						try {
							ob(e, "");
						} catch (t) {
							W(a, a.return, t);
						}
					}
					if (d & 4 && (e = a.stateNode, null != e)) {
						var f = a.memoizedProps, g = null !== c ? c.memoizedProps : f, h = a.type, k = a.updateQueue;
						a.updateQueue = null;
						if (null !== k) try {
							"input" === h && "radio" === f.type && null != f.name && ab(e, f);
							vb(h, g);
							var l = vb(h, f);
							for (g = 0; g < k.length; g += 2) {
								var m = k[g], q = k[g + 1];
								"style" === m ? sb(e, q) : "dangerouslySetInnerHTML" === m ? nb(e, q) : "children" === m ? ob(e, q) : ta(e, m, q, l);
							}
							switch (h) {
								case "input":
									bb(e, f);
									break;
								case "textarea":
									ib(e, f);
									break;
								case "select":
									var r = e._wrapperState.wasMultiple;
									e._wrapperState.wasMultiple = !!f.multiple;
									var y = f.value;
									null != y ? fb(e, !!f.multiple, y, !1) : r !== !!f.multiple && (null != f.defaultValue ? fb(e, !!f.multiple, f.defaultValue, !0) : fb(e, !!f.multiple, f.multiple ? [] : "", !1));
							}
							e[Pf] = f;
						} catch (t) {
							W(a, a.return, t);
						}
					}
					break;
				case 6:
					ck(b, a);
					ek(a);
					if (d & 4) {
						if (null === a.stateNode) throw Error(p(162));
						e = a.stateNode;
						f = a.memoizedProps;
						try {
							e.nodeValue = f;
						} catch (t) {
							W(a, a.return, t);
						}
					}
					break;
				case 3:
					ck(b, a);
					ek(a);
					if (d & 4 && null !== c && c.memoizedState.isDehydrated) try {
						bd(b.containerInfo);
					} catch (t) {
						W(a, a.return, t);
					}
					break;
				case 4:
					ck(b, a);
					ek(a);
					break;
				case 13:
					ck(b, a);
					ek(a);
					e = a.child;
					e.flags & 8192 && (f = null !== e.memoizedState, e.stateNode.isHidden = f, !f || null !== e.alternate && null !== e.alternate.memoizedState || (fk = B()));
					d & 4 && ak(a);
					break;
				case 22:
					m = null !== c && null !== c.memoizedState;
					a.mode & 1 ? (U = (l = U) || m, ck(b, a), U = l) : ck(b, a);
					ek(a);
					if (d & 8192) {
						l = null !== a.memoizedState;
						if ((a.stateNode.isHidden = l) && !m && 0 !== (a.mode & 1)) for (V = a, m = a.child; null !== m;) {
							for (q = V = m; null !== V;) {
								r = V;
								y = r.child;
								switch (r.tag) {
									case 0:
									case 11:
									case 14:
									case 15:
										Pj(4, r, r.return);
										break;
									case 1:
										Lj(r, r.return);
										var n = r.stateNode;
										if ("function" === typeof n.componentWillUnmount) {
											d = r;
											c = r.return;
											try {
												b = d, n.props = b.memoizedProps, n.state = b.memoizedState, n.componentWillUnmount();
											} catch (t) {
												W(d, c, t);
											}
										}
										break;
									case 5:
										Lj(r, r.return);
										break;
									case 22: if (null !== r.memoizedState) {
										gk(q);
										continue;
									}
								}
								null !== y ? (y.return = r, V = y) : gk(q);
							}
							m = m.sibling;
						}
						a: for (m = null, q = a;;) {
							if (5 === q.tag) {
								if (null === m) {
									m = q;
									try {
										e = q.stateNode, l ? (f = e.style, "function" === typeof f.setProperty ? f.setProperty("display", "none", "important") : f.display = "none") : (h = q.stateNode, k = q.memoizedProps.style, g = void 0 !== k && null !== k && k.hasOwnProperty("display") ? k.display : null, h.style.display = rb("display", g));
									} catch (t) {
										W(a, a.return, t);
									}
								}
							} else if (6 === q.tag) {
								if (null === m) try {
									q.stateNode.nodeValue = l ? "" : q.memoizedProps;
								} catch (t) {
									W(a, a.return, t);
								}
							} else if ((22 !== q.tag && 23 !== q.tag || null === q.memoizedState || q === a) && null !== q.child) {
								q.child.return = q;
								q = q.child;
								continue;
							}
							if (q === a) break a;
							for (; null === q.sibling;) {
								if (null === q.return || q.return === a) break a;
								m === q && (m = null);
								q = q.return;
							}
							m === q && (m = null);
							q.sibling.return = q.return;
							q = q.sibling;
						}
					}
					break;
				case 19:
					ck(b, a);
					ek(a);
					d & 4 && ak(a);
					break;
				case 21: break;
				default: ck(b, a), ek(a);
			}
		}
		function ek(a) {
			var b = a.flags;
			if (b & 2) {
				try {
					a: {
						for (var c = a.return; null !== c;) {
							if (Tj(c)) {
								var d = c;
								break a;
							}
							c = c.return;
						}
						throw Error(p(160));
					}
					switch (d.tag) {
						case 5:
							var e = d.stateNode;
							d.flags & 32 && (ob(e, ""), d.flags &= -33);
							Wj(a, Uj(a), e);
							break;
						case 3:
						case 4:
							var g = d.stateNode.containerInfo;
							Vj(a, Uj(a), g);
							break;
						default: throw Error(p(161));
					}
				} catch (k) {
					W(a, a.return, k);
				}
				a.flags &= -3;
			}
			b & 4096 && (a.flags &= -4097);
		}
		function hk(a, b, c) {
			V = a;
			ik(a, b, c);
		}
		function ik(a, b, c) {
			for (var d = 0 !== (a.mode & 1); null !== V;) {
				var e = V, f = e.child;
				if (22 === e.tag && d) {
					var g = null !== e.memoizedState || Jj;
					if (!g) {
						var h = e.alternate, k = null !== h && null !== h.memoizedState || U;
						h = Jj;
						var l = U;
						Jj = g;
						if ((U = k) && !l) for (V = e; null !== V;) g = V, k = g.child, 22 === g.tag && null !== g.memoizedState ? jk(e) : null !== k ? (k.return = g, V = k) : jk(e);
						for (; null !== f;) V = f, ik(f, b, c), f = f.sibling;
						V = e;
						Jj = h;
						U = l;
					}
					kk(a, b, c);
				} else 0 !== (e.subtreeFlags & 8772) && null !== f ? (f.return = e, V = f) : kk(a, b, c);
			}
		}
		function kk(a) {
			for (; null !== V;) {
				var b = V;
				if (0 !== (b.flags & 8772)) {
					var c = b.alternate;
					try {
						if (0 !== (b.flags & 8772)) switch (b.tag) {
							case 0:
							case 11:
							case 15:
								U || Qj(5, b);
								break;
							case 1:
								var d = b.stateNode;
								if (b.flags & 4 && !U) if (null === c) d.componentDidMount();
								else {
									var e = b.elementType === b.type ? c.memoizedProps : Ci(b.type, c.memoizedProps);
									d.componentDidUpdate(e, c.memoizedState, d.__reactInternalSnapshotBeforeUpdate);
								}
								var f = b.updateQueue;
								null !== f && sh(b, f, d);
								break;
							case 3:
								var g = b.updateQueue;
								if (null !== g) {
									c = null;
									if (null !== b.child) switch (b.child.tag) {
										case 5:
											c = b.child.stateNode;
											break;
										case 1: c = b.child.stateNode;
									}
									sh(b, g, c);
								}
								break;
							case 5:
								var h = b.stateNode;
								if (null === c && b.flags & 4) {
									c = h;
									var k = b.memoizedProps;
									switch (b.type) {
										case "button":
										case "input":
										case "select":
										case "textarea":
											k.autoFocus && c.focus();
											break;
										case "img": k.src && (c.src = k.src);
									}
								}
								break;
							case 6: break;
							case 4: break;
							case 12: break;
							case 13:
								if (null === b.memoizedState) {
									var l = b.alternate;
									if (null !== l) {
										var m = l.memoizedState;
										if (null !== m) {
											var q = m.dehydrated;
											null !== q && bd(q);
										}
									}
								}
								break;
							case 19:
							case 17:
							case 21:
							case 22:
							case 23:
							case 25: break;
							default: throw Error(p(163));
						}
						U || b.flags & 512 && Rj(b);
					} catch (r) {
						W(b, b.return, r);
					}
				}
				if (b === a) {
					V = null;
					break;
				}
				c = b.sibling;
				if (null !== c) {
					c.return = b.return;
					V = c;
					break;
				}
				V = b.return;
			}
		}
		function gk(a) {
			for (; null !== V;) {
				var b = V;
				if (b === a) {
					V = null;
					break;
				}
				var c = b.sibling;
				if (null !== c) {
					c.return = b.return;
					V = c;
					break;
				}
				V = b.return;
			}
		}
		function jk(a) {
			for (; null !== V;) {
				var b = V;
				try {
					switch (b.tag) {
						case 0:
						case 11:
						case 15:
							var c = b.return;
							try {
								Qj(4, b);
							} catch (k) {
								W(b, c, k);
							}
							break;
						case 1:
							var d = b.stateNode;
							if ("function" === typeof d.componentDidMount) {
								var e = b.return;
								try {
									d.componentDidMount();
								} catch (k) {
									W(b, e, k);
								}
							}
							var f = b.return;
							try {
								Rj(b);
							} catch (k) {
								W(b, f, k);
							}
							break;
						case 5:
							var g = b.return;
							try {
								Rj(b);
							} catch (k) {
								W(b, g, k);
							}
					}
				} catch (k) {
					W(b, b.return, k);
				}
				if (b === a) {
					V = null;
					break;
				}
				var h = b.sibling;
				if (null !== h) {
					h.return = b.return;
					V = h;
					break;
				}
				V = b.return;
			}
		}
		var lk = Math.ceil;
		var mk = ua.ReactCurrentDispatcher;
		var nk = ua.ReactCurrentOwner;
		var ok = ua.ReactCurrentBatchConfig;
		var K = 0;
		var Q = null;
		var Y = null;
		var Z = 0;
		var fj = 0;
		var ej = Uf(0);
		var T = 0;
		var pk = null;
		var rh = 0;
		var qk = 0;
		var rk = 0;
		var sk = null;
		var tk = null;
		var fk = 0;
		var Gj = Infinity;
		var uk = null;
		var Oi = !1;
		var Pi = null;
		var Ri = null;
		var vk = !1;
		var wk = null;
		var xk = 0;
		var yk = 0;
		var zk = null;
		var Ak = -1;
		var Bk = 0;
		function R() {
			return 0 !== (K & 6) ? B() : -1 !== Ak ? Ak : Ak = B();
		}
		function yi(a) {
			if (0 === (a.mode & 1)) return 1;
			if (0 !== (K & 2) && 0 !== Z) return Z & -Z;
			if (null !== Kg.transition) return 0 === Bk && (Bk = yc()), Bk;
			a = C;
			if (0 !== a) return a;
			a = window.event;
			a = void 0 === a ? 16 : jd(a.type);
			return a;
		}
		function gi(a, b, c, d) {
			if (50 < yk) throw yk = 0, zk = null, Error(p(185));
			Ac(a, c, d);
			if (0 === (K & 2) || a !== Q) a === Q && (0 === (K & 2) && (qk |= c), 4 === T && Ck(a, Z)), Dk(a, d), 1 === c && 0 === K && 0 === (b.mode & 1) && (Gj = B() + 500, fg && jg());
		}
		function Dk(a, b) {
			var c = a.callbackNode;
			wc(a, b);
			var d = uc(a, a === Q ? Z : 0);
			if (0 === d) null !== c && bc(c), a.callbackNode = null, a.callbackPriority = 0;
			else if (b = d & -d, a.callbackPriority !== b) {
				null != c && bc(c);
				if (1 === b) 0 === a.tag ? ig(Ek.bind(null, a)) : hg(Ek.bind(null, a)), Jf(function() {
					0 === (K & 6) && jg();
				}), c = null;
				else {
					switch (Dc(d)) {
						case 1:
							c = fc;
							break;
						case 4:
							c = gc;
							break;
						case 16:
							c = hc;
							break;
						case 536870912:
							c = jc;
							break;
						default: c = hc;
					}
					c = Fk(c, Gk.bind(null, a));
				}
				a.callbackPriority = b;
				a.callbackNode = c;
			}
		}
		function Gk(a, b) {
			Ak = -1;
			Bk = 0;
			if (0 !== (K & 6)) throw Error(p(327));
			var c = a.callbackNode;
			if (Hk() && a.callbackNode !== c) return null;
			var d = uc(a, a === Q ? Z : 0);
			if (0 === d) return null;
			if (0 !== (d & 30) || 0 !== (d & a.expiredLanes) || b) b = Ik(a, d);
			else {
				b = d;
				var e = K;
				K |= 2;
				var f = Jk();
				if (Q !== a || Z !== b) uk = null, Gj = B() + 500, Kk(a, b);
				do
					try {
						Lk();
						break;
					} catch (h) {
						Mk(a, h);
					}
				while (1);
				$g();
				mk.current = f;
				K = e;
				null !== Y ? b = 0 : (Q = null, Z = 0, b = T);
			}
			if (0 !== b) {
				2 === b && (e = xc(a), 0 !== e && (d = e, b = Nk(a, e)));
				if (1 === b) throw c = pk, Kk(a, 0), Ck(a, d), Dk(a, B()), c;
				if (6 === b) Ck(a, d);
				else {
					e = a.current.alternate;
					if (0 === (d & 30) && !Ok(e) && (b = Ik(a, d), 2 === b && (f = xc(a), 0 !== f && (d = f, b = Nk(a, f))), 1 === b)) throw c = pk, Kk(a, 0), Ck(a, d), Dk(a, B()), c;
					a.finishedWork = e;
					a.finishedLanes = d;
					switch (b) {
						case 0:
						case 1: throw Error(p(345));
						case 2:
							Pk(a, tk, uk);
							break;
						case 3:
							Ck(a, d);
							if ((d & 130023424) === d && (b = fk + 500 - B(), 10 < b)) {
								if (0 !== uc(a, 0)) break;
								e = a.suspendedLanes;
								if ((e & d) !== d) {
									R();
									a.pingedLanes |= a.suspendedLanes & e;
									break;
								}
								a.timeoutHandle = Ff(Pk.bind(null, a, tk, uk), b);
								break;
							}
							Pk(a, tk, uk);
							break;
						case 4:
							Ck(a, d);
							if ((d & 4194240) === d) break;
							b = a.eventTimes;
							for (e = -1; 0 < d;) {
								var g = 31 - oc(d);
								f = 1 << g;
								g = b[g];
								g > e && (e = g);
								d &= ~f;
							}
							d = e;
							d = B() - d;
							d = (120 > d ? 120 : 480 > d ? 480 : 1080 > d ? 1080 : 1920 > d ? 1920 : 3e3 > d ? 3e3 : 4320 > d ? 4320 : 1960 * lk(d / 1960)) - d;
							if (10 < d) {
								a.timeoutHandle = Ff(Pk.bind(null, a, tk, uk), d);
								break;
							}
							Pk(a, tk, uk);
							break;
						case 5:
							Pk(a, tk, uk);
							break;
						default: throw Error(p(329));
					}
				}
			}
			Dk(a, B());
			return a.callbackNode === c ? Gk.bind(null, a) : null;
		}
		function Nk(a, b) {
			var c = sk;
			a.current.memoizedState.isDehydrated && (Kk(a, b).flags |= 256);
			a = Ik(a, b);
			2 !== a && (b = tk, tk = c, null !== b && Fj(b));
			return a;
		}
		function Fj(a) {
			null === tk ? tk = a : tk.push.apply(tk, a);
		}
		function Ok(a) {
			for (var b = a;;) {
				if (b.flags & 16384) {
					var c = b.updateQueue;
					if (null !== c && (c = c.stores, null !== c)) for (var d = 0; d < c.length; d++) {
						var e = c[d], f = e.getSnapshot;
						e = e.value;
						try {
							if (!He(f(), e)) return !1;
						} catch (g) {
							return !1;
						}
					}
				}
				c = b.child;
				if (b.subtreeFlags & 16384 && null !== c) c.return = b, b = c;
				else {
					if (b === a) break;
					for (; null === b.sibling;) {
						if (null === b.return || b.return === a) return !0;
						b = b.return;
					}
					b.sibling.return = b.return;
					b = b.sibling;
				}
			}
			return !0;
		}
		function Ck(a, b) {
			b &= ~rk;
			b &= ~qk;
			a.suspendedLanes |= b;
			a.pingedLanes &= ~b;
			for (a = a.expirationTimes; 0 < b;) {
				var c = 31 - oc(b), d = 1 << c;
				a[c] = -1;
				b &= ~d;
			}
		}
		function Ek(a) {
			if (0 !== (K & 6)) throw Error(p(327));
			Hk();
			var b = uc(a, 0);
			if (0 === (b & 1)) return Dk(a, B()), null;
			var c = Ik(a, b);
			if (0 !== a.tag && 2 === c) {
				var d = xc(a);
				0 !== d && (b = d, c = Nk(a, d));
			}
			if (1 === c) throw c = pk, Kk(a, 0), Ck(a, b), Dk(a, B()), c;
			if (6 === c) throw Error(p(345));
			a.finishedWork = a.current.alternate;
			a.finishedLanes = b;
			Pk(a, tk, uk);
			Dk(a, B());
			return null;
		}
		function Qk(a, b) {
			var c = K;
			K |= 1;
			try {
				return a(b);
			} finally {
				K = c, 0 === K && (Gj = B() + 500, fg && jg());
			}
		}
		function Rk(a) {
			null !== wk && 0 === wk.tag && 0 === (K & 6) && Hk();
			var b = K;
			K |= 1;
			var c = ok.transition, d = C;
			try {
				if (ok.transition = null, C = 1, a) return a();
			} finally {
				C = d, ok.transition = c, K = b, 0 === (K & 6) && jg();
			}
		}
		function Hj() {
			fj = ej.current;
			E(ej);
		}
		function Kk(a, b) {
			a.finishedWork = null;
			a.finishedLanes = 0;
			var c = a.timeoutHandle;
			-1 !== c && (a.timeoutHandle = -1, Gf(c));
			if (null !== Y) for (c = Y.return; null !== c;) {
				var d = c;
				wg(d);
				switch (d.tag) {
					case 1:
						d = d.type.childContextTypes;
						null !== d && void 0 !== d && $f();
						break;
					case 3:
						zh();
						E(Wf);
						E(H);
						Eh();
						break;
					case 5:
						Bh(d);
						break;
					case 4:
						zh();
						break;
					case 13:
						E(L);
						break;
					case 19:
						E(L);
						break;
					case 10:
						ah(d.type._context);
						break;
					case 22:
					case 23: Hj();
				}
				c = c.return;
			}
			Q = a;
			Y = a = Pg(a.current, null);
			Z = fj = b;
			T = 0;
			pk = null;
			rk = qk = rh = 0;
			tk = sk = null;
			if (null !== fh) {
				for (b = 0; b < fh.length; b++) if (c = fh[b], d = c.interleaved, null !== d) {
					c.interleaved = null;
					var e = d.next, f = c.pending;
					if (null !== f) {
						var g = f.next;
						f.next = e;
						d.next = g;
					}
					c.pending = d;
				}
				fh = null;
			}
			return a;
		}
		function Mk(a, b) {
			do {
				var c = Y;
				try {
					$g();
					Fh.current = Rh;
					if (Ih) {
						for (var d = M.memoizedState; null !== d;) {
							var e = d.queue;
							null !== e && (e.pending = null);
							d = d.next;
						}
						Ih = !1;
					}
					Hh = 0;
					O = N = M = null;
					Jh = !1;
					Kh = 0;
					nk.current = null;
					if (null === c || null === c.return) {
						T = 1;
						pk = b;
						Y = null;
						break;
					}
					a: {
						var f = a, g = c.return, h = c, k = b;
						b = Z;
						h.flags |= 32768;
						if (null !== k && "object" === typeof k && "function" === typeof k.then) {
							var l = k, m = h, q = m.tag;
							if (0 === (m.mode & 1) && (0 === q || 11 === q || 15 === q)) {
								var r = m.alternate;
								r ? (m.updateQueue = r.updateQueue, m.memoizedState = r.memoizedState, m.lanes = r.lanes) : (m.updateQueue = null, m.memoizedState = null);
							}
							var y = Ui(g);
							if (null !== y) {
								y.flags &= -257;
								Vi(y, g, h, f, b);
								y.mode & 1 && Si(f, l, b);
								b = y;
								k = l;
								var n = b.updateQueue;
								if (null === n) {
									var t = /* @__PURE__ */ new Set();
									t.add(k);
									b.updateQueue = t;
								} else n.add(k);
								break a;
							} else {
								if (0 === (b & 1)) {
									Si(f, l, b);
									tj();
									break a;
								}
								k = Error(p(426));
							}
						} else if (I && h.mode & 1) {
							var J = Ui(g);
							if (null !== J) {
								0 === (J.flags & 65536) && (J.flags |= 256);
								Vi(J, g, h, f, b);
								Jg(Ji(k, h));
								break a;
							}
						}
						f = k = Ji(k, h);
						4 !== T && (T = 2);
						null === sk ? sk = [f] : sk.push(f);
						f = g;
						do {
							switch (f.tag) {
								case 3:
									f.flags |= 65536;
									b &= -b;
									f.lanes |= b;
									var x = Ni(f, k, b);
									ph(f, x);
									break a;
								case 1:
									h = k;
									var w = f.type, u = f.stateNode;
									if (0 === (f.flags & 128) && ("function" === typeof w.getDerivedStateFromError || null !== u && "function" === typeof u.componentDidCatch && (null === Ri || !Ri.has(u)))) {
										f.flags |= 65536;
										b &= -b;
										f.lanes |= b;
										var F = Qi(f, h, b);
										ph(f, F);
										break a;
									}
							}
							f = f.return;
						} while (null !== f);
					}
					Sk(c);
				} catch (na) {
					b = na;
					Y === c && null !== c && (Y = c = c.return);
					continue;
				}
				break;
			} while (1);
		}
		function Jk() {
			var a = mk.current;
			mk.current = Rh;
			return null === a ? Rh : a;
		}
		function tj() {
			if (0 === T || 3 === T || 2 === T) T = 4;
			null === Q || 0 === (rh & 268435455) && 0 === (qk & 268435455) || Ck(Q, Z);
		}
		function Ik(a, b) {
			var c = K;
			K |= 2;
			var d = Jk();
			if (Q !== a || Z !== b) uk = null, Kk(a, b);
			do
				try {
					Tk();
					break;
				} catch (e) {
					Mk(a, e);
				}
			while (1);
			$g();
			K = c;
			mk.current = d;
			if (null !== Y) throw Error(p(261));
			Q = null;
			Z = 0;
			return T;
		}
		function Tk() {
			for (; null !== Y;) Uk(Y);
		}
		function Lk() {
			for (; null !== Y && !cc();) Uk(Y);
		}
		function Uk(a) {
			var b = Vk(a.alternate, a, fj);
			a.memoizedProps = a.pendingProps;
			null === b ? Sk(a) : Y = b;
			nk.current = null;
		}
		function Sk(a) {
			var b = a;
			do {
				var c = b.alternate;
				a = b.return;
				if (0 === (b.flags & 32768)) {
					if (c = Ej(c, b, fj), null !== c) {
						Y = c;
						return;
					}
				} else {
					c = Ij(c, b);
					if (null !== c) {
						c.flags &= 32767;
						Y = c;
						return;
					}
					if (null !== a) a.flags |= 32768, a.subtreeFlags = 0, a.deletions = null;
					else {
						T = 6;
						Y = null;
						return;
					}
				}
				b = b.sibling;
				if (null !== b) {
					Y = b;
					return;
				}
				Y = b = a;
			} while (null !== b);
			0 === T && (T = 5);
		}
		function Pk(a, b, c) {
			var d = C, e = ok.transition;
			try {
				ok.transition = null, C = 1, Wk(a, b, c, d);
			} finally {
				ok.transition = e, C = d;
			}
			return null;
		}
		function Wk(a, b, c, d) {
			do
				Hk();
			while (null !== wk);
			if (0 !== (K & 6)) throw Error(p(327));
			c = a.finishedWork;
			var e = a.finishedLanes;
			if (null === c) return null;
			a.finishedWork = null;
			a.finishedLanes = 0;
			if (c === a.current) throw Error(p(177));
			a.callbackNode = null;
			a.callbackPriority = 0;
			var f = c.lanes | c.childLanes;
			Bc(a, f);
			a === Q && (Y = Q = null, Z = 0);
			0 === (c.subtreeFlags & 2064) && 0 === (c.flags & 2064) || vk || (vk = !0, Fk(hc, function() {
				Hk();
				return null;
			}));
			f = 0 !== (c.flags & 15990);
			if (0 !== (c.subtreeFlags & 15990) || f) {
				f = ok.transition;
				ok.transition = null;
				var g = C;
				C = 1;
				var h = K;
				K |= 4;
				nk.current = null;
				Oj(a, c);
				dk(c, a);
				Oe(Df);
				dd = !!Cf;
				Df = Cf = null;
				a.current = c;
				hk(c, a, e);
				dc();
				K = h;
				C = g;
				ok.transition = f;
			} else a.current = c;
			vk && (vk = !1, wk = a, xk = e);
			f = a.pendingLanes;
			0 === f && (Ri = null);
			mc(c.stateNode, d);
			Dk(a, B());
			if (null !== b) for (d = a.onRecoverableError, c = 0; c < b.length; c++) e = b[c], d(e.value, {
				componentStack: e.stack,
				digest: e.digest
			});
			if (Oi) throw Oi = !1, a = Pi, Pi = null, a;
			0 !== (xk & 1) && 0 !== a.tag && Hk();
			f = a.pendingLanes;
			0 !== (f & 1) ? a === zk ? yk++ : (yk = 0, zk = a) : yk = 0;
			jg();
			return null;
		}
		function Hk() {
			if (null !== wk) {
				var a = Dc(xk), b = ok.transition, c = C;
				try {
					ok.transition = null;
					C = 16 > a ? 16 : a;
					if (null === wk) var d = !1;
					else {
						a = wk;
						wk = null;
						xk = 0;
						if (0 !== (K & 6)) throw Error(p(331));
						var e = K;
						K |= 4;
						for (V = a.current; null !== V;) {
							var f = V, g = f.child;
							if (0 !== (V.flags & 16)) {
								var h = f.deletions;
								if (null !== h) {
									for (var k = 0; k < h.length; k++) {
										var l = h[k];
										for (V = l; null !== V;) {
											var m = V;
											switch (m.tag) {
												case 0:
												case 11:
												case 15: Pj(8, m, f);
											}
											var q = m.child;
											if (null !== q) q.return = m, V = q;
											else for (; null !== V;) {
												m = V;
												var r = m.sibling, y = m.return;
												Sj(m);
												if (m === l) {
													V = null;
													break;
												}
												if (null !== r) {
													r.return = y;
													V = r;
													break;
												}
												V = y;
											}
										}
									}
									var n = f.alternate;
									if (null !== n) {
										var t = n.child;
										if (null !== t) {
											n.child = null;
											do {
												var J = t.sibling;
												t.sibling = null;
												t = J;
											} while (null !== t);
										}
									}
									V = f;
								}
							}
							if (0 !== (f.subtreeFlags & 2064) && null !== g) g.return = f, V = g;
							else b: for (; null !== V;) {
								f = V;
								if (0 !== (f.flags & 2048)) switch (f.tag) {
									case 0:
									case 11:
									case 15: Pj(9, f, f.return);
								}
								var x = f.sibling;
								if (null !== x) {
									x.return = f.return;
									V = x;
									break b;
								}
								V = f.return;
							}
						}
						var w = a.current;
						for (V = w; null !== V;) {
							g = V;
							var u = g.child;
							if (0 !== (g.subtreeFlags & 2064) && null !== u) u.return = g, V = u;
							else b: for (g = w; null !== V;) {
								h = V;
								if (0 !== (h.flags & 2048)) try {
									switch (h.tag) {
										case 0:
										case 11:
										case 15: Qj(9, h);
									}
								} catch (na) {
									W(h, h.return, na);
								}
								if (h === g) {
									V = null;
									break b;
								}
								var F = h.sibling;
								if (null !== F) {
									F.return = h.return;
									V = F;
									break b;
								}
								V = h.return;
							}
						}
						K = e;
						jg();
						if (lc && "function" === typeof lc.onPostCommitFiberRoot) try {
							lc.onPostCommitFiberRoot(kc, a);
						} catch (na) {}
						d = !0;
					}
					return d;
				} finally {
					C = c, ok.transition = b;
				}
			}
			return !1;
		}
		function Xk(a, b, c) {
			b = Ji(c, b);
			b = Ni(a, b, 1);
			a = nh(a, b, 1);
			b = R();
			null !== a && (Ac(a, 1, b), Dk(a, b));
		}
		function W(a, b, c) {
			if (3 === a.tag) Xk(a, a, c);
			else for (; null !== b;) {
				if (3 === b.tag) {
					Xk(b, a, c);
					break;
				} else if (1 === b.tag) {
					var d = b.stateNode;
					if ("function" === typeof b.type.getDerivedStateFromError || "function" === typeof d.componentDidCatch && (null === Ri || !Ri.has(d))) {
						a = Ji(c, a);
						a = Qi(b, a, 1);
						b = nh(b, a, 1);
						a = R();
						null !== b && (Ac(b, 1, a), Dk(b, a));
						break;
					}
				}
				b = b.return;
			}
		}
		function Ti(a, b, c) {
			var d = a.pingCache;
			null !== d && d.delete(b);
			b = R();
			a.pingedLanes |= a.suspendedLanes & c;
			Q === a && (Z & c) === c && (4 === T || 3 === T && (Z & 130023424) === Z && 500 > B() - fk ? Kk(a, 0) : rk |= c);
			Dk(a, b);
		}
		function Yk(a, b) {
			0 === b && (0 === (a.mode & 1) ? b = 1 : (b = sc, sc <<= 1, 0 === (sc & 130023424) && (sc = 4194304)));
			var c = R();
			a = ih(a, b);
			null !== a && (Ac(a, b, c), Dk(a, c));
		}
		function uj(a) {
			var b = a.memoizedState, c = 0;
			null !== b && (c = b.retryLane);
			Yk(a, c);
		}
		function bk(a, b) {
			var c = 0;
			switch (a.tag) {
				case 13:
					var d = a.stateNode;
					var e = a.memoizedState;
					null !== e && (c = e.retryLane);
					break;
				case 19:
					d = a.stateNode;
					break;
				default: throw Error(p(314));
			}
			null !== d && d.delete(b);
			Yk(a, c);
		}
		var Vk = function(a, b, c) {
			if (null !== a) if (a.memoizedProps !== b.pendingProps || Wf.current) dh = !0;
			else {
				if (0 === (a.lanes & c) && 0 === (b.flags & 128)) return dh = !1, yj(a, b, c);
				dh = 0 !== (a.flags & 131072) ? !0 : !1;
			}
			else dh = !1, I && 0 !== (b.flags & 1048576) && ug(b, ng, b.index);
			b.lanes = 0;
			switch (b.tag) {
				case 2:
					var d = b.type;
					ij(a, b);
					a = b.pendingProps;
					var e = Yf(b, H.current);
					ch(b, c);
					e = Nh(null, b, d, a, e, c);
					var f = Sh();
					b.flags |= 1;
					"object" === typeof e && null !== e && "function" === typeof e.render && void 0 === e.$$typeof ? (b.tag = 1, b.memoizedState = null, b.updateQueue = null, Zf(d) ? (f = !0, cg(b)) : f = !1, b.memoizedState = null !== e.state && void 0 !== e.state ? e.state : null, kh(b), e.updater = Ei, b.stateNode = e, e._reactInternals = b, Ii(b, d, a, c), b = jj(null, b, d, !0, f, c)) : (b.tag = 0, I && f && vg(b), Xi(null, b, e, c), b = b.child);
					return b;
				case 16:
					d = b.elementType;
					a: {
						ij(a, b);
						a = b.pendingProps;
						e = d._init;
						d = e(d._payload);
						b.type = d;
						e = b.tag = Zk(d);
						a = Ci(d, a);
						switch (e) {
							case 0:
								b = cj(null, b, d, a, c);
								break a;
							case 1:
								b = hj(null, b, d, a, c);
								break a;
							case 11:
								b = Yi(null, b, d, a, c);
								break a;
							case 14:
								b = $i(null, b, d, Ci(d.type, a), c);
								break a;
						}
						throw Error(p(306, d, ""));
					}
					return b;
				case 0: return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), cj(a, b, d, e, c);
				case 1: return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), hj(a, b, d, e, c);
				case 3:
					a: {
						kj(b);
						if (null === a) throw Error(p(387));
						d = b.pendingProps;
						f = b.memoizedState;
						e = f.element;
						lh(a, b);
						qh(b, d, null, c);
						var g = b.memoizedState;
						d = g.element;
						if (f.isDehydrated) if (f = {
							element: d,
							isDehydrated: !1,
							cache: g.cache,
							pendingSuspenseBoundaries: g.pendingSuspenseBoundaries,
							transitions: g.transitions
						}, b.updateQueue.baseState = f, b.memoizedState = f, b.flags & 256) {
							e = Ji(Error(p(423)), b);
							b = lj(a, b, d, c, e);
							break a;
						} else if (d !== e) {
							e = Ji(Error(p(424)), b);
							b = lj(a, b, d, c, e);
							break a;
						} else for (yg = Lf(b.stateNode.containerInfo.firstChild), xg = b, I = !0, zg = null, c = Vg(b, null, d, c), b.child = c; c;) c.flags = c.flags & -3 | 4096, c = c.sibling;
						else {
							Ig();
							if (d === e) {
								b = Zi(a, b, c);
								break a;
							}
							Xi(a, b, d, c);
						}
						b = b.child;
					}
					return b;
				case 5: return Ah(b), null === a && Eg(b), d = b.type, e = b.pendingProps, f = null !== a ? a.memoizedProps : null, g = e.children, Ef(d, e) ? g = null : null !== f && Ef(d, f) && (b.flags |= 32), gj(a, b), Xi(a, b, g, c), b.child;
				case 6: return null === a && Eg(b), null;
				case 13: return oj(a, b, c);
				case 4: return yh(b, b.stateNode.containerInfo), d = b.pendingProps, null === a ? b.child = Ug(b, null, d, c) : Xi(a, b, d, c), b.child;
				case 11: return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), Yi(a, b, d, e, c);
				case 7: return Xi(a, b, b.pendingProps, c), b.child;
				case 8: return Xi(a, b, b.pendingProps.children, c), b.child;
				case 12: return Xi(a, b, b.pendingProps.children, c), b.child;
				case 10:
					a: {
						d = b.type._context;
						e = b.pendingProps;
						f = b.memoizedProps;
						g = e.value;
						G(Wg, d._currentValue);
						d._currentValue = g;
						if (null !== f) if (He(f.value, g)) {
							if (f.children === e.children && !Wf.current) {
								b = Zi(a, b, c);
								break a;
							}
						} else for (f = b.child, null !== f && (f.return = b); null !== f;) {
							var h = f.dependencies;
							if (null !== h) {
								g = f.child;
								for (var k = h.firstContext; null !== k;) {
									if (k.context === d) {
										if (1 === f.tag) {
											k = mh(-1, c & -c);
											k.tag = 2;
											var l = f.updateQueue;
											if (null !== l) {
												l = l.shared;
												var m = l.pending;
												null === m ? k.next = k : (k.next = m.next, m.next = k);
												l.pending = k;
											}
										}
										f.lanes |= c;
										k = f.alternate;
										null !== k && (k.lanes |= c);
										bh(f.return, c, b);
										h.lanes |= c;
										break;
									}
									k = k.next;
								}
							} else if (10 === f.tag) g = f.type === b.type ? null : f.child;
							else if (18 === f.tag) {
								g = f.return;
								if (null === g) throw Error(p(341));
								g.lanes |= c;
								h = g.alternate;
								null !== h && (h.lanes |= c);
								bh(g, c, b);
								g = f.sibling;
							} else g = f.child;
							if (null !== g) g.return = f;
							else for (g = f; null !== g;) {
								if (g === b) {
									g = null;
									break;
								}
								f = g.sibling;
								if (null !== f) {
									f.return = g.return;
									g = f;
									break;
								}
								g = g.return;
							}
							f = g;
						}
						Xi(a, b, e.children, c);
						b = b.child;
					}
					return b;
				case 9: return e = b.type, d = b.pendingProps.children, ch(b, c), e = eh(e), d = d(e), b.flags |= 1, Xi(a, b, d, c), b.child;
				case 14: return d = b.type, e = Ci(d, b.pendingProps), e = Ci(d.type, e), $i(a, b, d, e, c);
				case 15: return bj(a, b, b.type, b.pendingProps, c);
				case 17: return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), ij(a, b), b.tag = 1, Zf(d) ? (a = !0, cg(b)) : a = !1, ch(b, c), Gi(b, d, e), Ii(b, d, e, c), jj(null, b, d, !0, a, c);
				case 19: return xj(a, b, c);
				case 22: return dj(a, b, c);
			}
			throw Error(p(156, b.tag));
		};
		function Fk(a, b) {
			return ac(a, b);
		}
		function $k(a, b, c, d) {
			this.tag = a;
			this.key = c;
			this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null;
			this.index = 0;
			this.ref = null;
			this.pendingProps = b;
			this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null;
			this.mode = d;
			this.subtreeFlags = this.flags = 0;
			this.deletions = null;
			this.childLanes = this.lanes = 0;
			this.alternate = null;
		}
		function Bg(a, b, c, d) {
			return new $k(a, b, c, d);
		}
		function aj(a) {
			a = a.prototype;
			return !(!a || !a.isReactComponent);
		}
		function Zk(a) {
			if ("function" === typeof a) return aj(a) ? 1 : 0;
			if (void 0 !== a && null !== a) {
				a = a.$$typeof;
				if (a === Da) return 11;
				if (a === Ga) return 14;
			}
			return 2;
		}
		function Pg(a, b) {
			var c = a.alternate;
			null === c ? (c = Bg(a.tag, b, a.key, a.mode), c.elementType = a.elementType, c.type = a.type, c.stateNode = a.stateNode, c.alternate = a, a.alternate = c) : (c.pendingProps = b, c.type = a.type, c.flags = 0, c.subtreeFlags = 0, c.deletions = null);
			c.flags = a.flags & 14680064;
			c.childLanes = a.childLanes;
			c.lanes = a.lanes;
			c.child = a.child;
			c.memoizedProps = a.memoizedProps;
			c.memoizedState = a.memoizedState;
			c.updateQueue = a.updateQueue;
			b = a.dependencies;
			c.dependencies = null === b ? null : {
				lanes: b.lanes,
				firstContext: b.firstContext
			};
			c.sibling = a.sibling;
			c.index = a.index;
			c.ref = a.ref;
			return c;
		}
		function Rg(a, b, c, d, e, f) {
			var g = 2;
			d = a;
			if ("function" === typeof a) aj(a) && (g = 1);
			else if ("string" === typeof a) g = 5;
			else a: switch (a) {
				case ya: return Tg(c.children, e, f, b);
				case za:
					g = 8;
					e |= 8;
					break;
				case Aa: return a = Bg(12, c, b, e | 2), a.elementType = Aa, a.lanes = f, a;
				case Ea: return a = Bg(13, c, b, e), a.elementType = Ea, a.lanes = f, a;
				case Fa: return a = Bg(19, c, b, e), a.elementType = Fa, a.lanes = f, a;
				case Ia: return pj(c, e, f, b);
				default:
					if ("object" === typeof a && null !== a) switch (a.$$typeof) {
						case Ba:
							g = 10;
							break a;
						case Ca:
							g = 9;
							break a;
						case Da:
							g = 11;
							break a;
						case Ga:
							g = 14;
							break a;
						case Ha:
							g = 16;
							d = null;
							break a;
					}
					throw Error(p(130, null == a ? a : typeof a, ""));
			}
			b = Bg(g, c, b, e);
			b.elementType = a;
			b.type = d;
			b.lanes = f;
			return b;
		}
		function Tg(a, b, c, d) {
			a = Bg(7, a, d, b);
			a.lanes = c;
			return a;
		}
		function pj(a, b, c, d) {
			a = Bg(22, a, d, b);
			a.elementType = Ia;
			a.lanes = c;
			a.stateNode = { isHidden: !1 };
			return a;
		}
		function Qg(a, b, c) {
			a = Bg(6, a, null, b);
			a.lanes = c;
			return a;
		}
		function Sg(a, b, c) {
			b = Bg(4, null !== a.children ? a.children : [], a.key, b);
			b.lanes = c;
			b.stateNode = {
				containerInfo: a.containerInfo,
				pendingChildren: null,
				implementation: a.implementation
			};
			return b;
		}
		function al(a, b, c, d, e) {
			this.tag = b;
			this.containerInfo = a;
			this.finishedWork = this.pingCache = this.current = this.pendingChildren = null;
			this.timeoutHandle = -1;
			this.callbackNode = this.pendingContext = this.context = null;
			this.callbackPriority = 0;
			this.eventTimes = zc(0);
			this.expirationTimes = zc(-1);
			this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0;
			this.entanglements = zc(0);
			this.identifierPrefix = d;
			this.onRecoverableError = e;
			this.mutableSourceEagerHydrationData = null;
		}
		function bl(a, b, c, d, e, f, g, h, k) {
			a = new al(a, b, c, h, k);
			1 === b ? (b = 1, !0 === f && (b |= 8)) : b = 0;
			f = Bg(3, null, null, b);
			a.current = f;
			f.stateNode = a;
			f.memoizedState = {
				element: d,
				isDehydrated: c,
				cache: null,
				transitions: null,
				pendingSuspenseBoundaries: null
			};
			kh(f);
			return a;
		}
		function cl(a, b, c) {
			var d = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
			return {
				$$typeof: wa,
				key: null == d ? null : "" + d,
				children: a,
				containerInfo: b,
				implementation: c
			};
		}
		function dl(a) {
			if (!a) return Vf;
			a = a._reactInternals;
			a: {
				if (Vb(a) !== a || 1 !== a.tag) throw Error(p(170));
				var b = a;
				do {
					switch (b.tag) {
						case 3:
							b = b.stateNode.context;
							break a;
						case 1: if (Zf(b.type)) {
							b = b.stateNode.__reactInternalMemoizedMergedChildContext;
							break a;
						}
					}
					b = b.return;
				} while (null !== b);
				throw Error(p(171));
			}
			if (1 === a.tag) {
				var c = a.type;
				if (Zf(c)) return bg(a, c, b);
			}
			return b;
		}
		function el(a, b, c, d, e, f, g, h, k) {
			a = bl(c, d, !0, a, e, f, g, h, k);
			a.context = dl(null);
			c = a.current;
			d = R();
			e = yi(c);
			f = mh(d, e);
			f.callback = void 0 !== b && null !== b ? b : null;
			nh(c, f, e);
			a.current.lanes = e;
			Ac(a, e, d);
			Dk(a, d);
			return a;
		}
		function fl(a, b, c, d) {
			var e = b.current, f = R(), g = yi(e);
			c = dl(c);
			null === b.context ? b.context = c : b.pendingContext = c;
			b = mh(f, g);
			b.payload = { element: a };
			d = void 0 === d ? null : d;
			null !== d && (b.callback = d);
			a = nh(e, b, g);
			null !== a && (gi(a, e, g, f), oh(a, e, g));
			return g;
		}
		function gl(a) {
			a = a.current;
			if (!a.child) return null;
			switch (a.child.tag) {
				case 5: return a.child.stateNode;
				default: return a.child.stateNode;
			}
		}
		function hl(a, b) {
			a = a.memoizedState;
			if (null !== a && null !== a.dehydrated) {
				var c = a.retryLane;
				a.retryLane = 0 !== c && c < b ? c : b;
			}
		}
		function il(a, b) {
			hl(a, b);
			(a = a.alternate) && hl(a, b);
		}
		function jl() {
			return null;
		}
		var kl = "function" === typeof reportError ? reportError : function(a) {
			console.error(a);
		};
		function ll(a) {
			this._internalRoot = a;
		}
		ml.prototype.render = ll.prototype.render = function(a) {
			var b = this._internalRoot;
			if (null === b) throw Error(p(409));
			fl(a, b, null, null);
		};
		ml.prototype.unmount = ll.prototype.unmount = function() {
			var a = this._internalRoot;
			if (null !== a) {
				this._internalRoot = null;
				var b = a.containerInfo;
				Rk(function() {
					fl(null, a, null, null);
				});
				b[uf] = null;
			}
		};
		function ml(a) {
			this._internalRoot = a;
		}
		ml.prototype.unstable_scheduleHydration = function(a) {
			if (a) {
				var b = Hc();
				a = {
					blockedOn: null,
					target: a,
					priority: b
				};
				for (var c = 0; c < Qc.length && 0 !== b && b < Qc[c].priority; c++);
				Qc.splice(c, 0, a);
				0 === c && Vc(a);
			}
		};
		function nl(a) {
			return !(!a || 1 !== a.nodeType && 9 !== a.nodeType && 11 !== a.nodeType);
		}
		function ol(a) {
			return !(!a || 1 !== a.nodeType && 9 !== a.nodeType && 11 !== a.nodeType && (8 !== a.nodeType || " react-mount-point-unstable " !== a.nodeValue));
		}
		function pl() {}
		function ql(a, b, c, d, e) {
			if (e) {
				if ("function" === typeof d) {
					var f = d;
					d = function() {
						var a = gl(g);
						f.call(a);
					};
				}
				var g = el(b, d, a, 0, null, !1, !1, "", pl);
				a._reactRootContainer = g;
				a[uf] = g.current;
				sf(8 === a.nodeType ? a.parentNode : a);
				Rk();
				return g;
			}
			for (; e = a.lastChild;) a.removeChild(e);
			if ("function" === typeof d) {
				var h = d;
				d = function() {
					var a = gl(k);
					h.call(a);
				};
			}
			var k = bl(a, 0, !1, null, null, !1, !1, "", pl);
			a._reactRootContainer = k;
			a[uf] = k.current;
			sf(8 === a.nodeType ? a.parentNode : a);
			Rk(function() {
				fl(b, k, c, d);
			});
			return k;
		}
		function rl(a, b, c, d, e) {
			var f = c._reactRootContainer;
			if (f) {
				var g = f;
				if ("function" === typeof e) {
					var h = e;
					e = function() {
						var a = gl(g);
						h.call(a);
					};
				}
				fl(b, g, a, e);
			} else g = ql(c, b, a, e, d);
			return gl(g);
		}
		Ec = function(a) {
			switch (a.tag) {
				case 3:
					var b = a.stateNode;
					if (b.current.memoizedState.isDehydrated) {
						var c = tc(b.pendingLanes);
						0 !== c && (Cc(b, c | 1), Dk(b, B()), 0 === (K & 6) && (Gj = B() + 500, jg()));
					}
					break;
				case 13: Rk(function() {
					var b = ih(a, 1);
					if (null !== b) gi(b, a, 1, R());
				}), il(a, 1);
			}
		};
		Fc = function(a) {
			if (13 === a.tag) {
				var b = ih(a, 134217728);
				if (null !== b) gi(b, a, 134217728, R());
				il(a, 134217728);
			}
		};
		Gc = function(a) {
			if (13 === a.tag) {
				var b = yi(a), c = ih(a, b);
				if (null !== c) gi(c, a, b, R());
				il(a, b);
			}
		};
		Hc = function() {
			return C;
		};
		Ic = function(a, b) {
			var c = C;
			try {
				return C = a, b();
			} finally {
				C = c;
			}
		};
		yb = function(a, b, c) {
			switch (b) {
				case "input":
					bb(a, c);
					b = c.name;
					if ("radio" === c.type && null != b) {
						for (c = a; c.parentNode;) c = c.parentNode;
						c = c.querySelectorAll("input[name=" + JSON.stringify("" + b) + "][type=\"radio\"]");
						for (b = 0; b < c.length; b++) {
							var d = c[b];
							if (d !== a && d.form === a.form) {
								var e = Db(d);
								if (!e) throw Error(p(90));
								Wa(d);
								bb(d, e);
							}
						}
					}
					break;
				case "textarea":
					ib(a, c);
					break;
				case "select": b = c.value, null != b && fb(a, !!c.multiple, b, !1);
			}
		};
		Gb = Qk;
		Hb = Rk;
		var sl = {
			usingClientEntryPoint: !1,
			Events: [
				Cb,
				ue,
				Db,
				Eb,
				Fb,
				Qk
			]
		};
		var tl = {
			findFiberByHostInstance: Wc,
			bundleType: 0,
			version: "18.3.1",
			rendererPackageName: "react-dom"
		};
		var ul = {
			bundleType: tl.bundleType,
			version: tl.version,
			rendererPackageName: tl.rendererPackageName,
			rendererConfig: tl.rendererConfig,
			overrideHookState: null,
			overrideHookStateDeletePath: null,
			overrideHookStateRenamePath: null,
			overrideProps: null,
			overridePropsDeletePath: null,
			overridePropsRenamePath: null,
			setErrorHandler: null,
			setSuspenseHandler: null,
			scheduleUpdate: null,
			currentDispatcherRef: ua.ReactCurrentDispatcher,
			findHostInstanceByFiber: function(a) {
				a = Zb(a);
				return null === a ? null : a.stateNode;
			},
			findFiberByHostInstance: tl.findFiberByHostInstance || jl,
			findHostInstancesForRefresh: null,
			scheduleRefresh: null,
			scheduleRoot: null,
			setRefreshHandler: null,
			getCurrentFiber: null,
			reconcilerVersion: "18.3.1-next-f1338f8080-20240426"
		};
		if ("undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__) {
			var vl = __REACT_DEVTOOLS_GLOBAL_HOOK__;
			if (!vl.isDisabled && vl.supportsFiber) try {
				kc = vl.inject(ul), lc = vl;
			} catch (a) {}
		}
		exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = sl;
		exports.createPortal = function(a, b) {
			var c = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
			if (!nl(b)) throw Error(p(200));
			return cl(a, b, null, c);
		};
		exports.createRoot = function(a, b) {
			if (!nl(a)) throw Error(p(299));
			var c = !1, d = "", e = kl;
			null !== b && void 0 !== b && (!0 === b.unstable_strictMode && (c = !0), void 0 !== b.identifierPrefix && (d = b.identifierPrefix), void 0 !== b.onRecoverableError && (e = b.onRecoverableError));
			b = bl(a, 1, !1, null, null, c, !1, d, e);
			a[uf] = b.current;
			sf(8 === a.nodeType ? a.parentNode : a);
			return new ll(b);
		};
		exports.findDOMNode = function(a) {
			if (null == a) return null;
			if (1 === a.nodeType) return a;
			var b = a._reactInternals;
			if (void 0 === b) {
				if ("function" === typeof a.render) throw Error(p(188));
				a = Object.keys(a).join(",");
				throw Error(p(268, a));
			}
			a = Zb(b);
			a = null === a ? null : a.stateNode;
			return a;
		};
		exports.flushSync = function(a) {
			return Rk(a);
		};
		exports.hydrate = function(a, b, c) {
			if (!ol(b)) throw Error(p(200));
			return rl(null, a, b, !0, c);
		};
		exports.hydrateRoot = function(a, b, c) {
			if (!nl(a)) throw Error(p(405));
			var d = null != c && c.hydratedSources || null, e = !1, f = "", g = kl;
			null !== c && void 0 !== c && (!0 === c.unstable_strictMode && (e = !0), void 0 !== c.identifierPrefix && (f = c.identifierPrefix), void 0 !== c.onRecoverableError && (g = c.onRecoverableError));
			b = el(b, null, a, 1, null != c ? c : null, e, !1, f, g);
			a[uf] = b.current;
			sf(a);
			if (d) for (a = 0; a < d.length; a++) c = d[a], e = c._getVersion, e = e(c._source), null == b.mutableSourceEagerHydrationData ? b.mutableSourceEagerHydrationData = [c, e] : b.mutableSourceEagerHydrationData.push(c, e);
			return new ml(b);
		};
		exports.render = function(a, b, c) {
			if (!ol(b)) throw Error(p(200));
			return rl(null, a, b, !1, c);
		};
		exports.unmountComponentAtNode = function(a) {
			if (!ol(a)) throw Error(p(40));
			return a._reactRootContainer ? (Rk(function() {
				rl(null, null, a, !1, function() {
					a._reactRootContainer = null;
					a[uf] = null;
				});
			}), !0) : !1;
		};
		exports.unstable_batchedUpdates = Qk;
		exports.unstable_renderSubtreeIntoContainer = function(a, b, c, d) {
			if (!ol(c)) throw Error(p(200));
			if (null == a || void 0 === a._reactInternals) throw Error(p(38));
			return rl(a, b, c, !1, d);
		};
		exports.version = "18.3.1-next-f1338f8080-20240426";
	}));
	//#endregion
	//#region node_modules/react-dom/index.js
	var require_react_dom = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		function checkDCE() {
			if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === "undefined" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== "function") return;
			try {
				__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
			} catch (err) {
				console.error(err);
			}
		}
		checkDCE();
		module.exports = require_react_dom_production_min();
	}));
	//#endregion
	//#region node_modules/react-dom/client.js
	var require_client = /* @__PURE__ */ __commonJSMin(((exports) => {
		var m = require_react_dom();
		exports.createRoot = m.createRoot;
		exports.hydrateRoot = m.hydrateRoot;
	}));
	//#endregion
	//#region \0@oxc-project+runtime@0.146.0/helpers/esm/typeof.js
	function _typeof(o) {
		"@babel/helpers - typeof";
		return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
			return typeof o;
		} : function(o) {
			return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
		}, _typeof(o);
	}
	var init_typeof = __esmMin((() => {}));
	//#endregion
	//#region \0@oxc-project+runtime@0.146.0/helpers/esm/toPrimitive.js
	function toPrimitive(t, r) {
		if ("object" != _typeof(t) || !t) return t;
		var e = t[Symbol.toPrimitive];
		if (void 0 !== e) {
			var i = e.call(t, r || "default");
			if ("object" != _typeof(i)) return i;
			throw new TypeError("@@toPrimitive must return a primitive value.");
		}
		return ("string" === r ? String : Number)(t);
	}
	var init_toPrimitive = __esmMin((() => {
		init_typeof();
	}));
	//#endregion
	//#region \0@oxc-project+runtime@0.146.0/helpers/esm/toPropertyKey.js
	function toPropertyKey(t) {
		var i = toPrimitive(t, "string");
		return "symbol" == _typeof(i) ? i : i + "";
	}
	var init_toPropertyKey = __esmMin((() => {
		init_typeof();
		init_toPrimitive();
	}));
	//#endregion
	//#region \0@oxc-project+runtime@0.146.0/helpers/esm/defineProperty.js
	function _defineProperty(e, r, t) {
		return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
			value: t,
			enumerable: !0,
			configurable: !0,
			writable: !0
		}) : e[r] = t, e;
	}
	var init_defineProperty = __esmMin((() => {
		init_toPropertyKey();
	}));
	//#endregion
	//#region \0@oxc-project+runtime@0.146.0/helpers/esm/objectSpread2.js
	function ownKeys(e, r) {
		var t = Object.keys(e);
		if (Object.getOwnPropertySymbols) {
			var o = Object.getOwnPropertySymbols(e);
			r && (o = o.filter(function(r) {
				return Object.getOwnPropertyDescriptor(e, r).enumerable;
			})), t.push.apply(t, o);
		}
		return t;
	}
	function _objectSpread2(e) {
		for (var r = 1; r < arguments.length; r++) {
			var t = null != arguments[r] ? arguments[r] : {};
			r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
				_defineProperty(e, r, t[r]);
			}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
				Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
			});
		}
		return e;
	}
	var init_objectSpread2 = __esmMin((() => {
		init_defineProperty();
	}));
	//#endregion
	//#region \0@oxc-project+runtime@0.146.0/helpers/esm/asyncToGenerator.js
	function asyncGeneratorStep(n, t, e, r, o, a, c) {
		try {
			var i = n[a](c), u = i.value;
		} catch (n) {
			e(n);
			return;
		}
		i.done ? t(u) : Promise.resolve(u).then(r, o);
	}
	function _asyncToGenerator(n) {
		return function() {
			var t = this, e = arguments;
			return new Promise(function(r, o) {
				var a = n.apply(t, e);
				function _next(n) {
					asyncGeneratorStep(a, r, o, _next, _throw, "next", n);
				}
				function _throw(n) {
					asyncGeneratorStep(a, r, o, _next, _throw, "throw", n);
				}
				_next(void 0);
			});
		};
	}
	var init_asyncToGenerator = __esmMin((() => {}));
	//#endregion
	//#region \0@oxc-project+runtime@0.146.0/helpers/esm/objectWithoutPropertiesLoose.js
	function _objectWithoutPropertiesLoose(r, e) {
		if (null == r) return {};
		var t = {};
		for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
			if (e.includes(n)) continue;
			t[n] = r[n];
		}
		return t;
	}
	var init_objectWithoutPropertiesLoose = __esmMin((() => {}));
	//#endregion
	//#region \0@oxc-project+runtime@0.146.0/helpers/esm/objectWithoutProperties.js
	function _objectWithoutProperties(e, t) {
		if (null == e) return {};
		var o, r, i = _objectWithoutPropertiesLoose(e, t);
		if (Object.getOwnPropertySymbols) {
			var s = Object.getOwnPropertySymbols(e);
			for (r = 0; r < s.length; r++) o = s[r], t.includes(o) || {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
		}
		return i;
	}
	var init_objectWithoutProperties = __esmMin((() => {
		init_objectWithoutPropertiesLoose();
	}));
	var __vitePreload = function preload(baseModule, deps, importerUrl) {
		let promise = Promise.resolve();
		function handlePreloadError(err) {
			const e = new Event("vite:preloadError", { cancelable: true });
			e.payload = err;
			window.dispatchEvent(e);
			if (!e.defaultPrevented) throw err;
		}
		return promise.then((res) => {
			for (const item of res || []) {
				if (item.status !== "rejected") continue;
				handlePreloadError(item.reason);
			}
			return baseModule().catch(handlePreloadError);
		});
	};
	//#endregion
	//#region node_modules/react-router/dist/development/chunk-62JRHF6Z.mjs
	init_objectSpread2();
	init_asyncToGenerator();
	init_objectWithoutProperties();
	var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
	var _excluded2$1 = ["matches", "historyAction"];
	var _excluded4 = ["page"];
	var _excluded5 = ["page", "matches"];
	var _excluded6 = ["page", "matches"];
	var _excluded8 = [
		"onClick",
		"discover",
		"prefetch",
		"relative",
		"reloadDocument",
		"replace",
		"mask",
		"state",
		"target",
		"to",
		"preventScrollReset",
		"viewTransition",
		"defaultShouldRevalidate"
	];
	var _excluded9 = [
		"aria-current",
		"caseSensitive",
		"className",
		"end",
		"style",
		"to",
		"viewTransition",
		"children"
	];
	var _excluded10 = [
		"discover",
		"fetcherKey",
		"navigate",
		"reloadDocument",
		"replace",
		"state",
		"method",
		"action",
		"onSubmit",
		"relative",
		"preventScrollReset",
		"viewTransition",
		"defaultShouldRevalidate"
	];
	var _excluded11 = ["getKey", "storageKey"];
	/**
	* react-router v7.18.2
	*
	* Copyright (c) Remix Software Inc.
	*
	* This source code is licensed under the MIT license found in the
	* LICENSE.md file in the root directory of this source tree.
	*
	* @license MIT
	*/
	var ABSOLUTE_URL_REGEX = /^(?:[a-z][a-z0-9+.-]*:|[\\/]{2})/i;
	var PROTOCOL_RELATIVE_URL_REGEX = /^[\\/]{2}/;
	function normalizeProtocolRelativeUrl(url, protocol) {
		return protocol + url.replace(/\\/g, "/");
	}
	var PopStateEventType = "popstate";
	function isLocation(obj) {
		return typeof obj === "object" && obj != null && "pathname" in obj && "search" in obj && "hash" in obj && "state" in obj && "key" in obj;
	}
	function createHashHistory(options = {}) {
		function createHashLocation(window2, globalHistory) {
			let { pathname = "/", search = "", hash = "" } = parsePath(window2.location.hash.substring(1));
			if (!pathname.startsWith("/") && !pathname.startsWith(".")) pathname = "/" + pathname;
			return createLocation("", {
				pathname,
				search,
				hash
			}, globalHistory.state && globalHistory.state.usr || null, globalHistory.state && globalHistory.state.key || "default");
		}
		function createHashHref(window2, to) {
			let base = window2.document.querySelector("base");
			let href = "";
			if (base && base.getAttribute("href")) {
				let url = window2.location.href;
				let hashIndex = url.indexOf("#");
				href = hashIndex === -1 ? url : url.slice(0, hashIndex);
			}
			return href + "#" + (typeof to === "string" ? to : createPath(to));
		}
		function validateHashLocation(location, to) {
			warning$1(location.pathname.charAt(0) === "/", `relative pathnames are not supported in hash history.push(${JSON.stringify(to)})`);
		}
		return getUrlBasedHistory(createHashLocation, createHashHref, validateHashLocation, options);
	}
	function invariant$1(value, message) {
		if (value === false || value === null || typeof value === "undefined") throw new Error(message);
	}
	function warning$1(cond, message) {
		if (!cond) {
			if (typeof console !== "undefined") console.warn(message);
			try {
				throw new Error(message);
			} catch (e) {}
		}
	}
	function createKey() {
		return Math.random().toString(36).substring(2, 10);
	}
	function getHistoryState(location, index) {
		return {
			usr: location.state,
			key: location.key,
			idx: index,
			masked: location.mask ? {
				pathname: location.pathname,
				search: location.search,
				hash: location.hash
			} : void 0
		};
	}
	function createLocation(current, to, state = null, key, mask) {
		return _objectSpread2(_objectSpread2({
			pathname: typeof current === "string" ? current : current.pathname,
			search: "",
			hash: ""
		}, typeof to === "string" ? parsePath(to) : to), {}, {
			state,
			key: to && to.key || key || createKey(),
			mask
		});
	}
	function createPath({ pathname = "/", search = "", hash = "" }) {
		if (search && search !== "?") pathname += search.charAt(0) === "?" ? search : "?" + search;
		if (hash && hash !== "#") pathname += hash.charAt(0) === "#" ? hash : "#" + hash;
		return pathname;
	}
	function parsePath(path) {
		let parsedPath = {};
		if (path) {
			let hashIndex = path.indexOf("#");
			if (hashIndex >= 0) {
				parsedPath.hash = path.substring(hashIndex);
				path = path.substring(0, hashIndex);
			}
			let searchIndex = path.indexOf("?");
			if (searchIndex >= 0) {
				parsedPath.search = path.substring(searchIndex);
				path = path.substring(0, searchIndex);
			}
			if (path) parsedPath.pathname = path;
		}
		return parsedPath;
	}
	function getUrlBasedHistory(getLocation, createHref2, validateLocation, options = {}) {
		let { window: window2 = document.defaultView, v5Compat = false } = options;
		let globalHistory = window2.history;
		let action = "POP";
		let listener = null;
		let index = getIndex();
		if (index == null) {
			index = 0;
			globalHistory.replaceState(_objectSpread2(_objectSpread2({}, globalHistory.state), {}, { idx: index }), "");
		}
		function getIndex() {
			return (globalHistory.state || { idx: null }).idx;
		}
		function handlePop() {
			action = "POP";
			let nextIndex = getIndex();
			let delta = nextIndex == null ? null : nextIndex - index;
			index = nextIndex;
			if (listener) listener({
				action,
				location: history.location,
				delta
			});
		}
		function push(to, state) {
			action = "PUSH";
			let location = isLocation(to) ? to : createLocation(history.location, to, state);
			if (validateLocation) validateLocation(location, to);
			index = getIndex() + 1;
			let historyState = getHistoryState(location, index);
			let url = history.createHref(location.mask || location);
			try {
				globalHistory.pushState(historyState, "", url);
			} catch (error) {
				if (error instanceof DOMException && error.name === "DataCloneError") throw error;
				window2.location.assign(url);
			}
			if (v5Compat && listener) listener({
				action,
				location: history.location,
				delta: 1
			});
		}
		function replace2(to, state) {
			action = "REPLACE";
			let location = isLocation(to) ? to : createLocation(history.location, to, state);
			if (validateLocation) validateLocation(location, to);
			index = getIndex();
			let historyState = getHistoryState(location, index);
			let url = history.createHref(location.mask || location);
			globalHistory.replaceState(historyState, "", url);
			if (v5Compat && listener) listener({
				action,
				location: history.location,
				delta: 0
			});
		}
		function createURL(to) {
			return createBrowserURLImpl(window2, to);
		}
		let history = {
			get action() {
				return action;
			},
			get location() {
				return getLocation(window2, globalHistory);
			},
			listen(fn) {
				if (listener) throw new Error("A history only accepts one active listener");
				window2.addEventListener(PopStateEventType, handlePop);
				listener = fn;
				return () => {
					window2.removeEventListener(PopStateEventType, handlePop);
					listener = null;
				};
			},
			createHref(to) {
				return createHref2(window2, to);
			},
			createURL,
			encodeLocation(to) {
				let url = createURL(to);
				return {
					pathname: url.pathname,
					search: url.search,
					hash: url.hash
				};
			},
			push,
			replace: replace2,
			go(n) {
				return globalHistory.go(n);
			}
		};
		return history;
	}
	function createBrowserURLImpl(windowImpl, to, isAbsolute = false) {
		let base = "http://localhost";
		if (windowImpl) base = windowImpl.location.origin !== "null" ? windowImpl.location.origin : windowImpl.location.href;
		invariant$1(base, "No window.location.(origin|href) available to create URL");
		let href = typeof to === "string" ? to : createPath(to);
		href = href.replace(/ $/, "%20");
		if (!isAbsolute && PROTOCOL_RELATIVE_URL_REGEX.test(href)) href = base + href;
		return new URL(href, base);
	}
	function matchRoutes(routes, locationArg, basename = "/") {
		return matchRoutesImpl(routes, locationArg, basename, false);
	}
	function matchRoutesImpl(routes, locationArg, basename, allowPartial, precomputedBranches) {
		let pathname = stripBasename((typeof locationArg === "string" ? parsePath(locationArg) : locationArg).pathname || "/", basename);
		if (pathname == null) return null;
		let branches = precomputedBranches !== null && precomputedBranches !== void 0 ? precomputedBranches : flattenAndRankRoutes(routes);
		let matches = null;
		let decoded = decodePath(pathname);
		for (let i = 0; matches == null && i < branches.length; ++i) matches = matchRouteBranch(branches[i], decoded, allowPartial);
		return matches;
	}
	function convertRouteMatchToUiMatch(match, loaderData) {
		let { route, pathname, params } = match;
		return {
			id: route.id,
			pathname,
			params,
			data: loaderData[route.id],
			loaderData: loaderData[route.id],
			handle: route.handle
		};
	}
	function flattenAndRankRoutes(routes) {
		let branches = flattenRoutes(routes);
		rankRouteBranches(branches);
		return branches;
	}
	function flattenRoutes(routes, branches = [], parentsMeta = [], parentPath = "", _hasParentOptionalSegments = false) {
		let flattenRoute = (route, index, hasParentOptionalSegments = _hasParentOptionalSegments, relativePath) => {
			let meta = {
				relativePath: relativePath === void 0 ? route.path || "" : relativePath,
				caseSensitive: route.caseSensitive === true,
				childrenIndex: index,
				route
			};
			if (meta.relativePath.startsWith("/")) {
				if (!meta.relativePath.startsWith(parentPath) && hasParentOptionalSegments) return;
				invariant$1(meta.relativePath.startsWith(parentPath), `Absolute route path "${meta.relativePath}" nested under path "${parentPath}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`);
				meta.relativePath = meta.relativePath.slice(parentPath.length);
			}
			let path = joinPaths([parentPath, meta.relativePath]);
			let routesMeta = parentsMeta.concat(meta);
			if (route.children && route.children.length > 0) {
				invariant$1(route.index !== true, `Index routes must not have child routes. Please remove all child routes from route path "${path}".`);
				flattenRoutes(route.children, branches, routesMeta, path, hasParentOptionalSegments);
			}
			if (route.path == null && !route.index) return;
			branches.push({
				path,
				score: computeScore(path, route.index),
				routesMeta: routesMeta.map((meta2, i) => {
					let [matcher, params] = compilePath(meta2.relativePath, meta2.caseSensitive, i === routesMeta.length - 1);
					return _objectSpread2(_objectSpread2({}, meta2), {}, {
						matcher,
						compiledParams: params
					});
				})
			});
		};
		routes.forEach((route, index) => {
			var _route$path;
			if (route.path === "" || !((_route$path = route.path) === null || _route$path === void 0 ? void 0 : _route$path.includes("?"))) flattenRoute(route, index);
			else for (let exploded of explodeOptionalSegments(route.path)) flattenRoute(route, index, true, exploded);
		});
		return branches;
	}
	function explodeOptionalSegments(path) {
		let segments = path.split("/");
		if (segments.length === 0) return [];
		let [first, ...rest] = segments;
		let isOptional = first.endsWith("?");
		let required = first.replace(/\?$/, "");
		if (rest.length === 0) return isOptional ? [required, ""] : [required];
		let restExploded = explodeOptionalSegments(rest.join("/"));
		let result = [];
		result.push(...restExploded.map((subpath) => subpath === "" ? required : [required, subpath].join("/")));
		if (isOptional) result.push(...restExploded);
		return result.map((exploded) => path.startsWith("/") && exploded === "" ? "/" : exploded);
	}
	function rankRouteBranches(branches) {
		branches.sort((a, b) => a.score !== b.score ? b.score - a.score : compareIndexes(a.routesMeta.map((meta) => meta.childrenIndex), b.routesMeta.map((meta) => meta.childrenIndex)));
	}
	var paramRe = /^:[\w-]+$/;
	var dynamicSegmentValue = 3;
	var indexRouteValue = 2;
	var emptySegmentValue = 1;
	var staticSegmentValue = 10;
	var splatPenalty = -2;
	var isSplat = (s) => s === "*";
	function computeScore(path, index) {
		let segments = path.split("/");
		let initialScore = segments.length;
		if (segments.some(isSplat)) initialScore += splatPenalty;
		if (index) initialScore += indexRouteValue;
		return segments.filter((s) => !isSplat(s)).reduce((score, segment) => score + (paramRe.test(segment) ? dynamicSegmentValue : segment === "" ? emptySegmentValue : staticSegmentValue), initialScore);
	}
	function compareIndexes(a, b) {
		return a.length === b.length && a.slice(0, -1).every((n, i) => n === b[i]) ? a[a.length - 1] - b[b.length - 1] : 0;
	}
	function matchRouteBranch(branch, pathname, allowPartial = false) {
		let { routesMeta } = branch;
		let matchedParams = {};
		let matchedPathname = "/";
		let matches = [];
		for (let i = 0; i < routesMeta.length; ++i) {
			let meta = routesMeta[i];
			let end = i === routesMeta.length - 1;
			let remainingPathname = matchedPathname === "/" ? pathname : pathname.slice(matchedPathname.length) || "/";
			let pattern = {
				path: meta.relativePath,
				caseSensitive: meta.caseSensitive,
				end
			};
			let match = meta.matcher && meta.compiledParams ? matchPathImpl(pattern, remainingPathname, meta.matcher, meta.compiledParams) : matchPath(pattern, remainingPathname);
			let route = meta.route;
			if (!match && end && allowPartial && !routesMeta[routesMeta.length - 1].route.index) match = matchPath({
				path: meta.relativePath,
				caseSensitive: meta.caseSensitive,
				end: false
			}, remainingPathname);
			if (!match) return null;
			Object.assign(matchedParams, match.params);
			matches.push({
				params: matchedParams,
				pathname: joinPaths([matchedPathname, match.pathname]),
				pathnameBase: normalizePathname(joinPaths([matchedPathname, match.pathnameBase])),
				route
			});
			if (match.pathnameBase !== "/") matchedPathname = joinPaths([matchedPathname, match.pathnameBase]);
		}
		return matches;
	}
	function matchPath(pattern, pathname) {
		if (typeof pattern === "string") pattern = {
			path: pattern,
			caseSensitive: false,
			end: true
		};
		let [matcher, compiledParams] = compilePath(pattern.path, pattern.caseSensitive, pattern.end);
		return matchPathImpl(pattern, pathname, matcher, compiledParams);
	}
	function matchPathImpl(pattern, pathname, matcher, compiledParams) {
		let match = pathname.match(matcher);
		if (!match) return null;
		let matchedPathname = match[0];
		let pathnameBase = matchedPathname.replace(/(.)\/+$/, "$1");
		let captureGroups = match.slice(1);
		return {
			params: compiledParams.reduce((memo2, { paramName, isOptional }, index) => {
				if (paramName === "*") {
					let splatValue = captureGroups[index] || "";
					pathnameBase = matchedPathname.slice(0, matchedPathname.length - splatValue.length).replace(/(.)\/+$/, "$1");
				}
				const value = captureGroups[index];
				if (isOptional && !value) memo2[paramName] = void 0;
				else memo2[paramName] = (value || "").replace(/%2F/g, "/");
				return memo2;
			}, {}),
			pathname: matchedPathname,
			pathnameBase,
			pattern
		};
	}
	function compilePath(path, caseSensitive = false, end = true) {
		warning$1(path === "*" || !path.endsWith("*") || path.endsWith("/*"), `Route path "${path}" will be treated as if it were "${path.replace(/\*$/, "/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${path.replace(/\*$/, "/*")}".`);
		let params = [];
		let regexpSource = "^" + path.replace(/\/*\*?$/, "").replace(/^\/*/, "/").replace(/[\\.*+^${}|()[\]]/g, "\\$&").replace(/\/:([\w-]+)(\?)?/g, (match, paramName, isOptional, index, str) => {
			params.push({
				paramName,
				isOptional: isOptional != null
			});
			if (isOptional) {
				let nextChar = str.charAt(index + match.length);
				if (nextChar && nextChar !== "/") return "/([^\\/]*)";
				return "(?:/([^\\/]*))?";
			}
			return "/([^\\/]+)";
		}).replace(/\/([\w-]+)\?(\/|$)/g, "(/$1)?$2");
		if (path.endsWith("*")) {
			params.push({ paramName: "*" });
			regexpSource += path === "*" || path === "/*" ? "(.*)$" : "(?:\\/(.+)|\\/*)$";
		} else if (end) regexpSource += "\\/*$";
		else if (path !== "" && path !== "/") regexpSource += "(?:(?=\\/|$))";
		return [new RegExp(regexpSource, caseSensitive ? void 0 : "i"), params];
	}
	function decodePath(value) {
		try {
			return value.split("/").map((v) => decodeURIComponent(v).replace(/\//g, "%2F")).join("/");
		} catch (error) {
			warning$1(false, `The URL path "${value}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${error}).`);
			return value;
		}
	}
	function stripBasename(pathname, basename) {
		if (basename === "/") return pathname;
		if (!pathname.toLowerCase().startsWith(basename.toLowerCase())) return null;
		let startIndex = basename.endsWith("/") ? basename.length - 1 : basename.length;
		let nextChar = pathname.charAt(startIndex);
		if (nextChar && nextChar !== "/") return null;
		return pathname.slice(startIndex) || "/";
	}
	function resolvePath(to, fromPathname = "/") {
		let { pathname: toPathname, search = "", hash = "" } = typeof to === "string" ? parsePath(to) : to;
		let pathname;
		if (toPathname) {
			toPathname = removeDoubleSlashes(toPathname);
			if (toPathname.startsWith("/")) pathname = resolvePathname(toPathname.substring(1), "/");
			else pathname = resolvePathname(toPathname, fromPathname);
		} else pathname = fromPathname;
		return {
			pathname,
			search: normalizeSearch(search),
			hash: normalizeHash(hash)
		};
	}
	function resolvePathname(relativePath, fromPathname) {
		let segments = removeTrailingSlash(fromPathname).split("/");
		relativePath.split("/").forEach((segment) => {
			if (segment === "..") {
				if (segments.length > 1) segments.pop();
			} else if (segment !== ".") segments.push(segment);
		});
		return segments.length > 1 ? segments.join("/") : "/";
	}
	function getInvalidPathError(char, field, dest, path) {
		return `Cannot include a '${char}' character in a manually specified \`to.${field}\` field [${JSON.stringify(path)}].  Please separate it out to the \`to.${dest}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`;
	}
	function getPathContributingMatches(matches) {
		return matches.filter((match, index) => index === 0 || match.route.path && match.route.path.length > 0);
	}
	function getResolveToMatches(matches) {
		let pathMatches = getPathContributingMatches(matches);
		return pathMatches.map((match, idx) => idx === pathMatches.length - 1 ? match.pathname : match.pathnameBase);
	}
	function resolveTo(toArg, routePathnames, locationPathname, isPathRelative = false) {
		let to;
		if (typeof toArg === "string") to = parsePath(toArg);
		else {
			to = _objectSpread2({}, toArg);
			invariant$1(!to.pathname || !to.pathname.includes("?"), getInvalidPathError("?", "pathname", "search", to));
			invariant$1(!to.pathname || !to.pathname.includes("#"), getInvalidPathError("#", "pathname", "hash", to));
			invariant$1(!to.search || !to.search.includes("#"), getInvalidPathError("#", "search", "hash", to));
		}
		let isEmptyPath = toArg === "" || to.pathname === "";
		let toPathname = isEmptyPath ? "/" : to.pathname;
		let from;
		if (toPathname == null) from = locationPathname;
		else {
			let routePathnameIndex = routePathnames.length - 1;
			if (!isPathRelative && toPathname.startsWith("..")) {
				let toSegments = toPathname.split("/");
				while (toSegments[0] === "..") {
					toSegments.shift();
					routePathnameIndex -= 1;
				}
				to.pathname = toSegments.join("/");
			}
			from = routePathnameIndex >= 0 ? routePathnames[routePathnameIndex] : "/";
		}
		let path = resolvePath(to, from);
		let hasExplicitTrailingSlash = toPathname && toPathname !== "/" && toPathname.endsWith("/");
		let hasCurrentTrailingSlash = (isEmptyPath || toPathname === ".") && locationPathname.endsWith("/");
		if (!path.pathname.endsWith("/") && (hasExplicitTrailingSlash || hasCurrentTrailingSlash)) path.pathname += "/";
		return path;
	}
	var removeDoubleSlashes = (path) => path.replace(/[\\/]{2,}/g, "/");
	var joinPaths = (paths) => removeDoubleSlashes(paths.join("/"));
	var removeTrailingSlash = (path) => path.replace(/\/+$/, "");
	var normalizePathname = (pathname) => removeTrailingSlash(pathname).replace(/^\/*/, "/");
	var normalizeSearch = (search) => !search || search === "?" ? "" : search.startsWith("?") ? search : "?" + search;
	var normalizeHash = (hash) => !hash || hash === "#" ? "" : hash.startsWith("#") ? hash : "#" + hash;
	var ErrorResponseImpl = class {
		constructor(status, statusText, data2, internal = false) {
			this.status = status;
			this.statusText = statusText || "";
			this.internal = internal;
			if (data2 instanceof Error) {
				this.data = data2.toString();
				this.error = data2;
			} else this.data = data2;
		}
	};
	function isRouteErrorResponse(error) {
		return error != null && typeof error.status === "number" && typeof error.statusText === "string" && typeof error.internal === "boolean" && "data" in error;
	}
	function getRoutePattern(matches) {
		return joinPaths(matches.map((m) => m.route.path).filter(Boolean)) || "/";
	}
	var isBrowser$1 = typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined";
	function parseToInfo(_to, basename) {
		let to = _to;
		if (typeof to !== "string" || !ABSOLUTE_URL_REGEX.test(to)) return {
			absoluteURL: void 0,
			isExternal: false,
			to
		};
		let absoluteURL = to;
		let isExternal = false;
		if (isBrowser$1) try {
			let currentUrl = new URL(window.location.href);
			let targetUrl = PROTOCOL_RELATIVE_URL_REGEX.test(to) ? new URL(normalizeProtocolRelativeUrl(to, currentUrl.protocol)) : new URL(to);
			let path = stripBasename(targetUrl.pathname, basename);
			if (targetUrl.origin === currentUrl.origin && path != null) to = path + targetUrl.search + targetUrl.hash;
			else isExternal = true;
		} catch (e) {
			warning$1(false, `<Link to="${to}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`);
		}
		return {
			absoluteURL,
			isExternal,
			to
		};
	}
	Object.getOwnPropertyNames(Object.prototype).sort().join("\0");
	var validMutationMethodsArr = [
		"POST",
		"PUT",
		"PATCH",
		"DELETE"
	];
	new Set(validMutationMethodsArr);
	var validRequestMethodsArr = ["GET", ...validMutationMethodsArr];
	new Set(validRequestMethodsArr);
	var invalidProtocols = [
		"about:",
		"blob:",
		"chrome:",
		"chrome-untrusted:",
		"content:",
		"data:",
		"devtools:",
		"file:",
		"filesystem:",
		"javascript:"
	];
	function hasInvalidProtocol(location) {
		try {
			return invalidProtocols.includes(new URL(location).protocol);
		} catch (_unused) {
			return false;
		}
	}
	var DataRouterContext = import_react.createContext(null);
	DataRouterContext.displayName = "DataRouter";
	var DataRouterStateContext = import_react.createContext(null);
	DataRouterStateContext.displayName = "DataRouterState";
	var RSCRouterContext = import_react.createContext(false);
	function useIsRSCRouterContext() {
		return import_react.useContext(RSCRouterContext);
	}
	var ViewTransitionContext = import_react.createContext({ isTransitioning: false });
	ViewTransitionContext.displayName = "ViewTransition";
	var FetchersContext = import_react.createContext(/* @__PURE__ */ new Map());
	FetchersContext.displayName = "Fetchers";
	var AwaitContext = import_react.createContext(null);
	AwaitContext.displayName = "Await";
	var NavigationContext = import_react.createContext(null);
	NavigationContext.displayName = "Navigation";
	var LocationContext = import_react.createContext(null);
	LocationContext.displayName = "Location";
	var RouteContext = import_react.createContext({
		outlet: null,
		matches: [],
		isDataRoute: false
	});
	RouteContext.displayName = "Route";
	var RouteErrorContext = import_react.createContext(null);
	RouteErrorContext.displayName = "RouteError";
	var ERROR_DIGEST_BASE = "REACT_ROUTER_ERROR";
	var ERROR_DIGEST_REDIRECT = "REDIRECT";
	var ERROR_DIGEST_ROUTE_ERROR_RESPONSE = "ROUTE_ERROR_RESPONSE";
	function decodeRedirectErrorDigest(digest) {
		if (digest.startsWith(`${ERROR_DIGEST_BASE}:${ERROR_DIGEST_REDIRECT}:{`)) try {
			let parsed = JSON.parse(digest.slice(28));
			if (typeof parsed === "object" && parsed && typeof parsed.status === "number" && typeof parsed.statusText === "string" && typeof parsed.location === "string" && typeof parsed.reloadDocument === "boolean" && typeof parsed.replace === "boolean") return parsed;
		} catch (_unused2) {}
	}
	function decodeRouteErrorResponseDigest(digest) {
		if (digest.startsWith(`${ERROR_DIGEST_BASE}:${ERROR_DIGEST_ROUTE_ERROR_RESPONSE}:{`)) try {
			let parsed = JSON.parse(digest.slice(40));
			if (typeof parsed === "object" && parsed && typeof parsed.status === "number" && typeof parsed.statusText === "string") return new ErrorResponseImpl(parsed.status, parsed.statusText, parsed.data);
		} catch (_unused3) {}
	}
	function useHref(to, { relative } = {}) {
		invariant$1(useInRouterContext(), `useHref() may be used only in the context of a <Router> component.`);
		let { basename, navigator } = import_react.useContext(NavigationContext);
		let { hash, pathname, search } = useResolvedPath(to, { relative });
		let joinedPathname = pathname;
		if (basename !== "/") joinedPathname = pathname === "/" ? basename : joinPaths([basename, pathname]);
		return navigator.createHref({
			pathname: joinedPathname,
			search,
			hash
		});
	}
	function useInRouterContext() {
		return import_react.useContext(LocationContext) != null;
	}
	function useLocation() {
		invariant$1(useInRouterContext(), `useLocation() may be used only in the context of a <Router> component.`);
		return import_react.useContext(LocationContext).location;
	}
	var navigateEffectWarning = `You should call navigate() in a React.useEffect(), not when your component is first rendered.`;
	function useIsomorphicLayoutEffect$1(cb) {
		if (!import_react.useContext(NavigationContext).static) import_react.useLayoutEffect(cb);
	}
	function useNavigate() {
		let { isDataRoute } = import_react.useContext(RouteContext);
		return isDataRoute ? useNavigateStable() : useNavigateUnstable();
	}
	function useNavigateUnstable() {
		invariant$1(useInRouterContext(), `useNavigate() may be used only in the context of a <Router> component.`);
		let dataRouterContext = import_react.useContext(DataRouterContext);
		let { basename, navigator } = import_react.useContext(NavigationContext);
		let { matches } = import_react.useContext(RouteContext);
		let { pathname: locationPathname } = useLocation();
		let routePathnamesJson = JSON.stringify(getResolveToMatches(matches));
		let activeRef = import_react.useRef(false);
		useIsomorphicLayoutEffect$1(() => {
			activeRef.current = true;
		});
		return import_react.useCallback((to, options = {}) => {
			warning$1(activeRef.current, navigateEffectWarning);
			if (!activeRef.current) return;
			if (typeof to === "number") {
				navigator.go(to);
				return;
			}
			let path = resolveTo(to, JSON.parse(routePathnamesJson), locationPathname, options.relative === "path");
			if (dataRouterContext == null && basename !== "/") path.pathname = path.pathname === "/" ? basename : joinPaths([basename, path.pathname]);
			(!!options.replace ? navigator.replace : navigator.push)(path, options.state, options);
		}, [
			basename,
			navigator,
			routePathnamesJson,
			locationPathname,
			dataRouterContext
		]);
	}
	import_react.createContext(null);
	function useParams() {
		var _routeMatch$params;
		let { matches } = import_react.useContext(RouteContext);
		let routeMatch = matches[matches.length - 1];
		return (_routeMatch$params = routeMatch === null || routeMatch === void 0 ? void 0 : routeMatch.params) !== null && _routeMatch$params !== void 0 ? _routeMatch$params : {};
	}
	function useResolvedPath(to, { relative } = {}) {
		let { matches } = import_react.useContext(RouteContext);
		let { pathname: locationPathname } = useLocation();
		let routePathnamesJson = JSON.stringify(getResolveToMatches(matches));
		return import_react.useMemo(() => resolveTo(to, JSON.parse(routePathnamesJson), locationPathname, relative === "path"), [
			to,
			routePathnamesJson,
			locationPathname,
			relative
		]);
	}
	function useRoutes(routes, locationArg) {
		return useRoutesImpl(routes, locationArg);
	}
	function useRoutesImpl(routes, locationArg, dataRouterOpts) {
		invariant$1(useInRouterContext(), `useRoutes() may be used only in the context of a <Router> component.`);
		let { navigator } = import_react.useContext(NavigationContext);
		let { matches: parentMatches } = import_react.useContext(RouteContext);
		let routeMatch = parentMatches[parentMatches.length - 1];
		let parentParams = routeMatch ? routeMatch.params : {};
		let parentPathname = routeMatch ? routeMatch.pathname : "/";
		let parentPathnameBase = routeMatch ? routeMatch.pathnameBase : "/";
		let parentRoute = routeMatch && routeMatch.route;
		{
			let parentPath = parentRoute && parentRoute.path || "";
			warningOnce(parentPathname, !parentRoute || parentPath.endsWith("*") || parentPath.endsWith("*?"), `You rendered descendant <Routes> (or called \`useRoutes()\`) at "${parentPathname}" (under <Route path="${parentPath}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.

Please change the parent <Route path="${parentPath}"> to <Route path="${parentPath === "/" ? "*" : `${parentPath}/*`}">.`);
		}
		let locationFromContext = useLocation();
		let location;
		if (locationArg) {
			var _parsedLocationArg$pa;
			let parsedLocationArg = typeof locationArg === "string" ? parsePath(locationArg) : locationArg;
			invariant$1(parentPathnameBase === "/" || ((_parsedLocationArg$pa = parsedLocationArg.pathname) === null || _parsedLocationArg$pa === void 0 ? void 0 : _parsedLocationArg$pa.startsWith(parentPathnameBase)), `When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${parentPathnameBase}" but pathname "${parsedLocationArg.pathname}" was given in the \`location\` prop.`);
			location = parsedLocationArg;
		} else location = locationFromContext;
		let pathname = location.pathname || "/";
		let remainingPathname = pathname;
		if (parentPathnameBase !== "/") {
			let parentSegments = parentPathnameBase.replace(/^\//, "").split("/");
			remainingPathname = "/" + pathname.replace(/^\//, "").split("/").slice(parentSegments.length).join("/");
		}
		let matches = dataRouterOpts && dataRouterOpts.state.matches.length ? dataRouterOpts.state.matches.map((m) => Object.assign(m, { route: dataRouterOpts.manifest[m.route.id] || m.route })) : matchRoutes(routes, { pathname: remainingPathname });
		warning$1(parentRoute || matches != null, `No routes matched location "${location.pathname}${location.search}${location.hash}" `);
		warning$1(matches == null || matches[matches.length - 1].route.element !== void 0 || matches[matches.length - 1].route.Component !== void 0 || matches[matches.length - 1].route.lazy !== void 0, `Matched leaf route at location "${location.pathname}${location.search}${location.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`);
		let renderedMatches = _renderMatches(matches && matches.map((match) => Object.assign({}, match, {
			params: Object.assign({}, parentParams, match.params),
			pathname: joinPaths([parentPathnameBase, navigator.encodeLocation ? navigator.encodeLocation(match.pathname.replace(/%/g, "%25").replace(/\?/g, "%3F").replace(/#/g, "%23")).pathname : match.pathname]),
			pathnameBase: match.pathnameBase === "/" ? parentPathnameBase : joinPaths([parentPathnameBase, navigator.encodeLocation ? navigator.encodeLocation(match.pathnameBase.replace(/%/g, "%25").replace(/\?/g, "%3F").replace(/#/g, "%23")).pathname : match.pathnameBase])
		})), parentMatches, dataRouterOpts);
		if (locationArg && renderedMatches) return /* @__PURE__ */ import_react.createElement(LocationContext.Provider, { value: {
			location: _objectSpread2({
				pathname: "/",
				search: "",
				hash: "",
				state: null,
				key: "default",
				mask: void 0
			}, location),
			navigationType: "POP"
		} }, renderedMatches);
		return renderedMatches;
	}
	function DefaultErrorComponent() {
		let error = useRouteError();
		let message = isRouteErrorResponse(error) ? `${error.status} ${error.statusText}` : error instanceof Error ? error.message : JSON.stringify(error);
		let stack = error instanceof Error ? error.stack : null;
		let lightgrey = "rgba(200,200,200, 0.5)";
		let preStyles = {
			padding: "0.5rem",
			backgroundColor: lightgrey
		};
		let codeStyles = {
			padding: "2px 4px",
			backgroundColor: lightgrey
		};
		let devInfo = null;
		console.error("Error handled by React Router default ErrorBoundary:", error);
		devInfo = /* @__PURE__ */ import_react.createElement(import_react.Fragment, null, /* @__PURE__ */ import_react.createElement("p", null, "💿 Hey developer 👋"), /* @__PURE__ */ import_react.createElement("p", null, "You can provide a way better UX than this when your app throws errors by providing your own ", /* @__PURE__ */ import_react.createElement("code", { style: codeStyles }, "ErrorBoundary"), " or", " ", /* @__PURE__ */ import_react.createElement("code", { style: codeStyles }, "errorElement"), " prop on your route."));
		return /* @__PURE__ */ import_react.createElement(import_react.Fragment, null, /* @__PURE__ */ import_react.createElement("h2", null, "Unexpected Application Error!"), /* @__PURE__ */ import_react.createElement("h3", { style: { fontStyle: "italic" } }, message), stack ? /* @__PURE__ */ import_react.createElement("pre", { style: preStyles }, stack) : null, devInfo);
	}
	var defaultErrorElement = /* @__PURE__ */ import_react.createElement(DefaultErrorComponent, null);
	var RenderErrorBoundary = class extends import_react.Component {
		constructor(props) {
			super(props);
			this.state = {
				location: props.location,
				revalidation: props.revalidation,
				error: props.error
			};
		}
		static getDerivedStateFromError(error) {
			return { error };
		}
		static getDerivedStateFromProps(props, state) {
			if (state.location !== props.location || state.revalidation !== "idle" && props.revalidation === "idle") return {
				error: props.error,
				location: props.location,
				revalidation: props.revalidation
			};
			return {
				error: props.error !== void 0 ? props.error : state.error,
				location: state.location,
				revalidation: props.revalidation || state.revalidation
			};
		}
		componentDidCatch(error, errorInfo) {
			if (this.props.onError) this.props.onError(error, errorInfo);
			else console.error("React Router caught the following error during render", error);
		}
		render() {
			let error = this.state.error;
			if (this.context && typeof error === "object" && error && "digest" in error && typeof error.digest === "string") {
				const decoded = decodeRouteErrorResponseDigest(error.digest);
				if (decoded) error = decoded;
			}
			let result = error !== void 0 ? /* @__PURE__ */ import_react.createElement(RouteContext.Provider, { value: this.props.routeContext }, /* @__PURE__ */ import_react.createElement(RouteErrorContext.Provider, {
				value: error,
				children: this.props.component
			})) : this.props.children;
			if (this.context) return /* @__PURE__ */ import_react.createElement(RSCErrorHandler, { error }, result);
			return result;
		}
	};
	RenderErrorBoundary.contextType = RSCRouterContext;
	var errorRedirectHandledMap = /* @__PURE__ */ new WeakMap();
	function RSCErrorHandler({ children, error }) {
		let { basename } = import_react.useContext(NavigationContext);
		if (typeof error === "object" && error && "digest" in error && typeof error.digest === "string") {
			let redirect2 = decodeRedirectErrorDigest(error.digest);
			if (redirect2) {
				let existingRedirect = errorRedirectHandledMap.get(error);
				if (existingRedirect) throw existingRedirect;
				let parsed = parseToInfo(redirect2.location, basename);
				let target = parsed.absoluteURL || parsed.to;
				if (hasInvalidProtocol(target)) throw new Error("Invalid redirect location");
				if (isBrowser$1 && !errorRedirectHandledMap.get(error)) {
					if (parsed.isExternal || redirect2.reloadDocument) window.location.href = target;
					else {
						const redirectPromise = Promise.resolve().then(() => window.__reactRouterDataRouter.navigate(parsed.to, { replace: redirect2.replace }));
						errorRedirectHandledMap.set(error, redirectPromise);
						throw redirectPromise;
					}
				}
				return /* @__PURE__ */ import_react.createElement("meta", {
					httpEquiv: "refresh",
					content: `0;url=${target}`
				});
			}
		}
		return children;
	}
	function RenderedRoute({ routeContext, match, children }) {
		let dataRouterContext = import_react.useContext(DataRouterContext);
		if (dataRouterContext && dataRouterContext.static && dataRouterContext.staticContext && (match.route.errorElement || match.route.ErrorBoundary)) dataRouterContext.staticContext._deepestRenderedBoundaryId = match.route.id;
		return /* @__PURE__ */ import_react.createElement(RouteContext.Provider, { value: routeContext }, children);
	}
	function _renderMatches(matches, parentMatches = [], dataRouterOpts) {
		let dataRouterState = dataRouterOpts === null || dataRouterOpts === void 0 ? void 0 : dataRouterOpts.state;
		if (matches == null) {
			if (!dataRouterState) return null;
			if (dataRouterState.errors) matches = dataRouterState.matches;
			else if (parentMatches.length === 0 && !dataRouterState.initialized && dataRouterState.matches.length > 0) matches = dataRouterState.matches;
			else return null;
		}
		let renderedMatches = matches;
		let errors = dataRouterState === null || dataRouterState === void 0 ? void 0 : dataRouterState.errors;
		if (errors != null) {
			let errorIndex = renderedMatches.findIndex((m) => m.route.id && (errors === null || errors === void 0 ? void 0 : errors[m.route.id]) !== void 0);
			invariant$1(errorIndex >= 0, `Could not find a matching route for errors on route IDs: ${Object.keys(errors).join(",")}`);
			renderedMatches = renderedMatches.slice(0, Math.min(renderedMatches.length, errorIndex + 1));
		}
		let renderFallback = false;
		let fallbackIndex = -1;
		if (dataRouterOpts && dataRouterState) {
			renderFallback = dataRouterState.renderFallback;
			for (let i = 0; i < renderedMatches.length; i++) {
				let match = renderedMatches[i];
				if (match.route.HydrateFallback || match.route.hydrateFallbackElement) fallbackIndex = i;
				if (match.route.id) {
					let { loaderData, errors: errors2 } = dataRouterState;
					let needsToRunLoader = match.route.loader && !loaderData.hasOwnProperty(match.route.id) && (!errors2 || errors2[match.route.id] === void 0);
					if (match.route.lazy || needsToRunLoader) {
						if (dataRouterOpts.isStatic) renderFallback = true;
						if (fallbackIndex >= 0) renderedMatches = renderedMatches.slice(0, fallbackIndex + 1);
						else renderedMatches = [renderedMatches[0]];
						break;
					}
				}
			}
		}
		let onErrorHandler = dataRouterOpts === null || dataRouterOpts === void 0 ? void 0 : dataRouterOpts.onError;
		let onError = dataRouterState && onErrorHandler ? (error, errorInfo) => {
			var _dataRouterState$matc, _dataRouterState$matc2;
			onErrorHandler(error, {
				location: dataRouterState.location,
				params: (_dataRouterState$matc = (_dataRouterState$matc2 = dataRouterState.matches) === null || _dataRouterState$matc2 === void 0 || (_dataRouterState$matc2 = _dataRouterState$matc2[0]) === null || _dataRouterState$matc2 === void 0 ? void 0 : _dataRouterState$matc2.params) !== null && _dataRouterState$matc !== void 0 ? _dataRouterState$matc : {},
				pattern: getRoutePattern(dataRouterState.matches),
				errorInfo
			});
		} : void 0;
		return renderedMatches.reduceRight((outlet, match, index) => {
			let error;
			let shouldRenderHydrateFallback = false;
			let errorElement = null;
			let hydrateFallbackElement = null;
			if (dataRouterState) {
				error = errors && match.route.id ? errors[match.route.id] : void 0;
				errorElement = match.route.errorElement || defaultErrorElement;
				if (renderFallback) {
					if (fallbackIndex < 0 && index === 0) {
						warningOnce("route-fallback", false, "No `HydrateFallback` element provided to render during initial hydration");
						shouldRenderHydrateFallback = true;
						hydrateFallbackElement = null;
					} else if (fallbackIndex === index) {
						shouldRenderHydrateFallback = true;
						hydrateFallbackElement = match.route.hydrateFallbackElement || null;
					}
				}
			}
			let matches2 = parentMatches.concat(renderedMatches.slice(0, index + 1));
			let getChildren = () => {
				let children;
				if (error) children = errorElement;
				else if (shouldRenderHydrateFallback) children = hydrateFallbackElement;
				else if (match.route.Component) children = /* @__PURE__ */ import_react.createElement(match.route.Component, null);
				else if (match.route.element) children = match.route.element;
				else children = outlet;
				return /* @__PURE__ */ import_react.createElement(RenderedRoute, {
					match,
					routeContext: {
						outlet,
						matches: matches2,
						isDataRoute: dataRouterState != null
					},
					children
				});
			};
			return dataRouterState && (match.route.ErrorBoundary || match.route.errorElement || index === 0) ? /* @__PURE__ */ import_react.createElement(RenderErrorBoundary, {
				location: dataRouterState.location,
				revalidation: dataRouterState.revalidation,
				component: errorElement,
				error,
				children: getChildren(),
				routeContext: {
					outlet: null,
					matches: matches2,
					isDataRoute: true
				},
				onError
			}) : getChildren();
		}, null);
	}
	function getDataRouterConsoleError(hookName) {
		return `${hookName} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`;
	}
	function useDataRouterContext(hookName) {
		let ctx = import_react.useContext(DataRouterContext);
		invariant$1(ctx, getDataRouterConsoleError(hookName));
		return ctx;
	}
	function useDataRouterState(hookName) {
		let state = import_react.useContext(DataRouterStateContext);
		invariant$1(state, getDataRouterConsoleError(hookName));
		return state;
	}
	function useRouteContext(hookName) {
		let route = import_react.useContext(RouteContext);
		invariant$1(route, getDataRouterConsoleError(hookName));
		return route;
	}
	function useCurrentRouteId(hookName) {
		let route = useRouteContext(hookName);
		let thisRoute = route.matches[route.matches.length - 1];
		invariant$1(thisRoute.route.id, `${hookName} can only be used on routes that contain a unique "id"`);
		return thisRoute.route.id;
	}
	function useRouteId() {
		return useCurrentRouteId("useRouteId");
	}
	function useNavigation() {
		let state = useDataRouterState("useNavigation");
		return import_react.useMemo(() => {
			let _state$navigation = state.navigation, { matches, historyAction } = _state$navigation;
			return _objectWithoutProperties(_state$navigation, _excluded2$1);
		}, [state.navigation]);
	}
	function useMatches() {
		let { matches, loaderData } = useDataRouterState("useMatches");
		return import_react.useMemo(() => matches.map((m) => convertRouteMatchToUiMatch(m, loaderData)), [matches, loaderData]);
	}
	function useRouteError() {
		var _state$errors;
		let error = import_react.useContext(RouteErrorContext);
		let state = useDataRouterState("useRouteError");
		let routeId = useCurrentRouteId("useRouteError");
		if (error !== void 0) return error;
		return (_state$errors = state.errors) === null || _state$errors === void 0 ? void 0 : _state$errors[routeId];
	}
	function useNavigateStable() {
		let { router } = useDataRouterContext("useNavigate");
		let id = useCurrentRouteId("useNavigate");
		let activeRef = import_react.useRef(false);
		useIsomorphicLayoutEffect$1(() => {
			activeRef.current = true;
		});
		return import_react.useCallback(function() {
			var _ref10 = _asyncToGenerator(function* (to, options = {}) {
				warning$1(activeRef.current, navigateEffectWarning);
				if (!activeRef.current) return;
				if (typeof to === "number") yield router.navigate(to);
				else yield router.navigate(to, _objectSpread2({ fromRouteId: id }, options));
			});
			return function(_x139) {
				return _ref10.apply(this, arguments);
			};
		}(), [router, id]);
	}
	var alreadyWarned = {};
	function warningOnce(key, cond, message) {
		if (!cond && !alreadyWarned[key]) {
			alreadyWarned[key] = true;
			warning$1(false, message);
		}
	}
	import_react.memo(DataRoutes2);
	function DataRoutes2({ routes, manifest, future, state, isStatic, onError }) {
		return useRoutesImpl(routes, void 0, {
			manifest,
			state,
			isStatic,
			onError,
			future
		});
	}
	function Route(props) {
		invariant$1(false, `A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.`);
	}
	function Router({ basename: basenameProp = "/", children = null, location: locationProp, navigationType = "POP", navigator, static: staticProp = false, useTransitions }) {
		invariant$1(!useInRouterContext(), `You cannot render a <Router> inside another <Router>. You should never have more than one in your app.`);
		let basename = basenameProp.replace(/^\/*/, "/");
		let navigationContext = import_react.useMemo(() => ({
			basename,
			navigator,
			static: staticProp,
			useTransitions,
			future: {}
		}), [
			basename,
			navigator,
			staticProp,
			useTransitions
		]);
		if (typeof locationProp === "string") locationProp = parsePath(locationProp);
		let { pathname = "/", search = "", hash = "", state = null, key = "default", mask } = locationProp;
		let locationContext = import_react.useMemo(() => {
			let trailingPathname = stripBasename(pathname, basename);
			if (trailingPathname == null) return null;
			return {
				location: {
					pathname: trailingPathname,
					search,
					hash,
					state,
					key,
					mask
				},
				navigationType
			};
		}, [
			basename,
			pathname,
			search,
			hash,
			state,
			key,
			navigationType,
			mask
		]);
		warning$1(locationContext != null, `<Router basename="${basename}"> is not able to match the URL "${pathname}${search}${hash}" because it does not start with the basename, so the <Router> won't render anything.`);
		if (locationContext == null) return null;
		return /* @__PURE__ */ import_react.createElement(NavigationContext.Provider, { value: navigationContext }, /* @__PURE__ */ import_react.createElement(LocationContext.Provider, {
			children,
			value: locationContext
		}));
	}
	function Routes({ children, location }) {
		return useRoutes(createRoutesFromChildren(children), location);
	}
	import_react.Component;
	function createRoutesFromChildren(children, parentPath = []) {
		let routes = [];
		import_react.Children.forEach(children, (element, index) => {
			if (!import_react.isValidElement(element)) return;
			let treePath = [...parentPath, index];
			if (element.type === import_react.Fragment) {
				routes.push.apply(routes, createRoutesFromChildren(element.props.children, treePath));
				return;
			}
			invariant$1(element.type === Route, `[${typeof element.type === "string" ? element.type : element.type.name}] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>`);
			invariant$1(!element.props.index || !element.props.children, "An index route cannot have child routes.");
			let route = {
				id: element.props.id || treePath.join("-"),
				caseSensitive: element.props.caseSensitive,
				element: element.props.element,
				Component: element.props.Component,
				index: element.props.index,
				path: element.props.path,
				middleware: element.props.middleware,
				loader: element.props.loader,
				action: element.props.action,
				hydrateFallbackElement: element.props.hydrateFallbackElement,
				HydrateFallback: element.props.HydrateFallback,
				errorElement: element.props.errorElement,
				ErrorBoundary: element.props.ErrorBoundary,
				hasErrorBoundary: element.props.hasErrorBoundary === true || element.props.ErrorBoundary != null || element.props.errorElement != null,
				shouldRevalidate: element.props.shouldRevalidate,
				handle: element.props.handle,
				lazy: element.props.lazy
			};
			if (element.props.children) route.children = createRoutesFromChildren(element.props.children, treePath);
			routes.push(route);
		});
		return routes;
	}
	var defaultMethod = "get";
	var defaultEncType = "application/x-www-form-urlencoded";
	function isHtmlElement(object) {
		return typeof HTMLElement !== "undefined" && object instanceof HTMLElement;
	}
	function isButtonElement(object) {
		return isHtmlElement(object) && object.tagName.toLowerCase() === "button";
	}
	function isFormElement(object) {
		return isHtmlElement(object) && object.tagName.toLowerCase() === "form";
	}
	function isInputElement(object) {
		return isHtmlElement(object) && object.tagName.toLowerCase() === "input";
	}
	function isModifiedEvent(event) {
		return !!(event.metaKey || event.altKey || event.ctrlKey || event.shiftKey);
	}
	function shouldProcessLinkClick(event, target) {
		return event.button === 0 && (!target || target === "_self") && !isModifiedEvent(event);
	}
	var _formDataSupportsSubmitter = null;
	function isFormDataSubmitterSupported() {
		if (_formDataSupportsSubmitter === null) try {
			new FormData(document.createElement("form"), 0);
			_formDataSupportsSubmitter = false;
		} catch (e) {
			_formDataSupportsSubmitter = true;
		}
		return _formDataSupportsSubmitter;
	}
	var supportedFormEncTypes = /* @__PURE__ */ new Set([
		"application/x-www-form-urlencoded",
		"multipart/form-data",
		"text/plain"
	]);
	function getFormEncType(encType) {
		if (encType != null && !supportedFormEncTypes.has(encType)) {
			warning$1(false, `"${encType}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${defaultEncType}"`);
			return null;
		}
		return encType;
	}
	function getFormSubmissionInfo(target, basename) {
		let method;
		let action;
		let encType;
		let formData;
		let body;
		if (isFormElement(target)) {
			let attr = target.getAttribute("action");
			action = attr ? stripBasename(attr, basename) : null;
			method = target.getAttribute("method") || defaultMethod;
			encType = getFormEncType(target.getAttribute("enctype")) || defaultEncType;
			formData = new FormData(target);
		} else if (isButtonElement(target) || isInputElement(target) && (target.type === "submit" || target.type === "image")) {
			let form = target.form;
			if (form == null) throw new Error(`Cannot submit a <button> or <input type="submit"> without a <form>`);
			let attr = target.getAttribute("formaction") || form.getAttribute("action");
			action = attr ? stripBasename(attr, basename) : null;
			method = target.getAttribute("formmethod") || form.getAttribute("method") || defaultMethod;
			encType = getFormEncType(target.getAttribute("formenctype")) || getFormEncType(form.getAttribute("enctype")) || defaultEncType;
			formData = new FormData(form, target);
			if (!isFormDataSubmitterSupported()) {
				let { name, type, value } = target;
				if (type === "image") {
					let prefix = name ? `${name}.` : "";
					formData.append(`${prefix}x`, "0");
					formData.append(`${prefix}y`, "0");
				} else if (name) formData.append(name, value);
			}
		} else if (isHtmlElement(target)) throw new Error(`Cannot submit element that is not <form>, <button>, or <input type="submit|image">`);
		else {
			method = defaultMethod;
			action = null;
			encType = defaultEncType;
			body = target;
		}
		if (formData && encType === "text/plain") {
			body = formData;
			formData = void 0;
		}
		return {
			action,
			method: method.toLowerCase(),
			encType,
			formData,
			body
		};
	}
	Object.getOwnPropertyNames(Object.prototype).sort().join("\0");
	var ESCAPE_LOOKUP = {
		"&": "\\u0026",
		">": "\\u003e",
		"<": "\\u003c",
		"\u2028": "\\u2028",
		"\u2029": "\\u2029"
	};
	var ESCAPE_REGEX = /[&><\u2028\u2029]/g;
	function escapeHtml(html) {
		return html.replace(ESCAPE_REGEX, (match) => ESCAPE_LOOKUP[match]);
	}
	function invariant2(value, message) {
		if (value === false || value === null || typeof value === "undefined") throw new Error(message);
	}
	function singleFetchUrl(reqUrl, basename, trailingSlashAware, extension) {
		let url = typeof reqUrl === "string" ? new URL(reqUrl, typeof window === "undefined" ? "server://singlefetch/" : window.location.origin) : reqUrl;
		if (trailingSlashAware) {
			if (url.pathname.endsWith("/")) url.pathname = `${url.pathname}_.${extension}`;
			else url.pathname = `${url.pathname}.${extension}`;
		} else if (url.pathname === "/") url.pathname = `_root.${extension}`;
		else if (basename && stripBasename(url.pathname, basename) === "/") url.pathname = `${removeTrailingSlash(basename)}/_root.${extension}`;
		else url.pathname = `${removeTrailingSlash(url.pathname)}.${extension}`;
		return url;
	}
	function loadRouteModule(_x185, _x186) {
		return _loadRouteModule.apply(this, arguments);
	}
	function _loadRouteModule() {
		_loadRouteModule = _asyncToGenerator(function* (route, routeModulesCache) {
			if (route.id in routeModulesCache) return routeModulesCache[route.id];
			try {
				let routeModule = yield __vitePreload(() => import(
					/* @vite-ignore */
					/* webpackIgnore: true */
					route.module
), void 0);
				routeModulesCache[route.id] = routeModule;
				return routeModule;
			} catch (error) {
				console.error(`Error loading route module \`${route.module}\`, reloading page...`);
				console.error(error);
				if (window.__reactRouterContext && window.__reactRouterContext.isSpaMode && void 0);
				window.location.reload();
				return new Promise(() => {});
			}
		});
		return _loadRouteModule.apply(this, arguments);
	}
	function isPageLinkDescriptor(object) {
		return object != null && typeof object.page === "string";
	}
	function isHtmlLinkDescriptor(object) {
		if (object == null) return false;
		if (object.href == null) return object.rel === "preload" && typeof object.imageSrcSet === "string" && typeof object.imageSizes === "string";
		return typeof object.rel === "string" && typeof object.href === "string";
	}
	function getKeyedPrefetchLinks(_x192, _x193, _x194) {
		return _getKeyedPrefetchLinks.apply(this, arguments);
	}
	function _getKeyedPrefetchLinks() {
		_getKeyedPrefetchLinks = _asyncToGenerator(function* (matches, manifest, routeModules) {
			return dedupeLinkDescriptors((yield Promise.all(matches.map(function() {
				var _ref20 = _asyncToGenerator(function* (match) {
					let route = manifest.routes[match.route.id];
					if (route) {
						let mod = yield loadRouteModule(route, routeModules);
						return mod.links ? mod.links() : [];
					}
					return [];
				});
				return function(_x191) {
					return _ref20.apply(this, arguments);
				};
			}()))).flat(1).filter(isHtmlLinkDescriptor).filter((link) => link.rel === "stylesheet" || link.rel === "preload").map((link) => link.rel === "stylesheet" ? _objectSpread2(_objectSpread2({}, link), {}, {
				rel: "prefetch",
				as: "style"
			}) : _objectSpread2(_objectSpread2({}, link), {}, { rel: "prefetch" })));
		});
		return _getKeyedPrefetchLinks.apply(this, arguments);
	}
	function getNewMatchesForLinks(page, nextMatches, currentMatches, manifest, location, mode) {
		let isNew = (match, index) => {
			if (!currentMatches[index]) return true;
			return match.route.id !== currentMatches[index].route.id;
		};
		let matchPathChanged = (match, index) => {
			var _currentMatches$index;
			return currentMatches[index].pathname !== match.pathname || ((_currentMatches$index = currentMatches[index].route.path) === null || _currentMatches$index === void 0 ? void 0 : _currentMatches$index.endsWith("*")) && currentMatches[index].params["*"] !== match.params["*"];
		};
		if (mode === "assets") return nextMatches.filter((match, index) => isNew(match, index) || matchPathChanged(match, index));
		if (mode === "data") return nextMatches.filter((match, index) => {
			let manifestRoute = manifest.routes[match.route.id];
			if (!manifestRoute || !manifestRoute.hasLoader) return false;
			if (isNew(match, index) || matchPathChanged(match, index)) return true;
			if (match.route.shouldRevalidate) {
				var _currentMatches$;
				let routeChoice = match.route.shouldRevalidate({
					currentUrl: new URL(location.pathname + location.search + location.hash, window.origin),
					currentParams: ((_currentMatches$ = currentMatches[0]) === null || _currentMatches$ === void 0 ? void 0 : _currentMatches$.params) || {},
					nextUrl: new URL(page, window.origin),
					nextParams: match.params,
					defaultShouldRevalidate: true
				});
				if (typeof routeChoice === "boolean") return routeChoice;
			}
			return true;
		});
		return [];
	}
	function getModuleLinkHrefs(matches, manifest, { includeHydrateFallback } = {}) {
		return dedupeHrefs(matches.map((match) => {
			let route = manifest.routes[match.route.id];
			if (!route) return [];
			let hrefs = [route.module];
			if (route.clientActionModule) hrefs = hrefs.concat(route.clientActionModule);
			if (route.clientLoaderModule) hrefs = hrefs.concat(route.clientLoaderModule);
			if (includeHydrateFallback && route.hydrateFallbackModule) hrefs = hrefs.concat(route.hydrateFallbackModule);
			if (route.imports) hrefs = hrefs.concat(route.imports);
			return hrefs;
		}).flat(1));
	}
	function dedupeHrefs(hrefs) {
		return [...new Set(hrefs)];
	}
	function sortKeys(obj) {
		let sorted = {};
		let keys = Object.keys(obj).sort();
		for (let key of keys) sorted[key] = obj[key];
		return sorted;
	}
	function dedupeLinkDescriptors(descriptors, preloads) {
		let set = /* @__PURE__ */ new Set();
		let preloadsSet = new Set(preloads);
		return descriptors.reduce((deduped, descriptor) => {
			if (preloads && !isPageLinkDescriptor(descriptor) && descriptor.as === "script" && descriptor.href && preloadsSet.has(descriptor.href)) return deduped;
			let key = JSON.stringify(sortKeys(descriptor));
			if (!set.has(key)) {
				set.add(key);
				deduped.push({
					key,
					link: descriptor
				});
			}
			return deduped;
		}, []);
	}
	function useDataRouterContext2() {
		let context = import_react.useContext(DataRouterContext);
		invariant2(context, "You must render this element inside a <DataRouterContext.Provider> element");
		return context;
	}
	function useDataRouterStateContext() {
		let context = import_react.useContext(DataRouterStateContext);
		invariant2(context, "You must render this element inside a <DataRouterStateContext.Provider> element");
		return context;
	}
	var FrameworkContext = import_react.createContext(void 0);
	FrameworkContext.displayName = "FrameworkContext";
	function useFrameworkContext() {
		let context = import_react.useContext(FrameworkContext);
		invariant2(context, "You must render this element inside a <HydratedRouter> element");
		return context;
	}
	function usePrefetchBehavior(prefetch, theirElementProps) {
		let frameworkContext = import_react.useContext(FrameworkContext);
		let [maybePrefetch, setMaybePrefetch] = import_react.useState(false);
		let [shouldPrefetch, setShouldPrefetch] = import_react.useState(false);
		let { onFocus, onBlur, onMouseEnter, onMouseLeave, onTouchStart } = theirElementProps;
		let ref = import_react.useRef(null);
		import_react.useEffect(() => {
			if (prefetch === "render") setShouldPrefetch(true);
			if (prefetch === "viewport") {
				let callback = (entries) => {
					entries.forEach((entry) => {
						setShouldPrefetch(entry.isIntersecting);
					});
				};
				let observer = new IntersectionObserver(callback, { threshold: .5 });
				if (ref.current) observer.observe(ref.current);
				return () => {
					observer.disconnect();
				};
			}
		}, [prefetch]);
		import_react.useEffect(() => {
			if (maybePrefetch) {
				let id = setTimeout(() => {
					setShouldPrefetch(true);
				}, 100);
				return () => {
					clearTimeout(id);
				};
			}
		}, [maybePrefetch]);
		let setIntent = () => {
			setMaybePrefetch(true);
		};
		let cancelIntent = () => {
			setMaybePrefetch(false);
			setShouldPrefetch(false);
		};
		if (!frameworkContext) return [
			false,
			ref,
			{}
		];
		if (prefetch !== "intent") return [
			shouldPrefetch,
			ref,
			{}
		];
		return [
			shouldPrefetch,
			ref,
			{
				onFocus: composeEventHandlers(onFocus, setIntent),
				onBlur: composeEventHandlers(onBlur, cancelIntent),
				onMouseEnter: composeEventHandlers(onMouseEnter, setIntent),
				onMouseLeave: composeEventHandlers(onMouseLeave, cancelIntent),
				onTouchStart: composeEventHandlers(onTouchStart, setIntent)
			}
		];
	}
	function composeEventHandlers(theirHandler, ourHandler) {
		return (event) => {
			theirHandler && theirHandler(event);
			if (!event.defaultPrevented) ourHandler(event);
		};
	}
	function PrefetchPageLinks(_ref27) {
		let { page } = _ref27, linkProps = _objectWithoutProperties(_ref27, _excluded4);
		let rsc = useIsRSCRouterContext();
		let { nonce: contextNonce } = useFrameworkContext();
		let { router } = useDataRouterContext2();
		let matches = import_react.useMemo(() => matchRoutes(router.routes, page, router.basename), [
			router.routes,
			page,
			router.basename
		]);
		if (!matches) return null;
		if (linkProps.nonce == null && contextNonce) linkProps = _objectSpread2(_objectSpread2({}, linkProps), {}, { nonce: contextNonce });
		if (rsc) return /* @__PURE__ */ import_react.createElement(RSCPrefetchPageLinksImpl, _objectSpread2({
			page,
			matches
		}, linkProps));
		return /* @__PURE__ */ import_react.createElement(PrefetchPageLinksImpl, _objectSpread2({
			page,
			matches
		}, linkProps));
	}
	function useKeyedPrefetchLinks(matches) {
		let { manifest, routeModules } = useFrameworkContext();
		let [keyedPrefetchLinks, setKeyedPrefetchLinks] = import_react.useState([]);
		import_react.useEffect(() => {
			let interrupted = false;
			getKeyedPrefetchLinks(matches, manifest, routeModules).then((links) => {
				if (!interrupted) setKeyedPrefetchLinks(links);
			});
			return () => {
				interrupted = true;
			};
		}, [
			matches,
			manifest,
			routeModules
		]);
		return keyedPrefetchLinks;
	}
	function RSCPrefetchPageLinksImpl(_ref28) {
		let { page, matches: nextMatches } = _ref28, linkProps = _objectWithoutProperties(_ref28, _excluded5);
		let location = useLocation();
		let { future } = useFrameworkContext();
		let { basename } = useDataRouterContext2();
		let dataHrefs = import_react.useMemo(() => {
			if (page === location.pathname + location.search + location.hash) return [];
			let url = singleFetchUrl(page, basename, future.v8_trailingSlashAwareDataRequests, "rsc");
			let hasSomeRoutesWithShouldRevalidate = false;
			let targetRoutes = [];
			for (let match of nextMatches) if (typeof match.route.shouldRevalidate === "function") hasSomeRoutesWithShouldRevalidate = true;
			else targetRoutes.push(match.route.id);
			if (hasSomeRoutesWithShouldRevalidate && targetRoutes.length > 0) url.searchParams.set("_routes", targetRoutes.join(","));
			return [url.pathname + url.search];
		}, [
			basename,
			future.v8_trailingSlashAwareDataRequests,
			page,
			location,
			nextMatches
		]);
		return /* @__PURE__ */ import_react.createElement(import_react.Fragment, null, dataHrefs.map((href) => /* @__PURE__ */ import_react.createElement("link", _objectSpread2({
			key: href,
			rel: "prefetch",
			as: "fetch",
			href
		}, linkProps))));
	}
	function PrefetchPageLinksImpl(_ref29) {
		let { page, matches: nextMatches } = _ref29, linkProps = _objectWithoutProperties(_ref29, _excluded6);
		let location = useLocation();
		let { future, manifest, routeModules } = useFrameworkContext();
		let { basename } = useDataRouterContext2();
		let { loaderData, matches } = useDataRouterStateContext();
		let newMatchesForData = import_react.useMemo(() => getNewMatchesForLinks(page, nextMatches, matches, manifest, location, "data"), [
			page,
			nextMatches,
			matches,
			manifest,
			location
		]);
		let newMatchesForAssets = import_react.useMemo(() => getNewMatchesForLinks(page, nextMatches, matches, manifest, location, "assets"), [
			page,
			nextMatches,
			matches,
			manifest,
			location
		]);
		let dataHrefs = import_react.useMemo(() => {
			if (page === location.pathname + location.search + location.hash) return [];
			let routesParams = /* @__PURE__ */ new Set();
			let foundOptOutRoute = false;
			nextMatches.forEach((m) => {
				var _routeModules$m$route;
				let manifestRoute = manifest.routes[m.route.id];
				if (!manifestRoute || !manifestRoute.hasLoader) return;
				if (!newMatchesForData.some((m2) => m2.route.id === m.route.id) && m.route.id in loaderData && ((_routeModules$m$route = routeModules[m.route.id]) === null || _routeModules$m$route === void 0 ? void 0 : _routeModules$m$route.shouldRevalidate)) foundOptOutRoute = true;
				else if (manifestRoute.hasClientLoader) foundOptOutRoute = true;
				else routesParams.add(m.route.id);
			});
			if (routesParams.size === 0) return [];
			let url = singleFetchUrl(page, basename, future.v8_trailingSlashAwareDataRequests, "data");
			if (foundOptOutRoute && routesParams.size > 0) url.searchParams.set("_routes", nextMatches.filter((m) => routesParams.has(m.route.id)).map((m) => m.route.id).join(","));
			return [url.pathname + url.search];
		}, [
			basename,
			future.v8_trailingSlashAwareDataRequests,
			loaderData,
			location,
			manifest,
			newMatchesForData,
			nextMatches,
			page,
			routeModules
		]);
		let moduleHrefs = import_react.useMemo(() => getModuleLinkHrefs(newMatchesForAssets, manifest), [newMatchesForAssets, manifest]);
		let keyedPrefetchLinks = useKeyedPrefetchLinks(newMatchesForAssets);
		return /* @__PURE__ */ import_react.createElement(import_react.Fragment, null, dataHrefs.map((href) => /* @__PURE__ */ import_react.createElement("link", _objectSpread2({
			key: href,
			rel: "prefetch",
			as: "fetch",
			href
		}, linkProps))), moduleHrefs.map((href) => /* @__PURE__ */ import_react.createElement("link", _objectSpread2({
			key: href,
			rel: "modulepreload",
			href
		}, linkProps))), keyedPrefetchLinks.map(({ key, link }) => {
			var _link$crossOrigin3;
			return /* @__PURE__ */ import_react.createElement("link", _objectSpread2(_objectSpread2({
				key,
				nonce: linkProps.nonce
			}, link), {}, { crossOrigin: (_link$crossOrigin3 = link.crossOrigin) !== null && _link$crossOrigin3 !== void 0 ? _link$crossOrigin3 : linkProps.crossOrigin }));
		}));
	}
	function mergeRefs(...refs) {
		return (value) => {
			refs.forEach((ref) => {
				if (typeof ref === "function") ref(value);
				else if (ref != null) ref.current = value;
			});
		};
	}
	import_react.Component;
	var isBrowser2 = typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined";
	try {
		if (isBrowser2) window.__reactRouterVersion = "7.18.2";
	} catch (e) {}
	function HashRouter({ basename, children, useTransitions, window: window2 }) {
		let historyRef = import_react.useRef();
		if (historyRef.current == null) historyRef.current = createHashHistory({
			window: window2,
			v5Compat: true
		});
		let history = historyRef.current;
		let [state, setStateImpl] = import_react.useState({
			action: history.action,
			location: history.location
		});
		let setState = import_react.useCallback((newState) => {
			if (useTransitions === false) setStateImpl(newState);
			else import_react.startTransition(() => setStateImpl(newState));
		}, [useTransitions]);
		import_react.useLayoutEffect(() => history.listen(setState), [history, setState]);
		return /* @__PURE__ */ import_react.createElement(Router, {
			basename,
			children,
			location: state.location,
			navigationType: state.action,
			navigator: history,
			useTransitions
		});
	}
	function HistoryRouter({ basename, children, history, useTransitions }) {
		let [state, setStateImpl] = import_react.useState({
			action: history.action,
			location: history.location
		});
		let setState = import_react.useCallback((newState) => {
			if (useTransitions === false) setStateImpl(newState);
			else import_react.startTransition(() => setStateImpl(newState));
		}, [useTransitions]);
		import_react.useLayoutEffect(() => history.listen(setState), [history, setState]);
		return /* @__PURE__ */ import_react.createElement(Router, {
			basename,
			children,
			location: state.location,
			navigationType: state.action,
			navigator: history,
			useTransitions
		});
	}
	HistoryRouter.displayName = "unstable_HistoryRouter";
	var Link$2 = import_react.forwardRef(function LinkWithRef(_ref30, forwardedRef) {
		let { onClick, discover = "render", prefetch = "none", relative, reloadDocument, replace: replace2, mask, state, target, to, preventScrollReset, viewTransition, defaultShouldRevalidate } = _ref30, rest = _objectWithoutProperties(_ref30, _excluded8);
		let { basename, navigator, useTransitions } = import_react.useContext(NavigationContext);
		let isAbsolute = typeof to === "string" && ABSOLUTE_URL_REGEX.test(to);
		let parsed = parseToInfo(to, basename);
		to = parsed.to;
		let href = useHref(to, { relative });
		let location = useLocation();
		let maskedHref = null;
		if (mask) {
			let resolved = resolveTo(mask, [], location.mask ? location.mask.pathname : "/", true);
			if (basename !== "/") resolved.pathname = resolved.pathname === "/" ? basename : joinPaths([basename, resolved.pathname]);
			maskedHref = navigator.createHref(resolved);
		}
		let [shouldPrefetch, prefetchRef, prefetchHandlers] = usePrefetchBehavior(prefetch, rest);
		let internalOnClick = useLinkClickHandler(to, {
			replace: replace2,
			mask,
			state,
			target,
			preventScrollReset,
			relative,
			viewTransition,
			defaultShouldRevalidate,
			useTransitions
		});
		function handleClick(event) {
			if (onClick) onClick(event);
			if (!event.defaultPrevented) internalOnClick(event);
		}
		let isSpaLink = !(parsed.isExternal || reloadDocument);
		let link = /* @__PURE__ */ import_react.createElement("a", _objectSpread2(_objectSpread2(_objectSpread2({}, rest), prefetchHandlers), {}, {
			href: (isSpaLink ? maskedHref : void 0) || parsed.absoluteURL || href,
			onClick: isSpaLink ? handleClick : onClick,
			ref: mergeRefs(forwardedRef, prefetchRef),
			target,
			"data-discover": !isAbsolute && discover === "render" ? "true" : void 0
		}));
		return shouldPrefetch && !isAbsolute ? /* @__PURE__ */ import_react.createElement(import_react.Fragment, null, link, /* @__PURE__ */ import_react.createElement(PrefetchPageLinks, { page: href })) : link;
	});
	Link$2.displayName = "Link";
	var NavLink = import_react.forwardRef(function NavLinkWithRef(_ref31, ref) {
		let { "aria-current": ariaCurrentProp = "page", caseSensitive = false, className: classNameProp = "", end = false, style: styleProp, to, viewTransition, children } = _ref31, rest = _objectWithoutProperties(_ref31, _excluded9);
		let path = useResolvedPath(to, { relative: rest.relative });
		let location = useLocation();
		let routerState = import_react.useContext(DataRouterStateContext);
		let { navigator, basename } = import_react.useContext(NavigationContext);
		let isTransitioning = routerState != null && useViewTransitionState(path) && viewTransition === true;
		let toPathname = navigator.encodeLocation ? navigator.encodeLocation(path).pathname : path.pathname;
		let locationPathname = location.pathname;
		let nextLocationPathname = routerState && routerState.navigation && routerState.navigation.location ? routerState.navigation.location.pathname : null;
		if (!caseSensitive) {
			locationPathname = locationPathname.toLowerCase();
			nextLocationPathname = nextLocationPathname ? nextLocationPathname.toLowerCase() : null;
			toPathname = toPathname.toLowerCase();
		}
		if (nextLocationPathname && basename) nextLocationPathname = stripBasename(nextLocationPathname, basename) || nextLocationPathname;
		const endSlashPosition = toPathname !== "/" && toPathname.endsWith("/") ? toPathname.length - 1 : toPathname.length;
		let isActive = locationPathname === toPathname || !end && locationPathname.startsWith(toPathname) && locationPathname.charAt(endSlashPosition) === "/";
		let isPending = nextLocationPathname != null && (nextLocationPathname === toPathname || !end && nextLocationPathname.startsWith(toPathname) && nextLocationPathname.charAt(toPathname.length) === "/");
		let renderProps = {
			isActive,
			isPending,
			isTransitioning
		};
		let ariaCurrent = isActive ? ariaCurrentProp : void 0;
		let className;
		if (typeof classNameProp === "function") className = classNameProp(renderProps);
		else className = [
			classNameProp,
			isActive ? "active" : null,
			isPending ? "pending" : null,
			isTransitioning ? "transitioning" : null
		].filter(Boolean).join(" ");
		let style = typeof styleProp === "function" ? styleProp(renderProps) : styleProp;
		return /* @__PURE__ */ import_react.createElement(Link$2, _objectSpread2(_objectSpread2({}, rest), {}, {
			"aria-current": ariaCurrent,
			className,
			ref,
			style,
			to,
			viewTransition
		}), typeof children === "function" ? children(renderProps) : children);
	});
	NavLink.displayName = "NavLink";
	var Form = import_react.forwardRef((_ref32, forwardedRef) => {
		let { discover = "render", fetcherKey, navigate, reloadDocument, replace: replace2, state, method = defaultMethod, action, onSubmit, relative, preventScrollReset, viewTransition, defaultShouldRevalidate } = _ref32, props = _objectWithoutProperties(_ref32, _excluded10);
		let { useTransitions } = import_react.useContext(NavigationContext);
		let submit = useSubmit();
		let formAction = useFormAction(action, { relative });
		let formMethod = method.toLowerCase() === "get" ? "get" : "post";
		let isAbsolute = typeof action === "string" && ABSOLUTE_URL_REGEX.test(action);
		let submitHandler = (event) => {
			onSubmit && onSubmit(event);
			if (event.defaultPrevented) return;
			event.preventDefault();
			let submitter = event.nativeEvent.submitter;
			let submitMethod = (submitter === null || submitter === void 0 ? void 0 : submitter.getAttribute("formmethod")) || method;
			let doSubmit = () => submit(submitter || event.currentTarget, {
				fetcherKey,
				method: submitMethod,
				navigate,
				replace: replace2,
				state,
				relative,
				preventScrollReset,
				viewTransition,
				defaultShouldRevalidate
			});
			if (useTransitions && navigate !== false) import_react.startTransition(() => doSubmit());
			else doSubmit();
		};
		return /* @__PURE__ */ import_react.createElement("form", _objectSpread2(_objectSpread2({
			ref: forwardedRef,
			method: formMethod,
			action: formAction,
			onSubmit: reloadDocument ? onSubmit : submitHandler
		}, props), {}, { "data-discover": !isAbsolute && discover === "render" ? "true" : void 0 }));
	});
	Form.displayName = "Form";
	function ScrollRestoration(_ref33) {
		let { getKey, storageKey } = _ref33, props = _objectWithoutProperties(_ref33, _excluded11);
		let remixContext = import_react.useContext(FrameworkContext);
		let { basename } = import_react.useContext(NavigationContext);
		let location = useLocation();
		let matches = useMatches();
		useScrollRestoration({
			getKey,
			storageKey
		});
		let ssrKey = import_react.useMemo(() => {
			if (!remixContext || !getKey) return null;
			let userKey = getScrollRestorationKey(location, matches, basename, getKey);
			return userKey !== location.key ? userKey : null;
		}, []);
		if (!remixContext || remixContext.isSpaMode) return null;
		let restoreScroll = ((storageKey2, restoreKey) => {
			if (!window.history.state || !window.history.state.key) {
				let key = Math.random().toString(32).slice(2);
				window.history.replaceState({ key }, "");
			}
			try {
				let storedY = JSON.parse(sessionStorage.getItem(storageKey2) || "{}")[restoreKey || window.history.state.key];
				if (typeof storedY === "number") window.scrollTo(0, storedY);
			} catch (error) {
				console.error(error);
				sessionStorage.removeItem(storageKey2);
			}
		}).toString();
		if (props.nonce == null && (remixContext === null || remixContext === void 0 ? void 0 : remixContext.nonce)) props.nonce = remixContext.nonce;
		return /* @__PURE__ */ import_react.createElement("script", _objectSpread2(_objectSpread2({}, props), {}, {
			suppressHydrationWarning: true,
			dangerouslySetInnerHTML: { __html: `(${restoreScroll})(${escapeHtml(JSON.stringify(storageKey || SCROLL_RESTORATION_STORAGE_KEY))}, ${escapeHtml(JSON.stringify(ssrKey))})` }
		}));
	}
	ScrollRestoration.displayName = "ScrollRestoration";
	function getDataRouterConsoleError2(hookName) {
		return `${hookName} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`;
	}
	function useDataRouterContext3(hookName) {
		let ctx = import_react.useContext(DataRouterContext);
		invariant$1(ctx, getDataRouterConsoleError2(hookName));
		return ctx;
	}
	function useDataRouterState2(hookName) {
		let state = import_react.useContext(DataRouterStateContext);
		invariant$1(state, getDataRouterConsoleError2(hookName));
		return state;
	}
	function useLinkClickHandler(to, { target, replace: replaceProp, mask, state, preventScrollReset, relative, viewTransition, defaultShouldRevalidate, useTransitions } = {}) {
		let navigate = useNavigate();
		let location = useLocation();
		let path = useResolvedPath(to, { relative });
		return import_react.useCallback((event) => {
			if (shouldProcessLinkClick(event, target)) {
				event.preventDefault();
				let replace2 = replaceProp !== void 0 ? replaceProp : createPath(location) === createPath(path);
				let doNavigate = () => navigate(to, {
					replace: replace2,
					mask,
					state,
					preventScrollReset,
					relative,
					viewTransition,
					defaultShouldRevalidate
				});
				if (useTransitions) import_react.startTransition(() => doNavigate());
				else doNavigate();
			}
		}, [
			location,
			navigate,
			path,
			replaceProp,
			mask,
			state,
			target,
			to,
			preventScrollReset,
			relative,
			viewTransition,
			defaultShouldRevalidate,
			useTransitions
		]);
	}
	var fetcherId = 0;
	var getUniqueFetcherId = () => `__${String(++fetcherId)}__`;
	function useSubmit() {
		let { router } = useDataRouterContext3("useSubmit");
		let { basename } = import_react.useContext(NavigationContext);
		let currentRouteId = useRouteId();
		let routerFetch = router.fetch;
		let routerNavigate = router.navigate;
		return import_react.useCallback(function() {
			var _ref34 = _asyncToGenerator(function* (target, options = {}) {
				let { action, method, encType, formData, body } = getFormSubmissionInfo(target, basename);
				if (options.navigate === false) {
					let key = options.fetcherKey || getUniqueFetcherId();
					yield routerFetch(key, currentRouteId, options.action || action, {
						defaultShouldRevalidate: options.defaultShouldRevalidate,
						preventScrollReset: options.preventScrollReset,
						formData,
						body,
						formMethod: options.method || method,
						formEncType: options.encType || encType,
						flushSync: options.flushSync
					});
				} else yield routerNavigate(options.action || action, {
					defaultShouldRevalidate: options.defaultShouldRevalidate,
					preventScrollReset: options.preventScrollReset,
					formData,
					body,
					formMethod: options.method || method,
					formEncType: options.encType || encType,
					replace: options.replace,
					state: options.state,
					fromRouteId: currentRouteId,
					flushSync: options.flushSync,
					viewTransition: options.viewTransition
				});
			});
			return function(_x211) {
				return _ref34.apply(this, arguments);
			};
		}(), [
			routerFetch,
			routerNavigate,
			basename,
			currentRouteId
		]);
	}
	function useFormAction(action, { relative } = {}) {
		let { basename } = import_react.useContext(NavigationContext);
		let routeContext = import_react.useContext(RouteContext);
		invariant$1(routeContext, "useFormAction must be used inside a RouteContext");
		let [match] = routeContext.matches.slice(-1);
		let path = _objectSpread2({}, useResolvedPath(action ? action : ".", { relative }));
		let location = useLocation();
		if (action == null) {
			path.search = location.search;
			let params = new URLSearchParams(path.search);
			let indexValues = params.getAll("index");
			if (indexValues.some((v) => v === "")) {
				params.delete("index");
				indexValues.filter((v) => v).forEach((v) => params.append("index", v));
				let qs = params.toString();
				path.search = qs ? `?${qs}` : "";
			}
		}
		if ((!action || action === ".") && match.route.index) path.search = path.search ? path.search.replace(/^\?/, "?index&") : "?index";
		if (basename !== "/") path.pathname = path.pathname === "/" ? basename : joinPaths([basename, path.pathname]);
		return createPath(path);
	}
	var SCROLL_RESTORATION_STORAGE_KEY = "react-router-scroll-positions";
	var savedScrollPositions = {};
	function getScrollRestorationKey(location, matches, basename, getKey) {
		let key = null;
		if (getKey) {
			if (basename !== "/") key = getKey(_objectSpread2(_objectSpread2({}, location), {}, { pathname: stripBasename(location.pathname, basename) || location.pathname }), matches);
			else key = getKey(location, matches);
		}
		if (key == null) key = location.key;
		return key;
	}
	function useScrollRestoration({ getKey, storageKey } = {}) {
		let { router } = useDataRouterContext3("useScrollRestoration");
		let { restoreScrollPosition, preventScrollReset } = useDataRouterState2("useScrollRestoration");
		let { basename } = import_react.useContext(NavigationContext);
		let location = useLocation();
		let matches = useMatches();
		let navigation = useNavigation();
		import_react.useEffect(() => {
			window.history.scrollRestoration = "manual";
			return () => {
				window.history.scrollRestoration = "auto";
			};
		}, []);
		usePageHide(import_react.useCallback(() => {
			if (navigation.state === "idle") {
				let key = getScrollRestorationKey(location, matches, basename, getKey);
				savedScrollPositions[key] = window.scrollY;
			}
			try {
				sessionStorage.setItem(storageKey || SCROLL_RESTORATION_STORAGE_KEY, JSON.stringify(savedScrollPositions));
			} catch (error) {
				warning$1(false, `Failed to save scroll positions in sessionStorage, <ScrollRestoration /> will not work properly (${error}).`);
			}
			window.history.scrollRestoration = "auto";
		}, [
			navigation.state,
			getKey,
			basename,
			location,
			matches,
			storageKey
		]));
		if (typeof document !== "undefined") {
			import_react.useLayoutEffect(() => {
				try {
					let sessionPositions = sessionStorage.getItem(storageKey || SCROLL_RESTORATION_STORAGE_KEY);
					if (sessionPositions) savedScrollPositions = JSON.parse(sessionPositions);
				} catch (e) {}
			}, [storageKey]);
			import_react.useLayoutEffect(() => {
				let disableScrollRestoration = router === null || router === void 0 ? void 0 : router.enableScrollRestoration(savedScrollPositions, () => window.scrollY, getKey ? (location2, matches2) => getScrollRestorationKey(location2, matches2, basename, getKey) : void 0);
				return () => disableScrollRestoration && disableScrollRestoration();
			}, [
				router,
				basename,
				getKey
			]);
			import_react.useLayoutEffect(() => {
				if (restoreScrollPosition === false) return;
				if (typeof restoreScrollPosition === "number") {
					window.scrollTo(0, restoreScrollPosition);
					return;
				}
				try {
					if (location.hash) {
						let el = document.getElementById(decodeURIComponent(location.hash.slice(1)));
						if (el) {
							el.scrollIntoView();
							return;
						}
					}
				} catch (_unused6) {
					warning$1(false, `"${location.hash.slice(1)}" is not a decodable element ID. The view will not scroll to it.`);
				}
				if (preventScrollReset === true) return;
				window.scrollTo(0, 0);
			}, [
				location,
				restoreScrollPosition,
				preventScrollReset
			]);
		}
	}
	function usePageHide(callback, options) {
		let { capture } = options || {};
		import_react.useEffect(() => {
			let opts = capture != null ? { capture } : void 0;
			window.addEventListener("pagehide", callback, opts);
			return () => {
				window.removeEventListener("pagehide", callback, opts);
			};
		}, [callback, capture]);
	}
	function useViewTransitionState(to, { relative } = {}) {
		let vtContext = import_react.useContext(ViewTransitionContext);
		invariant$1(vtContext != null, "`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?");
		let { basename } = useDataRouterContext3("useViewTransitionState");
		let path = useResolvedPath(to, { relative });
		if (!vtContext.isTransitioning) return false;
		let currentPath = stripBasename(vtContext.currentLocation.pathname, basename) || vtContext.currentLocation.pathname;
		let nextPath = stripBasename(vtContext.nextLocation.pathname, basename) || vtContext.nextLocation.pathname;
		return matchPath(path.pathname, nextPath) != null || matchPath(path.pathname, currentPath) != null;
	}
	//#endregion
	//#region node_modules/@tanstack/query-core/build/modern/subscribable.js
	var Subscribable = class {
		constructor() {
			this.listeners = /* @__PURE__ */ new Set();
			this.subscribe = this.subscribe.bind(this);
		}
		subscribe(listener) {
			this.listeners.add(listener);
			this.onSubscribe();
			return () => {
				this.listeners.delete(listener);
				this.onUnsubscribe();
			};
		}
		hasListeners() {
			return this.listeners.size > 0;
		}
		onSubscribe() {}
		onUnsubscribe() {}
	};
	//#endregion
	//#region \0@oxc-project+runtime@0.146.0/helpers/esm/checkPrivateRedeclaration.js
	function _checkPrivateRedeclaration(e, t) {
		if (t.has(e)) throw new TypeError("Cannot initialize the same private elements twice on an object");
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.146.0/helpers/esm/classPrivateFieldInitSpec.js
	function _classPrivateFieldInitSpec(e, t, a) {
		_checkPrivateRedeclaration(e, t), t.set(e, a);
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.146.0/helpers/esm/assertClassBrand.js
	function _assertClassBrand(e, t, n) {
		if ("function" == typeof e ? e === t : e.has(t)) return arguments.length < 3 ? t : n;
		throw new TypeError("Private element is not present on this object");
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.146.0/helpers/esm/classPrivateFieldSet2.js
	function _classPrivateFieldSet2(s, a, r) {
		return s.set(_assertClassBrand(s, a), r), r;
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.146.0/helpers/esm/classPrivateFieldGet2.js
	function _classPrivateFieldGet2(s, a) {
		return s.get(_assertClassBrand(s, a));
	}
	//#endregion
	//#region node_modules/@tanstack/query-core/build/modern/focusManager.js
	var _focused;
	var _cleanup$1;
	var _setup$1;
	var focusManager = new (_focused = /* @__PURE__ */ new WeakMap(), _cleanup$1 = /* @__PURE__ */ new WeakMap(), _setup$1 = /* @__PURE__ */ new WeakMap(), class extends Subscribable {
		constructor() {
			super();
			_classPrivateFieldInitSpec(this, _focused, void 0);
			_classPrivateFieldInitSpec(this, _cleanup$1, void 0);
			_classPrivateFieldInitSpec(this, _setup$1, void 0);
			_classPrivateFieldSet2(_setup$1, this, (onFocus) => {
				if (typeof window !== "undefined" && window.addEventListener) {
					const listener = () => onFocus();
					window.addEventListener("visibilitychange", listener, false);
					return () => {
						window.removeEventListener("visibilitychange", listener);
					};
				}
			});
		}
		onSubscribe() {
			if (!_classPrivateFieldGet2(_cleanup$1, this)) this.setEventListener(_classPrivateFieldGet2(_setup$1, this));
		}
		onUnsubscribe() {
			if (!this.hasListeners()) {
				var _classPrivateFieldGet2$8;
				(_classPrivateFieldGet2$8 = _classPrivateFieldGet2(_cleanup$1, this)) === null || _classPrivateFieldGet2$8 === void 0 || _classPrivateFieldGet2$8.call(this);
				_classPrivateFieldSet2(_cleanup$1, this, void 0);
			}
		}
		setEventListener(setup) {
			var _classPrivateFieldGet3;
			_classPrivateFieldSet2(_setup$1, this, setup);
			(_classPrivateFieldGet3 = _classPrivateFieldGet2(_cleanup$1, this)) === null || _classPrivateFieldGet3 === void 0 || _classPrivateFieldGet3.call(this);
			_classPrivateFieldSet2(_cleanup$1, this, setup((focused) => {
				if (typeof focused === "boolean") this.setFocused(focused);
				else this.onFocus();
			}));
		}
		setFocused(focused) {
			if (_classPrivateFieldGet2(_focused, this) !== focused) {
				_classPrivateFieldSet2(_focused, this, focused);
				this.onFocus();
			}
		}
		onFocus() {
			const isFocused = this.isFocused();
			this.listeners.forEach((listener) => {
				listener(isFocused);
			});
		}
		isFocused() {
			var _globalThis$document;
			if (typeof _classPrivateFieldGet2(_focused, this) === "boolean") return _classPrivateFieldGet2(_focused, this);
			return ((_globalThis$document = globalThis.document) === null || _globalThis$document === void 0 ? void 0 : _globalThis$document.visibilityState) !== "hidden";
		}
	})();
	//#endregion
	//#region node_modules/@tanstack/query-core/build/modern/timeoutManager.js
	var _provider;
	var _providerCalled;
	var defaultTimeoutProvider = {
		setTimeout: (callback, delay) => setTimeout(callback, delay),
		clearTimeout: (timeoutId) => clearTimeout(timeoutId),
		setInterval: (callback, delay) => setInterval(callback, delay),
		clearInterval: (intervalId) => clearInterval(intervalId)
	};
	var timeoutManager = new (_provider = /* @__PURE__ */ new WeakMap(), _providerCalled = /* @__PURE__ */ new WeakMap(), class {
		constructor() {
			_classPrivateFieldInitSpec(this, _provider, defaultTimeoutProvider);
			_classPrivateFieldInitSpec(this, _providerCalled, false);
		}
		setTimeoutProvider(provider) {
			_classPrivateFieldSet2(_provider, this, provider);
		}
		setTimeout(callback, delay) {
			return _classPrivateFieldGet2(_provider, this).setTimeout(callback, delay);
		}
		clearTimeout(timeoutId) {
			_classPrivateFieldGet2(_provider, this).clearTimeout(timeoutId);
		}
		setInterval(callback, delay) {
			return _classPrivateFieldGet2(_provider, this).setInterval(callback, delay);
		}
		clearInterval(intervalId) {
			_classPrivateFieldGet2(_provider, this).clearInterval(intervalId);
		}
	})();
	function systemSetTimeoutZero(callback) {
		setTimeout(callback, 0);
	}
	//#endregion
	//#region node_modules/@tanstack/query-core/build/modern/utils.js
	var isServer = typeof window === "undefined" || "Deno" in globalThis;
	function noop$1() {}
	function functionalUpdate(updater, input) {
		return typeof updater === "function" ? updater(input) : updater;
	}
	function isValidTimeout(value) {
		return typeof value === "number" && value >= 0 && value !== Infinity;
	}
	function timeUntilStale(updatedAt, staleTime) {
		return Math.max(updatedAt + (staleTime || 0) - Date.now(), 0);
	}
	function resolveStaleTime(staleTime, query) {
		return typeof staleTime === "function" ? staleTime(query) : staleTime;
	}
	function resolveQueryBoolean(option, query) {
		return typeof option === "function" ? option(query) : option;
	}
	function matchQuery(filters, query) {
		const { type = "all", exact, fetchStatus, predicate, queryKey, stale } = filters;
		if (queryKey) {
			if (exact) {
				if (query.queryHash !== hashQueryKeyByOptions(queryKey, query.options)) return false;
			} else if (!partialMatchKey(query.queryKey, queryKey)) return false;
		}
		if (type !== "all") {
			const isActive = query.isActive();
			if (type === "active" && !isActive) return false;
			if (type === "inactive" && isActive) return false;
		}
		if (typeof stale === "boolean" && query.isStale() !== stale) return false;
		if (fetchStatus && fetchStatus !== query.state.fetchStatus) return false;
		if (predicate && !predicate(query)) return false;
		return true;
	}
	function matchMutation(filters, mutation) {
		const { exact, status, predicate, mutationKey } = filters;
		if (mutationKey) {
			if (!mutation.options.mutationKey) return false;
			if (exact) {
				if (hashKey(mutation.options.mutationKey) !== hashKey(mutationKey)) return false;
			} else if (!partialMatchKey(mutation.options.mutationKey, mutationKey)) return false;
		}
		if (status && mutation.state.status !== status) return false;
		if (predicate && !predicate(mutation)) return false;
		return true;
	}
	function hashQueryKeyByOptions(queryKey, options) {
		return ((options === null || options === void 0 ? void 0 : options.queryKeyHashFn) || hashKey)(queryKey);
	}
	function hashKey(queryKey) {
		return JSON.stringify(queryKey, (_, val) => isPlainObject(val) ? Object.keys(val).sort().reduce((result, key) => {
			result[key] = val[key];
			return result;
		}, {}) : val);
	}
	function partialMatchKey(a, b) {
		if (a === b) return true;
		if (typeof a !== typeof b) return false;
		if (a && b && typeof a === "object" && typeof b === "object") return Object.keys(b).every((key) => partialMatchKey(a[key], b[key]));
		return false;
	}
	var hasOwn = Object.prototype.hasOwnProperty;
	function replaceEqualDeep(a, b, depth = 0) {
		if (a === b) return a;
		if (depth > 500) return b;
		const array = isPlainArray(a) && isPlainArray(b);
		if (!array && !(isPlainObject(a) && isPlainObject(b))) return b;
		const aSize = (array ? a : Object.keys(a)).length;
		const bItems = array ? b : Object.keys(b);
		const bSize = bItems.length;
		const copy = array ? new Array(bSize) : {};
		let equalItems = 0;
		for (let i = 0; i < bSize; i++) {
			const key = array ? i : bItems[i];
			const aItem = a[key];
			const bItem = b[key];
			if (aItem === bItem) {
				copy[key] = aItem;
				if (array ? i < aSize : hasOwn.call(a, key)) equalItems++;
				continue;
			}
			if (aItem === null || bItem === null || typeof aItem !== "object" || typeof bItem !== "object") {
				copy[key] = bItem;
				continue;
			}
			const v = replaceEqualDeep(aItem, bItem, depth + 1);
			copy[key] = v;
			if (v === aItem) equalItems++;
		}
		return aSize === bSize && equalItems === aSize ? a : copy;
	}
	function shallowEqualObjects(a, b) {
		if (!b || Object.keys(a).length !== Object.keys(b).length) return false;
		for (const key in a) if (a[key] !== b[key]) return false;
		return true;
	}
	function isPlainArray(value) {
		return Array.isArray(value) && value.length === Object.keys(value).length;
	}
	function isPlainObject(o) {
		if (!hasObjectPrototype(o)) return false;
		const ctor = o.constructor;
		if (ctor === void 0) return true;
		const prot = ctor.prototype;
		if (!hasObjectPrototype(prot)) return false;
		if (!prot.hasOwnProperty("isPrototypeOf")) return false;
		if (Object.getPrototypeOf(o) !== Object.prototype) return false;
		return true;
	}
	function hasObjectPrototype(o) {
		return Object.prototype.toString.call(o) === "[object Object]";
	}
	function sleep(timeout) {
		return new Promise((resolve) => {
			timeoutManager.setTimeout(resolve, timeout);
		});
	}
	function replaceData(prevData, data, options) {
		if (typeof options.structuralSharing === "function") return options.structuralSharing(prevData, data);
		else if (options.structuralSharing !== false) return replaceEqualDeep(prevData, data);
		return data;
	}
	function addToEnd(items, item, max = 0) {
		const newItems = [...items, item];
		return max && newItems.length > max ? newItems.slice(1) : newItems;
	}
	function addToStart(items, item, max = 0) {
		const newItems = [item, ...items];
		return max && newItems.length > max ? newItems.slice(0, -1) : newItems;
	}
	var skipToken = /* @__PURE__ */ Symbol();
	function ensureQueryFn(options, fetchOptions) {
		if (!options.queryFn && (fetchOptions === null || fetchOptions === void 0 ? void 0 : fetchOptions.initialPromise)) return () => fetchOptions.initialPromise;
		if (!options.queryFn || options.queryFn === skipToken) return () => Promise.reject(/* @__PURE__ */ new Error(`Missing queryFn: '${options.queryHash}'`));
		return options.queryFn;
	}
	function shouldThrowError(throwOnError, params) {
		if (typeof throwOnError === "function") return throwOnError(...params);
		return !!throwOnError;
	}
	function addConsumeAwareSignal(object, getSignal, onCancelled) {
		let consumed = false;
		let signal;
		Object.defineProperty(object, "signal", {
			enumerable: true,
			get: () => {
				var _signal;
				(_signal = signal) !== null && _signal !== void 0 || (signal = getSignal());
				if (consumed) return signal;
				consumed = true;
				if (signal.aborted) onCancelled();
				else signal.addEventListener("abort", onCancelled, { once: true });
				return signal;
			}
		});
		return object;
	}
	//#endregion
	//#region node_modules/@tanstack/query-core/build/modern/environmentManager.js
	var environmentManager = /* @__PURE__ */ (() => {
		let isServerFn = () => isServer;
		return {
			/**
			* Returns whether the current runtime should be treated as a server environment.
			*/
			isServer() {
				return isServerFn();
			},
			/**
			* Overrides the server check globally.
			*/
			setIsServer(isServerValue) {
				isServerFn = isServerValue;
			}
		};
	})();
	//#endregion
	//#region node_modules/@tanstack/query-core/build/modern/thenable.js
	function pendingThenable() {
		let resolve;
		let reject;
		const thenable = new Promise((_resolve, _reject) => {
			resolve = _resolve;
			reject = _reject;
		});
		thenable.status = "pending";
		thenable.catch(() => {});
		function finalize(data) {
			Object.assign(thenable, data);
			delete thenable.resolve;
			delete thenable.reject;
		}
		thenable.resolve = (value) => {
			finalize({
				status: "fulfilled",
				value
			});
			resolve(value);
		};
		thenable.reject = (reason) => {
			finalize({
				status: "rejected",
				reason
			});
			reject(reason);
		};
		return thenable;
	}
	//#endregion
	//#region node_modules/@tanstack/query-core/build/modern/notifyManager.js
	var defaultScheduler = systemSetTimeoutZero;
	function createNotifyManager() {
		let queue = [];
		let transactions = 0;
		let notifyFn = (callback) => {
			callback();
		};
		let batchNotifyFn = (callback) => {
			callback();
		};
		let scheduleFn = defaultScheduler;
		const schedule = (callback) => {
			if (transactions) queue.push(callback);
			else scheduleFn(() => {
				notifyFn(callback);
			});
		};
		const flush = () => {
			const originalQueue = queue;
			queue = [];
			if (originalQueue.length) scheduleFn(() => {
				batchNotifyFn(() => {
					originalQueue.forEach((callback) => {
						notifyFn(callback);
					});
				});
			});
		};
		return {
			batch: (callback) => {
				let result;
				transactions++;
				try {
					result = callback();
				} finally {
					transactions--;
					if (!transactions) flush();
				}
				return result;
			},
			/**
			* All calls to the wrapped function will be batched.
			*/
			batchCalls: (callback) => {
				return (...args) => {
					schedule(() => {
						callback(...args);
					});
				};
			},
			schedule,
			/**
			* Use this method to set a custom notify function.
			* This can be used to for example wrap notifications with `React.act` while running tests.
			*/
			setNotifyFunction: (fn) => {
				notifyFn = fn;
			},
			/**
			* Use this method to set a custom function to batch notifications together into a single tick.
			* By default React Query will use the batch function provided by ReactDOM or React Native.
			*/
			setBatchNotifyFunction: (fn) => {
				batchNotifyFn = fn;
			},
			setScheduler: (fn) => {
				scheduleFn = fn;
			}
		};
	}
	var notifyManager = createNotifyManager();
	//#endregion
	//#region node_modules/@tanstack/query-core/build/modern/onlineManager.js
	var _online;
	var _cleanup;
	var _setup;
	var onlineManager = new (_online = /* @__PURE__ */ new WeakMap(), _cleanup = /* @__PURE__ */ new WeakMap(), _setup = /* @__PURE__ */ new WeakMap(), class extends Subscribable {
		constructor() {
			super();
			_classPrivateFieldInitSpec(this, _online, true);
			_classPrivateFieldInitSpec(this, _cleanup, void 0);
			_classPrivateFieldInitSpec(this, _setup, void 0);
			_classPrivateFieldSet2(_setup, this, (onOnline) => {
				if (typeof window !== "undefined" && window.addEventListener) {
					const onlineListener = () => onOnline(true);
					const offlineListener = () => onOnline(false);
					window.addEventListener("online", onlineListener, false);
					window.addEventListener("offline", offlineListener, false);
					return () => {
						window.removeEventListener("online", onlineListener);
						window.removeEventListener("offline", offlineListener);
					};
				}
			});
		}
		onSubscribe() {
			if (!_classPrivateFieldGet2(_cleanup, this)) this.setEventListener(_classPrivateFieldGet2(_setup, this));
		}
		onUnsubscribe() {
			if (!this.hasListeners()) {
				var _classPrivateFieldGet2$7;
				(_classPrivateFieldGet2$7 = _classPrivateFieldGet2(_cleanup, this)) === null || _classPrivateFieldGet2$7 === void 0 || _classPrivateFieldGet2$7.call(this);
				_classPrivateFieldSet2(_cleanup, this, void 0);
			}
		}
		setEventListener(setup) {
			var _classPrivateFieldGet3;
			_classPrivateFieldSet2(_setup, this, setup);
			(_classPrivateFieldGet3 = _classPrivateFieldGet2(_cleanup, this)) === null || _classPrivateFieldGet3 === void 0 || _classPrivateFieldGet3.call(this);
			_classPrivateFieldSet2(_cleanup, this, setup(this.setOnline.bind(this)));
		}
		setOnline(online) {
			if (_classPrivateFieldGet2(_online, this) !== online) {
				_classPrivateFieldSet2(_online, this, online);
				this.listeners.forEach((listener) => {
					listener(online);
				});
			}
		}
		isOnline() {
			return _classPrivateFieldGet2(_online, this);
		}
	})();
	//#endregion
	//#region node_modules/@tanstack/query-core/build/modern/retryer.js
	function defaultRetryDelay(failureCount) {
		return Math.min(1e3 * Math.pow(2, failureCount), 3e4);
	}
	function canFetch(networkMode) {
		return (networkMode !== null && networkMode !== void 0 ? networkMode : "online") === "online" ? onlineManager.isOnline() : true;
	}
	var CancelledError = class extends Error {
		constructor(options) {
			super("CancelledError");
			this.revert = options === null || options === void 0 ? void 0 : options.revert;
			this.silent = options === null || options === void 0 ? void 0 : options.silent;
		}
	};
	function createRetryer(config) {
		let isRetryCancelled = false;
		let failureCount = 0;
		let continueFn;
		const thenable = pendingThenable();
		const isResolved = () => thenable.status !== "pending";
		const cancel = (cancelOptions) => {
			if (!isResolved()) {
				var _config$onCancel;
				const error = new CancelledError(cancelOptions);
				reject(error);
				(_config$onCancel = config.onCancel) === null || _config$onCancel === void 0 || _config$onCancel.call(config, error);
			}
		};
		const cancelRetry = () => {
			isRetryCancelled = true;
		};
		const continueRetry = () => {
			isRetryCancelled = false;
		};
		const canContinue = () => focusManager.isFocused() && (config.networkMode === "always" || onlineManager.isOnline()) && config.canRun();
		const canStart = () => canFetch(config.networkMode) && config.canRun();
		const resolve = (value) => {
			if (!isResolved()) {
				continueFn === null || continueFn === void 0 || continueFn();
				thenable.resolve(value);
			}
		};
		const reject = (value) => {
			if (!isResolved()) {
				continueFn === null || continueFn === void 0 || continueFn();
				thenable.reject(value);
			}
		};
		const pause = () => {
			return new Promise((continueResolve) => {
				var _config$onPause;
				continueFn = (value) => {
					if (isResolved() || canContinue()) continueResolve(value);
				};
				(_config$onPause = config.onPause) === null || _config$onPause === void 0 || _config$onPause.call(config);
			}).then(() => {
				continueFn = void 0;
				if (!isResolved()) {
					var _config$onContinue;
					(_config$onContinue = config.onContinue) === null || _config$onContinue === void 0 || _config$onContinue.call(config);
				}
			});
		};
		const run = () => {
			if (isResolved()) return;
			let promiseOrValue;
			const initialPromise = failureCount === 0 ? config.initialPromise : void 0;
			try {
				promiseOrValue = initialPromise !== null && initialPromise !== void 0 ? initialPromise : config.fn();
			} catch (error) {
				promiseOrValue = Promise.reject(error);
			}
			Promise.resolve(promiseOrValue).then(resolve).catch((error) => {
				var _config$retry, _config$retryDelay, _config$onFail;
				if (isResolved()) return;
				const retry = (_config$retry = config.retry) !== null && _config$retry !== void 0 ? _config$retry : environmentManager.isServer() ? 0 : 3;
				const retryDelay = (_config$retryDelay = config.retryDelay) !== null && _config$retryDelay !== void 0 ? _config$retryDelay : defaultRetryDelay;
				const delay = typeof retryDelay === "function" ? retryDelay(failureCount, error) : retryDelay;
				const shouldRetry = retry === true || typeof retry === "number" && failureCount < retry || typeof retry === "function" && retry(failureCount, error);
				if (isRetryCancelled || !shouldRetry) {
					reject(error);
					return;
				}
				failureCount++;
				(_config$onFail = config.onFail) === null || _config$onFail === void 0 || _config$onFail.call(config, failureCount, error);
				sleep(delay).then(() => {
					return canContinue() ? void 0 : pause();
				}).then(() => {
					if (isRetryCancelled) reject(error);
					else run();
				});
			});
		};
		return {
			promise: thenable,
			status: () => thenable.status,
			cancel,
			continue: () => {
				continueFn === null || continueFn === void 0 || continueFn();
				return thenable;
			},
			cancelRetry,
			continueRetry,
			canStart,
			start: () => {
				if (canStart()) run();
				else pause().then(run);
				return thenable;
			}
		};
	}
	//#endregion
	//#region node_modules/@tanstack/query-core/build/modern/removable.js
	var _gcTimeout;
	var Removable = (_gcTimeout = /* @__PURE__ */ new WeakMap(), class {
		constructor() {
			_classPrivateFieldInitSpec(this, _gcTimeout, void 0);
		}
		destroy() {
			this.clearGcTimeout();
		}
		scheduleGc() {
			this.clearGcTimeout();
			if (isValidTimeout(this.gcTime)) _classPrivateFieldSet2(_gcTimeout, this, timeoutManager.setTimeout(() => {
				this.optionalRemove();
			}, this.gcTime));
		}
		updateGcTime(newGcTime) {
			this.gcTime = Math.max(this.gcTime || 0, newGcTime !== null && newGcTime !== void 0 ? newGcTime : environmentManager.isServer() ? Infinity : 3e5);
		}
		clearGcTimeout() {
			if (_classPrivateFieldGet2(_gcTimeout, this) !== void 0) {
				timeoutManager.clearTimeout(_classPrivateFieldGet2(_gcTimeout, this));
				_classPrivateFieldSet2(_gcTimeout, this, void 0);
			}
		}
	});
	//#endregion
	//#region node_modules/@tanstack/query-core/build/modern/infiniteQueryBehavior.js
	init_asyncToGenerator();
	function infiniteQueryBehavior(pages) {
		return { onFetch: (context, query) => {
			var _context$fetchOptions, _context$state$data, _context$state$data2;
			const options = context.options;
			const direction = (_context$fetchOptions = context.fetchOptions) === null || _context$fetchOptions === void 0 || (_context$fetchOptions = _context$fetchOptions.meta) === null || _context$fetchOptions === void 0 || (_context$fetchOptions = _context$fetchOptions.fetchMore) === null || _context$fetchOptions === void 0 ? void 0 : _context$fetchOptions.direction;
			const oldPages = ((_context$state$data = context.state.data) === null || _context$state$data === void 0 ? void 0 : _context$state$data.pages) || [];
			const oldPageParams = ((_context$state$data2 = context.state.data) === null || _context$state$data2 === void 0 ? void 0 : _context$state$data2.pageParams) || [];
			let result = {
				pages: [],
				pageParams: []
			};
			let currentPage = 0;
			const fetchFn = function() {
				var _ref2 = _asyncToGenerator(function* () {
					let cancelled = false;
					const addSignalProperty = (object) => {
						addConsumeAwareSignal(object, () => context.signal, () => cancelled = true);
					};
					const queryFn = ensureQueryFn(context.options, context.fetchOptions);
					const fetchPage = function() {
						var _ref = _asyncToGenerator(function* (data, param, previous) {
							if (cancelled) return Promise.reject(context.signal.reason);
							if (param == null && data.pages.length) return Promise.resolve(data);
							const createQueryFnContext = () => {
								const queryFnContext2 = {
									client: context.client,
									queryKey: context.queryKey,
									pageParam: param,
									direction: previous ? "backward" : "forward",
									meta: context.options.meta
								};
								addSignalProperty(queryFnContext2);
								return queryFnContext2;
							};
							const queryFnContext = createQueryFnContext();
							const page = yield queryFn(queryFnContext);
							const { maxPages } = context.options;
							const addTo = previous ? addToStart : addToEnd;
							return {
								pages: addTo(data.pages, page, maxPages),
								pageParams: addTo(data.pageParams, param, maxPages)
							};
						});
						return function fetchPage(_x, _x2, _x3) {
							return _ref.apply(this, arguments);
						};
					}();
					if (direction && oldPages.length) {
						const previous = direction === "backward";
						const pageParamFn = previous ? getPreviousPageParam : getNextPageParam;
						const oldData = {
							pages: oldPages,
							pageParams: oldPageParams
						};
						result = yield fetchPage(oldData, pageParamFn(options, oldData), previous);
					} else {
						const remainingPages = pages !== null && pages !== void 0 ? pages : oldPages.length;
						do {
							var _oldPageParams$;
							const param = currentPage === 0 ? (_oldPageParams$ = oldPageParams[0]) !== null && _oldPageParams$ !== void 0 ? _oldPageParams$ : options.initialPageParam : getNextPageParam(options, result);
							if (currentPage > 0 && param == null) break;
							result = yield fetchPage(result, param);
							currentPage++;
						} while (currentPage < remainingPages);
					}
					return result;
				});
				return function fetchFn() {
					return _ref2.apply(this, arguments);
				};
			}();
			if (context.options.persister) context.fetchFn = () => {
				var _context$options$pers, _context$options;
				return (_context$options$pers = (_context$options = context.options).persister) === null || _context$options$pers === void 0 ? void 0 : _context$options$pers.call(_context$options, fetchFn, {
					client: context.client,
					queryKey: context.queryKey,
					meta: context.options.meta,
					signal: context.signal
				}, query);
			};
			else context.fetchFn = fetchFn;
		} };
	}
	function getNextPageParam(options, { pages, pageParams }) {
		const lastIndex = pages.length - 1;
		return pages.length > 0 ? options.getNextPageParam(pages[lastIndex], pages, pageParams[lastIndex], pageParams) : void 0;
	}
	function getPreviousPageParam(options, { pages, pageParams }) {
		var _options$getPreviousP;
		return pages.length > 0 ? (_options$getPreviousP = options.getPreviousPageParam) === null || _options$getPreviousP === void 0 ? void 0 : _options$getPreviousP.call(options, pages[0], pages, pageParams[0], pageParams) : void 0;
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.146.0/helpers/esm/classPrivateMethodInitSpec.js
	function _classPrivateMethodInitSpec(e, a) {
		_checkPrivateRedeclaration(e, a), a.add(e);
	}
	//#endregion
	//#region node_modules/@tanstack/query-core/build/modern/query.js
	init_objectSpread2();
	init_asyncToGenerator();
	var _queryType;
	var _initialState;
	var _revertState;
	var _cache;
	var _client$3;
	var _retryer$1;
	var _defaultOptions$1;
	var _abortSignalConsumed;
	var _Class_brand$3;
	var Query = (_queryType = /* @__PURE__ */ new WeakMap(), _initialState = /* @__PURE__ */ new WeakMap(), _revertState = /* @__PURE__ */ new WeakMap(), _cache = /* @__PURE__ */ new WeakMap(), _client$3 = /* @__PURE__ */ new WeakMap(), _retryer$1 = /* @__PURE__ */ new WeakMap(), _defaultOptions$1 = /* @__PURE__ */ new WeakMap(), _abortSignalConsumed = /* @__PURE__ */ new WeakMap(), _Class_brand$3 = /* @__PURE__ */ new WeakSet(), class extends Removable {
		constructor(config) {
			var _config$state;
			super();
			_classPrivateMethodInitSpec(this, _Class_brand$3);
			_classPrivateFieldInitSpec(this, _queryType, void 0);
			_classPrivateFieldInitSpec(this, _initialState, void 0);
			_classPrivateFieldInitSpec(this, _revertState, void 0);
			_classPrivateFieldInitSpec(this, _cache, void 0);
			_classPrivateFieldInitSpec(this, _client$3, void 0);
			_classPrivateFieldInitSpec(this, _retryer$1, void 0);
			_classPrivateFieldInitSpec(this, _defaultOptions$1, void 0);
			_classPrivateFieldInitSpec(this, _abortSignalConsumed, void 0);
			_classPrivateFieldSet2(_abortSignalConsumed, this, false);
			_classPrivateFieldSet2(_defaultOptions$1, this, config.defaultOptions);
			this.setOptions(config.options);
			this.observers = [];
			_classPrivateFieldSet2(_client$3, this, config.client);
			_classPrivateFieldSet2(_cache, this, _classPrivateFieldGet2(_client$3, this).getQueryCache());
			this.queryKey = config.queryKey;
			this.queryHash = config.queryHash;
			_classPrivateFieldSet2(_initialState, this, getDefaultState$1(this.options));
			this.state = (_config$state = config.state) !== null && _config$state !== void 0 ? _config$state : _classPrivateFieldGet2(_initialState, this);
			this.scheduleGc();
		}
		get meta() {
			return this.options.meta;
		}
		get queryType() {
			return _classPrivateFieldGet2(_queryType, this);
		}
		get promise() {
			var _classPrivateFieldGet2$6;
			return (_classPrivateFieldGet2$6 = _classPrivateFieldGet2(_retryer$1, this)) === null || _classPrivateFieldGet2$6 === void 0 ? void 0 : _classPrivateFieldGet2$6.promise;
		}
		setOptions(options) {
			this.options = _objectSpread2(_objectSpread2({}, _classPrivateFieldGet2(_defaultOptions$1, this)), options);
			if (options === null || options === void 0 ? void 0 : options._type) _classPrivateFieldSet2(_queryType, this, options._type);
			this.updateGcTime(this.options.gcTime);
			if (this.state && this.state.data === void 0) {
				const defaultState = getDefaultState$1(this.options);
				if (defaultState.data !== void 0) {
					this.setState(successState(defaultState.data, defaultState.dataUpdatedAt));
					_classPrivateFieldSet2(_initialState, this, defaultState);
				}
			}
		}
		optionalRemove() {
			if (!this.observers.length && this.state.fetchStatus === "idle") _classPrivateFieldGet2(_cache, this).remove(this);
		}
		setData(newData, options) {
			const data = replaceData(this.state.data, newData, this.options);
			_assertClassBrand(_Class_brand$3, this, _dispatch$1).call(this, {
				data,
				type: "success",
				dataUpdatedAt: options === null || options === void 0 ? void 0 : options.updatedAt,
				manual: options === null || options === void 0 ? void 0 : options.manual
			});
			return data;
		}
		setState(state) {
			_assertClassBrand(_Class_brand$3, this, _dispatch$1).call(this, {
				type: "setState",
				state
			});
		}
		cancel(options) {
			var _classPrivateFieldGet3, _classPrivateFieldGet4;
			const promise = (_classPrivateFieldGet3 = _classPrivateFieldGet2(_retryer$1, this)) === null || _classPrivateFieldGet3 === void 0 ? void 0 : _classPrivateFieldGet3.promise;
			(_classPrivateFieldGet4 = _classPrivateFieldGet2(_retryer$1, this)) === null || _classPrivateFieldGet4 === void 0 || _classPrivateFieldGet4.cancel(options);
			return promise ? promise.then(noop$1).catch(noop$1) : Promise.resolve();
		}
		destroy() {
			super.destroy();
			this.cancel({ silent: true });
		}
		get resetState() {
			return _classPrivateFieldGet2(_initialState, this);
		}
		reset() {
			this.destroy();
			this.setState(this.resetState);
		}
		isActive() {
			return this.observers.some((observer) => resolveQueryBoolean(observer.options.enabled, this) !== false);
		}
		isDisabled() {
			if (this.getObserversCount() > 0) return !this.isActive();
			return this.options.queryFn === skipToken || !this.isFetched();
		}
		isFetched() {
			return this.state.dataUpdateCount + this.state.errorUpdateCount > 0;
		}
		isStatic() {
			if (this.getObserversCount() > 0) return this.observers.some((observer) => resolveStaleTime(observer.options.staleTime, this) === "static");
			return false;
		}
		isStale() {
			if (this.getObserversCount() > 0) return this.observers.some((observer) => observer.getCurrentResult().isStale);
			return this.state.data === void 0 || this.state.isInvalidated;
		}
		isStaleByTime(staleTime = 0) {
			if (this.state.data === void 0) return true;
			if (staleTime === "static") return false;
			if (this.state.isInvalidated) return true;
			return !timeUntilStale(this.state.dataUpdatedAt, staleTime);
		}
		onFocus() {
			var _classPrivateFieldGet5;
			const observer = this.observers.find((x) => x.shouldFetchOnWindowFocus());
			observer === null || observer === void 0 || observer.refetch({ cancelRefetch: false });
			(_classPrivateFieldGet5 = _classPrivateFieldGet2(_retryer$1, this)) === null || _classPrivateFieldGet5 === void 0 || _classPrivateFieldGet5.continue();
		}
		onOnline() {
			var _classPrivateFieldGet6;
			const observer = this.observers.find((x) => x.shouldFetchOnReconnect());
			observer === null || observer === void 0 || observer.refetch({ cancelRefetch: false });
			(_classPrivateFieldGet6 = _classPrivateFieldGet2(_retryer$1, this)) === null || _classPrivateFieldGet6 === void 0 || _classPrivateFieldGet6.continue();
		}
		addObserver(observer) {
			if (!this.observers.includes(observer)) {
				this.observers.push(observer);
				this.clearGcTimeout();
				_classPrivateFieldGet2(_cache, this).notify({
					type: "observerAdded",
					query: this,
					observer
				});
			}
		}
		removeObserver(observer) {
			if (this.observers.includes(observer)) {
				this.observers = this.observers.filter((x) => x !== observer);
				if (!this.observers.length) {
					if (_classPrivateFieldGet2(_retryer$1, this)) {
						if (_classPrivateFieldGet2(_abortSignalConsumed, this) || _assertClassBrand(_Class_brand$3, this, _isInitialPausedFetch).call(this)) _classPrivateFieldGet2(_retryer$1, this).cancel({ revert: true });
						else _classPrivateFieldGet2(_retryer$1, this).cancelRetry();
					}
					this.scheduleGc();
				}
				_classPrivateFieldGet2(_cache, this).notify({
					type: "observerRemoved",
					query: this,
					observer
				});
			}
		}
		getObserversCount() {
			return this.observers.length;
		}
		invalidate() {
			if (!this.state.isInvalidated) _assertClassBrand(_Class_brand$3, this, _dispatch$1).call(this, { type: "invalidate" });
		}
		fetch(options, fetchOptions) {
			var _this = this;
			return _asyncToGenerator(function* () {
				var _classPrivateFieldGet7, _context$fetchOptions;
				if (_this.state.fetchStatus !== "idle" && ((_classPrivateFieldGet7 = _classPrivateFieldGet2(_retryer$1, _this)) === null || _classPrivateFieldGet7 === void 0 ? void 0 : _classPrivateFieldGet7.status()) !== "rejected") {
					if (_this.state.data !== void 0 && (fetchOptions === null || fetchOptions === void 0 ? void 0 : fetchOptions.cancelRefetch)) _this.cancel({ silent: true });
					else if (_classPrivateFieldGet2(_retryer$1, _this)) {
						_classPrivateFieldGet2(_retryer$1, _this).continueRetry();
						return _classPrivateFieldGet2(_retryer$1, _this).promise;
					}
				}
				if (options) _this.setOptions(options);
				if (!_this.options.queryFn) {
					const observer = _this.observers.find((x) => x.options.queryFn);
					if (observer) _this.setOptions(observer.options);
				}
				const abortController = new AbortController();
				const addSignalProperty = (object) => {
					Object.defineProperty(object, "signal", {
						enumerable: true,
						get: () => {
							_classPrivateFieldSet2(_abortSignalConsumed, _this, true);
							return abortController.signal;
						}
					});
				};
				const fetchFn = () => {
					const queryFn = ensureQueryFn(_this.options, fetchOptions);
					const createQueryFnContext = () => {
						const queryFnContext2 = {
							client: _classPrivateFieldGet2(_client$3, _this),
							queryKey: _this.queryKey,
							meta: _this.meta
						};
						addSignalProperty(queryFnContext2);
						return queryFnContext2;
					};
					const queryFnContext = createQueryFnContext();
					_classPrivateFieldSet2(_abortSignalConsumed, _this, false);
					if (_this.options.persister) return _this.options.persister(queryFn, queryFnContext, _this);
					return queryFn(queryFnContext);
				};
				const createFetchContext = () => {
					const context2 = {
						fetchOptions,
						options: _this.options,
						queryKey: _this.queryKey,
						client: _classPrivateFieldGet2(_client$3, _this),
						state: _this.state,
						fetchFn
					};
					addSignalProperty(context2);
					return context2;
				};
				const context = createFetchContext();
				const behavior = _classPrivateFieldGet2(_queryType, _this) === "infinite" ? infiniteQueryBehavior(_this.options.pages) : _this.options.behavior;
				behavior === null || behavior === void 0 || behavior.onFetch(context, _this);
				_classPrivateFieldSet2(_revertState, _this, _this.state);
				if (_this.state.fetchStatus === "idle" || _this.state.fetchMeta !== ((_context$fetchOptions = context.fetchOptions) === null || _context$fetchOptions === void 0 ? void 0 : _context$fetchOptions.meta)) {
					var _context$fetchOptions2;
					_assertClassBrand(_Class_brand$3, _this, _dispatch$1).call(_this, {
						type: "fetch",
						meta: (_context$fetchOptions2 = context.fetchOptions) === null || _context$fetchOptions2 === void 0 ? void 0 : _context$fetchOptions2.meta
					});
				}
				_classPrivateFieldSet2(_retryer$1, _this, createRetryer({
					initialPromise: fetchOptions === null || fetchOptions === void 0 ? void 0 : fetchOptions.initialPromise,
					fn: context.fetchFn,
					onCancel: (error) => {
						if (error instanceof CancelledError && error.revert) _this.setState(_objectSpread2(_objectSpread2({}, _classPrivateFieldGet2(_revertState, _this)), {}, { fetchStatus: "idle" }));
						abortController.abort();
					},
					onFail: (failureCount, error) => {
						_assertClassBrand(_Class_brand$3, _this, _dispatch$1).call(_this, {
							type: "failed",
							failureCount,
							error
						});
					},
					onPause: () => {
						_assertClassBrand(_Class_brand$3, _this, _dispatch$1).call(_this, { type: "pause" });
					},
					onContinue: () => {
						_assertClassBrand(_Class_brand$3, _this, _dispatch$1).call(_this, { type: "continue" });
					},
					retry: context.options.retry,
					retryDelay: context.options.retryDelay,
					networkMode: context.options.networkMode,
					canRun: () => true
				}));
				try {
					var _classPrivateFieldGet8, _classPrivateFieldGet9, _classPrivateFieldGet10, _classPrivateFieldGet11;
					const data = yield _classPrivateFieldGet2(_retryer$1, _this).start();
					if (data === void 0) throw new Error(`${_this.queryHash} data is undefined`);
					_this.setData(data);
					(_classPrivateFieldGet8 = (_classPrivateFieldGet9 = _classPrivateFieldGet2(_cache, _this).config).onSuccess) === null || _classPrivateFieldGet8 === void 0 || _classPrivateFieldGet8.call(_classPrivateFieldGet9, data, _this);
					(_classPrivateFieldGet10 = (_classPrivateFieldGet11 = _classPrivateFieldGet2(_cache, _this).config).onSettled) === null || _classPrivateFieldGet10 === void 0 || _classPrivateFieldGet10.call(_classPrivateFieldGet11, data, _this.state.error, _this);
					return data;
				} catch (error) {
					var _classPrivateFieldGet12, _classPrivateFieldGet13, _classPrivateFieldGet14, _classPrivateFieldGet15;
					if (error instanceof CancelledError) {
						if (error.silent) return _classPrivateFieldGet2(_retryer$1, _this).promise;
						else if (error.revert) {
							if (_this.state.data === void 0) throw error;
							return _this.state.data;
						}
					}
					_assertClassBrand(_Class_brand$3, _this, _dispatch$1).call(_this, {
						type: "error",
						error
					});
					(_classPrivateFieldGet12 = (_classPrivateFieldGet13 = _classPrivateFieldGet2(_cache, _this).config).onError) === null || _classPrivateFieldGet12 === void 0 || _classPrivateFieldGet12.call(_classPrivateFieldGet13, error, _this);
					(_classPrivateFieldGet14 = (_classPrivateFieldGet15 = _classPrivateFieldGet2(_cache, _this).config).onSettled) === null || _classPrivateFieldGet14 === void 0 || _classPrivateFieldGet14.call(_classPrivateFieldGet15, _this.state.data, error, _this);
					throw error;
				} finally {
					_this.scheduleGc();
				}
			})();
		}
	});
	function _isInitialPausedFetch() {
		return this.state.fetchStatus === "paused" && this.state.status === "pending";
	}
	function _dispatch$1(action) {
		const reducer = (state) => {
			switch (action.type) {
				case "failed": return _objectSpread2(_objectSpread2({}, state), {}, {
					fetchFailureCount: action.failureCount,
					fetchFailureReason: action.error
				});
				case "pause": return _objectSpread2(_objectSpread2({}, state), {}, { fetchStatus: "paused" });
				case "continue": return _objectSpread2(_objectSpread2({}, state), {}, { fetchStatus: "fetching" });
				case "fetch":
					var _action$meta;
					return _objectSpread2(_objectSpread2(_objectSpread2({}, state), fetchState(state.data, this.options)), {}, { fetchMeta: (_action$meta = action.meta) !== null && _action$meta !== void 0 ? _action$meta : null });
				case "success":
					const newState = _objectSpread2(_objectSpread2(_objectSpread2({}, state), successState(action.data, action.dataUpdatedAt)), {}, { dataUpdateCount: state.dataUpdateCount + 1 }, !action.manual && {
						fetchStatus: "idle",
						fetchFailureCount: 0,
						fetchFailureReason: null
					});
					_classPrivateFieldSet2(_revertState, this, action.manual ? newState : void 0);
					return newState;
				case "error":
					const error = action.error;
					return _objectSpread2(_objectSpread2({}, state), {}, {
						error,
						errorUpdateCount: state.errorUpdateCount + 1,
						errorUpdatedAt: Date.now(),
						fetchFailureCount: state.fetchFailureCount + 1,
						fetchFailureReason: error,
						fetchStatus: "idle",
						status: "error",
						isInvalidated: true
					});
				case "invalidate": return _objectSpread2(_objectSpread2({}, state), {}, { isInvalidated: true });
				case "setState": return _objectSpread2(_objectSpread2({}, state), action.state);
			}
		};
		this.state = reducer(this.state);
		notifyManager.batch(() => {
			this.observers.forEach((observer) => {
				observer.onQueryUpdate();
			});
			_classPrivateFieldGet2(_cache, this).notify({
				query: this,
				type: "updated",
				action
			});
		});
	}
	function fetchState(data, options) {
		return _objectSpread2({
			fetchFailureCount: 0,
			fetchFailureReason: null,
			fetchStatus: canFetch(options.networkMode) ? "fetching" : "paused"
		}, data === void 0 && {
			error: null,
			status: "pending"
		});
	}
	function successState(data, dataUpdatedAt) {
		return {
			data,
			dataUpdatedAt: dataUpdatedAt !== null && dataUpdatedAt !== void 0 ? dataUpdatedAt : Date.now(),
			error: null,
			isInvalidated: false,
			status: "success"
		};
	}
	function getDefaultState$1(options) {
		const data = typeof options.initialData === "function" ? options.initialData() : options.initialData;
		const hasData = data !== void 0;
		const initialDataUpdatedAt = hasData ? typeof options.initialDataUpdatedAt === "function" ? options.initialDataUpdatedAt() : options.initialDataUpdatedAt : 0;
		return {
			data,
			dataUpdateCount: 0,
			dataUpdatedAt: hasData ? initialDataUpdatedAt !== null && initialDataUpdatedAt !== void 0 ? initialDataUpdatedAt : Date.now() : 0,
			error: null,
			errorUpdateCount: 0,
			errorUpdatedAt: 0,
			fetchFailureCount: 0,
			fetchFailureReason: null,
			fetchMeta: null,
			isInvalidated: false,
			status: hasData ? "success" : "pending",
			fetchStatus: "idle"
		};
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.146.0/helpers/esm/objectDestructuringEmpty.js
	function _objectDestructuringEmpty(t) {
		if (null == t) throw new TypeError("Cannot destructure " + t);
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.146.0/helpers/esm/extends.js
	function _extends() {
		return _extends = Object.assign ? Object.assign.bind() : function(n) {
			for (var e = 1; e < arguments.length; e++) {
				var t = arguments[e];
				for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
			}
			return n;
		}, _extends.apply(null, arguments);
	}
	//#endregion
	//#region node_modules/@tanstack/query-core/build/modern/queryObserver.js
	init_objectSpread2();
	var _client$2;
	var _currentQuery;
	var _currentQueryInitialState;
	var _currentResult$1;
	var _currentResultState;
	var _currentResultOptions;
	var _currentThenable;
	var _selectError;
	var _selectFn;
	var _selectResult;
	var _lastQueryWithDefinedData;
	var _staleTimeoutId;
	var _refetchIntervalId;
	var _currentRefetchInterval;
	var _trackedProps;
	var _Class_brand$2;
	var QueryObserver = (_client$2 = /* @__PURE__ */ new WeakMap(), _currentQuery = /* @__PURE__ */ new WeakMap(), _currentQueryInitialState = /* @__PURE__ */ new WeakMap(), _currentResult$1 = /* @__PURE__ */ new WeakMap(), _currentResultState = /* @__PURE__ */ new WeakMap(), _currentResultOptions = /* @__PURE__ */ new WeakMap(), _currentThenable = /* @__PURE__ */ new WeakMap(), _selectError = /* @__PURE__ */ new WeakMap(), _selectFn = /* @__PURE__ */ new WeakMap(), _selectResult = /* @__PURE__ */ new WeakMap(), _lastQueryWithDefinedData = /* @__PURE__ */ new WeakMap(), _staleTimeoutId = /* @__PURE__ */ new WeakMap(), _refetchIntervalId = /* @__PURE__ */ new WeakMap(), _currentRefetchInterval = /* @__PURE__ */ new WeakMap(), _trackedProps = /* @__PURE__ */ new WeakMap(), _Class_brand$2 = /* @__PURE__ */ new WeakSet(), class extends Subscribable {
		constructor(client, options) {
			super();
			_classPrivateMethodInitSpec(this, _Class_brand$2);
			_classPrivateFieldInitSpec(this, _client$2, void 0);
			_classPrivateFieldInitSpec(this, _currentQuery, void 0);
			_classPrivateFieldInitSpec(this, _currentQueryInitialState, void 0);
			_classPrivateFieldInitSpec(this, _currentResult$1, void 0);
			_classPrivateFieldInitSpec(this, _currentResultState, void 0);
			_classPrivateFieldInitSpec(this, _currentResultOptions, void 0);
			_classPrivateFieldInitSpec(this, _currentThenable, void 0);
			_classPrivateFieldInitSpec(this, _selectError, void 0);
			_classPrivateFieldInitSpec(this, _selectFn, void 0);
			_classPrivateFieldInitSpec(this, _selectResult, void 0);
			_classPrivateFieldInitSpec(this, _lastQueryWithDefinedData, void 0);
			_classPrivateFieldInitSpec(this, _staleTimeoutId, void 0);
			_classPrivateFieldInitSpec(this, _refetchIntervalId, void 0);
			_classPrivateFieldInitSpec(this, _currentRefetchInterval, void 0);
			_classPrivateFieldInitSpec(this, _trackedProps, /* @__PURE__ */ new Set());
			this.options = options;
			_classPrivateFieldSet2(_client$2, this, client);
			_classPrivateFieldSet2(_selectError, this, null);
			_classPrivateFieldSet2(_currentThenable, this, pendingThenable());
			this.bindMethods();
			this.setOptions(options);
		}
		bindMethods() {
			this.refetch = this.refetch.bind(this);
		}
		onSubscribe() {
			if (this.listeners.size === 1) {
				_classPrivateFieldGet2(_currentQuery, this).addObserver(this);
				if (shouldFetchOnMount(_classPrivateFieldGet2(_currentQuery, this), this.options)) _assertClassBrand(_Class_brand$2, this, _executeFetch).call(this);
				else this.updateResult();
				_assertClassBrand(_Class_brand$2, this, _updateTimers).call(this);
			}
		}
		onUnsubscribe() {
			if (!this.hasListeners()) this.destroy();
		}
		shouldFetchOnReconnect() {
			return shouldFetchOn(_classPrivateFieldGet2(_currentQuery, this), this.options, this.options.refetchOnReconnect);
		}
		shouldFetchOnWindowFocus() {
			return shouldFetchOn(_classPrivateFieldGet2(_currentQuery, this), this.options, this.options.refetchOnWindowFocus);
		}
		destroy() {
			this.listeners = /* @__PURE__ */ new Set();
			_assertClassBrand(_Class_brand$2, this, _clearStaleTimeout).call(this);
			_assertClassBrand(_Class_brand$2, this, _clearRefetchInterval).call(this);
			_classPrivateFieldGet2(_currentQuery, this).removeObserver(this);
		}
		setOptions(options) {
			const prevOptions = this.options;
			const prevQuery = _classPrivateFieldGet2(_currentQuery, this);
			this.options = _classPrivateFieldGet2(_client$2, this).defaultQueryOptions(options);
			if (this.options.enabled !== void 0 && typeof this.options.enabled !== "boolean" && typeof this.options.enabled !== "function" && typeof resolveQueryBoolean(this.options.enabled, _classPrivateFieldGet2(_currentQuery, this)) !== "boolean") throw new Error("Expected enabled to be a boolean or a callback that returns a boolean");
			_assertClassBrand(_Class_brand$2, this, _updateQuery).call(this);
			_classPrivateFieldGet2(_currentQuery, this).setOptions(this.options);
			if (prevOptions._defaulted && !shallowEqualObjects(this.options, prevOptions)) _classPrivateFieldGet2(_client$2, this).getQueryCache().notify({
				type: "observerOptionsUpdated",
				query: _classPrivateFieldGet2(_currentQuery, this),
				observer: this
			});
			const mounted = this.hasListeners();
			if (mounted && shouldFetchOptionally(_classPrivateFieldGet2(_currentQuery, this), prevQuery, this.options, prevOptions)) _assertClassBrand(_Class_brand$2, this, _executeFetch).call(this);
			this.updateResult();
			if (mounted && (_classPrivateFieldGet2(_currentQuery, this) !== prevQuery || resolveQueryBoolean(this.options.enabled, _classPrivateFieldGet2(_currentQuery, this)) !== resolveQueryBoolean(prevOptions.enabled, _classPrivateFieldGet2(_currentQuery, this)) || resolveStaleTime(this.options.staleTime, _classPrivateFieldGet2(_currentQuery, this)) !== resolveStaleTime(prevOptions.staleTime, _classPrivateFieldGet2(_currentQuery, this)))) _assertClassBrand(_Class_brand$2, this, _updateStaleTimeout).call(this);
			const nextRefetchInterval = _assertClassBrand(_Class_brand$2, this, _computeRefetchInterval).call(this);
			if (mounted && (_classPrivateFieldGet2(_currentQuery, this) !== prevQuery || resolveQueryBoolean(this.options.enabled, _classPrivateFieldGet2(_currentQuery, this)) !== resolveQueryBoolean(prevOptions.enabled, _classPrivateFieldGet2(_currentQuery, this)) || nextRefetchInterval !== _classPrivateFieldGet2(_currentRefetchInterval, this))) _assertClassBrand(_Class_brand$2, this, _updateRefetchInterval).call(this, nextRefetchInterval);
		}
		getOptimisticResult(options) {
			const query = _classPrivateFieldGet2(_client$2, this).getQueryCache().build(_classPrivateFieldGet2(_client$2, this), options);
			const result = this.createResult(query, options);
			if (shouldAssignObserverCurrentProperties(this, result)) {
				_classPrivateFieldSet2(_currentResult$1, this, result);
				_classPrivateFieldSet2(_currentResultOptions, this, this.options);
				_classPrivateFieldSet2(_currentResultState, this, _classPrivateFieldGet2(_currentQuery, this).state);
			}
			return result;
		}
		getCurrentResult() {
			return _classPrivateFieldGet2(_currentResult$1, this);
		}
		trackResult(result, onPropTracked) {
			return new Proxy(result, { get: (target, key) => {
				this.trackProp(key);
				onPropTracked === null || onPropTracked === void 0 || onPropTracked(key);
				if (key === "promise") {
					this.trackProp("data");
					if (!this.options.experimental_prefetchInRender && _classPrivateFieldGet2(_currentThenable, this).status === "pending") _classPrivateFieldGet2(_currentThenable, this).reject(/* @__PURE__ */ new Error("experimental_prefetchInRender feature flag is not enabled"));
				}
				return Reflect.get(target, key);
			} });
		}
		trackProp(key) {
			_classPrivateFieldGet2(_trackedProps, this).add(key);
		}
		getCurrentQuery() {
			return _classPrivateFieldGet2(_currentQuery, this);
		}
		refetch(_ref = {}) {
			let options = _extends({}, (_objectDestructuringEmpty(_ref), _ref));
			return this.fetch(_objectSpread2({}, options));
		}
		fetchOptimistic(options) {
			const defaultedOptions = _classPrivateFieldGet2(_client$2, this).defaultQueryOptions(options);
			const query = _classPrivateFieldGet2(_client$2, this).getQueryCache().build(_classPrivateFieldGet2(_client$2, this), defaultedOptions);
			return query.fetch().then(() => this.createResult(query, defaultedOptions));
		}
		fetch(fetchOptions) {
			var _fetchOptions$cancelR;
			return _assertClassBrand(_Class_brand$2, this, _executeFetch).call(this, _objectSpread2(_objectSpread2({}, fetchOptions), {}, { cancelRefetch: (_fetchOptions$cancelR = fetchOptions.cancelRefetch) !== null && _fetchOptions$cancelR !== void 0 ? _fetchOptions$cancelR : true })).then(() => {
				this.updateResult();
				return _classPrivateFieldGet2(_currentResult$1, this);
			});
		}
		createResult(query, options) {
			const prevQuery = _classPrivateFieldGet2(_currentQuery, this);
			const prevOptions = this.options;
			const prevResult = _classPrivateFieldGet2(_currentResult$1, this);
			const prevResultState = _classPrivateFieldGet2(_currentResultState, this);
			const prevResultOptions = _classPrivateFieldGet2(_currentResultOptions, this);
			const queryInitialState = query !== prevQuery ? query.state : _classPrivateFieldGet2(_currentQueryInitialState, this);
			const { state } = query;
			let newState = _objectSpread2({}, state);
			let isPlaceholderData = false;
			let data;
			if (options._optimisticResults) {
				const mounted = this.hasListeners();
				const fetchOnMount = !mounted && shouldFetchOnMount(query, options);
				const fetchOptionally = mounted && shouldFetchOptionally(query, prevQuery, options, prevOptions);
				if (fetchOnMount || fetchOptionally) newState = _objectSpread2(_objectSpread2({}, newState), fetchState(state.data, query.options));
				if (options._optimisticResults === "isRestoring") newState.fetchStatus = "idle";
			}
			let { error, errorUpdatedAt, status } = newState;
			data = newState.data;
			let skipSelect = false;
			if (options.placeholderData !== void 0 && data === void 0 && status === "pending") {
				let placeholderData;
				if ((prevResult === null || prevResult === void 0 ? void 0 : prevResult.isPlaceholderData) && options.placeholderData === (prevResultOptions === null || prevResultOptions === void 0 ? void 0 : prevResultOptions.placeholderData)) {
					placeholderData = prevResult.data;
					skipSelect = true;
				} else {
					var _classPrivateFieldGet2$5;
					placeholderData = typeof options.placeholderData === "function" ? options.placeholderData((_classPrivateFieldGet2$5 = _classPrivateFieldGet2(_lastQueryWithDefinedData, this)) === null || _classPrivateFieldGet2$5 === void 0 ? void 0 : _classPrivateFieldGet2$5.state.data, _classPrivateFieldGet2(_lastQueryWithDefinedData, this)) : options.placeholderData;
				}
				if (placeholderData !== void 0) {
					status = "success";
					data = replaceData(prevResult === null || prevResult === void 0 ? void 0 : prevResult.data, placeholderData, options);
					isPlaceholderData = true;
				}
			}
			if (options.select && data !== void 0 && !skipSelect) {
				if (prevResult && data === (prevResultState === null || prevResultState === void 0 ? void 0 : prevResultState.data) && options.select === _classPrivateFieldGet2(_selectFn, this)) data = _classPrivateFieldGet2(_selectResult, this);
				else try {
					_classPrivateFieldSet2(_selectFn, this, options.select);
					data = options.select(data);
					data = replaceData(prevResult === null || prevResult === void 0 ? void 0 : prevResult.data, data, options);
					_classPrivateFieldSet2(_selectResult, this, data);
					_classPrivateFieldSet2(_selectError, this, null);
				} catch (selectError) {
					_classPrivateFieldSet2(_selectError, this, selectError);
				}
			}
			if (_classPrivateFieldGet2(_selectError, this)) {
				error = _classPrivateFieldGet2(_selectError, this);
				data = _classPrivateFieldGet2(_selectResult, this);
				errorUpdatedAt = Date.now();
				status = "error";
			}
			const isFetching = newState.fetchStatus === "fetching";
			const isPending = status === "pending";
			const isError = status === "error";
			const isLoading = isPending && isFetching;
			const hasData = data !== void 0;
			const nextResult = {
				status,
				fetchStatus: newState.fetchStatus,
				isPending,
				isSuccess: status === "success",
				isError,
				isInitialLoading: isLoading,
				isLoading,
				data,
				dataUpdatedAt: newState.dataUpdatedAt,
				error,
				errorUpdatedAt,
				failureCount: newState.fetchFailureCount,
				failureReason: newState.fetchFailureReason,
				errorUpdateCount: newState.errorUpdateCount,
				isFetched: query.isFetched(),
				isFetchedAfterMount: newState.dataUpdateCount > queryInitialState.dataUpdateCount || newState.errorUpdateCount > queryInitialState.errorUpdateCount,
				isFetching,
				isRefetching: isFetching && !isPending,
				isLoadingError: isError && !hasData,
				isPaused: newState.fetchStatus === "paused",
				isPlaceholderData,
				isRefetchError: isError && hasData,
				isStale: isStale(query, options),
				refetch: this.refetch,
				promise: _classPrivateFieldGet2(_currentThenable, this),
				isEnabled: resolveQueryBoolean(options.enabled, query) !== false
			};
			if (this.options.experimental_prefetchInRender) {
				const hasResultData = nextResult.data !== void 0;
				const isErrorWithoutData = nextResult.status === "error" && !hasResultData;
				const finalizeThenableIfPossible = (thenable) => {
					if (isErrorWithoutData) thenable.reject(nextResult.error);
					else if (hasResultData) thenable.resolve(nextResult.data);
				};
				const recreateThenable = () => {
					const pending = _classPrivateFieldSet2(_currentThenable, this, nextResult.promise = pendingThenable());
					finalizeThenableIfPossible(pending);
				};
				const prevThenable = _classPrivateFieldGet2(_currentThenable, this);
				switch (prevThenable.status) {
					case "pending":
						if (query.queryHash === prevQuery.queryHash) finalizeThenableIfPossible(prevThenable);
						break;
					case "fulfilled":
						if (isErrorWithoutData || nextResult.data !== prevThenable.value) recreateThenable();
						break;
					case "rejected": if (!isErrorWithoutData || nextResult.error !== prevThenable.reason) recreateThenable();
				}
			}
			return nextResult;
		}
		updateResult() {
			const prevResult = _classPrivateFieldGet2(_currentResult$1, this);
			const nextResult = this.createResult(_classPrivateFieldGet2(_currentQuery, this), this.options);
			_classPrivateFieldSet2(_currentResultState, this, _classPrivateFieldGet2(_currentQuery, this).state);
			_classPrivateFieldSet2(_currentResultOptions, this, this.options);
			if (_classPrivateFieldGet2(_currentResultState, this).data !== void 0) _classPrivateFieldSet2(_lastQueryWithDefinedData, this, _classPrivateFieldGet2(_currentQuery, this));
			if (shallowEqualObjects(nextResult, prevResult)) return;
			_classPrivateFieldSet2(_currentResult$1, this, nextResult);
			const shouldNotifyListeners = () => {
				if (!prevResult) return true;
				const { notifyOnChangeProps } = this.options;
				const notifyOnChangePropsValue = typeof notifyOnChangeProps === "function" ? notifyOnChangeProps() : notifyOnChangeProps;
				if (notifyOnChangePropsValue === "all" || !notifyOnChangePropsValue && !_classPrivateFieldGet2(_trackedProps, this).size) return true;
				const includedProps = new Set(notifyOnChangePropsValue !== null && notifyOnChangePropsValue !== void 0 ? notifyOnChangePropsValue : _classPrivateFieldGet2(_trackedProps, this));
				if (this.options.throwOnError) includedProps.add("error");
				return Object.keys(_classPrivateFieldGet2(_currentResult$1, this)).some((key) => {
					const typedKey = key;
					return _classPrivateFieldGet2(_currentResult$1, this)[typedKey] !== prevResult[typedKey] && includedProps.has(typedKey);
				});
			};
			_assertClassBrand(_Class_brand$2, this, _notify$1).call(this, { listeners: shouldNotifyListeners() });
		}
		onQueryUpdate() {
			this.updateResult();
			if (this.hasListeners()) _assertClassBrand(_Class_brand$2, this, _updateTimers).call(this);
		}
	});
	function _executeFetch(fetchOptions) {
		_assertClassBrand(_Class_brand$2, this, _updateQuery).call(this);
		let promise = _classPrivateFieldGet2(_currentQuery, this).fetch(this.options, fetchOptions);
		if (!(fetchOptions === null || fetchOptions === void 0 ? void 0 : fetchOptions.throwOnError)) promise = promise.catch(noop$1);
		return promise;
	}
	function _updateStaleTimeout() {
		_assertClassBrand(_Class_brand$2, this, _clearStaleTimeout).call(this);
		const staleTime = resolveStaleTime(this.options.staleTime, _classPrivateFieldGet2(_currentQuery, this));
		if (environmentManager.isServer() || _classPrivateFieldGet2(_currentResult$1, this).isStale || !isValidTimeout(staleTime)) return;
		const timeout = timeUntilStale(_classPrivateFieldGet2(_currentResult$1, this).dataUpdatedAt, staleTime) + 1;
		_classPrivateFieldSet2(_staleTimeoutId, this, timeoutManager.setTimeout(() => {
			if (!_classPrivateFieldGet2(_currentResult$1, this).isStale) this.updateResult();
		}, timeout));
	}
	function _computeRefetchInterval() {
		var _ref2;
		return (_ref2 = typeof this.options.refetchInterval === "function" ? this.options.refetchInterval(_classPrivateFieldGet2(_currentQuery, this)) : this.options.refetchInterval) !== null && _ref2 !== void 0 ? _ref2 : false;
	}
	function _updateRefetchInterval(nextInterval) {
		_assertClassBrand(_Class_brand$2, this, _clearRefetchInterval).call(this);
		_classPrivateFieldSet2(_currentRefetchInterval, this, nextInterval);
		if (environmentManager.isServer() || resolveQueryBoolean(this.options.enabled, _classPrivateFieldGet2(_currentQuery, this)) === false || !isValidTimeout(_classPrivateFieldGet2(_currentRefetchInterval, this)) || _classPrivateFieldGet2(_currentRefetchInterval, this) === 0) return;
		_classPrivateFieldSet2(_refetchIntervalId, this, timeoutManager.setInterval(() => {
			if (this.options.refetchIntervalInBackground || focusManager.isFocused()) _assertClassBrand(_Class_brand$2, this, _executeFetch).call(this);
		}, _classPrivateFieldGet2(_currentRefetchInterval, this)));
	}
	function _updateTimers() {
		_assertClassBrand(_Class_brand$2, this, _updateStaleTimeout).call(this);
		_assertClassBrand(_Class_brand$2, this, _updateRefetchInterval).call(this, _assertClassBrand(_Class_brand$2, this, _computeRefetchInterval).call(this));
	}
	function _clearStaleTimeout() {
		if (_classPrivateFieldGet2(_staleTimeoutId, this) !== void 0) {
			timeoutManager.clearTimeout(_classPrivateFieldGet2(_staleTimeoutId, this));
			_classPrivateFieldSet2(_staleTimeoutId, this, void 0);
		}
	}
	function _clearRefetchInterval() {
		if (_classPrivateFieldGet2(_refetchIntervalId, this) !== void 0) {
			timeoutManager.clearInterval(_classPrivateFieldGet2(_refetchIntervalId, this));
			_classPrivateFieldSet2(_refetchIntervalId, this, void 0);
		}
	}
	function _updateQuery() {
		const query = _classPrivateFieldGet2(_client$2, this).getQueryCache().build(_classPrivateFieldGet2(_client$2, this), this.options);
		if (query === _classPrivateFieldGet2(_currentQuery, this)) return;
		const prevQuery = _classPrivateFieldGet2(_currentQuery, this);
		_classPrivateFieldSet2(_currentQuery, this, query);
		_classPrivateFieldSet2(_currentQueryInitialState, this, query.state);
		if (this.hasListeners()) {
			prevQuery === null || prevQuery === void 0 || prevQuery.removeObserver(this);
			query.addObserver(this);
		}
	}
	function _notify$1(notifyOptions) {
		notifyManager.batch(() => {
			if (notifyOptions.listeners) this.listeners.forEach((listener) => {
				listener(_classPrivateFieldGet2(_currentResult$1, this));
			});
			_classPrivateFieldGet2(_client$2, this).getQueryCache().notify({
				query: _classPrivateFieldGet2(_currentQuery, this),
				type: "observerResultsUpdated"
			});
		});
	}
	function shouldLoadOnMount(query, options) {
		return resolveQueryBoolean(options.enabled, query) !== false && query.state.data === void 0 && !(query.state.status === "error" && resolveQueryBoolean(options.retryOnMount, query) === false);
	}
	function shouldFetchOnMount(query, options) {
		return shouldLoadOnMount(query, options) || query.state.data !== void 0 && shouldFetchOn(query, options, options.refetchOnMount);
	}
	function shouldFetchOn(query, options, field) {
		if (resolveQueryBoolean(options.enabled, query) !== false && resolveStaleTime(options.staleTime, query) !== "static") {
			const value = typeof field === "function" ? field(query) : field;
			return value === "always" || value !== false && isStale(query, options);
		}
		return false;
	}
	function shouldFetchOptionally(query, prevQuery, options, prevOptions) {
		return (query !== prevQuery || resolveQueryBoolean(prevOptions.enabled, query) === false) && (!options.suspense || query.state.status !== "error") && isStale(query, options);
	}
	function isStale(query, options) {
		return resolveQueryBoolean(options.enabled, query) !== false && query.isStaleByTime(resolveStaleTime(options.staleTime, query));
	}
	function shouldAssignObserverCurrentProperties(observer, optimisticResult) {
		if (!shallowEqualObjects(observer.getCurrentResult(), optimisticResult)) return true;
		return false;
	}
	//#endregion
	//#region node_modules/@tanstack/query-core/build/modern/mutation.js
	init_asyncToGenerator();
	init_objectSpread2();
	var _client$1;
	var _observers;
	var _mutationCache$1;
	var _retryer;
	var _Class_brand$1;
	var Mutation = (_client$1 = /* @__PURE__ */ new WeakMap(), _observers = /* @__PURE__ */ new WeakMap(), _mutationCache$1 = /* @__PURE__ */ new WeakMap(), _retryer = /* @__PURE__ */ new WeakMap(), _Class_brand$1 = /* @__PURE__ */ new WeakSet(), class extends Removable {
		constructor(config) {
			super();
			_classPrivateMethodInitSpec(this, _Class_brand$1);
			_classPrivateFieldInitSpec(this, _client$1, void 0);
			_classPrivateFieldInitSpec(this, _observers, void 0);
			_classPrivateFieldInitSpec(this, _mutationCache$1, void 0);
			_classPrivateFieldInitSpec(this, _retryer, void 0);
			_classPrivateFieldSet2(_client$1, this, config.client);
			this.mutationId = config.mutationId;
			_classPrivateFieldSet2(_mutationCache$1, this, config.mutationCache);
			_classPrivateFieldSet2(_observers, this, []);
			this.state = config.state || getDefaultState();
			this.setOptions(config.options);
			this.scheduleGc();
		}
		setOptions(options) {
			this.options = options;
			this.updateGcTime(this.options.gcTime);
		}
		get meta() {
			return this.options.meta;
		}
		addObserver(observer) {
			if (!_classPrivateFieldGet2(_observers, this).includes(observer)) {
				_classPrivateFieldGet2(_observers, this).push(observer);
				this.clearGcTimeout();
				_classPrivateFieldGet2(_mutationCache$1, this).notify({
					type: "observerAdded",
					mutation: this,
					observer
				});
			}
		}
		removeObserver(observer) {
			_classPrivateFieldSet2(_observers, this, _classPrivateFieldGet2(_observers, this).filter((x) => x !== observer));
			this.scheduleGc();
			_classPrivateFieldGet2(_mutationCache$1, this).notify({
				type: "observerRemoved",
				mutation: this,
				observer
			});
		}
		optionalRemove() {
			if (!_classPrivateFieldGet2(_observers, this).length) {
				if (this.state.status === "pending") this.scheduleGc();
				else _classPrivateFieldGet2(_mutationCache$1, this).remove(this);
			}
		}
		continue() {
			var _this$retryer$continu, _classPrivateFieldGet2$4;
			return (_this$retryer$continu = (_classPrivateFieldGet2$4 = _classPrivateFieldGet2(_retryer, this)) === null || _classPrivateFieldGet2$4 === void 0 ? void 0 : _classPrivateFieldGet2$4.continue()) !== null && _this$retryer$continu !== void 0 ? _this$retryer$continu : this.execute(this.state.variables);
		}
		execute(variables) {
			var _this = this;
			return _asyncToGenerator(function* () {
				var _this$options$retry;
				const onContinue = () => {
					_assertClassBrand(_Class_brand$1, _this, _dispatch).call(_this, { type: "continue" });
				};
				const mutationFnContext = {
					client: _classPrivateFieldGet2(_client$1, _this),
					meta: _this.options.meta,
					mutationKey: _this.options.mutationKey
				};
				_classPrivateFieldSet2(_retryer, _this, createRetryer({
					fn: () => {
						if (!_this.options.mutationFn) return Promise.reject(/* @__PURE__ */ new Error("No mutationFn found"));
						return _this.options.mutationFn(variables, mutationFnContext);
					},
					onFail: (failureCount, error) => {
						_assertClassBrand(_Class_brand$1, _this, _dispatch).call(_this, {
							type: "failed",
							failureCount,
							error
						});
					},
					onPause: () => {
						_assertClassBrand(_Class_brand$1, _this, _dispatch).call(_this, { type: "pause" });
					},
					onContinue,
					retry: (_this$options$retry = _this.options.retry) !== null && _this$options$retry !== void 0 ? _this$options$retry : 0,
					retryDelay: _this.options.retryDelay,
					networkMode: _this.options.networkMode,
					canRun: () => _classPrivateFieldGet2(_mutationCache$1, _this).canRun(_this)
				}));
				const restored = _this.state.status === "pending";
				const isPaused = !_classPrivateFieldGet2(_retryer, _this).canStart();
				try {
					var _classPrivateFieldGet3, _classPrivateFieldGet4, _this$options$onSucce, _this$options2, _classPrivateFieldGet5, _classPrivateFieldGet6, _this$options$onSettl, _this$options3;
					if (restored) onContinue();
					else {
						var _this$options$onMutat, _this$options;
						_assertClassBrand(_Class_brand$1, _this, _dispatch).call(_this, {
							type: "pending",
							variables,
							isPaused
						});
						if (_classPrivateFieldGet2(_mutationCache$1, _this).config.onMutate) yield _classPrivateFieldGet2(_mutationCache$1, _this).config.onMutate(variables, _this, mutationFnContext);
						const context = yield (_this$options$onMutat = (_this$options = _this.options).onMutate) === null || _this$options$onMutat === void 0 ? void 0 : _this$options$onMutat.call(_this$options, variables, mutationFnContext);
						if (context !== _this.state.context) _assertClassBrand(_Class_brand$1, _this, _dispatch).call(_this, {
							type: "pending",
							context,
							variables,
							isPaused
						});
					}
					const data = yield _classPrivateFieldGet2(_retryer, _this).start();
					yield (_classPrivateFieldGet3 = (_classPrivateFieldGet4 = _classPrivateFieldGet2(_mutationCache$1, _this).config).onSuccess) === null || _classPrivateFieldGet3 === void 0 ? void 0 : _classPrivateFieldGet3.call(_classPrivateFieldGet4, data, variables, _this.state.context, _this, mutationFnContext);
					yield (_this$options$onSucce = (_this$options2 = _this.options).onSuccess) === null || _this$options$onSucce === void 0 ? void 0 : _this$options$onSucce.call(_this$options2, data, variables, _this.state.context, mutationFnContext);
					yield (_classPrivateFieldGet5 = (_classPrivateFieldGet6 = _classPrivateFieldGet2(_mutationCache$1, _this).config).onSettled) === null || _classPrivateFieldGet5 === void 0 ? void 0 : _classPrivateFieldGet5.call(_classPrivateFieldGet6, data, null, _this.state.variables, _this.state.context, _this, mutationFnContext);
					yield (_this$options$onSettl = (_this$options3 = _this.options).onSettled) === null || _this$options$onSettl === void 0 ? void 0 : _this$options$onSettl.call(_this$options3, data, null, variables, _this.state.context, mutationFnContext);
					_assertClassBrand(_Class_brand$1, _this, _dispatch).call(_this, {
						type: "success",
						data
					});
					return data;
				} catch (error) {
					try {
						var _classPrivateFieldGet7, _classPrivateFieldGet8;
						yield (_classPrivateFieldGet7 = (_classPrivateFieldGet8 = _classPrivateFieldGet2(_mutationCache$1, _this).config).onError) === null || _classPrivateFieldGet7 === void 0 ? void 0 : _classPrivateFieldGet7.call(_classPrivateFieldGet8, error, variables, _this.state.context, _this, mutationFnContext);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						var _this$options$onError, _this$options4;
						yield (_this$options$onError = (_this$options4 = _this.options).onError) === null || _this$options$onError === void 0 ? void 0 : _this$options$onError.call(_this$options4, error, variables, _this.state.context, mutationFnContext);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						var _classPrivateFieldGet9, _classPrivateFieldGet10;
						yield (_classPrivateFieldGet9 = (_classPrivateFieldGet10 = _classPrivateFieldGet2(_mutationCache$1, _this).config).onSettled) === null || _classPrivateFieldGet9 === void 0 ? void 0 : _classPrivateFieldGet9.call(_classPrivateFieldGet10, void 0, error, _this.state.variables, _this.state.context, _this, mutationFnContext);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						var _this$options$onSettl2, _this$options5;
						yield (_this$options$onSettl2 = (_this$options5 = _this.options).onSettled) === null || _this$options$onSettl2 === void 0 ? void 0 : _this$options$onSettl2.call(_this$options5, void 0, error, variables, _this.state.context, mutationFnContext);
					} catch (e) {
						Promise.reject(e);
					}
					_assertClassBrand(_Class_brand$1, _this, _dispatch).call(_this, {
						type: "error",
						error
					});
					throw error;
				} finally {
					_classPrivateFieldGet2(_mutationCache$1, _this).runNext(_this);
				}
			})();
		}
	});
	function _dispatch(action) {
		const reducer = (state) => {
			switch (action.type) {
				case "failed": return _objectSpread2(_objectSpread2({}, state), {}, {
					failureCount: action.failureCount,
					failureReason: action.error
				});
				case "pause": return _objectSpread2(_objectSpread2({}, state), {}, { isPaused: true });
				case "continue": return _objectSpread2(_objectSpread2({}, state), {}, { isPaused: false });
				case "pending": return _objectSpread2(_objectSpread2({}, state), {}, {
					context: action.context,
					data: void 0,
					failureCount: 0,
					failureReason: null,
					error: null,
					isPaused: action.isPaused,
					status: "pending",
					variables: action.variables,
					submittedAt: Date.now()
				});
				case "success": return _objectSpread2(_objectSpread2({}, state), {}, {
					data: action.data,
					failureCount: 0,
					failureReason: null,
					error: null,
					status: "success",
					isPaused: false
				});
				case "error": return _objectSpread2(_objectSpread2({}, state), {}, {
					data: void 0,
					error: action.error,
					failureCount: state.failureCount + 1,
					failureReason: action.error,
					isPaused: false,
					status: "error"
				});
			}
		};
		this.state = reducer(this.state);
		notifyManager.batch(() => {
			_classPrivateFieldGet2(_observers, this).forEach((observer) => {
				observer.onMutationUpdate(action);
			});
			_classPrivateFieldGet2(_mutationCache$1, this).notify({
				mutation: this,
				type: "updated",
				action
			});
		});
	}
	function getDefaultState() {
		return {
			context: void 0,
			data: void 0,
			error: null,
			failureCount: 0,
			failureReason: null,
			isPaused: false,
			status: "idle",
			variables: void 0,
			submittedAt: 0
		};
	}
	//#endregion
	//#region node_modules/@tanstack/query-core/build/modern/mutationCache.js
	init_objectSpread2();
	var _mutations;
	var _scopes;
	var _mutationId;
	var MutationCache = (_mutations = /* @__PURE__ */ new WeakMap(), _scopes = /* @__PURE__ */ new WeakMap(), _mutationId = /* @__PURE__ */ new WeakMap(), class extends Subscribable {
		constructor(config = {}) {
			super();
			_classPrivateFieldInitSpec(this, _mutations, void 0);
			_classPrivateFieldInitSpec(this, _scopes, void 0);
			_classPrivateFieldInitSpec(this, _mutationId, void 0);
			this.config = config;
			_classPrivateFieldSet2(_mutations, this, /* @__PURE__ */ new Set());
			_classPrivateFieldSet2(_scopes, this, /* @__PURE__ */ new Map());
			_classPrivateFieldSet2(_mutationId, this, 0);
		}
		build(client, options, state) {
			var _this$mutationId;
			const mutation = new Mutation({
				client,
				mutationCache: this,
				mutationId: _classPrivateFieldSet2(_mutationId, this, (_this$mutationId = _classPrivateFieldGet2(_mutationId, this), ++_this$mutationId)),
				options: client.defaultMutationOptions(options),
				state
			});
			this.add(mutation);
			return mutation;
		}
		add(mutation) {
			_classPrivateFieldGet2(_mutations, this).add(mutation);
			const scope = scopeFor(mutation);
			if (typeof scope === "string") {
				const scopedMutations = _classPrivateFieldGet2(_scopes, this).get(scope);
				if (scopedMutations) scopedMutations.push(mutation);
				else _classPrivateFieldGet2(_scopes, this).set(scope, [mutation]);
			}
			this.notify({
				type: "added",
				mutation
			});
		}
		remove(mutation) {
			if (_classPrivateFieldGet2(_mutations, this).delete(mutation)) {
				const scope = scopeFor(mutation);
				if (typeof scope === "string") {
					const scopedMutations = _classPrivateFieldGet2(_scopes, this).get(scope);
					if (scopedMutations) {
						if (scopedMutations.length > 1) {
							const index = scopedMutations.indexOf(mutation);
							if (index !== -1) scopedMutations.splice(index, 1);
						} else if (scopedMutations[0] === mutation) _classPrivateFieldGet2(_scopes, this).delete(scope);
					}
				}
			}
			this.notify({
				type: "removed",
				mutation
			});
		}
		canRun(mutation) {
			const scope = scopeFor(mutation);
			if (typeof scope === "string") {
				const mutationsWithSameScope = _classPrivateFieldGet2(_scopes, this).get(scope);
				const firstPendingMutation = mutationsWithSameScope === null || mutationsWithSameScope === void 0 ? void 0 : mutationsWithSameScope.find((m) => m.state.status === "pending");
				return !firstPendingMutation || firstPendingMutation === mutation;
			} else return true;
		}
		runNext(mutation) {
			const scope = scopeFor(mutation);
			if (typeof scope === "string") {
				var _classPrivateFieldGet2$3, _foundMutation$contin;
				const foundMutation = (_classPrivateFieldGet2$3 = _classPrivateFieldGet2(_scopes, this).get(scope)) === null || _classPrivateFieldGet2$3 === void 0 ? void 0 : _classPrivateFieldGet2$3.find((m) => m !== mutation && m.state.isPaused);
				return (_foundMutation$contin = foundMutation === null || foundMutation === void 0 ? void 0 : foundMutation.continue()) !== null && _foundMutation$contin !== void 0 ? _foundMutation$contin : Promise.resolve();
			} else return Promise.resolve();
		}
		clear() {
			notifyManager.batch(() => {
				_classPrivateFieldGet2(_mutations, this).forEach((mutation) => {
					this.notify({
						type: "removed",
						mutation
					});
				});
				_classPrivateFieldGet2(_mutations, this).clear();
				_classPrivateFieldGet2(_scopes, this).clear();
			});
		}
		getAll() {
			return Array.from(_classPrivateFieldGet2(_mutations, this));
		}
		find(filters) {
			const defaultedFilters = _objectSpread2({ exact: true }, filters);
			return this.getAll().find((mutation) => matchMutation(defaultedFilters, mutation));
		}
		findAll(filters = {}) {
			return this.getAll().filter((mutation) => matchMutation(filters, mutation));
		}
		notify(event) {
			notifyManager.batch(() => {
				this.listeners.forEach((listener) => {
					listener(event);
				});
			});
		}
		resumePausedMutations() {
			const pausedMutations = this.getAll().filter((x) => x.state.isPaused);
			return notifyManager.batch(() => Promise.all(pausedMutations.map((mutation) => mutation.continue().catch(noop$1))));
		}
	});
	function scopeFor(mutation) {
		var _mutation$options$sco;
		return (_mutation$options$sco = mutation.options.scope) === null || _mutation$options$sco === void 0 ? void 0 : _mutation$options$sco.id;
	}
	//#endregion
	//#region node_modules/@tanstack/query-core/build/modern/mutationObserver.js
	init_objectSpread2();
	var _client;
	var _currentResult;
	var _currentMutation;
	var _mutateOptions;
	var _Class_brand;
	var MutationObserver$1 = (_client = /* @__PURE__ */ new WeakMap(), _currentResult = /* @__PURE__ */ new WeakMap(), _currentMutation = /* @__PURE__ */ new WeakMap(), _mutateOptions = /* @__PURE__ */ new WeakMap(), _Class_brand = /* @__PURE__ */ new WeakSet(), class extends Subscribable {
		constructor(client, options) {
			super();
			_classPrivateMethodInitSpec(this, _Class_brand);
			_classPrivateFieldInitSpec(this, _client, void 0);
			_classPrivateFieldInitSpec(this, _currentResult, void 0);
			_classPrivateFieldInitSpec(this, _currentMutation, void 0);
			_classPrivateFieldInitSpec(this, _mutateOptions, void 0);
			_classPrivateFieldSet2(_client, this, client);
			this.setOptions(options);
			this.bindMethods();
			_assertClassBrand(_Class_brand, this, _updateResult).call(this);
		}
		bindMethods() {
			this.mutate = this.mutate.bind(this);
			this.reset = this.reset.bind(this);
		}
		setOptions(options) {
			var _classPrivateFieldGet2$2;
			const prevOptions = this.options;
			this.options = _classPrivateFieldGet2(_client, this).defaultMutationOptions(options);
			if (!shallowEqualObjects(this.options, prevOptions)) _classPrivateFieldGet2(_client, this).getMutationCache().notify({
				type: "observerOptionsUpdated",
				mutation: _classPrivateFieldGet2(_currentMutation, this),
				observer: this
			});
			if ((prevOptions === null || prevOptions === void 0 ? void 0 : prevOptions.mutationKey) && this.options.mutationKey && hashKey(prevOptions.mutationKey) !== hashKey(this.options.mutationKey)) this.reset();
			else if (((_classPrivateFieldGet2$2 = _classPrivateFieldGet2(_currentMutation, this)) === null || _classPrivateFieldGet2$2 === void 0 ? void 0 : _classPrivateFieldGet2$2.state.status) === "pending") _classPrivateFieldGet2(_currentMutation, this).setOptions(this.options);
		}
		onUnsubscribe() {
			if (!this.hasListeners()) {
				var _classPrivateFieldGet3;
				(_classPrivateFieldGet3 = _classPrivateFieldGet2(_currentMutation, this)) === null || _classPrivateFieldGet3 === void 0 || _classPrivateFieldGet3.removeObserver(this);
			}
		}
		onMutationUpdate(action) {
			_assertClassBrand(_Class_brand, this, _updateResult).call(this);
			_assertClassBrand(_Class_brand, this, _notify).call(this, action);
		}
		getCurrentResult() {
			return _classPrivateFieldGet2(_currentResult, this);
		}
		reset() {
			var _classPrivateFieldGet4;
			(_classPrivateFieldGet4 = _classPrivateFieldGet2(_currentMutation, this)) === null || _classPrivateFieldGet4 === void 0 || _classPrivateFieldGet4.removeObserver(this);
			_classPrivateFieldSet2(_currentMutation, this, void 0);
			_assertClassBrand(_Class_brand, this, _updateResult).call(this);
			_assertClassBrand(_Class_brand, this, _notify).call(this);
		}
		mutate(variables, options) {
			var _classPrivateFieldGet5;
			_classPrivateFieldSet2(_mutateOptions, this, options);
			(_classPrivateFieldGet5 = _classPrivateFieldGet2(_currentMutation, this)) === null || _classPrivateFieldGet5 === void 0 || _classPrivateFieldGet5.removeObserver(this);
			_classPrivateFieldSet2(_currentMutation, this, _classPrivateFieldGet2(_client, this).getMutationCache().build(_classPrivateFieldGet2(_client, this), this.options));
			_classPrivateFieldGet2(_currentMutation, this).addObserver(this);
			return _classPrivateFieldGet2(_currentMutation, this).execute(variables);
		}
	});
	function _updateResult() {
		var _this$currentMutation, _classPrivateFieldGet6;
		const state = (_this$currentMutation = (_classPrivateFieldGet6 = _classPrivateFieldGet2(_currentMutation, this)) === null || _classPrivateFieldGet6 === void 0 ? void 0 : _classPrivateFieldGet6.state) !== null && _this$currentMutation !== void 0 ? _this$currentMutation : getDefaultState();
		_classPrivateFieldSet2(_currentResult, this, _objectSpread2(_objectSpread2({}, state), {}, {
			isPending: state.status === "pending",
			isSuccess: state.status === "success",
			isError: state.status === "error",
			isIdle: state.status === "idle",
			mutate: this.mutate,
			reset: this.reset
		}));
	}
	function _notify(action) {
		notifyManager.batch(() => {
			if (_classPrivateFieldGet2(_mutateOptions, this) && this.hasListeners()) {
				const variables = _classPrivateFieldGet2(_currentResult, this).variables;
				const onMutateResult = _classPrivateFieldGet2(_currentResult, this).context;
				const context = {
					client: _classPrivateFieldGet2(_client, this),
					meta: this.options.meta,
					mutationKey: this.options.mutationKey
				};
				if ((action === null || action === void 0 ? void 0 : action.type) === "success") {
					try {
						var _classPrivateFieldGet7, _classPrivateFieldGet8;
						(_classPrivateFieldGet7 = (_classPrivateFieldGet8 = _classPrivateFieldGet2(_mutateOptions, this)).onSuccess) === null || _classPrivateFieldGet7 === void 0 || _classPrivateFieldGet7.call(_classPrivateFieldGet8, action.data, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						var _classPrivateFieldGet9, _classPrivateFieldGet10;
						(_classPrivateFieldGet9 = (_classPrivateFieldGet10 = _classPrivateFieldGet2(_mutateOptions, this)).onSettled) === null || _classPrivateFieldGet9 === void 0 || _classPrivateFieldGet9.call(_classPrivateFieldGet10, action.data, null, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
				} else if ((action === null || action === void 0 ? void 0 : action.type) === "error") {
					try {
						var _classPrivateFieldGet11, _classPrivateFieldGet12;
						(_classPrivateFieldGet11 = (_classPrivateFieldGet12 = _classPrivateFieldGet2(_mutateOptions, this)).onError) === null || _classPrivateFieldGet11 === void 0 || _classPrivateFieldGet11.call(_classPrivateFieldGet12, action.error, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						var _classPrivateFieldGet13, _classPrivateFieldGet14;
						(_classPrivateFieldGet13 = (_classPrivateFieldGet14 = _classPrivateFieldGet2(_mutateOptions, this)).onSettled) === null || _classPrivateFieldGet13 === void 0 || _classPrivateFieldGet13.call(_classPrivateFieldGet14, void 0, action.error, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
				}
			}
			this.listeners.forEach((listener) => {
				listener(_classPrivateFieldGet2(_currentResult, this));
			});
		});
	}
	//#endregion
	//#region node_modules/@tanstack/query-core/build/modern/queryCache.js
	init_objectSpread2();
	var _queries;
	var QueryCache = (_queries = /* @__PURE__ */ new WeakMap(), class extends Subscribable {
		constructor(config = {}) {
			super();
			_classPrivateFieldInitSpec(this, _queries, void 0);
			this.config = config;
			_classPrivateFieldSet2(_queries, this, /* @__PURE__ */ new Map());
		}
		build(client, options, state) {
			var _options$queryHash;
			const queryKey = options.queryKey;
			const queryHash = (_options$queryHash = options.queryHash) !== null && _options$queryHash !== void 0 ? _options$queryHash : hashQueryKeyByOptions(queryKey, options);
			let query = this.get(queryHash);
			if (!query) {
				query = new Query({
					client,
					queryKey,
					queryHash,
					options: client.defaultQueryOptions(options),
					state,
					defaultOptions: client.getQueryDefaults(queryKey)
				});
				this.add(query);
			}
			return query;
		}
		add(query) {
			if (!_classPrivateFieldGet2(_queries, this).has(query.queryHash)) {
				_classPrivateFieldGet2(_queries, this).set(query.queryHash, query);
				this.notify({
					type: "added",
					query
				});
			}
		}
		remove(query) {
			const queryInMap = _classPrivateFieldGet2(_queries, this).get(query.queryHash);
			if (queryInMap) {
				query.destroy();
				if (queryInMap === query) _classPrivateFieldGet2(_queries, this).delete(query.queryHash);
				this.notify({
					type: "removed",
					query
				});
			}
		}
		clear() {
			notifyManager.batch(() => {
				this.getAll().forEach((query) => {
					this.remove(query);
				});
			});
		}
		get(queryHash) {
			return _classPrivateFieldGet2(_queries, this).get(queryHash);
		}
		getAll() {
			return [..._classPrivateFieldGet2(_queries, this).values()];
		}
		find(filters) {
			const defaultedFilters = _objectSpread2({ exact: true }, filters);
			return this.getAll().find((query) => matchQuery(defaultedFilters, query));
		}
		findAll(filters = {}) {
			const queries = this.getAll();
			return Object.keys(filters).length > 0 ? queries.filter((query) => matchQuery(filters, query)) : queries;
		}
		notify(event) {
			notifyManager.batch(() => {
				this.listeners.forEach((listener) => {
					listener(event);
				});
			});
		}
		onFocus() {
			notifyManager.batch(() => {
				this.getAll().forEach((query) => {
					query.onFocus();
				});
			});
		}
		onOnline() {
			notifyManager.batch(() => {
				this.getAll().forEach((query) => {
					query.onOnline();
				});
			});
		}
	});
	//#endregion
	//#region node_modules/@tanstack/query-core/build/modern/queryClient.js
	init_asyncToGenerator();
	init_objectSpread2();
	var _queryCache;
	var _mutationCache;
	var _defaultOptions;
	var _queryDefaults;
	var _mutationDefaults;
	var _mountCount;
	var _unsubscribeFocus;
	var _unsubscribeOnline;
	var QueryClient = (_queryCache = /* @__PURE__ */ new WeakMap(), _mutationCache = /* @__PURE__ */ new WeakMap(), _defaultOptions = /* @__PURE__ */ new WeakMap(), _queryDefaults = /* @__PURE__ */ new WeakMap(), _mutationDefaults = /* @__PURE__ */ new WeakMap(), _mountCount = /* @__PURE__ */ new WeakMap(), _unsubscribeFocus = /* @__PURE__ */ new WeakMap(), _unsubscribeOnline = /* @__PURE__ */ new WeakMap(), class {
		constructor(config = {}) {
			_classPrivateFieldInitSpec(this, _queryCache, void 0);
			_classPrivateFieldInitSpec(this, _mutationCache, void 0);
			_classPrivateFieldInitSpec(this, _defaultOptions, void 0);
			_classPrivateFieldInitSpec(this, _queryDefaults, void 0);
			_classPrivateFieldInitSpec(this, _mutationDefaults, void 0);
			_classPrivateFieldInitSpec(this, _mountCount, void 0);
			_classPrivateFieldInitSpec(this, _unsubscribeFocus, void 0);
			_classPrivateFieldInitSpec(this, _unsubscribeOnline, void 0);
			_classPrivateFieldSet2(_queryCache, this, config.queryCache || new QueryCache());
			_classPrivateFieldSet2(_mutationCache, this, config.mutationCache || new MutationCache());
			_classPrivateFieldSet2(_defaultOptions, this, config.defaultOptions || {});
			_classPrivateFieldSet2(_queryDefaults, this, /* @__PURE__ */ new Map());
			_classPrivateFieldSet2(_mutationDefaults, this, /* @__PURE__ */ new Map());
			_classPrivateFieldSet2(_mountCount, this, 0);
		}
		mount() {
			var _this = this, _this$mountCount;
			_classPrivateFieldSet2(_mountCount, this, (_this$mountCount = _classPrivateFieldGet2(_mountCount, this), _this$mountCount++, _this$mountCount));
			if (_classPrivateFieldGet2(_mountCount, this) !== 1) return;
			_classPrivateFieldSet2(_unsubscribeFocus, this, focusManager.subscribe(function() {
				var _ref = _asyncToGenerator(function* (focused) {
					if (focused) {
						yield _this.resumePausedMutations();
						_classPrivateFieldGet2(_queryCache, _this).onFocus();
					}
				});
				return function(_x) {
					return _ref.apply(this, arguments);
				};
			}()));
			_classPrivateFieldSet2(_unsubscribeOnline, this, onlineManager.subscribe(function() {
				var _ref2 = _asyncToGenerator(function* (online) {
					if (online) {
						yield _this.resumePausedMutations();
						_classPrivateFieldGet2(_queryCache, _this).onOnline();
					}
				});
				return function(_x2) {
					return _ref2.apply(this, arguments);
				};
			}()));
		}
		unmount() {
			var _this$mountCount3, _classPrivateFieldGet2$1, _classPrivateFieldGet3;
			_classPrivateFieldSet2(_mountCount, this, (_this$mountCount3 = _classPrivateFieldGet2(_mountCount, this), _this$mountCount3--, _this$mountCount3));
			if (_classPrivateFieldGet2(_mountCount, this) !== 0) return;
			(_classPrivateFieldGet2$1 = _classPrivateFieldGet2(_unsubscribeFocus, this)) === null || _classPrivateFieldGet2$1 === void 0 || _classPrivateFieldGet2$1.call(this);
			_classPrivateFieldSet2(_unsubscribeFocus, this, void 0);
			(_classPrivateFieldGet3 = _classPrivateFieldGet2(_unsubscribeOnline, this)) === null || _classPrivateFieldGet3 === void 0 || _classPrivateFieldGet3.call(this);
			_classPrivateFieldSet2(_unsubscribeOnline, this, void 0);
		}
		isFetching(filters) {
			return _classPrivateFieldGet2(_queryCache, this).findAll(_objectSpread2(_objectSpread2({}, filters), {}, { fetchStatus: "fetching" })).length;
		}
		isMutating(filters) {
			return _classPrivateFieldGet2(_mutationCache, this).findAll(_objectSpread2(_objectSpread2({}, filters), {}, { status: "pending" })).length;
		}
		/**
		* Imperative (non-reactive) way to retrieve data for a QueryKey.
		* Should only be used in callbacks or functions where reading the latest data is necessary, e.g. for optimistic updates.
		*
		* Hint: Do not use this function inside a component, because it won't receive updates.
		* Use `useQuery` to create a `QueryObserver` that subscribes to changes.
		*/
		getQueryData(queryKey) {
			var _classPrivateFieldGet4;
			const options = this.defaultQueryOptions({ queryKey });
			return (_classPrivateFieldGet4 = _classPrivateFieldGet2(_queryCache, this).get(options.queryHash)) === null || _classPrivateFieldGet4 === void 0 ? void 0 : _classPrivateFieldGet4.state.data;
		}
		ensureQueryData(options) {
			const defaultedOptions = this.defaultQueryOptions(options);
			const query = _classPrivateFieldGet2(_queryCache, this).build(this, defaultedOptions);
			const cachedData = query.state.data;
			if (cachedData === void 0) return this.fetchQuery(options);
			if (options.revalidateIfStale && query.isStaleByTime(resolveStaleTime(defaultedOptions.staleTime, query))) this.prefetchQuery(defaultedOptions);
			return Promise.resolve(cachedData);
		}
		getQueriesData(filters) {
			return _classPrivateFieldGet2(_queryCache, this).findAll(filters).map(({ queryKey, state }) => {
				return [queryKey, state.data];
			});
		}
		setQueryData(queryKey, updater, options) {
			const defaultedOptions = this.defaultQueryOptions({ queryKey });
			const query = _classPrivateFieldGet2(_queryCache, this).get(defaultedOptions.queryHash);
			const data = functionalUpdate(updater, query === null || query === void 0 ? void 0 : query.state.data);
			if (data === void 0) return;
			return _classPrivateFieldGet2(_queryCache, this).build(this, defaultedOptions).setData(data, _objectSpread2(_objectSpread2({}, options), {}, { manual: true }));
		}
		setQueriesData(filters, updater, options) {
			return notifyManager.batch(() => _classPrivateFieldGet2(_queryCache, this).findAll(filters).map(({ queryKey }) => [queryKey, this.setQueryData(queryKey, updater, options)]));
		}
		getQueryState(queryKey) {
			var _classPrivateFieldGet5;
			const options = this.defaultQueryOptions({ queryKey });
			return (_classPrivateFieldGet5 = _classPrivateFieldGet2(_queryCache, this).get(options.queryHash)) === null || _classPrivateFieldGet5 === void 0 ? void 0 : _classPrivateFieldGet5.state;
		}
		removeQueries(filters) {
			const queryCache = _classPrivateFieldGet2(_queryCache, this);
			notifyManager.batch(() => {
				queryCache.findAll(filters).forEach((query) => {
					queryCache.remove(query);
				});
			});
		}
		resetQueries(filters, options) {
			const queryCache = _classPrivateFieldGet2(_queryCache, this);
			return notifyManager.batch(() => {
				queryCache.findAll(filters).forEach((query) => {
					query.reset();
				});
				return this.refetchQueries(_objectSpread2({ type: "active" }, filters), options);
			});
		}
		cancelQueries(filters, cancelOptions = {}) {
			const defaultedCancelOptions = _objectSpread2({ revert: true }, cancelOptions);
			const promises = notifyManager.batch(() => _classPrivateFieldGet2(_queryCache, this).findAll(filters).map((query) => query.cancel(defaultedCancelOptions)));
			return Promise.all(promises).then(noop$1).catch(noop$1);
		}
		invalidateQueries(filters, options = {}) {
			return notifyManager.batch(() => {
				var _ref3, _filters$refetchType;
				_classPrivateFieldGet2(_queryCache, this).findAll(filters).forEach((query) => {
					query.invalidate();
				});
				if ((filters === null || filters === void 0 ? void 0 : filters.refetchType) === "none") return Promise.resolve();
				return this.refetchQueries(_objectSpread2(_objectSpread2({}, filters), {}, { type: (_ref3 = (_filters$refetchType = filters === null || filters === void 0 ? void 0 : filters.refetchType) !== null && _filters$refetchType !== void 0 ? _filters$refetchType : filters === null || filters === void 0 ? void 0 : filters.type) !== null && _ref3 !== void 0 ? _ref3 : "active" }), options);
			});
		}
		refetchQueries(filters, options = {}) {
			var _options$cancelRefetc;
			const fetchOptions = _objectSpread2(_objectSpread2({}, options), {}, { cancelRefetch: (_options$cancelRefetc = options.cancelRefetch) !== null && _options$cancelRefetc !== void 0 ? _options$cancelRefetc : true });
			const promises = notifyManager.batch(() => _classPrivateFieldGet2(_queryCache, this).findAll(filters).filter((query) => !query.isDisabled() && !query.isStatic()).map((query) => {
				let promise = query.fetch(void 0, fetchOptions);
				if (!fetchOptions.throwOnError) promise = promise.catch(noop$1);
				return query.state.fetchStatus === "paused" ? Promise.resolve() : promise;
			}));
			return Promise.all(promises).then(noop$1);
		}
		fetchQuery(options) {
			const defaultedOptions = this.defaultQueryOptions(options);
			if (defaultedOptions.retry === void 0) defaultedOptions.retry = false;
			const query = _classPrivateFieldGet2(_queryCache, this).build(this, defaultedOptions);
			return query.isStaleByTime(resolveStaleTime(defaultedOptions.staleTime, query)) ? query.fetch(defaultedOptions) : Promise.resolve(query.state.data);
		}
		prefetchQuery(options) {
			return this.fetchQuery(options).then(noop$1).catch(noop$1);
		}
		fetchInfiniteQuery(options) {
			options._type = "infinite";
			return this.fetchQuery(options);
		}
		prefetchInfiniteQuery(options) {
			return this.fetchInfiniteQuery(options).then(noop$1).catch(noop$1);
		}
		ensureInfiniteQueryData(options) {
			options._type = "infinite";
			return this.ensureQueryData(options);
		}
		resumePausedMutations() {
			if (onlineManager.isOnline()) return _classPrivateFieldGet2(_mutationCache, this).resumePausedMutations();
			return Promise.resolve();
		}
		getQueryCache() {
			return _classPrivateFieldGet2(_queryCache, this);
		}
		getMutationCache() {
			return _classPrivateFieldGet2(_mutationCache, this);
		}
		getDefaultOptions() {
			return _classPrivateFieldGet2(_defaultOptions, this);
		}
		setDefaultOptions(options) {
			_classPrivateFieldSet2(_defaultOptions, this, options);
		}
		setQueryDefaults(queryKey, options) {
			_classPrivateFieldGet2(_queryDefaults, this).set(hashKey(queryKey), {
				queryKey,
				defaultOptions: options
			});
		}
		getQueryDefaults(queryKey) {
			const defaults = [..._classPrivateFieldGet2(_queryDefaults, this).values()];
			const result = {};
			defaults.forEach((queryDefault) => {
				if (partialMatchKey(queryKey, queryDefault.queryKey)) Object.assign(result, queryDefault.defaultOptions);
			});
			return result;
		}
		setMutationDefaults(mutationKey, options) {
			_classPrivateFieldGet2(_mutationDefaults, this).set(hashKey(mutationKey), {
				mutationKey,
				defaultOptions: options
			});
		}
		getMutationDefaults(mutationKey) {
			const defaults = [..._classPrivateFieldGet2(_mutationDefaults, this).values()];
			const result = {};
			defaults.forEach((queryDefault) => {
				if (partialMatchKey(mutationKey, queryDefault.mutationKey)) Object.assign(result, queryDefault.defaultOptions);
			});
			return result;
		}
		defaultQueryOptions(options) {
			if (options._defaulted) return options;
			const defaultedOptions = _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, _classPrivateFieldGet2(_defaultOptions, this).queries), this.getQueryDefaults(options.queryKey)), options), {}, { _defaulted: true });
			if (!defaultedOptions.queryHash) defaultedOptions.queryHash = hashQueryKeyByOptions(defaultedOptions.queryKey, defaultedOptions);
			if (defaultedOptions.refetchOnReconnect === void 0) defaultedOptions.refetchOnReconnect = defaultedOptions.networkMode !== "always";
			if (defaultedOptions.throwOnError === void 0) defaultedOptions.throwOnError = !!defaultedOptions.suspense;
			if (!defaultedOptions.networkMode && defaultedOptions.persister) defaultedOptions.networkMode = "offlineFirst";
			if (defaultedOptions.queryFn === skipToken) defaultedOptions.enabled = false;
			return defaultedOptions;
		}
		defaultMutationOptions(options) {
			if (options === null || options === void 0 ? void 0 : options._defaulted) return options;
			return _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, _classPrivateFieldGet2(_defaultOptions, this).mutations), (options === null || options === void 0 ? void 0 : options.mutationKey) && this.getMutationDefaults(options.mutationKey)), options), {}, { _defaulted: true });
		}
		clear() {
			_classPrivateFieldGet2(_queryCache, this).clear();
			_classPrivateFieldGet2(_mutationCache, this).clear();
		}
	});
	//#endregion
	//#region node_modules/react/cjs/react-jsx-runtime.production.min.js
	/**
	* @license React
	* react-jsx-runtime.production.min.js
	*
	* Copyright (c) Facebook, Inc. and its affiliates.
	*
	* This source code is licensed under the MIT license found in the
	* LICENSE file in the root directory of this source tree.
	*/
	var require_react_jsx_runtime_production_min = /* @__PURE__ */ __commonJSMin(((exports) => {
		var f = require_react();
		var k = Symbol.for("react.element");
		var l = Symbol.for("react.fragment");
		var m = Object.prototype.hasOwnProperty;
		var n = f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner;
		var p = {
			key: !0,
			ref: !0,
			__self: !0,
			__source: !0
		};
		function q(c, a, g) {
			var b, d = {}, e = null, h = null;
			void 0 !== g && (e = "" + g);
			void 0 !== a.key && (e = "" + a.key);
			void 0 !== a.ref && (h = a.ref);
			for (b in a) m.call(a, b) && !p.hasOwnProperty(b) && (d[b] = a[b]);
			if (c && c.defaultProps) for (b in a = c.defaultProps, a) void 0 === d[b] && (d[b] = a[b]);
			return {
				$$typeof: k,
				type: c,
				key: e,
				ref: h,
				props: d,
				_owner: n.current
			};
		}
		exports.Fragment = l;
		exports.jsx = q;
		exports.jsxs = q;
	}));
	//#endregion
	//#region node_modules/react/jsx-runtime.js
	var require_jsx_runtime = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		module.exports = require_react_jsx_runtime_production_min();
	}));
	//#endregion
	//#region node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js
	var import_jsx_runtime = require_jsx_runtime();
	var QueryClientContext = import_react.createContext(void 0);
	var useQueryClient = (queryClient) => {
		const client = import_react.useContext(QueryClientContext);
		if (queryClient) return queryClient;
		if (!client) throw new Error("No QueryClient set, use QueryClientProvider to set one");
		return client;
	};
	var QueryClientProvider = ({ client, children }) => {
		import_react.useEffect(() => {
			client.mount();
			return () => {
				client.unmount();
			};
		}, [client]);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientContext.Provider, {
			value: client,
			children
		});
	};
	//#endregion
	//#region node_modules/@tanstack/react-query/build/modern/IsRestoringProvider.js
	var IsRestoringContext = import_react.createContext(false);
	var useIsRestoring = () => import_react.useContext(IsRestoringContext);
	IsRestoringContext.Provider;
	//#endregion
	//#region node_modules/@tanstack/react-query/build/modern/QueryErrorResetBoundary.js
	function createValue() {
		let isReset = false;
		return {
			clearReset: () => {
				isReset = false;
			},
			reset: () => {
				isReset = true;
			},
			isReset: () => {
				return isReset;
			}
		};
	}
	var QueryErrorResetBoundaryContext = import_react.createContext(createValue());
	var useQueryErrorResetBoundary = () => import_react.useContext(QueryErrorResetBoundaryContext);
	//#endregion
	//#region node_modules/@tanstack/react-query/build/modern/errorBoundaryUtils.js
	var ensurePreventErrorBoundaryRetry = (options, errorResetBoundary, query) => {
		const throwOnError = (query === null || query === void 0 ? void 0 : query.state.error) && typeof options.throwOnError === "function" ? shouldThrowError(options.throwOnError, [query.state.error, query]) : options.throwOnError;
		if (options.suspense || options.experimental_prefetchInRender || throwOnError) {
			if (!errorResetBoundary.isReset()) options.retryOnMount = false;
		}
	};
	var useClearResetErrorBoundary = (errorResetBoundary) => {
		import_react.useEffect(() => {
			errorResetBoundary.clearReset();
		}, [errorResetBoundary]);
	};
	var getHasError = ({ result, errorResetBoundary, throwOnError, query, suspense }) => {
		return result.isError && !errorResetBoundary.isReset() && !result.isFetching && query && (suspense && result.data === void 0 || shouldThrowError(throwOnError, [result.error, query]));
	};
	//#endregion
	//#region node_modules/@tanstack/react-query/build/modern/suspense.js
	var ensureSuspenseTimers = (defaultedOptions) => {
		if (defaultedOptions.suspense) {
			const MIN_SUSPENSE_TIME_MS = 1e3;
			const clamp = (value) => value === "static" ? value : Math.max(value !== null && value !== void 0 ? value : MIN_SUSPENSE_TIME_MS, MIN_SUSPENSE_TIME_MS);
			const originalStaleTime = defaultedOptions.staleTime;
			defaultedOptions.staleTime = typeof originalStaleTime === "function" ? (...args) => clamp(originalStaleTime(...args)) : clamp(originalStaleTime);
			if (typeof defaultedOptions.gcTime === "number") defaultedOptions.gcTime = Math.max(defaultedOptions.gcTime, MIN_SUSPENSE_TIME_MS);
		}
	};
	var willFetch = (result, isRestoring) => result.isLoading && result.isFetching && !isRestoring;
	var shouldSuspend = (defaultedOptions, result) => (defaultedOptions === null || defaultedOptions === void 0 ? void 0 : defaultedOptions.suspense) && result.isPending;
	var fetchOptimistic = (defaultedOptions, observer, errorResetBoundary) => observer.fetchOptimistic(defaultedOptions).catch(() => {
		errorResetBoundary.clearReset();
	});
	//#endregion
	//#region node_modules/@tanstack/react-query/build/modern/useBaseQuery.js
	function useBaseQuery(options, Observer, queryClient) {
		var _client$getDefaultOpt, _client$getDefaultOpt2, _client$getDefaultOpt3, _client$getDefaultOpt4;
		const isRestoring = useIsRestoring();
		const errorResetBoundary = useQueryErrorResetBoundary();
		const client = useQueryClient(queryClient);
		const defaultedOptions = client.defaultQueryOptions(options);
		(_client$getDefaultOpt = client.getDefaultOptions().queries) === null || _client$getDefaultOpt === void 0 || (_client$getDefaultOpt2 = _client$getDefaultOpt._experimental_beforeQuery) === null || _client$getDefaultOpt2 === void 0 || _client$getDefaultOpt2.call(_client$getDefaultOpt, defaultedOptions);
		const query = client.getQueryCache().get(defaultedOptions.queryHash);
		defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : "optimistic";
		ensureSuspenseTimers(defaultedOptions);
		ensurePreventErrorBoundaryRetry(defaultedOptions, errorResetBoundary, query);
		useClearResetErrorBoundary(errorResetBoundary);
		const isNewCacheEntry = !client.getQueryCache().get(defaultedOptions.queryHash);
		const [observer] = import_react.useState(() => new Observer(client, defaultedOptions));
		const result = observer.getOptimisticResult(defaultedOptions);
		const shouldSubscribe = !isRestoring && options.subscribed !== false;
		import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => {
			const unsubscribe = shouldSubscribe ? observer.subscribe(notifyManager.batchCalls(onStoreChange)) : noop$1;
			observer.updateResult();
			return unsubscribe;
		}, [observer, shouldSubscribe]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
		import_react.useEffect(() => {
			observer.setOptions(defaultedOptions);
		}, [defaultedOptions, observer]);
		if (shouldSuspend(defaultedOptions, result)) throw fetchOptimistic(defaultedOptions, observer, errorResetBoundary);
		if (getHasError({
			result,
			errorResetBoundary,
			throwOnError: defaultedOptions.throwOnError,
			query,
			suspense: defaultedOptions.suspense
		})) throw result.error;
		(_client$getDefaultOpt3 = client.getDefaultOptions().queries) === null || _client$getDefaultOpt3 === void 0 || (_client$getDefaultOpt4 = _client$getDefaultOpt3._experimental_afterQuery) === null || _client$getDefaultOpt4 === void 0 || _client$getDefaultOpt4.call(_client$getDefaultOpt3, defaultedOptions, result);
		if (defaultedOptions.experimental_prefetchInRender && !environmentManager.isServer() && willFetch(result, isRestoring)) {
			const promise = isNewCacheEntry ? fetchOptimistic(defaultedOptions, observer, errorResetBoundary) : query === null || query === void 0 ? void 0 : query.promise;
			promise === null || promise === void 0 || promise.catch(noop$1).finally(() => {
				observer.updateResult();
			});
		}
		return !defaultedOptions.notifyOnChangeProps ? observer.trackResult(result) : result;
	}
	//#endregion
	//#region node_modules/@tanstack/react-query/build/modern/useQuery.js
	function useQuery(options, queryClient) {
		return useBaseQuery(options, QueryObserver, queryClient);
	}
	//#endregion
	//#region node_modules/@tanstack/react-query/build/modern/useMutation.js
	init_objectSpread2();
	function useMutation(options, queryClient) {
		const client = useQueryClient(queryClient);
		const [observer] = import_react.useState(() => new MutationObserver$1(client, options));
		import_react.useEffect(() => {
			observer.setOptions(options);
		}, [observer, options]);
		const result = import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => observer.subscribe(notifyManager.batchCalls(onStoreChange)), [observer]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
		const mutate = import_react.useCallback((variables, mutateOptions) => {
			observer.mutate(variables, mutateOptions).catch(noop$1);
		}, [observer]);
		if (result.error && shouldThrowError(observer.options.throwOnError, [result.error])) throw result.error;
		return _objectSpread2(_objectSpread2({}, result), {}, {
			mutate,
			mutateAsync: result.mutate
		});
	}
	//#endregion
	//#region src/lib/api.ts
	var import_client = /* @__PURE__ */ __toESM(require_client());
	init_asyncToGenerator();
	init_objectSpread2();
	var CATALOGUE_URL = "/apcatalogue.json";
	function hexToRgb(hex) {
		const h = hex.replace("#", "");
		return [
			parseInt(h.slice(0, 2), 16),
			parseInt(h.slice(2, 4), 16),
			parseInt(h.slice(4, 6), 16)
		];
	}
	function computeLrv(r, g, b) {
		const lin = (c) => {
			const s = c / 255;
			return s <= .04045 ? s / 12.92 : Math.pow((s + .055) / 1.055, 2.4);
		};
		return Math.round((.2126 * lin(r) + .7152 * lin(g) + .0722 * lin(b)) * 100);
	}
	function capitalize(str) {
		return str.replace(/\b\w/g, (c) => c.toUpperCase());
	}
	var FAMILY_META = {
		"off whites": {
			order: 1,
			hex: "#F5F0E8"
		},
		whites: {
			order: 2,
			hex: "#FAFAFA"
		},
		pinks: {
			order: 3,
			hex: "#F48FB1"
		},
		reds: {
			order: 4,
			hex: "#C62828"
		},
		oranges: {
			order: 5,
			hex: "#E65100"
		},
		yellows: {
			order: 6,
			hex: "#F9A825"
		},
		greens: {
			order: 7,
			hex: "#2E7D32"
		},
		blues: {
			order: 8,
			hex: "#1565C0"
		},
		purples: {
			order: 9,
			hex: "#6A1B9A"
		},
		browns: {
			order: 10,
			hex: "#5D4037"
		},
		greys: {
			order: 11,
			hex: "#9E9E9E"
		}
	};
	var _families = null;
	var _colors = null;
	function loadData() {
		return _loadData.apply(this, arguments);
	}
	function _loadData() {
		_loadData = _asyncToGenerator(function* () {
			var _json$shade;
			if (_families && _colors) return {
				families: _families,
				colors: _colors
			};
			const res = yield fetch(CATALOGUE_URL);
			if (!res.ok) throw new Error(`Failed to fetch catalogue: ${res.status}`);
			const shades = (_json$shade = (yield res.json()).shade) !== null && _json$shade !== void 0 ? _json$shade : [];
			const familyCounts = {};
			const familyHexMap = {};
			const colors = shades.map((s, i) => {
				var _familyCounts$family, _s$filterTitle, _ft$colorTemperature, _ft$tonality;
				const hex = s.shadeHexCode || "#CCCCCC";
				const [r, g, b] = hexToRgb(hex);
				const family = s.shadeFamily.toLowerCase();
				familyCounts[family] = ((_familyCounts$family = familyCounts[family]) !== null && _familyCounts$family !== void 0 ? _familyCounts$family : 0) + 1;
				if (!familyHexMap[family]) familyHexMap[family] = hex;
				const ft = (_s$filterTitle = s.filterTitle) !== null && _s$filterTitle !== void 0 ? _s$filterTitle : {};
				const tags = [...(_ft$colorTemperature = ft["color temperature"]) !== null && _ft$colorTemperature !== void 0 ? _ft$colorTemperature : [], ...(_ft$tonality = ft.tonality) !== null && _ft$tonality !== void 0 ? _ft$tonality : []];
				const isPopular = s.featureTag === "Recommended" || parseInt(s.popularity) <= 10;
				return {
					id: i + 1,
					code: s.entityCode,
					name: capitalize(s.entityName),
					hexValue: hex,
					rgbR: r,
					rgbG: g,
					rgbB: b,
					lrv: computeLrv(r, g, b),
					colorFamilyId: 0,
					colorFamilyName: capitalize(family),
					collection: s.featureTag || "",
					pageUrl: s.pageUrl || "",
					positionNumber: parseInt(s.positionNumber) || i + 1,
					pageNumber: parseInt(s.pageNumber) || 0,
					tags,
					isPopular
				};
			});
			const familyNames = [...new Set(shades.map((s) => s.shadeFamily.toLowerCase()))];
			familyNames.sort((a, b) => {
				var _FAMILY_META$a$order, _FAMILY_META$a, _FAMILY_META$b$order, _FAMILY_META$b;
				return ((_FAMILY_META$a$order = (_FAMILY_META$a = FAMILY_META[a]) === null || _FAMILY_META$a === void 0 ? void 0 : _FAMILY_META$a.order) !== null && _FAMILY_META$a$order !== void 0 ? _FAMILY_META$a$order : 99) - ((_FAMILY_META$b$order = (_FAMILY_META$b = FAMILY_META[b]) === null || _FAMILY_META$b === void 0 ? void 0 : _FAMILY_META$b.order) !== null && _FAMILY_META$b$order !== void 0 ? _FAMILY_META$b$order : 99);
			});
			const familyIdMap = {};
			const families = familyNames.map((name, i) => {
				var _FAMILY_META$name$ord, _FAMILY_META$name, _ref, _FAMILY_META$name$hex, _FAMILY_META$name2, _familyCounts$name;
				familyIdMap[name] = i + 1;
				return {
					id: i + 1,
					name: capitalize(name),
					displayOrder: (_FAMILY_META$name$ord = (_FAMILY_META$name = FAMILY_META[name]) === null || _FAMILY_META$name === void 0 ? void 0 : _FAMILY_META$name.order) !== null && _FAMILY_META$name$ord !== void 0 ? _FAMILY_META$name$ord : i + 1,
					representativeHex: (_ref = (_FAMILY_META$name$hex = (_FAMILY_META$name2 = FAMILY_META[name]) === null || _FAMILY_META$name2 === void 0 ? void 0 : _FAMILY_META$name2.hex) !== null && _FAMILY_META$name$hex !== void 0 ? _FAMILY_META$name$hex : familyHexMap[name]) !== null && _ref !== void 0 ? _ref : "#CCCCCC",
					colorCount: (_familyCounts$name = familyCounts[name]) !== null && _familyCounts$name !== void 0 ? _familyCounts$name : 0
				};
			});
			for (const c of colors) {
				var _familyIdMap$c$colorF;
				c.colorFamilyId = (_familyIdMap$c$colorF = familyIdMap[c.colorFamilyName.toLowerCase()]) !== null && _familyIdMap$c$colorF !== void 0 ? _familyIdMap$c$colorF : 1;
			}
			_families = families;
			_colors = colors;
			return {
				families,
				colors
			};
		});
		return _loadData.apply(this, arguments);
	}
	function sortColors(arr, sort) {
		const [field, dir] = sort.split(",");
		return [...arr].sort((a, b) => {
			const av = a[field];
			const bv = b[field];
			return dir === "desc" ? bv - av : av - bv;
		});
	}
	function paginate(items, page, size) {
		return {
			content: items.slice(page * size, (page + 1) * size),
			totalElements: items.length,
			totalPages: Math.ceil(items.length / size),
			size,
			number: page,
			first: page === 0,
			last: (page + 1) * size >= items.length
		};
	}
	function getSimilar(target, all) {
		return all.filter((c) => c.pageNumber === target.pageNumber && c.id !== target.id).sort((a, b) => a.positionNumber - b.positionNumber);
	}
	function getPageSiblings(target, all) {
		return all.filter((c) => c.pageNumber === target.pageNumber).sort((a, b) => a.positionNumber - b.positionNumber);
	}
	var shortlistStore = /* @__PURE__ */ new Map();
	function getOrCreate(sid) {
		if (!shortlistStore.has(sid)) shortlistStore.set(sid, /* @__PURE__ */ new Set());
		return shortlistStore.get(sid);
	}
	var api = {
		families: {
			getAll: function() {
				var _ref2 = _asyncToGenerator(function* () {
					const { families } = yield loadData();
					return families;
				});
				return function getAll() {
					return _ref2.apply(this, arguments);
				};
			}(),
			getColors: function() {
				var _ref3 = _asyncToGenerator(function* (familyId, page = 0, size = 20, sort = "lrv,asc") {
					const { colors } = yield loadData();
					return paginate(sortColors(colors.filter((c) => c.colorFamilyId === familyId), sort), page, size);
				});
				return function getColors(_x) {
					return _ref3.apply(this, arguments);
				};
			}()
		},
		colors: {
			search: function() {
				var _ref4 = _asyncToGenerator(function* (params) {
					const { colors } = yield loadData();
					const { family, collection, tag, q, page = 0, size = 20 } = params;
					let r = colors;
					if (family) r = r.filter((c) => c.colorFamilyId === family);
					if (collection) r = r.filter((c) => c.collection === collection);
					if (tag) r = r.filter((c) => c.tags.includes(tag));
					if (q) {
						const lq = q.toLowerCase();
						r = r.filter((c) => c.name.toLowerCase().includes(lq) || c.code.toLowerCase().includes(lq));
					}
					return paginate(r, page, size);
				});
				return function search(_x2) {
					return _ref4.apply(this, arguments);
				};
			}(),
			getAll: function() {
				var _ref5 = _asyncToGenerator(function* () {
					const { colors } = yield loadData();
					return colors;
				});
				return function getAll() {
					return _ref5.apply(this, arguments);
				};
			}(),
			getById: function() {
				var _ref6 = _asyncToGenerator(function* (id) {
					const { colors } = yield loadData();
					const color = colors.find((c) => c.id === id);
					if (!color) throw new Error(`Color ${id} not found`);
					return _objectSpread2(_objectSpread2({}, color), {}, { complementary: getSimilar(color, colors) });
				});
				return function getById(_x3) {
					return _ref6.apply(this, arguments);
				};
			}(),
			getSimilar: function() {
				var _ref7 = _asyncToGenerator(function* (id) {
					const { colors } = yield loadData();
					const color = colors.find((c) => c.id === id);
					return color ? getSimilar(color, colors) : [];
				});
				return function getSimilar(_x4) {
					return _ref7.apply(this, arguments);
				};
			}(),
			getPageSiblings: function() {
				var _ref8 = _asyncToGenerator(function* (id) {
					const { colors } = yield loadData();
					const color = colors.find((c) => c.id === id);
					return color ? getPageSiblings(color, colors) : [];
				});
				return function getPageSiblings(_x5) {
					return _ref8.apply(this, arguments);
				};
			}()
		},
		shortlist: {
			create: function() {
				var _ref9 = _asyncToGenerator(function* (data) {
					const { colors } = yield loadData();
					const set = getOrCreate(data.sessionId);
					data.colorIds.forEach((id) => set.add(id));
					return {
						sessionId: data.sessionId,
						colors: [...set].map((id) => colors.find((c) => c.id === id)).filter(Boolean),
						updatedAt: (/* @__PURE__ */ new Date()).toISOString()
					};
				});
				return function create(_x6) {
					return _ref9.apply(this, arguments);
				};
			}(),
			get: function() {
				var _ref10 = _asyncToGenerator(function* (sessionId) {
					const { colors } = yield loadData();
					return {
						sessionId,
						colors: [...getOrCreate(sessionId)].map((id) => colors.find((c) => c.id === id)).filter(Boolean),
						updatedAt: (/* @__PURE__ */ new Date()).toISOString()
					};
				});
				return function get(_x7) {
					return _ref10.apply(this, arguments);
				};
			}(),
			remove: function() {
				var _ref11 = _asyncToGenerator(function* (sessionId, colorId) {
					getOrCreate(sessionId).delete(colorId);
				});
				return function remove(_x8, _x9) {
					return _ref11.apply(this, arguments);
				};
			}()
		}
	};
	//#endregion
	//#region node_modules/zustand/esm/vanilla.mjs
	var createStoreImpl = (createState) => {
		let state;
		const listeners = /* @__PURE__ */ new Set();
		const setState = (partial, replace) => {
			const nextState = typeof partial === "function" ? partial(state) : partial;
			if (!Object.is(nextState, state)) {
				const previousState = state;
				state = (replace != null ? replace : typeof nextState !== "object" || nextState === null) ? nextState : Object.assign({}, state, nextState);
				listeners.forEach((listener) => listener(state, previousState));
			}
		};
		const getState = () => state;
		const getInitialState = () => initialState;
		const subscribe = (listener) => {
			listeners.add(listener);
			return () => listeners.delete(listener);
		};
		const destroy = () => {
			listeners.clear();
		};
		const api = {
			setState,
			getState,
			getInitialState,
			subscribe,
			destroy
		};
		const initialState = state = createState(setState, getState, api);
		return api;
	};
	var createStore = (createState) => createState ? createStoreImpl(createState) : createStoreImpl;
	//#endregion
	//#region node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.production.js
	/**
	* @license React
	* use-sync-external-store-shim.production.js
	*
	* Copyright (c) Meta Platforms, Inc. and affiliates.
	*
	* This source code is licensed under the MIT license found in the
	* LICENSE file in the root directory of this source tree.
	*/
	var require_use_sync_external_store_shim_production = /* @__PURE__ */ __commonJSMin(((exports) => {
		var React = require_react();
		function is(x, y) {
			return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
		}
		var objectIs = "function" === typeof Object.is ? Object.is : is;
		var useState = React.useState;
		var useEffect = React.useEffect;
		var useLayoutEffect = React.useLayoutEffect;
		var useDebugValue = React.useDebugValue;
		function useSyncExternalStore$2(subscribe, getSnapshot) {
			var value = getSnapshot(), _useState = useState({ inst: {
				value,
				getSnapshot
			} }), inst = _useState[0].inst, forceUpdate = _useState[1];
			useLayoutEffect(function() {
				inst.value = value;
				inst.getSnapshot = getSnapshot;
				checkIfSnapshotChanged(inst) && forceUpdate({ inst });
			}, [
				subscribe,
				value,
				getSnapshot
			]);
			useEffect(function() {
				checkIfSnapshotChanged(inst) && forceUpdate({ inst });
				return subscribe(function() {
					checkIfSnapshotChanged(inst) && forceUpdate({ inst });
				});
			}, [subscribe]);
			useDebugValue(value);
			return value;
		}
		function checkIfSnapshotChanged(inst) {
			var latestGetSnapshot = inst.getSnapshot;
			inst = inst.value;
			try {
				var nextValue = latestGetSnapshot();
				return !objectIs(inst, nextValue);
			} catch (error) {
				return !0;
			}
		}
		function useSyncExternalStore$1(subscribe, getSnapshot) {
			return getSnapshot();
		}
		var shim = "undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? useSyncExternalStore$1 : useSyncExternalStore$2;
		exports.useSyncExternalStore = void 0 !== React.useSyncExternalStore ? React.useSyncExternalStore : shim;
	}));
	//#endregion
	//#region node_modules/use-sync-external-store/shim/index.js
	var require_shim = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		module.exports = require_use_sync_external_store_shim_production();
	}));
	//#endregion
	//#region node_modules/use-sync-external-store/cjs/use-sync-external-store-shim/with-selector.production.js
	/**
	* @license React
	* use-sync-external-store-shim/with-selector.production.js
	*
	* Copyright (c) Meta Platforms, Inc. and affiliates.
	*
	* This source code is licensed under the MIT license found in the
	* LICENSE file in the root directory of this source tree.
	*/
	var require_with_selector_production = /* @__PURE__ */ __commonJSMin(((exports) => {
		var React = require_react();
		var shim = require_shim();
		function is(x, y) {
			return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
		}
		var objectIs = "function" === typeof Object.is ? Object.is : is;
		var useSyncExternalStore = shim.useSyncExternalStore;
		var useRef = React.useRef;
		var useEffect = React.useEffect;
		var useMemo = React.useMemo;
		var useDebugValue = React.useDebugValue;
		exports.useSyncExternalStoreWithSelector = function(subscribe, getSnapshot, getServerSnapshot, selector, isEqual) {
			var instRef = useRef(null);
			if (null === instRef.current) {
				var inst = {
					hasValue: !1,
					value: null
				};
				instRef.current = inst;
			} else inst = instRef.current;
			instRef = useMemo(function() {
				function memoizedSelector(nextSnapshot) {
					if (!hasMemo) {
						hasMemo = !0;
						memoizedSnapshot = nextSnapshot;
						nextSnapshot = selector(nextSnapshot);
						if (void 0 !== isEqual && inst.hasValue) {
							var currentSelection = inst.value;
							if (isEqual(currentSelection, nextSnapshot)) return memoizedSelection = currentSelection;
						}
						return memoizedSelection = nextSnapshot;
					}
					currentSelection = memoizedSelection;
					if (objectIs(memoizedSnapshot, nextSnapshot)) return currentSelection;
					var nextSelection = selector(nextSnapshot);
					if (void 0 !== isEqual && isEqual(currentSelection, nextSelection)) return memoizedSnapshot = nextSnapshot, currentSelection;
					memoizedSnapshot = nextSnapshot;
					return memoizedSelection = nextSelection;
				}
				var hasMemo = !1, memoizedSnapshot, memoizedSelection, maybeGetServerSnapshot = void 0 === getServerSnapshot ? null : getServerSnapshot;
				return [function() {
					return memoizedSelector(getSnapshot());
				}, null === maybeGetServerSnapshot ? void 0 : function() {
					return memoizedSelector(maybeGetServerSnapshot());
				}];
			}, [
				getSnapshot,
				getServerSnapshot,
				selector,
				isEqual
			]);
			var value = useSyncExternalStore(subscribe, instRef[0], instRef[1]);
			useEffect(function() {
				inst.hasValue = !0;
				inst.value = value;
			}, [value]);
			useDebugValue(value);
			return value;
		};
	}));
	//#endregion
	//#region node_modules/zustand/esm/index.mjs
	var import_with_selector = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
		module.exports = require_with_selector_production();
	})))(), 1);
	var { useDebugValue } = import_react.default;
	var { useSyncExternalStoreWithSelector } = import_with_selector.default;
	var identity = (arg) => arg;
	function useStore(api, selector = identity, equalityFn) {
		const slice = useSyncExternalStoreWithSelector(api.subscribe, api.getState, api.getServerState || api.getInitialState, selector, equalityFn);
		useDebugValue(slice);
		return slice;
	}
	var createImpl = (createState) => {
		const api = typeof createState === "function" ? createStore(createState) : createState;
		const useBoundStore = (selector, equalityFn) => useStore(api, selector, equalityFn);
		Object.assign(useBoundStore, api);
		return useBoundStore;
	};
	var create = (createState) => createState ? createImpl(createState) : createImpl;
	//#endregion
	//#region node_modules/zustand/esm/middleware.mjs
	init_objectSpread2();
	function createJSONStorage(getStorage, options) {
		let storage;
		try {
			storage = getStorage();
		} catch (_e) {
			return;
		}
		return {
			getItem: (name) => {
				var _a;
				const parse = (str2) => {
					if (str2 === null) return null;
					return JSON.parse(str2, options == null ? void 0 : options.reviver);
				};
				const str = (_a = storage.getItem(name)) != null ? _a : null;
				if (str instanceof Promise) return str.then(parse);
				return parse(str);
			},
			setItem: (name, newValue) => storage.setItem(name, JSON.stringify(newValue, options == null ? void 0 : options.replacer)),
			removeItem: (name) => storage.removeItem(name)
		};
	}
	var toThenable = (fn) => (input) => {
		try {
			const result = fn(input);
			if (result instanceof Promise) return result;
			return {
				then(onFulfilled) {
					return toThenable(onFulfilled)(result);
				},
				catch(_onRejected) {
					return this;
				}
			};
		} catch (e) {
			return {
				then(_onFulfilled) {
					return this;
				},
				catch(onRejected) {
					return toThenable(onRejected)(e);
				}
			};
		}
	};
	var oldImpl = (config, baseOptions) => (set, get, api) => {
		let options = _objectSpread2({
			getStorage: () => localStorage,
			serialize: JSON.stringify,
			deserialize: JSON.parse,
			partialize: (state) => state,
			version: 0,
			merge: (persistedState, currentState) => _objectSpread2(_objectSpread2({}, currentState), persistedState)
		}, baseOptions);
		let hasHydrated = false;
		const hydrationListeners = /* @__PURE__ */ new Set();
		const finishHydrationListeners = /* @__PURE__ */ new Set();
		let storage;
		try {
			storage = options.getStorage();
		} catch (_e) {}
		if (!storage) return config((...args) => {
			console.warn(`[zustand persist middleware] Unable to update item '${options.name}', the given storage is currently unavailable.`);
			set(...args);
		}, get, api);
		const thenableSerialize = toThenable(options.serialize);
		const setItem = () => {
			const state = options.partialize(_objectSpread2({}, get()));
			let errorInSync;
			const thenable = thenableSerialize({
				state,
				version: options.version
			}).then((serializedValue) => storage.setItem(options.name, serializedValue)).catch((e) => {
				errorInSync = e;
			});
			if (errorInSync) throw errorInSync;
			return thenable;
		};
		const savedSetState = api.setState;
		api.setState = (state, replace) => {
			savedSetState(state, replace);
			setItem();
		};
		const configResult = config((...args) => {
			set(...args);
			setItem();
		}, get, api);
		let stateFromStorage;
		const hydrate = () => {
			var _a;
			if (!storage) return;
			hasHydrated = false;
			hydrationListeners.forEach((cb) => cb(get()));
			const postRehydrationCallback = ((_a = options.onRehydrateStorage) == null ? void 0 : _a.call(options, get())) || void 0;
			return toThenable(storage.getItem.bind(storage))(options.name).then((storageValue) => {
				if (storageValue) return options.deserialize(storageValue);
			}).then((deserializedStorageValue) => {
				if (deserializedStorageValue) {
					if (typeof deserializedStorageValue.version === "number" && deserializedStorageValue.version !== options.version) {
						if (options.migrate) return options.migrate(deserializedStorageValue.state, deserializedStorageValue.version);
						console.error(`State loaded from storage couldn't be migrated since no migrate function was provided`);
					} else return deserializedStorageValue.state;
				}
			}).then((migratedState) => {
				var _a2;
				stateFromStorage = options.merge(migratedState, (_a2 = get()) != null ? _a2 : configResult);
				set(stateFromStorage, true);
				return setItem();
			}).then(() => {
				postRehydrationCallback == null || postRehydrationCallback(stateFromStorage, void 0);
				hasHydrated = true;
				finishHydrationListeners.forEach((cb) => cb(stateFromStorage));
			}).catch((e) => {
				postRehydrationCallback == null || postRehydrationCallback(void 0, e);
			});
		};
		api.persist = {
			setOptions: (newOptions) => {
				options = _objectSpread2(_objectSpread2({}, options), newOptions);
				if (newOptions.getStorage) storage = newOptions.getStorage();
			},
			clearStorage: () => {
				storage == null || storage.removeItem(options.name);
			},
			getOptions: () => options,
			rehydrate: () => hydrate(),
			hasHydrated: () => hasHydrated,
			onHydrate: (cb) => {
				hydrationListeners.add(cb);
				return () => {
					hydrationListeners.delete(cb);
				};
			},
			onFinishHydration: (cb) => {
				finishHydrationListeners.add(cb);
				return () => {
					finishHydrationListeners.delete(cb);
				};
			}
		};
		hydrate();
		return stateFromStorage || configResult;
	};
	var newImpl = (config, baseOptions) => (set, get, api) => {
		let options = _objectSpread2({
			storage: createJSONStorage(() => localStorage),
			partialize: (state) => state,
			version: 0,
			merge: (persistedState, currentState) => _objectSpread2(_objectSpread2({}, currentState), persistedState)
		}, baseOptions);
		let hasHydrated = false;
		const hydrationListeners = /* @__PURE__ */ new Set();
		const finishHydrationListeners = /* @__PURE__ */ new Set();
		let storage = options.storage;
		if (!storage) return config((...args) => {
			console.warn(`[zustand persist middleware] Unable to update item '${options.name}', the given storage is currently unavailable.`);
			set(...args);
		}, get, api);
		const setItem = () => {
			const state = options.partialize(_objectSpread2({}, get()));
			return storage.setItem(options.name, {
				state,
				version: options.version
			});
		};
		const savedSetState = api.setState;
		api.setState = (state, replace) => {
			savedSetState(state, replace);
			setItem();
		};
		const configResult = config((...args) => {
			set(...args);
			setItem();
		}, get, api);
		api.getInitialState = () => configResult;
		let stateFromStorage;
		const hydrate = () => {
			var _a, _b;
			if (!storage) return;
			hasHydrated = false;
			hydrationListeners.forEach((cb) => {
				var _a2;
				return cb((_a2 = get()) != null ? _a2 : configResult);
			});
			const postRehydrationCallback = ((_b = options.onRehydrateStorage) == null ? void 0 : _b.call(options, (_a = get()) != null ? _a : configResult)) || void 0;
			return toThenable(storage.getItem.bind(storage))(options.name).then((deserializedStorageValue) => {
				if (deserializedStorageValue) {
					if (typeof deserializedStorageValue.version === "number" && deserializedStorageValue.version !== options.version) {
						if (options.migrate) return [true, options.migrate(deserializedStorageValue.state, deserializedStorageValue.version)];
						console.error(`State loaded from storage couldn't be migrated since no migrate function was provided`);
					} else return [false, deserializedStorageValue.state];
				}
				return [false, void 0];
			}).then((migrationResult) => {
				var _a2;
				const [migrated, migratedState] = migrationResult;
				stateFromStorage = options.merge(migratedState, (_a2 = get()) != null ? _a2 : configResult);
				set(stateFromStorage, true);
				if (migrated) return setItem();
			}).then(() => {
				postRehydrationCallback == null || postRehydrationCallback(stateFromStorage, void 0);
				stateFromStorage = get();
				hasHydrated = true;
				finishHydrationListeners.forEach((cb) => cb(stateFromStorage));
			}).catch((e) => {
				postRehydrationCallback == null || postRehydrationCallback(void 0, e);
			});
		};
		api.persist = {
			setOptions: (newOptions) => {
				options = _objectSpread2(_objectSpread2({}, options), newOptions);
				if (newOptions.storage) storage = newOptions.storage;
			},
			clearStorage: () => {
				storage == null || storage.removeItem(options.name);
			},
			getOptions: () => options,
			rehydrate: () => hydrate(),
			hasHydrated: () => hasHydrated,
			onHydrate: (cb) => {
				hydrationListeners.add(cb);
				return () => {
					hydrationListeners.delete(cb);
				};
			},
			onFinishHydration: (cb) => {
				finishHydrationListeners.add(cb);
				return () => {
					finishHydrationListeners.delete(cb);
				};
			}
		};
		if (!options.skipHydration) hydrate();
		return stateFromStorage || configResult;
	};
	var persistImpl = (config, baseOptions) => {
		if ("getStorage" in baseOptions || "serialize" in baseOptions || "deserialize" in baseOptions) return oldImpl(config, baseOptions);
		return newImpl(config, baseOptions);
	};
	var persist = persistImpl;
	//#endregion
	//#region src/store/useFandeckStore.ts
	function generateSessionId() {
		if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
		return `session-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
	}
	var useFandeckStore = create()(persist((set, get) => ({
		selectedFamilyId: null,
		setSelectedFamilyId: (id) => set({
			selectedFamilyId: id,
			fanPage: 0
		}),
		activeShade: null,
		setActiveShade: (color) => set({ activeShade: color }),
		sessionId: generateSessionId(),
		shortlistedIds: [],
		addToShortlist: (colorId) => set((state) => ({ shortlistedIds: state.shortlistedIds.includes(colorId) ? state.shortlistedIds : [...state.shortlistedIds, colorId] })),
		removeFromShortlist: (colorId) => set((state) => ({ shortlistedIds: state.shortlistedIds.filter((id) => id !== colorId) })),
		isShortlisted: (colorId) => get().shortlistedIds.includes(colorId),
		searchQuery: "",
		setSearchQuery: (q) => set({ searchQuery: q }),
		fanPage: 0,
		setFanPage: (page) => set({ fanPage: page })
	}), {
		name: "fandeck-storage",
		partialize: (state) => ({
			sessionId: state.sessionId,
			shortlistedIds: state.shortlistedIds
		})
	}));
	//#endregion
	//#region node_modules/framer-motion/dist/es/context/LayoutGroupContext.mjs
	var LayoutGroupContext = (0, import_react.createContext)({});
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/use-constant.mjs
	/**
	* Creates a constant value over the lifecycle of a component.
	*
	* Even if `useMemo` is provided an empty array as its final argument, it doesn't offer
	* a guarantee that it won't re-run for performance reasons later on. By using `useConstant`
	* you can ensure that initialisers don't execute twice or more.
	*/
	function useConstant(init) {
		const ref = (0, import_react.useRef)(null);
		if (ref.current === null) ref.current = init();
		return ref.current;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/context/PresenceContext.mjs
	/**
	* @public
	*/
	var PresenceContext = (0, import_react.createContext)(null);
	//#endregion
	//#region node_modules/framer-motion/dist/es/context/MotionConfigContext.mjs
	/**
	* @public
	*/
	var MotionConfigContext = (0, import_react.createContext)({
		transformPagePoint: (p) => p,
		isStatic: false,
		reducedMotion: "never"
	});
	//#endregion
	//#region node_modules/framer-motion/dist/es/components/AnimatePresence/PopChild.mjs
	/**
	* Measurement functionality has to be within a separate component
	* to leverage snapshot lifecycle.
	*/
	var PopChildMeasure = class extends import_react.Component {
		getSnapshotBeforeUpdate(prevProps) {
			const element = this.props.childRef.current;
			if (element && prevProps.isPresent && !this.props.isPresent) {
				const size = this.props.sizeRef.current;
				size.height = element.offsetHeight || 0;
				size.width = element.offsetWidth || 0;
				size.top = element.offsetTop;
				size.left = element.offsetLeft;
			}
			return null;
		}
		/**
		* Required with getSnapshotBeforeUpdate to stop React complaining.
		*/
		componentDidUpdate() {}
		render() {
			return this.props.children;
		}
	};
	function PopChild({ children, isPresent }) {
		const id = (0, import_react.useId)();
		const ref = (0, import_react.useRef)(null);
		const size = (0, import_react.useRef)({
			width: 0,
			height: 0,
			top: 0,
			left: 0
		});
		const { nonce } = (0, import_react.useContext)(MotionConfigContext);
		/**
		* We create and inject a style block so we can apply this explicit
		* sizing in a non-destructive manner by just deleting the style block.
		*
		* We can't apply size via render as the measurement happens
		* in getSnapshotBeforeUpdate (post-render), likewise if we apply the
		* styles directly on the DOM node, we might be overwriting
		* styles set via the style prop.
		*/
		(0, import_react.useInsertionEffect)(() => {
			const { width, height, top, left } = size.current;
			if (isPresent || !ref.current || !width || !height) return;
			ref.current.dataset.motionPopId = id;
			const style = document.createElement("style");
			if (nonce) style.nonce = nonce;
			document.head.appendChild(style);
			if (style.sheet) style.sheet.insertRule(`
          [data-motion-pop-id="${id}"] {
            position: absolute !important;
            width: ${width}px !important;
            height: ${height}px !important;
            top: ${top}px !important;
            left: ${left}px !important;
          }
        `);
			return () => {
				document.head.removeChild(style);
			};
		}, [isPresent]);
		return (0, import_jsx_runtime.jsx)(PopChildMeasure, {
			isPresent,
			childRef: ref,
			sizeRef: size,
			children: import_react.cloneElement(children, { ref })
		});
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/components/AnimatePresence/PresenceChild.mjs
	var PresenceChild = ({ children, initial, isPresent, onExitComplete, custom, presenceAffectsLayout, mode }) => {
		const presenceChildren = useConstant(newChildrenMap);
		const id = (0, import_react.useId)();
		const memoizedOnExitComplete = (0, import_react.useCallback)((childId) => {
			presenceChildren.set(childId, true);
			for (const isComplete of presenceChildren.values()) if (!isComplete) return;
			onExitComplete && onExitComplete();
		}, [presenceChildren, onExitComplete]);
		const context = (0, import_react.useMemo)(
			() => ({
				id,
				initial,
				isPresent,
				custom,
				onExitComplete: memoizedOnExitComplete,
				register: (childId) => {
					presenceChildren.set(childId, false);
					return () => presenceChildren.delete(childId);
				}
			}),
			/**
			* If the presence of a child affects the layout of the components around it,
			* we want to make a new context value to ensure they get re-rendered
			* so they can detect that layout change.
			*/
			presenceAffectsLayout ? [Math.random(), memoizedOnExitComplete] : [isPresent, memoizedOnExitComplete]
		);
		(0, import_react.useMemo)(() => {
			presenceChildren.forEach((_, key) => presenceChildren.set(key, false));
		}, [isPresent]);
		/**
		* If there's no `motion` components to fire exit animations, we want to remove this
		* component immediately.
		*/
		import_react.useEffect(() => {
			!isPresent && !presenceChildren.size && onExitComplete && onExitComplete();
		}, [isPresent]);
		if (mode === "popLayout") children = (0, import_jsx_runtime.jsx)(PopChild, {
			isPresent,
			children
		});
		return (0, import_jsx_runtime.jsx)(PresenceContext.Provider, {
			value: context,
			children
		});
	};
	function newChildrenMap() {
		return /* @__PURE__ */ new Map();
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/components/AnimatePresence/use-presence.mjs
	/**
	* When a component is the child of `AnimatePresence`, it can use `usePresence`
	* to access information about whether it's still present in the React tree.
	*
	* ```jsx
	* import { usePresence } from "framer-motion"
	*
	* export const Component = () => {
	*   const [isPresent, safeToRemove] = usePresence()
	*
	*   useEffect(() => {
	*     !isPresent && setTimeout(safeToRemove, 1000)
	*   }, [isPresent])
	*
	*   return <div />
	* }
	* ```
	*
	* If `isPresent` is `false`, it means that a component has been removed the tree, but
	* `AnimatePresence` won't really remove it until `safeToRemove` has been called.
	*
	* @public
	*/
	function usePresence(subscribe = true) {
		const context = (0, import_react.useContext)(PresenceContext);
		if (context === null) return [true, null];
		const { isPresent, onExitComplete, register } = context;
		const id = (0, import_react.useId)();
		(0, import_react.useEffect)(() => {
			if (subscribe) register(id);
		}, [subscribe]);
		const safeToRemove = (0, import_react.useCallback)(() => subscribe && onExitComplete && onExitComplete(id), [
			id,
			onExitComplete,
			subscribe
		]);
		return !isPresent && onExitComplete ? [false, safeToRemove] : [true];
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/components/AnimatePresence/utils.mjs
	var getChildKey = (child) => child.key || "";
	function onlyElements(children) {
		const filtered = [];
		import_react.Children.forEach(children, (child) => {
			if ((0, import_react.isValidElement)(child)) filtered.push(child);
		});
		return filtered;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/is-browser.mjs
	var isBrowser = typeof window !== "undefined";
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/use-isomorphic-effect.mjs
	var useIsomorphicLayoutEffect = isBrowser ? import_react.useLayoutEffect : import_react.useEffect;
	//#endregion
	//#region node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs
	/**
	* `AnimatePresence` enables the animation of components that have been removed from the tree.
	*
	* When adding/removing more than a single child, every child **must** be given a unique `key` prop.
	*
	* Any `motion` components that have an `exit` property defined will animate out when removed from
	* the tree.
	*
	* ```jsx
	* import { motion, AnimatePresence } from 'framer-motion'
	*
	* export const Items = ({ items }) => (
	*   <AnimatePresence>
	*     {items.map(item => (
	*       <motion.div
	*         key={item.id}
	*         initial={{ opacity: 0 }}
	*         animate={{ opacity: 1 }}
	*         exit={{ opacity: 0 }}
	*       />
	*     ))}
	*   </AnimatePresence>
	* )
	* ```
	*
	* You can sequence exit animations throughout a tree using variants.
	*
	* If a child contains multiple `motion` components with `exit` props, it will only unmount the child
	* once all `motion` components have finished animating out. Likewise, any components using
	* `usePresence` all need to call `safeToRemove`.
	*
	* @public
	*/
	var AnimatePresence = ({ children, custom, initial = true, onExitComplete, presenceAffectsLayout = true, mode = "sync", propagate = false }) => {
		const [isParentPresent, safeToRemove] = usePresence(propagate);
		/**
		* Filter any children that aren't ReactElements. We can only track components
		* between renders with a props.key.
		*/
		const presentChildren = (0, import_react.useMemo)(() => onlyElements(children), [children]);
		/**
		* Track the keys of the currently rendered children. This is used to
		* determine which children are exiting.
		*/
		const presentKeys = propagate && !isParentPresent ? [] : presentChildren.map(getChildKey);
		/**
		* If `initial={false}` we only want to pass this to components in the first render.
		*/
		const isInitialRender = (0, import_react.useRef)(true);
		/**
		* A ref containing the currently present children. When all exit animations
		* are complete, we use this to re-render the component with the latest children
		* *committed* rather than the latest children *rendered*.
		*/
		const pendingPresentChildren = (0, import_react.useRef)(presentChildren);
		/**
		* Track which exiting children have finished animating out.
		*/
		const exitComplete = useConstant(() => /* @__PURE__ */ new Map());
		/**
		* Save children to render as React state. To ensure this component is concurrent-safe,
		* we check for exiting children via an effect.
		*/
		const [diffedChildren, setDiffedChildren] = (0, import_react.useState)(presentChildren);
		const [renderedChildren, setRenderedChildren] = (0, import_react.useState)(presentChildren);
		useIsomorphicLayoutEffect(() => {
			isInitialRender.current = false;
			pendingPresentChildren.current = presentChildren;
			/**
			* Update complete status of exiting children.
			*/
			for (let i = 0; i < renderedChildren.length; i++) {
				const key = getChildKey(renderedChildren[i]);
				if (!presentKeys.includes(key)) {
					if (exitComplete.get(key) !== true) exitComplete.set(key, false);
				} else exitComplete.delete(key);
			}
		}, [
			renderedChildren,
			presentKeys.length,
			presentKeys.join("-")
		]);
		const exitingChildren = [];
		if (presentChildren !== diffedChildren) {
			let nextChildren = [...presentChildren];
			/**
			* Loop through all the currently rendered components and decide which
			* are exiting.
			*/
			for (let i = 0; i < renderedChildren.length; i++) {
				const child = renderedChildren[i];
				const key = getChildKey(child);
				if (!presentKeys.includes(key)) {
					nextChildren.splice(i, 0, child);
					exitingChildren.push(child);
				}
			}
			/**
			* If we're in "wait" mode, and we have exiting children, we want to
			* only render these until they've all exited.
			*/
			if (mode === "wait" && exitingChildren.length) nextChildren = exitingChildren;
			setRenderedChildren(onlyElements(nextChildren));
			setDiffedChildren(presentChildren);
			/**
			* Early return to ensure once we've set state with the latest diffed
			* children, we can immediately re-render.
			*/
			return;
		}
		/**
		* If we've been provided a forceRender function by the LayoutGroupContext,
		* we can use it to force a re-render amongst all surrounding components once
		* all components have finished animating out.
		*/
		const { forceRender } = (0, import_react.useContext)(LayoutGroupContext);
		return (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: renderedChildren.map((child) => {
			const key = getChildKey(child);
			const isPresent = propagate && !isParentPresent ? false : presentChildren === renderedChildren || presentKeys.includes(key);
			const onExit = () => {
				if (exitComplete.has(key)) exitComplete.set(key, true);
				else return;
				let isEveryExitComplete = true;
				exitComplete.forEach((isExitComplete) => {
					if (!isExitComplete) isEveryExitComplete = false;
				});
				if (isEveryExitComplete) {
					forceRender === null || forceRender === void 0 || forceRender();
					setRenderedChildren(pendingPresentChildren.current);
					propagate && (safeToRemove === null || safeToRemove === void 0 || safeToRemove());
					onExitComplete && onExitComplete();
				}
			};
			return (0, import_jsx_runtime.jsx)(PresenceChild, {
				isPresent,
				initial: !isInitialRender.current || initial ? void 0 : false,
				custom: isPresent ? void 0 : custom,
				presenceAffectsLayout,
				mode,
				onExitComplete: isPresent ? void 0 : onExit,
				children: child
			}, key);
		}) });
	};
	//#endregion
	//#region node_modules/motion-utils/dist/es/noop.mjs
	var noop = /* @__NO_SIDE_EFFECTS__ */ (any) => any;
	//#endregion
	//#region node_modules/motion-utils/dist/es/errors.mjs
	var warning = noop;
	var invariant = noop;
	//#endregion
	//#region node_modules/motion-utils/dist/es/memo.mjs
	/*#__NO_SIDE_EFFECTS__*/
	function memo(callback) {
		let result;
		return () => {
			if (result === void 0) result = callback();
			return result;
		};
	}
	//#endregion
	//#region node_modules/motion-utils/dist/es/progress.mjs
	var progress = /* @__NO_SIDE_EFFECTS__ */ (from, to, value) => {
		const toFromDifference = to - from;
		return toFromDifference === 0 ? 1 : (value - from) / toFromDifference;
	};
	//#endregion
	//#region node_modules/motion-utils/dist/es/time-conversion.mjs
	/**
	* Converts seconds to milliseconds
	*
	* @param seconds - Time in seconds.
	* @return milliseconds - Converted time in milliseconds.
	*/
	var secondsToMilliseconds = /* @__NO_SIDE_EFFECTS__ */ (seconds) => seconds * 1e3;
	var millisecondsToSeconds = /* @__NO_SIDE_EFFECTS__ */ (milliseconds) => milliseconds / 1e3;
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/GlobalConfig.mjs
	var MotionGlobalConfig = {
		skipAnimations: false,
		useManualTiming: false
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/frameloop/render-step.mjs
	function createRenderStep(runNextFrame) {
		/**
		* We create and reuse two queues, one to queue jobs for the current frame
		* and one for the next. We reuse to avoid triggering GC after x frames.
		*/
		let thisFrame = /* @__PURE__ */ new Set();
		let nextFrame = /* @__PURE__ */ new Set();
		/**
		* Track whether we're currently processing jobs in this step. This way
		* we can decide whether to schedule new jobs for this frame or next.
		*/
		let isProcessing = false;
		let flushNextFrame = false;
		/**
		* A set of processes which were marked keepAlive when scheduled.
		*/
		const toKeepAlive = /* @__PURE__ */ new WeakSet();
		let latestFrameData = {
			delta: 0,
			timestamp: 0,
			isProcessing: false
		};
		function triggerCallback(callback) {
			if (toKeepAlive.has(callback)) {
				step.schedule(callback);
				runNextFrame();
			}
			callback(latestFrameData);
		}
		const step = {
			/**
			* Schedule a process to run on the next frame.
			*/
			schedule: (callback, keepAlive = false, immediate = false) => {
				const queue = immediate && isProcessing ? thisFrame : nextFrame;
				if (keepAlive) toKeepAlive.add(callback);
				if (!queue.has(callback)) queue.add(callback);
				return callback;
			},
			/**
			* Cancel the provided callback from running on the next frame.
			*/
			cancel: (callback) => {
				nextFrame.delete(callback);
				toKeepAlive.delete(callback);
			},
			/**
			* Execute all schedule callbacks.
			*/
			process: (frameData) => {
				latestFrameData = frameData;
				/**
				* If we're already processing we've probably been triggered by a flushSync
				* inside an existing process. Instead of executing, mark flushNextFrame
				* as true and ensure we flush the following frame at the end of this one.
				*/
				if (isProcessing) {
					flushNextFrame = true;
					return;
				}
				isProcessing = true;
				[thisFrame, nextFrame] = [nextFrame, thisFrame];
				thisFrame.forEach(triggerCallback);
				thisFrame.clear();
				isProcessing = false;
				if (flushNextFrame) {
					flushNextFrame = false;
					step.process(frameData);
				}
			}
		};
		return step;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/frameloop/batcher.mjs
	var stepsOrder = [
		"read",
		"resolveKeyframes",
		"update",
		"preRender",
		"render",
		"postRender"
	];
	var maxElapsed = 40;
	function createRenderBatcher(scheduleNextBatch, allowKeepAlive) {
		let runNextFrame = false;
		let useDefaultElapsed = true;
		const state = {
			delta: 0,
			timestamp: 0,
			isProcessing: false
		};
		const flagRunNextFrame = () => runNextFrame = true;
		const steps = stepsOrder.reduce((acc, key) => {
			acc[key] = createRenderStep(flagRunNextFrame);
			return acc;
		}, {});
		const { read, resolveKeyframes, update, preRender, render, postRender } = steps;
		const processBatch = () => {
			const timestamp = MotionGlobalConfig.useManualTiming ? state.timestamp : performance.now();
			runNextFrame = false;
			state.delta = useDefaultElapsed ? 1e3 / 60 : Math.max(Math.min(timestamp - state.timestamp, maxElapsed), 1);
			state.timestamp = timestamp;
			state.isProcessing = true;
			read.process(state);
			resolveKeyframes.process(state);
			update.process(state);
			preRender.process(state);
			render.process(state);
			postRender.process(state);
			state.isProcessing = false;
			if (runNextFrame && allowKeepAlive) {
				useDefaultElapsed = false;
				scheduleNextBatch(processBatch);
			}
		};
		const wake = () => {
			runNextFrame = true;
			useDefaultElapsed = true;
			if (!state.isProcessing) scheduleNextBatch(processBatch);
		};
		const schedule = stepsOrder.reduce((acc, key) => {
			const step = steps[key];
			acc[key] = (process, keepAlive = false, immediate = false) => {
				if (!runNextFrame) wake();
				return step.schedule(process, keepAlive, immediate);
			};
			return acc;
		}, {});
		const cancel = (process) => {
			for (let i = 0; i < stepsOrder.length; i++) steps[stepsOrder[i]].cancel(process);
		};
		return {
			schedule,
			cancel,
			state,
			steps
		};
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/frameloop/frame.mjs
	var { schedule: frame, cancel: cancelFrame, state: frameData, steps: frameSteps } = createRenderBatcher(typeof requestAnimationFrame !== "undefined" ? requestAnimationFrame : noop, true);
	//#endregion
	//#region node_modules/framer-motion/dist/es/context/LazyContext.mjs
	var LazyContext = (0, import_react.createContext)({ strict: false });
	//#endregion
	//#region node_modules/framer-motion/dist/es/motion/features/definitions.mjs
	var featureProps = {
		animation: [
			"animate",
			"variants",
			"whileHover",
			"whileTap",
			"exit",
			"whileInView",
			"whileFocus",
			"whileDrag"
		],
		exit: ["exit"],
		drag: ["drag", "dragControls"],
		focus: ["whileFocus"],
		hover: [
			"whileHover",
			"onHoverStart",
			"onHoverEnd"
		],
		tap: [
			"whileTap",
			"onTap",
			"onTapStart",
			"onTapCancel"
		],
		pan: [
			"onPan",
			"onPanStart",
			"onPanSessionStart",
			"onPanEnd"
		],
		inView: [
			"whileInView",
			"onViewportEnter",
			"onViewportLeave"
		],
		layout: ["layout", "layoutId"]
	};
	var featureDefinitions = {};
	for (const key in featureProps) featureDefinitions[key] = { isEnabled: (props) => featureProps[key].some((name) => !!props[name]) };
	//#endregion
	//#region node_modules/framer-motion/dist/es/motion/features/load-features.mjs
	init_objectSpread2();
	function loadFeatures(features) {
		for (const key in features) featureDefinitions[key] = _objectSpread2(_objectSpread2({}, featureDefinitions[key]), features[key]);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/motion/utils/valid-prop.mjs
	/**
	* A list of all valid MotionProps.
	*
	* @privateRemarks
	* This doesn't throw if a `MotionProp` name is missing - it should.
	*/
	var validMotionProps = /* @__PURE__ */ new Set([
		"animate",
		"exit",
		"variants",
		"initial",
		"style",
		"values",
		"variants",
		"transition",
		"transformTemplate",
		"custom",
		"inherit",
		"onBeforeLayoutMeasure",
		"onAnimationStart",
		"onAnimationComplete",
		"onUpdate",
		"onDragStart",
		"onDrag",
		"onDragEnd",
		"onMeasureDragConstraints",
		"onDirectionLock",
		"onDragTransitionEnd",
		"_dragX",
		"_dragY",
		"onHoverStart",
		"onHoverEnd",
		"onViewportEnter",
		"onViewportLeave",
		"globalTapTarget",
		"ignoreStrict",
		"viewport"
	]);
	/**
	* Check whether a prop name is a valid `MotionProp` key.
	*
	* @param key - Name of the property to check
	* @returns `true` is key is a valid `MotionProp`.
	*
	* @public
	*/
	function isValidMotionProp(key) {
		return key.startsWith("while") || key.startsWith("drag") && key !== "draggable" || key.startsWith("layout") || key.startsWith("onTap") || key.startsWith("onPan") || key.startsWith("onLayout") || validMotionProps.has(key);
	}
	//#endregion
	//#region __vite-optional-peer-dep:@emotion/is-prop-valid:framer-motion
	var is_prop_valid_framer_motion_exports = /* @__PURE__ */ __exportAll({ default: () => is_prop_valid_framer_motion_default });
	var is_prop_valid_framer_motion_default;
	var init_is_prop_valid_framer_motion = __esmMin((() => {
		is_prop_valid_framer_motion_default = {};
		throw new Error(`Could not resolve "@emotion/is-prop-valid" imported by "framer-motion". Is it installed?`);
	}));
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/dom/utils/filter-props.mjs
	var shouldForward = (key) => !isValidMotionProp(key);
	function loadExternalIsValidProp(isValidProp) {
		if (!isValidProp) return;
		shouldForward = (key) => key.startsWith("on") ? !isValidMotionProp(key) : isValidProp(key);
	}
	/**
	* Emotion and Styled Components both allow users to pass through arbitrary props to their components
	* to dynamically generate CSS. They both use the `@emotion/is-prop-valid` package to determine which
	* of these should be passed to the underlying DOM node.
	*
	* However, when styling a Motion component `styled(motion.div)`, both packages pass through *all* props
	* as it's seen as an arbitrary component rather than a DOM node. Motion only allows arbitrary props
	* passed through the `custom` prop so it doesn't *need* the payload or computational overhead of
	* `@emotion/is-prop-valid`, however to fix this problem we need to use it.
	*
	* By making it an optionalDependency we can offer this functionality only in the situations where it's
	* actually required.
	*/
	try {
		/**
		* We attempt to import this package but require won't be defined in esm environments, in that case
		* isPropValid will have to be provided via `MotionContext`. In a 6.0.0 this should probably be removed
		* in favour of explicit injection.
		*/
		loadExternalIsValidProp((init_is_prop_valid_framer_motion(), __toCommonJS(is_prop_valid_framer_motion_exports)).default);
	} catch (_a) {}
	function filterProps(props, isDom, forwardMotionProps) {
		const filteredProps = {};
		for (const key in props) {
			/**
			* values is considered a valid prop by Emotion, so if it's present
			* this will be rendered out to the DOM unless explicitly filtered.
			*
			* We check the type as it could be used with the `feColorMatrix`
			* element, which we support.
			*/
			if (key === "values" && typeof props.values === "object") continue;
			if (shouldForward(key) || forwardMotionProps === true && isValidMotionProp(key) || !isDom && !isValidMotionProp(key) || props["draggable"] && key.startsWith("onDrag")) filteredProps[key] = props[key];
		}
		return filteredProps;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/components/create-proxy.mjs
	function createDOMMotionComponentProxy(componentFactory) {
		if (typeof Proxy === "undefined") return componentFactory;
		/**
		* A cache of generated `motion` components, e.g `motion.div`, `motion.input` etc.
		* Rather than generating them anew every render.
		*/
		const componentCache = /* @__PURE__ */ new Map();
		const deprecatedFactoryFunction = (...args) => {
			return componentFactory(...args);
		};
		return new Proxy(deprecatedFactoryFunction, { 
		/**
		* Called when `motion` is referenced with a prop: `motion.div`, `motion.input` etc.
		* The prop name is passed through as `key` and we can use that to generate a `motion`
		* DOM component with that name.
		*/
get: (_target, key) => {
			if (key === "create") return componentFactory;
			/**
			* If this element doesn't exist in the component cache, create it and cache.
			*/
			if (!componentCache.has(key)) componentCache.set(key, componentFactory(key));
			return componentCache.get(key);
		} });
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/context/MotionContext/index.mjs
	var MotionContext = (0, import_react.createContext)({});
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/utils/is-variant-label.mjs
	/**
	* Decides if the supplied variable is variant label
	*/
	function isVariantLabel(v) {
		return typeof v === "string" || Array.isArray(v);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/utils/is-animation-controls.mjs
	function isAnimationControls(v) {
		return v !== null && typeof v === "object" && typeof v.start === "function";
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/utils/variant-props.mjs
	var variantPriorityOrder = [
		"animate",
		"whileInView",
		"whileFocus",
		"whileHover",
		"whileTap",
		"whileDrag",
		"exit"
	];
	var variantProps = ["initial", ...variantPriorityOrder];
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/utils/is-controlling-variants.mjs
	function isControllingVariants(props) {
		return isAnimationControls(props.animate) || variantProps.some((name) => isVariantLabel(props[name]));
	}
	function isVariantNode(props) {
		return Boolean(isControllingVariants(props) || props.variants);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/context/MotionContext/utils.mjs
	function getCurrentTreeVariants(props, context) {
		if (isControllingVariants(props)) {
			const { initial, animate } = props;
			return {
				initial: initial === false || isVariantLabel(initial) ? initial : void 0,
				animate: isVariantLabel(animate) ? animate : void 0
			};
		}
		return props.inherit !== false ? context : {};
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/context/MotionContext/create.mjs
	function useCreateMotionContext(props) {
		const { initial, animate } = getCurrentTreeVariants(props, (0, import_react.useContext)(MotionContext));
		return (0, import_react.useMemo)(() => ({
			initial,
			animate
		}), [variantLabelsAsDependency(initial), variantLabelsAsDependency(animate)]);
	}
	function variantLabelsAsDependency(prop) {
		return Array.isArray(prop) ? prop.join(" ") : prop;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/motion/utils/symbol.mjs
	var motionComponentSymbol = Symbol.for("motionComponentSymbol");
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/is-ref-object.mjs
	function isRefObject(ref) {
		return ref && typeof ref === "object" && Object.prototype.hasOwnProperty.call(ref, "current");
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/motion/utils/use-motion-ref.mjs
	/**
	* Creates a ref function that, when called, hydrates the provided
	* external ref and VisualElement.
	*/
	function useMotionRef(visualState, visualElement, externalRef) {
		return (0, import_react.useCallback)(
			(instance) => {
				if (instance) visualState.onMount && visualState.onMount(instance);
				if (visualElement) {
					if (instance) visualElement.mount(instance);
					else visualElement.unmount();
				}
				if (externalRef) {
					if (typeof externalRef === "function") externalRef(instance);
					else if (isRefObject(externalRef)) externalRef.current = instance;
				}
			},
			/**
			* Only pass a new ref callback to React if we've received a visual element
			* factory. Otherwise we'll be mounting/remounting every time externalRef
			* or other dependencies change.
			*/
			[visualElement]
		);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/dom/utils/camel-to-dash.mjs
	/**
	* Convert camelCase to dash-case properties.
	*/
	var camelToDash = (str) => str.replace(/([a-z])([A-Z])/gu, "$1-$2").toLowerCase();
	var optimizedAppearDataAttribute = "data-" + camelToDash("framerAppearId");
	//#endregion
	//#region node_modules/framer-motion/dist/es/frameloop/microtask.mjs
	var { schedule: microtask, cancel: cancelMicrotask } = createRenderBatcher(queueMicrotask, false);
	//#endregion
	//#region node_modules/framer-motion/dist/es/context/SwitchLayoutGroupContext.mjs
	/**
	* Internal, exported only for usage in Framer
	*/
	var SwitchLayoutGroupContext = (0, import_react.createContext)({});
	//#endregion
	//#region node_modules/framer-motion/dist/es/motion/utils/use-visual-element.mjs
	function useVisualElement(Component, visualState, props, createVisualElement, ProjectionNodeConstructor) {
		var _a, _b;
		const { visualElement: parent } = (0, import_react.useContext)(MotionContext);
		const lazyContext = (0, import_react.useContext)(LazyContext);
		const presenceContext = (0, import_react.useContext)(PresenceContext);
		const reducedMotionConfig = (0, import_react.useContext)(MotionConfigContext).reducedMotion;
		const visualElementRef = (0, import_react.useRef)(null);
		/**
		* If we haven't preloaded a renderer, check to see if we have one lazy-loaded
		*/
		createVisualElement = createVisualElement || lazyContext.renderer;
		if (!visualElementRef.current && createVisualElement) visualElementRef.current = createVisualElement(Component, {
			visualState,
			parent,
			props,
			presenceContext,
			blockInitialAnimation: presenceContext ? presenceContext.initial === false : false,
			reducedMotionConfig
		});
		const visualElement = visualElementRef.current;
		/**
		* Load Motion gesture and animation features. These are rendered as renderless
		* components so each feature can optionally make use of React lifecycle methods.
		*/
		const initialLayoutGroupConfig = (0, import_react.useContext)(SwitchLayoutGroupContext);
		if (visualElement && !visualElement.projection && ProjectionNodeConstructor && (visualElement.type === "html" || visualElement.type === "svg")) createProjectionNode$1(visualElementRef.current, props, ProjectionNodeConstructor, initialLayoutGroupConfig);
		const isMounted = (0, import_react.useRef)(false);
		(0, import_react.useInsertionEffect)(() => {
			/**
			* Check the component has already mounted before calling
			* `update` unnecessarily. This ensures we skip the initial update.
			*/
			if (visualElement && isMounted.current) visualElement.update(props, presenceContext);
		});
		/**
		* Cache this value as we want to know whether HandoffAppearAnimations
		* was present on initial render - it will be deleted after this.
		*/
		const optimisedAppearId = props[optimizedAppearDataAttribute];
		const wantsHandoff = (0, import_react.useRef)(Boolean(optimisedAppearId) && !((_a = window.MotionHandoffIsComplete) === null || _a === void 0 ? void 0 : _a.call(window, optimisedAppearId)) && ((_b = window.MotionHasOptimisedAnimation) === null || _b === void 0 ? void 0 : _b.call(window, optimisedAppearId)));
		useIsomorphicLayoutEffect(() => {
			if (!visualElement) return;
			isMounted.current = true;
			window.MotionIsMounted = true;
			visualElement.updateFeatures();
			microtask.render(visualElement.render);
			/**
			* Ideally this function would always run in a useEffect.
			*
			* However, if we have optimised appear animations to handoff from,
			* it needs to happen synchronously to ensure there's no flash of
			* incorrect styles in the event of a hydration error.
			*
			* So if we detect a situtation where optimised appear animations
			* are running, we use useLayoutEffect to trigger animations.
			*/
			if (wantsHandoff.current && visualElement.animationState) visualElement.animationState.animateChanges();
		});
		(0, import_react.useEffect)(() => {
			if (!visualElement) return;
			if (!wantsHandoff.current && visualElement.animationState) visualElement.animationState.animateChanges();
			if (wantsHandoff.current) {
				queueMicrotask(() => {
					var _a;
					(_a = window.MotionHandoffMarkAsComplete) === null || _a === void 0 || _a.call(window, optimisedAppearId);
				});
				wantsHandoff.current = false;
			}
		});
		return visualElement;
	}
	function createProjectionNode$1(visualElement, props, ProjectionNodeConstructor, initialPromotionConfig) {
		const { layoutId, layout, drag, dragConstraints, layoutScroll, layoutRoot } = props;
		visualElement.projection = new ProjectionNodeConstructor(visualElement.latestValues, props["data-framer-portal-id"] ? void 0 : getClosestProjectingNode(visualElement.parent));
		visualElement.projection.setOptions({
			layoutId,
			layout,
			alwaysMeasureLayout: Boolean(drag) || dragConstraints && isRefObject(dragConstraints),
			visualElement,
			/**
			* TODO: Update options in an effect. This could be tricky as it'll be too late
			* to update by the time layout animations run.
			* We also need to fix this safeToRemove by linking it up to the one returned by usePresence,
			* ensuring it gets called if there's no potential layout animations.
			*
			*/
			animationType: typeof layout === "string" ? layout : "both",
			initialPromotionConfig,
			layoutScroll,
			layoutRoot
		});
	}
	function getClosestProjectingNode(visualElement) {
		if (!visualElement) return void 0;
		return visualElement.options.allowProjection !== false ? visualElement.projection : getClosestProjectingNode(visualElement.parent);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/motion/index.mjs
	init_objectSpread2();
	/**
	* Create a `motion` component.
	*
	* This function accepts a Component argument, which can be either a string (ie "div"
	* for `motion.div`), or an actual React component.
	*
	* Alongside this is a config option which provides a way of rendering the provided
	* component "offline", or outside the React render cycle.
	*/
	function createRendererMotionComponent({ preloadedFeatures, createVisualElement, useRender, useVisualState, Component }) {
		var _a, _b;
		preloadedFeatures && loadFeatures(preloadedFeatures);
		function MotionComponent(props, externalRef) {
			/**
			* If we need to measure the element we load this functionality in a
			* separate class component in order to gain access to getSnapshotBeforeUpdate.
			*/
			let MeasureLayout;
			const configAndProps = _objectSpread2(_objectSpread2(_objectSpread2({}, (0, import_react.useContext)(MotionConfigContext)), props), {}, { layoutId: useLayoutId(props) });
			const { isStatic } = configAndProps;
			const context = useCreateMotionContext(props);
			const visualState = useVisualState(props, isStatic);
			if (!isStatic && isBrowser) {
				useStrictMode(configAndProps, preloadedFeatures);
				const layoutProjection = getProjectionFunctionality(configAndProps);
				MeasureLayout = layoutProjection.MeasureLayout;
				/**
				* Create a VisualElement for this component. A VisualElement provides a common
				* interface to renderer-specific APIs (ie DOM/Three.js etc) as well as
				* providing a way of rendering to these APIs outside of the React render loop
				* for more performant animations and interactions
				*/
				context.visualElement = useVisualElement(Component, visualState, configAndProps, createVisualElement, layoutProjection.ProjectionNode);
			}
			/**
			* The mount order and hierarchy is specific to ensure our element ref
			* is hydrated by the time features fire their effects.
			*/
			return (0, import_jsx_runtime.jsxs)(MotionContext.Provider, {
				value: context,
				children: [MeasureLayout && context.visualElement ? (0, import_jsx_runtime.jsx)(MeasureLayout, _objectSpread2({ visualElement: context.visualElement }, configAndProps)) : null, useRender(Component, props, useMotionRef(visualState, context.visualElement, externalRef), visualState, isStatic, context.visualElement)]
			});
		}
		MotionComponent.displayName = `motion.${typeof Component === "string" ? Component : `create(${(_b = (_a = Component.displayName) !== null && _a !== void 0 ? _a : Component.name) !== null && _b !== void 0 ? _b : ""})`}`;
		const ForwardRefMotionComponent = (0, import_react.forwardRef)(MotionComponent);
		ForwardRefMotionComponent[motionComponentSymbol] = Component;
		return ForwardRefMotionComponent;
	}
	function useLayoutId({ layoutId }) {
		const layoutGroupId = (0, import_react.useContext)(LayoutGroupContext).id;
		return layoutGroupId && layoutId !== void 0 ? layoutGroupId + "-" + layoutId : layoutId;
	}
	function useStrictMode(configAndProps, preloadedFeatures) {
		(0, import_react.useContext)(LazyContext).strict;
	}
	function getProjectionFunctionality(props) {
		const { drag, layout } = featureDefinitions;
		if (!drag && !layout) return {};
		const combined = _objectSpread2(_objectSpread2({}, drag), layout);
		return {
			MeasureLayout: (drag === null || drag === void 0 ? void 0 : drag.isEnabled(props)) || (layout === null || layout === void 0 ? void 0 : layout.isEnabled(props)) ? combined.MeasureLayout : void 0,
			ProjectionNode: combined.ProjectionNode
		};
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/svg/lowercase-elements.mjs
	/**
	* We keep these listed separately as we use the lowercase tag names as part
	* of the runtime bundle to detect SVG components
	*/
	var lowercaseSVGElements = [
		"animate",
		"circle",
		"defs",
		"desc",
		"ellipse",
		"g",
		"image",
		"line",
		"filter",
		"marker",
		"mask",
		"metadata",
		"path",
		"pattern",
		"polygon",
		"polyline",
		"rect",
		"stop",
		"switch",
		"symbol",
		"svg",
		"text",
		"tspan",
		"use",
		"view"
	];
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/dom/utils/is-svg-component.mjs
	function isSVGComponent(Component) {
		if (typeof Component !== "string" || Component.includes("-")) return false;
		else if (lowercaseSVGElements.indexOf(Component) > -1 || /[A-Z]/u.test(Component)) return true;
		return false;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/utils/resolve-variants.mjs
	function getValueState(visualElement) {
		const state = [{}, {}];
		visualElement === null || visualElement === void 0 || visualElement.values.forEach((value, key) => {
			state[0][key] = value.get();
			state[1][key] = value.getVelocity();
		});
		return state;
	}
	function resolveVariantFromProps(props, definition, custom, visualElement) {
		/**
		* If the variant definition is a function, resolve.
		*/
		if (typeof definition === "function") {
			const [current, velocity] = getValueState(visualElement);
			definition = definition(custom !== void 0 ? custom : props.custom, current, velocity);
		}
		/**
		* If the variant definition is a variant label, or
		* the function returned a variant label, resolve.
		*/
		if (typeof definition === "string") definition = props.variants && props.variants[definition];
		/**
		* At this point we've resolved both functions and variant labels,
		* but the resolved variant label might itself have been a function.
		* If so, resolve. This can only have returned a valid target object.
		*/
		if (typeof definition === "function") {
			const [current, velocity] = getValueState(visualElement);
			definition = definition(custom !== void 0 ? custom : props.custom, current, velocity);
		}
		return definition;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/utils/is-keyframes-target.mjs
	var isKeyframesTarget = (v) => {
		return Array.isArray(v);
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/resolve-value.mjs
	var isCustomValue = (v) => {
		return Boolean(v && typeof v === "object" && v.mix && v.toValue);
	};
	var resolveFinalValueInKeyframes = (v) => {
		return isKeyframesTarget(v) ? v[v.length - 1] || 0 : v;
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/value/utils/is-motion-value.mjs
	var isMotionValue = (value) => Boolean(value && value.getVelocity);
	//#endregion
	//#region node_modules/framer-motion/dist/es/value/utils/resolve-motion-value.mjs
	/**
	* If the provided value is a MotionValue, this returns the actual value, otherwise just the value itself
	*
	* TODO: Remove and move to library
	*/
	function resolveMotionValue(value) {
		const unwrappedValue = isMotionValue(value) ? value.get() : value;
		return isCustomValue(unwrappedValue) ? unwrappedValue.toValue() : unwrappedValue;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/motion/utils/use-visual-state.mjs
	init_objectSpread2();
	init_objectWithoutProperties();
	var _excluded$9 = ["transitionEnd", "transition"];
	function makeState({ scrapeMotionValuesFromProps, createRenderState, onUpdate }, props, context, presenceContext) {
		const state = {
			latestValues: makeLatestValues(props, context, presenceContext, scrapeMotionValuesFromProps),
			renderState: createRenderState()
		};
		if (onUpdate) {
			/**
			* onMount works without the VisualElement because it could be
			* called before the VisualElement payload has been hydrated.
			* (e.g. if someone is using m components <m.circle />)
			*/
			state.onMount = (instance) => onUpdate(_objectSpread2({
				props,
				current: instance
			}, state));
			state.onUpdate = (visualElement) => onUpdate(visualElement);
		}
		return state;
	}
	var makeUseVisualState = (config) => (props, isStatic) => {
		const context = (0, import_react.useContext)(MotionContext);
		const presenceContext = (0, import_react.useContext)(PresenceContext);
		const make = () => makeState(config, props, context, presenceContext);
		return isStatic ? make() : useConstant(make);
	};
	function makeLatestValues(props, context, presenceContext, scrapeMotionValues) {
		const values = {};
		const motionValues = scrapeMotionValues(props, {});
		for (const key in motionValues) values[key] = resolveMotionValue(motionValues[key]);
		let { initial, animate } = props;
		const isControllingVariants$1 = isControllingVariants(props);
		const isVariantNode$1 = isVariantNode(props);
		if (context && isVariantNode$1 && !isControllingVariants$1 && props.inherit !== false) {
			if (initial === void 0) initial = context.initial;
			if (animate === void 0) animate = context.animate;
		}
		let isInitialAnimationBlocked = presenceContext ? presenceContext.initial === false : false;
		isInitialAnimationBlocked = isInitialAnimationBlocked || initial === false;
		const variantToSet = isInitialAnimationBlocked ? animate : initial;
		if (variantToSet && typeof variantToSet !== "boolean" && !isAnimationControls(variantToSet)) {
			const list = Array.isArray(variantToSet) ? variantToSet : [variantToSet];
			for (let i = 0; i < list.length; i++) {
				const resolved = resolveVariantFromProps(props, list[i]);
				if (resolved) {
					const { transitionEnd, transition } = resolved, target = _objectWithoutProperties(resolved, _excluded$9);
					for (const key in target) {
						let valueTarget = target[key];
						if (Array.isArray(valueTarget)) {
							/**
							* Take final keyframe if the initial animation is blocked because
							* we want to initialise at the end of that blocked animation.
							*/
							const index = isInitialAnimationBlocked ? valueTarget.length - 1 : 0;
							valueTarget = valueTarget[index];
						}
						if (valueTarget !== null) values[key] = valueTarget;
					}
					for (const key in transitionEnd) values[key] = transitionEnd[key];
				}
			}
		}
		return values;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/html/utils/keys-transform.mjs
	/**
	* Generate a list of every possible transform key.
	*/
	var transformPropOrder = [
		"transformPerspective",
		"x",
		"y",
		"z",
		"translateX",
		"translateY",
		"translateZ",
		"scale",
		"scaleX",
		"scaleY",
		"rotate",
		"rotateX",
		"rotateY",
		"rotateZ",
		"skew",
		"skewX",
		"skewY"
	];
	/**
	* A quick lookup for transform props.
	*/
	var transformProps = new Set(transformPropOrder);
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/dom/utils/is-css-variable.mjs
	var checkStringStartsWith = (token) => (key) => typeof key === "string" && key.startsWith(token);
	var isCSSVariableName = /*@__PURE__*/ checkStringStartsWith("--");
	var startsAsVariableToken = /*@__PURE__*/ checkStringStartsWith("var(--");
	var isCSSVariableToken = (value) => {
		if (!startsAsVariableToken(value)) return false;
		return singleCssVariableRegex.test(value.split("/*")[0].trim());
	};
	var singleCssVariableRegex = /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu;
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/dom/value-types/get-as-type.mjs
	/**
	* Provided a value and a ValueType, returns the value as that value type.
	*/
	var getValueAsType = (value, type) => {
		return type && typeof value === "number" ? type.transform(value) : value;
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/clamp.mjs
	var clamp = (min, max, v) => {
		if (v > max) return max;
		if (v < min) return min;
		return v;
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/value/types/numbers/index.mjs
	init_objectSpread2();
	var number = {
		test: (v) => typeof v === "number",
		parse: parseFloat,
		transform: (v) => v
	};
	var alpha = _objectSpread2(_objectSpread2({}, number), {}, { transform: (v) => clamp(0, 1, v) });
	var scale = _objectSpread2(_objectSpread2({}, number), {}, { default: 1 });
	//#endregion
	//#region node_modules/framer-motion/dist/es/value/types/numbers/units.mjs
	init_objectSpread2();
	var createUnitType = (unit) => ({
		test: (v) => typeof v === "string" && v.endsWith(unit) && v.split(" ").length === 1,
		parse: parseFloat,
		transform: (v) => `${v}${unit}`
	});
	var degrees = /*@__PURE__*/ createUnitType("deg");
	var percent = /*@__PURE__*/ createUnitType("%");
	var px = /*@__PURE__*/ createUnitType("px");
	var vh = /*@__PURE__*/ createUnitType("vh");
	var vw = /*@__PURE__*/ createUnitType("vw");
	var progressPercentage = _objectSpread2(_objectSpread2({}, percent), {}, {
		parse: (v) => percent.parse(v) / 100,
		transform: (v) => percent.transform(v * 100)
	});
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/dom/value-types/number-browser.mjs
	var browserNumberValueTypes = {
		borderWidth: px,
		borderTopWidth: px,
		borderRightWidth: px,
		borderBottomWidth: px,
		borderLeftWidth: px,
		borderRadius: px,
		radius: px,
		borderTopLeftRadius: px,
		borderTopRightRadius: px,
		borderBottomRightRadius: px,
		borderBottomLeftRadius: px,
		width: px,
		maxWidth: px,
		height: px,
		maxHeight: px,
		top: px,
		right: px,
		bottom: px,
		left: px,
		padding: px,
		paddingTop: px,
		paddingRight: px,
		paddingBottom: px,
		paddingLeft: px,
		margin: px,
		marginTop: px,
		marginRight: px,
		marginBottom: px,
		marginLeft: px,
		backgroundPositionX: px,
		backgroundPositionY: px
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/dom/value-types/transform.mjs
	var transformValueTypes = {
		rotate: degrees,
		rotateX: degrees,
		rotateY: degrees,
		rotateZ: degrees,
		scale,
		scaleX: scale,
		scaleY: scale,
		scaleZ: scale,
		skew: degrees,
		skewX: degrees,
		skewY: degrees,
		distance: px,
		translateX: px,
		translateY: px,
		translateZ: px,
		x: px,
		y: px,
		z: px,
		perspective: px,
		transformPerspective: px,
		opacity: alpha,
		originX: progressPercentage,
		originY: progressPercentage,
		originZ: px
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/dom/value-types/type-int.mjs
	init_objectSpread2();
	var int = _objectSpread2(_objectSpread2({}, number), {}, { transform: Math.round });
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/dom/value-types/number.mjs
	init_objectSpread2();
	var numberValueTypes = _objectSpread2(_objectSpread2(_objectSpread2({}, browserNumberValueTypes), transformValueTypes), {}, {
		zIndex: int,
		size: px,
		fillOpacity: alpha,
		strokeOpacity: alpha,
		numOctaves: int
	});
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/html/utils/build-transform.mjs
	var translateAlias = {
		x: "translateX",
		y: "translateY",
		z: "translateZ",
		transformPerspective: "perspective"
	};
	var numTransforms = transformPropOrder.length;
	/**
	* Build a CSS transform style from individual x/y/scale etc properties.
	*
	* This outputs with a default order of transforms/scales/rotations, this can be customised by
	* providing a transformTemplate function.
	*/
	function buildTransform(latestValues, transform, transformTemplate) {
		let transformString = "";
		let transformIsDefault = true;
		/**
		* Loop over all possible transforms in order, adding the ones that
		* are present to the transform string.
		*/
		for (let i = 0; i < numTransforms; i++) {
			const key = transformPropOrder[i];
			const value = latestValues[key];
			if (value === void 0) continue;
			let valueIsDefault = true;
			if (typeof value === "number") valueIsDefault = value === (key.startsWith("scale") ? 1 : 0);
			else valueIsDefault = parseFloat(value) === 0;
			if (!valueIsDefault || transformTemplate) {
				const valueAsType = getValueAsType(value, numberValueTypes[key]);
				if (!valueIsDefault) {
					transformIsDefault = false;
					const transformName = translateAlias[key] || key;
					transformString += `${transformName}(${valueAsType}) `;
				}
				if (transformTemplate) transform[key] = valueAsType;
			}
		}
		transformString = transformString.trim();
		if (transformTemplate) transformString = transformTemplate(transform, transformIsDefault ? "" : transformString);
		else if (transformIsDefault) transformString = "none";
		return transformString;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/html/utils/build-styles.mjs
	function buildHTMLStyles(state, latestValues, transformTemplate) {
		const { style, vars, transformOrigin } = state;
		let hasTransform = false;
		let hasTransformOrigin = false;
		/**
		* Loop over all our latest animated values and decide whether to handle them
		* as a style or CSS variable.
		*
		* Transforms and transform origins are kept separately for further processing.
		*/
		for (const key in latestValues) {
			const value = latestValues[key];
			if (transformProps.has(key)) {
				hasTransform = true;
				continue;
			} else if (isCSSVariableName(key)) {
				vars[key] = value;
				continue;
			} else {
				const valueAsType = getValueAsType(value, numberValueTypes[key]);
				if (key.startsWith("origin")) {
					hasTransformOrigin = true;
					transformOrigin[key] = valueAsType;
				} else style[key] = valueAsType;
			}
		}
		if (!latestValues.transform) {
			if (hasTransform || transformTemplate) style.transform = buildTransform(latestValues, state.transform, transformTemplate);
			else if (style.transform)
 /**
			* If we have previously created a transform but currently don't have any,
			* reset transform style to none.
			*/
			style.transform = "none";
		}
		/**
		* Build a transformOrigin style. Uses the same defaults as the browser for
		* undefined origins.
		*/
		if (hasTransformOrigin) {
			const { originX = "50%", originY = "50%", originZ = 0 } = transformOrigin;
			style.transformOrigin = `${originX} ${originY} ${originZ}`;
		}
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/svg/utils/path.mjs
	var dashKeys = {
		offset: "stroke-dashoffset",
		array: "stroke-dasharray"
	};
	var camelKeys = {
		offset: "strokeDashoffset",
		array: "strokeDasharray"
	};
	/**
	* Build SVG path properties. Uses the path's measured length to convert
	* our custom pathLength, pathSpacing and pathOffset into stroke-dashoffset
	* and stroke-dasharray attributes.
	*
	* This function is mutative to reduce per-frame GC.
	*/
	function buildSVGPath(attrs, length, spacing = 1, offset = 0, useDashCase = true) {
		attrs.pathLength = 1;
		const keys = useDashCase ? dashKeys : camelKeys;
		attrs[keys.offset] = px.transform(-offset);
		const pathLength = px.transform(length);
		const pathSpacing = px.transform(spacing);
		attrs[keys.array] = `${pathLength} ${pathSpacing}`;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/svg/utils/transform-origin.mjs
	function calcOrigin$1(origin, offset, size) {
		return typeof origin === "string" ? origin : px.transform(offset + size * origin);
	}
	/**
	* The SVG transform origin defaults are different to CSS and is less intuitive,
	* so we use the measured dimensions of the SVG to reconcile these.
	*/
	function calcSVGTransformOrigin(dimensions, originX, originY) {
		return `${calcOrigin$1(originX, dimensions.x, dimensions.width)} ${calcOrigin$1(originY, dimensions.y, dimensions.height)}`;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/svg/utils/build-attrs.mjs
	init_objectWithoutProperties();
	var _excluded$8 = [
		"attrX",
		"attrY",
		"attrScale",
		"originX",
		"originY",
		"pathLength",
		"pathSpacing",
		"pathOffset"
	];
	/**
	* Build SVG visual attrbutes, like cx and style.transform
	*/
	function buildSVGAttrs(state, _ref, isSVGTag, transformTemplate) {
		let { attrX, attrY, attrScale, originX, originY, pathLength, pathSpacing = 1, pathOffset = 0 } = _ref;
		buildHTMLStyles(state, _objectWithoutProperties(_ref, _excluded$8), transformTemplate);
		/**
		* For svg tags we just want to make sure viewBox is animatable and treat all the styles
		* as normal HTML tags.
		*/
		if (isSVGTag) {
			if (state.style.viewBox) state.attrs.viewBox = state.style.viewBox;
			return;
		}
		state.attrs = state.style;
		state.style = {};
		const { attrs, style, dimensions } = state;
		/**
		* However, we apply transforms as CSS transforms. So if we detect a transform we take it from attrs
		* and copy it into style.
		*/
		if (attrs.transform) {
			if (dimensions) style.transform = attrs.transform;
			delete attrs.transform;
		}
		if (dimensions && (originX !== void 0 || originY !== void 0 || style.transform)) style.transformOrigin = calcSVGTransformOrigin(dimensions, originX !== void 0 ? originX : .5, originY !== void 0 ? originY : .5);
		if (attrX !== void 0) attrs.x = attrX;
		if (attrY !== void 0) attrs.y = attrY;
		if (attrScale !== void 0) attrs.scale = attrScale;
		if (pathLength !== void 0) buildSVGPath(attrs, pathLength, pathSpacing, pathOffset, false);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/html/utils/create-render-state.mjs
	var createHtmlRenderState = () => ({
		style: {},
		transform: {},
		transformOrigin: {},
		vars: {}
	});
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/svg/utils/create-render-state.mjs
	init_objectSpread2();
	var createSvgRenderState = () => _objectSpread2(_objectSpread2({}, createHtmlRenderState()), {}, { attrs: {} });
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/svg/utils/is-svg-tag.mjs
	var isSVGTag = (tag) => typeof tag === "string" && tag.toLowerCase() === "svg";
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/html/utils/render.mjs
	function renderHTML(element, { style, vars }, styleProp, projection) {
		Object.assign(element.style, style, projection && projection.getProjectionStyles(styleProp));
		for (const key in vars) element.style.setProperty(key, vars[key]);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/svg/utils/camel-case-attrs.mjs
	/**
	* A set of attribute names that are always read/written as camel case.
	*/
	var camelCaseAttributes = /* @__PURE__ */ new Set([
		"baseFrequency",
		"diffuseConstant",
		"kernelMatrix",
		"kernelUnitLength",
		"keySplines",
		"keyTimes",
		"limitingConeAngle",
		"markerHeight",
		"markerWidth",
		"numOctaves",
		"targetX",
		"targetY",
		"surfaceScale",
		"specularConstant",
		"specularExponent",
		"stdDeviation",
		"tableValues",
		"viewBox",
		"gradientTransform",
		"pathLength",
		"startOffset",
		"textLength",
		"lengthAdjust"
	]);
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/svg/utils/render.mjs
	function renderSVG(element, renderState, _styleProp, projection) {
		renderHTML(element, renderState, void 0, projection);
		for (const key in renderState.attrs) element.setAttribute(!camelCaseAttributes.has(key) ? camelToDash(key) : key, renderState.attrs[key]);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/projection/styles/scale-correction.mjs
	var scaleCorrectors = {};
	function addScaleCorrector(correctors) {
		Object.assign(scaleCorrectors, correctors);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/motion/utils/is-forced-motion-value.mjs
	function isForcedMotionValue(key, { layout, layoutId }) {
		return transformProps.has(key) || key.startsWith("origin") || (layout || layoutId !== void 0) && (!!scaleCorrectors[key] || key === "opacity");
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/html/utils/scrape-motion-values.mjs
	function scrapeMotionValuesFromProps$1(props, prevProps, visualElement) {
		var _a;
		const { style } = props;
		const newValues = {};
		for (const key in style) if (isMotionValue(style[key]) || prevProps.style && isMotionValue(prevProps.style[key]) || isForcedMotionValue(key, props) || ((_a = visualElement === null || visualElement === void 0 ? void 0 : visualElement.getValue(key)) === null || _a === void 0 ? void 0 : _a.liveStyle) !== void 0) newValues[key] = style[key];
		return newValues;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/svg/utils/scrape-motion-values.mjs
	function scrapeMotionValuesFromProps(props, prevProps, visualElement) {
		const newValues = scrapeMotionValuesFromProps$1(props, prevProps, visualElement);
		for (const key in props) if (isMotionValue(props[key]) || isMotionValue(prevProps[key])) {
			const targetKey = transformPropOrder.indexOf(key) !== -1 ? "attr" + key.charAt(0).toUpperCase() + key.substring(1) : key;
			newValues[targetKey] = props[key];
		}
		return newValues;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/svg/config-motion.mjs
	function updateSVGDimensions(instance, renderState) {
		try {
			renderState.dimensions = typeof instance.getBBox === "function" ? instance.getBBox() : instance.getBoundingClientRect();
		} catch (e) {
			renderState.dimensions = {
				x: 0,
				y: 0,
				width: 0,
				height: 0
			};
		}
	}
	var layoutProps = [
		"x",
		"y",
		"width",
		"height",
		"cx",
		"cy",
		"r"
	];
	var svgMotionConfig = { useVisualState: makeUseVisualState({
		scrapeMotionValuesFromProps,
		createRenderState: createSvgRenderState,
		onUpdate: ({ props, prevProps, current, renderState, latestValues }) => {
			if (!current) return;
			let hasTransform = !!props.drag;
			if (!hasTransform) {
				for (const key in latestValues) if (transformProps.has(key)) {
					hasTransform = true;
					break;
				}
			}
			if (!hasTransform) return;
			let needsMeasure = !prevProps;
			if (prevProps)
 /**
			* Check the layout props for changes, if any are found we need to
			* measure the element again.
			*/
			for (let i = 0; i < layoutProps.length; i++) {
				const key = layoutProps[i];
				if (props[key] !== prevProps[key]) needsMeasure = true;
			}
			if (!needsMeasure) return;
			frame.read(() => {
				updateSVGDimensions(current, renderState);
				frame.render(() => {
					buildSVGAttrs(renderState, latestValues, isSVGTag(current.tagName), props.transformTemplate);
					renderSVG(current, renderState);
				});
			});
		}
	}) };
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/html/config-motion.mjs
	var htmlMotionConfig = { useVisualState: makeUseVisualState({
		scrapeMotionValuesFromProps: scrapeMotionValuesFromProps$1,
		createRenderState: createHtmlRenderState
	}) };
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/html/use-props.mjs
	function copyRawValuesOnly(target, source, props) {
		for (const key in source) if (!isMotionValue(source[key]) && !isForcedMotionValue(key, props)) target[key] = source[key];
	}
	function useInitialMotionValues({ transformTemplate }, visualState) {
		return (0, import_react.useMemo)(() => {
			const state = createHtmlRenderState();
			buildHTMLStyles(state, visualState, transformTemplate);
			return Object.assign({}, state.vars, state.style);
		}, [visualState]);
	}
	function useStyle(props, visualState) {
		const styleProp = props.style || {};
		const style = {};
		/**
		* Copy non-Motion Values straight into style
		*/
		copyRawValuesOnly(style, styleProp, props);
		Object.assign(style, useInitialMotionValues(props, visualState));
		return style;
	}
	function useHTMLProps(props, visualState) {
		const htmlProps = {};
		const style = useStyle(props, visualState);
		if (props.drag && props.dragListener !== false) {
			htmlProps.draggable = false;
			style.userSelect = style.WebkitUserSelect = style.WebkitTouchCallout = "none";
			style.touchAction = props.drag === true ? "none" : `pan-${props.drag === "x" ? "y" : "x"}`;
		}
		if (props.tabIndex === void 0 && (props.onTap || props.onTapStart || props.whileTap)) htmlProps.tabIndex = 0;
		htmlProps.style = style;
		return htmlProps;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/svg/use-props.mjs
	init_objectSpread2();
	function useSVGProps(props, visualState, _isStatic, Component) {
		const visualProps = (0, import_react.useMemo)(() => {
			const state = createSvgRenderState();
			buildSVGAttrs(state, visualState, isSVGTag(Component), props.transformTemplate);
			return _objectSpread2(_objectSpread2({}, state.attrs), {}, { style: _objectSpread2({}, state.style) });
		}, [visualState]);
		if (props.style) {
			const rawStyles = {};
			copyRawValuesOnly(rawStyles, props.style, props);
			visualProps.style = _objectSpread2(_objectSpread2({}, rawStyles), visualProps.style);
		}
		return visualProps;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/dom/use-render.mjs
	init_objectSpread2();
	function createUseRender(forwardMotionProps = false) {
		const useRender = (Component, props, ref, { latestValues }, isStatic) => {
			const visualProps = (isSVGComponent(Component) ? useSVGProps : useHTMLProps)(props, latestValues, isStatic, Component);
			const filteredProps = filterProps(props, typeof Component === "string", forwardMotionProps);
			const elementProps = Component !== import_react.Fragment ? _objectSpread2(_objectSpread2(_objectSpread2({}, filteredProps), visualProps), {}, { ref }) : {};
			/**
			* If component has been handed a motion value as its child,
			* memoise its initial value and render that. Subsequent updates
			* will be handled by the onChange handler
			*/
			const { children } = props;
			const renderedChildren = (0, import_react.useMemo)(() => isMotionValue(children) ? children.get() : children, [children]);
			return (0, import_react.createElement)(Component, _objectSpread2(_objectSpread2({}, elementProps), {}, { children: renderedChildren }));
		};
		return useRender;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/components/create-factory.mjs
	init_objectSpread2();
	function createMotionComponentFactory(preloadedFeatures, createVisualElement) {
		return function createMotionComponent(Component, { forwardMotionProps } = { forwardMotionProps: false }) {
			return createRendererMotionComponent(_objectSpread2(_objectSpread2({}, isSVGComponent(Component) ? svgMotionConfig : htmlMotionConfig), {}, {
				preloadedFeatures,
				useRender: createUseRender(forwardMotionProps),
				createVisualElement,
				Component
			}));
		};
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/shallow-compare.mjs
	function shallowCompare(next, prev) {
		if (!Array.isArray(prev)) return false;
		const prevLength = prev.length;
		if (prevLength !== next.length) return false;
		for (let i = 0; i < prevLength; i++) if (prev[i] !== next[i]) return false;
		return true;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/utils/resolve-dynamic-variants.mjs
	function resolveVariant(visualElement, definition, custom) {
		const props = visualElement.getProps();
		return resolveVariantFromProps(props, definition, custom !== void 0 ? custom : props.custom, visualElement);
	}
	//#endregion
	//#region node_modules/motion-dom/dist/es/utils/supports/scroll-timeline.mjs
	var supportsScrollTimeline = /* @__PURE__ */ memo(() => window.ScrollTimeline !== void 0);
	//#endregion
	//#region node_modules/motion-dom/dist/es/animation/controls/BaseGroup.mjs
	var BaseGroupPlaybackControls = class {
		constructor(animations) {
			this.stop = () => this.runAll("stop");
			this.animations = animations.filter(Boolean);
		}
		get finished() {
			return Promise.all(this.animations.map((animation) => "finished" in animation ? animation.finished : animation));
		}
		/**
		* TODO: Filter out cancelled or stopped animations before returning
		*/
		getAll(propName) {
			return this.animations[0][propName];
		}
		setAll(propName, newValue) {
			for (let i = 0; i < this.animations.length; i++) this.animations[i][propName] = newValue;
		}
		attachTimeline(timeline, fallback) {
			const subscriptions = this.animations.map((animation) => {
				if (supportsScrollTimeline() && animation.attachTimeline) return animation.attachTimeline(timeline);
				else if (typeof fallback === "function") return fallback(animation);
			});
			return () => {
				subscriptions.forEach((cancel, i) => {
					cancel && cancel();
					this.animations[i].stop();
				});
			};
		}
		get time() {
			return this.getAll("time");
		}
		set time(time) {
			this.setAll("time", time);
		}
		get speed() {
			return this.getAll("speed");
		}
		set speed(speed) {
			this.setAll("speed", speed);
		}
		get startTime() {
			return this.getAll("startTime");
		}
		get duration() {
			let max = 0;
			for (let i = 0; i < this.animations.length; i++) max = Math.max(max, this.animations[i].duration);
			return max;
		}
		runAll(methodName) {
			this.animations.forEach((controls) => controls[methodName]());
		}
		flatten() {
			this.runAll("flatten");
		}
		play() {
			this.runAll("play");
		}
		pause() {
			this.runAll("pause");
		}
		cancel() {
			this.runAll("cancel");
		}
		complete() {
			this.runAll("complete");
		}
	};
	//#endregion
	//#region node_modules/motion-dom/dist/es/animation/controls/Group.mjs
	/**
	* TODO: This is a temporary class to support the legacy
	* thennable API
	*/
	var GroupPlaybackControls = class extends BaseGroupPlaybackControls {
		then(onResolve, onReject) {
			return Promise.all(this.animations).then(onResolve).catch(onReject);
		}
	};
	//#endregion
	//#region node_modules/motion-dom/dist/es/animation/utils/get-value-transition.mjs
	function getValueTransition(transition, key) {
		return transition ? transition[key] || transition["default"] || transition : void 0;
	}
	//#endregion
	//#region node_modules/motion-dom/dist/es/animation/generators/utils/calc-duration.mjs
	/**
	* Implement a practical max duration for keyframe generation
	* to prevent infinite loops
	*/
	var maxGeneratorDuration = 2e4;
	function calcGeneratorDuration(generator) {
		let duration = 0;
		const timeStep = 50;
		let state = generator.next(duration);
		while (!state.done && duration < 2e4) {
			duration += timeStep;
			state = generator.next(duration);
		}
		return duration >= 2e4 ? Infinity : duration;
	}
	//#endregion
	//#region node_modules/motion-dom/dist/es/animation/generators/utils/is-generator.mjs
	function isGenerator(type) {
		return typeof type === "function";
	}
	//#endregion
	//#region node_modules/motion-dom/dist/es/animation/waapi/utils/attach-timeline.mjs
	function attachTimeline(animation, timeline) {
		animation.timeline = timeline;
		animation.onfinish = null;
	}
	//#endregion
	//#region node_modules/motion-dom/dist/es/utils/is-bezier-definition.mjs
	var isBezierDefinition = (easing) => Array.isArray(easing) && typeof easing[0] === "number";
	//#endregion
	//#region node_modules/motion-dom/dist/es/utils/supports/flags.mjs
	/**
	* Add the ability for test suites to manually set support flags
	* to better test more environments.
	*/
	var supportsFlags = { linearEasing: void 0 };
	//#endregion
	//#region node_modules/motion-dom/dist/es/utils/supports/memo.mjs
	function memoSupports(callback, supportsFlag) {
		const memoized = /* @__PURE__ */ memo(callback);
		return () => {
			var _a;
			return (_a = supportsFlags[supportsFlag]) !== null && _a !== void 0 ? _a : memoized();
		};
	}
	//#endregion
	//#region node_modules/motion-dom/dist/es/utils/supports/linear-easing.mjs
	var supportsLinearEasing = /*@__PURE__*/ memoSupports(() => {
		try {
			document.createElement("div").animate({ opacity: 0 }, { easing: "linear(0, 1)" });
		} catch (e) {
			return false;
		}
		return true;
	}, "linearEasing");
	//#endregion
	//#region node_modules/motion-dom/dist/es/animation/waapi/utils/linear.mjs
	var generateLinearEasing = (easing, duration, resolution = 10) => {
		let points = "";
		const numPoints = Math.max(Math.round(duration / resolution), 2);
		for (let i = 0; i < numPoints; i++) points += easing(/* @__PURE__ */ progress(0, numPoints - 1, i)) + ", ";
		return `linear(${points.substring(0, points.length - 2)})`;
	};
	//#endregion
	//#region node_modules/motion-dom/dist/es/animation/waapi/utils/easing.mjs
	function isWaapiSupportedEasing(easing) {
		return Boolean(typeof easing === "function" && supportsLinearEasing() || !easing || typeof easing === "string" && (easing in supportedWaapiEasing || supportsLinearEasing()) || isBezierDefinition(easing) || Array.isArray(easing) && easing.every(isWaapiSupportedEasing));
	}
	var cubicBezierAsString = ([a, b, c, d]) => `cubic-bezier(${a}, ${b}, ${c}, ${d})`;
	var supportedWaapiEasing = {
		linear: "linear",
		ease: "ease",
		easeIn: "ease-in",
		easeOut: "ease-out",
		easeInOut: "ease-in-out",
		circIn: /*@__PURE__*/ cubicBezierAsString([
			0,
			.65,
			.55,
			1
		]),
		circOut: /*@__PURE__*/ cubicBezierAsString([
			.55,
			0,
			1,
			.45
		]),
		backIn: /*@__PURE__*/ cubicBezierAsString([
			.31,
			.01,
			.66,
			-.59
		]),
		backOut: /*@__PURE__*/ cubicBezierAsString([
			.33,
			1.53,
			.69,
			.99
		])
	};
	function mapEasingToNativeEasing(easing, duration) {
		if (!easing) return;
		else if (typeof easing === "function" && supportsLinearEasing()) return generateLinearEasing(easing, duration);
		else if (isBezierDefinition(easing)) return cubicBezierAsString(easing);
		else if (Array.isArray(easing)) return easing.map((segmentEasing) => mapEasingToNativeEasing(segmentEasing, duration) || supportedWaapiEasing.easeOut);
		else return supportedWaapiEasing[easing];
	}
	//#endregion
	//#region node_modules/motion-dom/dist/es/gestures/drag/state/is-active.mjs
	var isDragging = {
		x: false,
		y: false
	};
	function isDragActive() {
		return isDragging.x || isDragging.y;
	}
	//#endregion
	//#region node_modules/motion-dom/dist/es/utils/resolve-elements.mjs
	function resolveElements(elementOrSelector, scope, selectorCache) {
		var _a;
		if (elementOrSelector instanceof Element) return [elementOrSelector];
		else if (typeof elementOrSelector === "string") {
			let root = document;
			if (scope) root = scope.current;
			const elements = (_a = selectorCache === null || selectorCache === void 0 ? void 0 : selectorCache[elementOrSelector]) !== null && _a !== void 0 ? _a : root.querySelectorAll(elementOrSelector);
			return elements ? Array.from(elements) : [];
		}
		return Array.from(elementOrSelector);
	}
	//#endregion
	//#region node_modules/motion-dom/dist/es/gestures/utils/setup.mjs
	init_objectSpread2();
	function setupGesture(elementOrSelector, options) {
		const elements = resolveElements(elementOrSelector);
		const gestureAbortController = new AbortController();
		const eventOptions = _objectSpread2(_objectSpread2({ passive: true }, options), {}, { signal: gestureAbortController.signal });
		const cancel = () => gestureAbortController.abort();
		return [
			elements,
			eventOptions,
			cancel
		];
	}
	//#endregion
	//#region node_modules/motion-dom/dist/es/gestures/hover.mjs
	/**
	* Filter out events that are not pointer events, or are triggering
	* while a Motion gesture is active.
	*/
	function filterEvents$1(callback) {
		return (event) => {
			if (event.pointerType === "touch" || isDragActive()) return;
			callback(event);
		};
	}
	/**
	* Create a hover gesture. hover() is different to .addEventListener("pointerenter")
	* in that it has an easier syntax, filters out polyfilled touch events, interoperates
	* with drag gestures, and automatically removes the "pointerennd" event listener when the hover ends.
	*
	* @public
	*/
	function hover(elementOrSelector, onHoverStart, options = {}) {
		const [elements, eventOptions, cancel] = setupGesture(elementOrSelector, options);
		const onPointerEnter = filterEvents$1((enterEvent) => {
			const { target } = enterEvent;
			const onHoverEnd = onHoverStart(enterEvent);
			if (typeof onHoverEnd !== "function" || !target) return;
			const onPointerLeave = filterEvents$1((leaveEvent) => {
				onHoverEnd(leaveEvent);
				target.removeEventListener("pointerleave", onPointerLeave);
			});
			target.addEventListener("pointerleave", onPointerLeave, eventOptions);
		});
		elements.forEach((element) => {
			element.addEventListener("pointerenter", onPointerEnter, eventOptions);
		});
		return cancel;
	}
	//#endregion
	//#region node_modules/motion-dom/dist/es/gestures/utils/is-node-or-child.mjs
	/**
	* Recursively traverse up the tree to check whether the provided child node
	* is the parent or a descendant of it.
	*
	* @param parent - Element to find
	* @param child - Element to test against parent
	*/
	var isNodeOrChild = (parent, child) => {
		if (!child) return false;
		else if (parent === child) return true;
		else return isNodeOrChild(parent, child.parentElement);
	};
	//#endregion
	//#region node_modules/motion-dom/dist/es/gestures/utils/is-primary-pointer.mjs
	var isPrimaryPointer = (event) => {
		if (event.pointerType === "mouse") return typeof event.button !== "number" || event.button <= 0;
		else
 /**
		* isPrimary is true for all mice buttons, whereas every touch point
		* is regarded as its own input. So subsequent concurrent touch points
		* will be false.
		*
		* Specifically match against false here as incomplete versions of
		* PointerEvents in very old browser might have it set as undefined.
		*/
		return event.isPrimary !== false;
	};
	//#endregion
	//#region node_modules/motion-dom/dist/es/gestures/press/utils/is-keyboard-accessible.mjs
	var focusableElements = /* @__PURE__ */ new Set([
		"BUTTON",
		"INPUT",
		"SELECT",
		"TEXTAREA",
		"A"
	]);
	function isElementKeyboardAccessible(element) {
		return focusableElements.has(element.tagName) || element.tabIndex !== -1;
	}
	//#endregion
	//#region node_modules/motion-dom/dist/es/gestures/press/utils/state.mjs
	var isPressing = /* @__PURE__ */ new WeakSet();
	//#endregion
	//#region node_modules/motion-dom/dist/es/gestures/press/utils/keyboard.mjs
	/**
	* Filter out events that are not "Enter" keys.
	*/
	function filterEvents(callback) {
		return (event) => {
			if (event.key !== "Enter") return;
			callback(event);
		};
	}
	function firePointerEvent(target, type) {
		target.dispatchEvent(new PointerEvent("pointer" + type, {
			isPrimary: true,
			bubbles: true
		}));
	}
	var enableKeyboardPress = (focusEvent, eventOptions) => {
		const element = focusEvent.currentTarget;
		if (!element) return;
		const handleKeydown = filterEvents(() => {
			if (isPressing.has(element)) return;
			firePointerEvent(element, "down");
			const handleKeyup = filterEvents(() => {
				firePointerEvent(element, "up");
			});
			const handleBlur = () => firePointerEvent(element, "cancel");
			element.addEventListener("keyup", handleKeyup, eventOptions);
			element.addEventListener("blur", handleBlur, eventOptions);
		});
		element.addEventListener("keydown", handleKeydown, eventOptions);
		/**
		* Add an event listener that fires on blur to remove the keydown events.
		*/
		element.addEventListener("blur", () => element.removeEventListener("keydown", handleKeydown), eventOptions);
	};
	//#endregion
	//#region node_modules/motion-dom/dist/es/gestures/press/index.mjs
	/**
	* Filter out events that are not primary pointer events, or are triggering
	* while a Motion gesture is active.
	*/
	function isValidPressEvent(event) {
		return isPrimaryPointer(event) && !isDragActive();
	}
	/**
	* Create a press gesture.
	*
	* Press is different to `"pointerdown"`, `"pointerup"` in that it
	* automatically filters out secondary pointer events like right
	* click and multitouch.
	*
	* It also adds accessibility support for keyboards, where
	* an element with a press gesture will receive focus and
	*  trigger on Enter `"keydown"` and `"keyup"` events.
	*
	* This is different to a browser's `"click"` event, which does
	* respond to keyboards but only for the `"click"` itself, rather
	* than the press start and end/cancel. The element also needs
	* to be focusable for this to work, whereas a press gesture will
	* make an element focusable by default.
	*
	* @public
	*/
	function press(elementOrSelector, onPressStart, options = {}) {
		const [elements, eventOptions, cancelEvents] = setupGesture(elementOrSelector, options);
		const startPress = (startEvent) => {
			const element = startEvent.currentTarget;
			if (!isValidPressEvent(startEvent) || isPressing.has(element)) return;
			isPressing.add(element);
			const onPressEnd = onPressStart(startEvent);
			const onPointerEnd = (endEvent, success) => {
				window.removeEventListener("pointerup", onPointerUp);
				window.removeEventListener("pointercancel", onPointerCancel);
				if (!isValidPressEvent(endEvent) || !isPressing.has(element)) return;
				isPressing.delete(element);
				if (typeof onPressEnd === "function") onPressEnd(endEvent, { success });
			};
			const onPointerUp = (upEvent) => {
				onPointerEnd(upEvent, options.useGlobalTarget || isNodeOrChild(element, upEvent.target));
			};
			const onPointerCancel = (cancelEvent) => {
				onPointerEnd(cancelEvent, false);
			};
			window.addEventListener("pointerup", onPointerUp, eventOptions);
			window.addEventListener("pointercancel", onPointerCancel, eventOptions);
		};
		elements.forEach((element) => {
			if (!isElementKeyboardAccessible(element) && element.getAttribute("tabindex") === null) element.tabIndex = 0;
			(options.useGlobalTarget ? window : element).addEventListener("pointerdown", startPress, eventOptions);
			element.addEventListener("focus", (event) => enableKeyboardPress(event, eventOptions), eventOptions);
		});
		return cancelEvents;
	}
	//#endregion
	//#region node_modules/motion-dom/dist/es/gestures/drag/state/set-active.mjs
	function setDragLock(axis) {
		if (axis === "x" || axis === "y") {
			if (isDragging[axis]) return null;
			else {
				isDragging[axis] = true;
				return () => {
					isDragging[axis] = false;
				};
			}
		} else if (isDragging.x || isDragging.y) return null;
		else {
			isDragging.x = isDragging.y = true;
			return () => {
				isDragging.x = isDragging.y = false;
			};
		}
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/html/utils/keys-position.mjs
	var positionalKeys = /* @__PURE__ */ new Set([
		"width",
		"height",
		"top",
		"left",
		"right",
		"bottom",
		...transformPropOrder
	]);
	//#endregion
	//#region node_modules/framer-motion/dist/es/frameloop/sync-time.mjs
	var now;
	function clearTime() {
		now = void 0;
	}
	/**
	* An eventloop-synchronous alternative to performance.now().
	*
	* Ensures that time measurements remain consistent within a synchronous context.
	* Usually calling performance.now() twice within the same synchronous context
	* will return different values which isn't useful for animations when we're usually
	* trying to sync animations to the same frame.
	*/
	var time = {
		now: () => {
			if (now === void 0) time.set(frameData.isProcessing || MotionGlobalConfig.useManualTiming ? frameData.timestamp : performance.now());
			return now;
		},
		set: (newTime) => {
			now = newTime;
			queueMicrotask(clearTime);
		}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/array.mjs
	function addUniqueItem(arr, item) {
		if (arr.indexOf(item) === -1) arr.push(item);
	}
	function removeItem(arr, item) {
		const index = arr.indexOf(item);
		if (index > -1) arr.splice(index, 1);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/subscription-manager.mjs
	var SubscriptionManager = class {
		constructor() {
			this.subscriptions = [];
		}
		add(handler) {
			addUniqueItem(this.subscriptions, handler);
			return () => removeItem(this.subscriptions, handler);
		}
		notify(a, b, c) {
			const numSubscriptions = this.subscriptions.length;
			if (!numSubscriptions) return;
			if (numSubscriptions === 1)
 /**
			* If there's only a single handler we can just call it without invoking a loop.
			*/
			this.subscriptions[0](a, b, c);
			else for (let i = 0; i < numSubscriptions; i++) {
				/**
				* Check whether the handler exists before firing as it's possible
				* the subscriptions were modified during this loop running.
				*/
				const handler = this.subscriptions[i];
				handler && handler(a, b, c);
			}
		}
		getSize() {
			return this.subscriptions.length;
		}
		clear() {
			this.subscriptions.length = 0;
		}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/velocity-per-second.mjs
	function velocityPerSecond(velocity, frameDuration) {
		return frameDuration ? velocity * (1e3 / frameDuration) : 0;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/value/index.mjs
	/**
	* Maximum time between the value of two frames, beyond which we
	* assume the velocity has since been 0.
	*/
	var MAX_VELOCITY_DELTA = 30;
	var isFloat = (value) => {
		return !isNaN(parseFloat(value));
	};
	var collectMotionValues = { current: void 0 };
	/**
	* `MotionValue` is used to track the state and velocity of motion values.
	*
	* @public
	*/
	var MotionValue = class {
		/**
		* @param init - The initiating value
		* @param config - Optional configuration options
		*
		* -  `transformer`: A function to transform incoming values with.
		*
		* @internal
		*/
		constructor(init, options = {}) {
			/**
			* This will be replaced by the build step with the latest version number.
			* When MotionValues are provided to motion components, warn if versions are mixed.
			*/
			this.version = "11.18.2";
			/**
			* Tracks whether this value can output a velocity. Currently this is only true
			* if the value is numerical, but we might be able to widen the scope here and support
			* other value types.
			*
			* @internal
			*/
			this.canTrackVelocity = null;
			/**
			* An object containing a SubscriptionManager for each active event.
			*/
			this.events = {};
			this.updateAndNotify = (v, render = true) => {
				const currentTime = time.now();
				/**
				* If we're updating the value during another frame or eventloop
				* than the previous frame, then the we set the previous frame value
				* to current.
				*/
				if (this.updatedAt !== currentTime) this.setPrevFrameValue();
				this.prev = this.current;
				this.setCurrent(v);
				if (this.current !== this.prev && this.events.change) this.events.change.notify(this.current);
				if (render && this.events.renderRequest) this.events.renderRequest.notify(this.current);
			};
			this.hasAnimated = false;
			this.setCurrent(init);
			this.owner = options.owner;
		}
		setCurrent(current) {
			this.current = current;
			this.updatedAt = time.now();
			if (this.canTrackVelocity === null && current !== void 0) this.canTrackVelocity = isFloat(this.current);
		}
		setPrevFrameValue(prevFrameValue = this.current) {
			this.prevFrameValue = prevFrameValue;
			this.prevUpdatedAt = this.updatedAt;
		}
		/**
		* Adds a function that will be notified when the `MotionValue` is updated.
		*
		* It returns a function that, when called, will cancel the subscription.
		*
		* When calling `onChange` inside a React component, it should be wrapped with the
		* `useEffect` hook. As it returns an unsubscribe function, this should be returned
		* from the `useEffect` function to ensure you don't add duplicate subscribers..
		*
		* ```jsx
		* export const MyComponent = () => {
		*   const x = useMotionValue(0)
		*   const y = useMotionValue(0)
		*   const opacity = useMotionValue(1)
		*
		*   useEffect(() => {
		*     function updateOpacity() {
		*       const maxXY = Math.max(x.get(), y.get())
		*       const newOpacity = transform(maxXY, [0, 100], [1, 0])
		*       opacity.set(newOpacity)
		*     }
		*
		*     const unsubscribeX = x.on("change", updateOpacity)
		*     const unsubscribeY = y.on("change", updateOpacity)
		*
		*     return () => {
		*       unsubscribeX()
		*       unsubscribeY()
		*     }
		*   }, [])
		*
		*   return <motion.div style={{ x }} />
		* }
		* ```
		*
		* @param subscriber - A function that receives the latest value.
		* @returns A function that, when called, will cancel this subscription.
		*
		* @deprecated
		*/
		onChange(subscription) {
			return this.on("change", subscription);
		}
		on(eventName, callback) {
			if (!this.events[eventName]) this.events[eventName] = new SubscriptionManager();
			const unsubscribe = this.events[eventName].add(callback);
			if (eventName === "change") return () => {
				unsubscribe();
				/**
				* If we have no more change listeners by the start
				* of the next frame, stop active animations.
				*/
				frame.read(() => {
					if (!this.events.change.getSize()) this.stop();
				});
			};
			return unsubscribe;
		}
		clearListeners() {
			for (const eventManagers in this.events) this.events[eventManagers].clear();
		}
		/**
		* Attaches a passive effect to the `MotionValue`.
		*
		* @internal
		*/
		attach(passiveEffect, stopPassiveEffect) {
			this.passiveEffect = passiveEffect;
			this.stopPassiveEffect = stopPassiveEffect;
		}
		/**
		* Sets the state of the `MotionValue`.
		*
		* @remarks
		*
		* ```jsx
		* const x = useMotionValue(0)
		* x.set(10)
		* ```
		*
		* @param latest - Latest value to set.
		* @param render - Whether to notify render subscribers. Defaults to `true`
		*
		* @public
		*/
		set(v, render = true) {
			if (!render || !this.passiveEffect) this.updateAndNotify(v, render);
			else this.passiveEffect(v, this.updateAndNotify);
		}
		setWithVelocity(prev, current, delta) {
			this.set(current);
			this.prev = void 0;
			this.prevFrameValue = prev;
			this.prevUpdatedAt = this.updatedAt - delta;
		}
		/**
		* Set the state of the `MotionValue`, stopping any active animations,
		* effects, and resets velocity to `0`.
		*/
		jump(v, endAnimation = true) {
			this.updateAndNotify(v);
			this.prev = v;
			this.prevUpdatedAt = this.prevFrameValue = void 0;
			endAnimation && this.stop();
			if (this.stopPassiveEffect) this.stopPassiveEffect();
		}
		/**
		* Returns the latest state of `MotionValue`
		*
		* @returns - The latest state of `MotionValue`
		*
		* @public
		*/
		get() {
			if (collectMotionValues.current) collectMotionValues.current.push(this);
			return this.current;
		}
		/**
		* @public
		*/
		getPrevious() {
			return this.prev;
		}
		/**
		* Returns the latest velocity of `MotionValue`
		*
		* @returns - The latest velocity of `MotionValue`. Returns `0` if the state is non-numerical.
		*
		* @public
		*/
		getVelocity() {
			const currentTime = time.now();
			if (!this.canTrackVelocity || this.prevFrameValue === void 0 || currentTime - this.updatedAt > MAX_VELOCITY_DELTA) return 0;
			const delta = Math.min(this.updatedAt - this.prevUpdatedAt, MAX_VELOCITY_DELTA);
			return velocityPerSecond(parseFloat(this.current) - parseFloat(this.prevFrameValue), delta);
		}
		/**
		* Registers a new animation to control this `MotionValue`. Only one
		* animation can drive a `MotionValue` at one time.
		*
		* ```jsx
		* value.start()
		* ```
		*
		* @param animation - A function that starts the provided animation
		*
		* @internal
		*/
		start(startAnimation) {
			this.stop();
			return new Promise((resolve) => {
				this.hasAnimated = true;
				this.animation = startAnimation(resolve);
				if (this.events.animationStart) this.events.animationStart.notify();
			}).then(() => {
				if (this.events.animationComplete) this.events.animationComplete.notify();
				this.clearAnimation();
			});
		}
		/**
		* Stop the currently active animation.
		*
		* @public
		*/
		stop() {
			if (this.animation) {
				this.animation.stop();
				if (this.events.animationCancel) this.events.animationCancel.notify();
			}
			this.clearAnimation();
		}
		/**
		* Returns `true` if this value is currently animating.
		*
		* @public
		*/
		isAnimating() {
			return !!this.animation;
		}
		clearAnimation() {
			delete this.animation;
		}
		/**
		* Destroy and clean up subscribers to this `MotionValue`.
		*
		* The `MotionValue` hooks like `useMotionValue` and `useTransform` automatically
		* handle the lifecycle of the returned `MotionValue`, so this method is only necessary if you've manually
		* created a `MotionValue` via the `motionValue` function.
		*
		* @public
		*/
		destroy() {
			this.clearListeners();
			this.stop();
			if (this.stopPassiveEffect) this.stopPassiveEffect();
		}
	};
	function motionValue(init, options) {
		return new MotionValue(init, options);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/utils/setters.mjs
	init_objectWithoutProperties();
	init_objectSpread2();
	var _excluded$7 = ["transitionEnd", "transition"];
	/**
	* Set VisualElement's MotionValue, creating a new MotionValue for it if
	* it doesn't exist.
	*/
	function setMotionValue(visualElement, key, value) {
		if (visualElement.hasValue(key)) visualElement.getValue(key).set(value);
		else visualElement.addValue(key, motionValue(value));
	}
	function setTarget(visualElement, definition) {
		let _ref = resolveVariant(visualElement, definition) || {}, { transitionEnd = {}, transition = {} } = _ref, target = _objectWithoutProperties(_ref, _excluded$7);
		target = _objectSpread2(_objectSpread2({}, target), transitionEnd);
		for (const key in target) setMotionValue(visualElement, key, resolveFinalValueInKeyframes(target[key]));
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/value/use-will-change/is.mjs
	function isWillChangeMotionValue(value) {
		return Boolean(isMotionValue(value) && value.add);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/value/use-will-change/add-will-change.mjs
	function addValueToWillChange(visualElement, key) {
		const willChange = visualElement.getValue("willChange");
		/**
		* It could be that a user has set willChange to a regular MotionValue,
		* in which case we can't add the value to it.
		*/
		if (isWillChangeMotionValue(willChange)) return willChange.add(key);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/optimized-appear/get-appear-id.mjs
	function getOptimisedAppearId(visualElement) {
		return visualElement.props[optimizedAppearDataAttribute];
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/use-instant-transition-state.mjs
	var instantAnimationState = { current: false };
	//#endregion
	//#region node_modules/framer-motion/dist/es/easing/cubic-bezier.mjs
	var calcBezier = (t, a1, a2) => (((1 - 3 * a2 + 3 * a1) * t + (3 * a2 - 6 * a1)) * t + 3 * a1) * t;
	var subdivisionPrecision = 1e-7;
	var subdivisionMaxIterations = 12;
	function binarySubdivide(x, lowerBound, upperBound, mX1, mX2) {
		let currentX;
		let currentT;
		let i = 0;
		do {
			currentT = lowerBound + (upperBound - lowerBound) / 2;
			currentX = calcBezier(currentT, mX1, mX2) - x;
			if (currentX > 0) upperBound = currentT;
			else lowerBound = currentT;
		} while (Math.abs(currentX) > subdivisionPrecision && ++i < subdivisionMaxIterations);
		return currentT;
	}
	function cubicBezier(mX1, mY1, mX2, mY2) {
		if (mX1 === mY1 && mX2 === mY2) return noop;
		const getTForX = (aX) => binarySubdivide(aX, 0, 1, mX1, mX2);
		return (t) => t === 0 || t === 1 ? t : calcBezier(getTForX(t), mY1, mY2);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/easing/modifiers/mirror.mjs
	var mirrorEasing = (easing) => (p) => p <= .5 ? easing(2 * p) / 2 : (2 - easing(2 * (1 - p))) / 2;
	//#endregion
	//#region node_modules/framer-motion/dist/es/easing/modifiers/reverse.mjs
	var reverseEasing = (easing) => (p) => 1 - easing(1 - p);
	//#endregion
	//#region node_modules/framer-motion/dist/es/easing/back.mjs
	var backOut = /*@__PURE__*/ cubicBezier(.33, 1.53, .69, .99);
	var backIn = /*@__PURE__*/ reverseEasing(backOut);
	var backInOut = /*@__PURE__*/ mirrorEasing(backIn);
	//#endregion
	//#region node_modules/framer-motion/dist/es/easing/anticipate.mjs
	var anticipate = (p) => (p *= 2) < 1 ? .5 * backIn(p) : .5 * (2 - Math.pow(2, -10 * (p - 1)));
	//#endregion
	//#region node_modules/framer-motion/dist/es/easing/circ.mjs
	var circIn = (p) => 1 - Math.sin(Math.acos(p));
	var circOut = reverseEasing(circIn);
	var circInOut = mirrorEasing(circIn);
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/is-zero-value-string.mjs
	/**
	* Check if the value is a zero value string like "0px" or "0%"
	*/
	var isZeroValueString = (v) => /^0[^.\s]+$/u.test(v);
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/utils/is-none.mjs
	function isNone(value) {
		if (typeof value === "number") return value === 0;
		else if (value !== null) return value === "none" || value === "0" || isZeroValueString(value);
		else return true;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/value/types/utils/sanitize.mjs
	var sanitize = (v) => Math.round(v * 1e5) / 1e5;
	//#endregion
	//#region node_modules/framer-motion/dist/es/value/types/utils/float-regex.mjs
	var floatRegex = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu;
	//#endregion
	//#region node_modules/framer-motion/dist/es/value/types/utils/is-nullish.mjs
	function isNullish(v) {
		return v == null;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/value/types/utils/single-color-regex.mjs
	var singleColorRegex = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu;
	//#endregion
	//#region node_modules/framer-motion/dist/es/value/types/color/utils.mjs
	/**
	* Returns true if the provided string is a color, ie rgba(0,0,0,0) or #000,
	* but false if a number or multiple colors
	*/
	var isColorString = (type, testProp) => (v) => {
		return Boolean(typeof v === "string" && singleColorRegex.test(v) && v.startsWith(type) || testProp && !isNullish(v) && Object.prototype.hasOwnProperty.call(v, testProp));
	};
	var splitColor = (aName, bName, cName) => (v) => {
		if (typeof v !== "string") return v;
		const [a, b, c, alpha] = v.match(floatRegex);
		return {
			[aName]: parseFloat(a),
			[bName]: parseFloat(b),
			[cName]: parseFloat(c),
			alpha: alpha !== void 0 ? parseFloat(alpha) : 1
		};
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/value/types/color/rgba.mjs
	init_objectSpread2();
	var clampRgbUnit = (v) => clamp(0, 255, v);
	var rgbUnit = _objectSpread2(_objectSpread2({}, number), {}, { transform: (v) => Math.round(clampRgbUnit(v)) });
	var rgba = {
		test: /*@__PURE__*/ isColorString("rgb", "red"),
		parse: /*@__PURE__*/ splitColor("red", "green", "blue"),
		transform: ({ red, green, blue, alpha: alpha$1 = 1 }) => "rgba(" + rgbUnit.transform(red) + ", " + rgbUnit.transform(green) + ", " + rgbUnit.transform(blue) + ", " + sanitize(alpha.transform(alpha$1)) + ")"
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/value/types/color/hex.mjs
	function parseHex(v) {
		let r = "";
		let g = "";
		let b = "";
		let a = "";
		if (v.length > 5) {
			r = v.substring(1, 3);
			g = v.substring(3, 5);
			b = v.substring(5, 7);
			a = v.substring(7, 9);
		} else {
			r = v.substring(1, 2);
			g = v.substring(2, 3);
			b = v.substring(3, 4);
			a = v.substring(4, 5);
			r += r;
			g += g;
			b += b;
			a += a;
		}
		return {
			red: parseInt(r, 16),
			green: parseInt(g, 16),
			blue: parseInt(b, 16),
			alpha: a ? parseInt(a, 16) / 255 : 1
		};
	}
	var hex = {
		test: /*@__PURE__*/ isColorString("#"),
		parse: parseHex,
		transform: rgba.transform
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/value/types/color/hsla.mjs
	var hsla = {
		test: /*@__PURE__*/ isColorString("hsl", "hue"),
		parse: /*@__PURE__*/ splitColor("hue", "saturation", "lightness"),
		transform: ({ hue, saturation, lightness, alpha: alpha$1 = 1 }) => {
			return "hsla(" + Math.round(hue) + ", " + percent.transform(sanitize(saturation)) + ", " + percent.transform(sanitize(lightness)) + ", " + sanitize(alpha.transform(alpha$1)) + ")";
		}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/value/types/color/index.mjs
	var color = {
		test: (v) => rgba.test(v) || hex.test(v) || hsla.test(v),
		parse: (v) => {
			if (rgba.test(v)) return rgba.parse(v);
			else if (hsla.test(v)) return hsla.parse(v);
			else return hex.parse(v);
		},
		transform: (v) => {
			return typeof v === "string" ? v : v.hasOwnProperty("red") ? rgba.transform(v) : hsla.transform(v);
		}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/value/types/utils/color-regex.mjs
	var colorRegex = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;
	//#endregion
	//#region node_modules/framer-motion/dist/es/value/types/complex/index.mjs
	function test(v) {
		var _a, _b;
		return isNaN(v) && typeof v === "string" && (((_a = v.match(floatRegex)) === null || _a === void 0 ? void 0 : _a.length) || 0) + (((_b = v.match(colorRegex)) === null || _b === void 0 ? void 0 : _b.length) || 0) > 0;
	}
	var NUMBER_TOKEN = "number";
	var COLOR_TOKEN = "color";
	var VAR_TOKEN = "var";
	var VAR_FUNCTION_TOKEN = "var(";
	var SPLIT_TOKEN = "${}";
	var complexRegex = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;
	function analyseComplexValue(value) {
		const originalValue = value.toString();
		const values = [];
		const indexes = {
			color: [],
			number: [],
			var: []
		};
		const types = [];
		let i = 0;
		return {
			values,
			split: originalValue.replace(complexRegex, (parsedValue) => {
				if (color.test(parsedValue)) {
					indexes.color.push(i);
					types.push(COLOR_TOKEN);
					values.push(color.parse(parsedValue));
				} else if (parsedValue.startsWith(VAR_FUNCTION_TOKEN)) {
					indexes.var.push(i);
					types.push(VAR_TOKEN);
					values.push(parsedValue);
				} else {
					indexes.number.push(i);
					types.push(NUMBER_TOKEN);
					values.push(parseFloat(parsedValue));
				}
				++i;
				return SPLIT_TOKEN;
			}).split(SPLIT_TOKEN),
			indexes,
			types
		};
	}
	function parseComplexValue(v) {
		return analyseComplexValue(v).values;
	}
	function createTransformer(source) {
		const { split, types } = analyseComplexValue(source);
		const numSections = split.length;
		return (v) => {
			let output = "";
			for (let i = 0; i < numSections; i++) {
				output += split[i];
				if (v[i] !== void 0) {
					const type = types[i];
					if (type === NUMBER_TOKEN) output += sanitize(v[i]);
					else if (type === COLOR_TOKEN) output += color.transform(v[i]);
					else output += v[i];
				}
			}
			return output;
		};
	}
	var convertNumbersToZero = (v) => typeof v === "number" ? 0 : v;
	function getAnimatableNone$1(v) {
		const parsed = parseComplexValue(v);
		return createTransformer(v)(parsed.map(convertNumbersToZero));
	}
	var complex = {
		test,
		parse: parseComplexValue,
		createTransformer,
		getAnimatableNone: getAnimatableNone$1
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/value/types/complex/filter.mjs
	init_objectSpread2();
	/**
	* Properties that should default to 1 or 100%
	*/
	var maxDefaults = /* @__PURE__ */ new Set([
		"brightness",
		"contrast",
		"saturate",
		"opacity"
	]);
	function applyDefaultFilter(v) {
		const [name, value] = v.slice(0, -1).split("(");
		if (name === "drop-shadow") return v;
		const [number] = value.match(floatRegex) || [];
		if (!number) return v;
		const unit = value.replace(number, "");
		let defaultValue = maxDefaults.has(name) ? 1 : 0;
		if (number !== value) defaultValue *= 100;
		return name + "(" + defaultValue + unit + ")";
	}
	var functionRegex = /\b([a-z-]*)\(.*?\)/gu;
	var filter = _objectSpread2(_objectSpread2({}, complex), {}, { getAnimatableNone: (v) => {
		const functions = v.match(functionRegex);
		return functions ? functions.map(applyDefaultFilter).join(" ") : v;
	} });
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/dom/value-types/defaults.mjs
	init_objectSpread2();
	/**
	* A map of default value types for common values
	*/
	var defaultValueTypes = _objectSpread2(_objectSpread2({}, numberValueTypes), {}, {
		color,
		backgroundColor: color,
		outlineColor: color,
		fill: color,
		stroke: color,
		borderColor: color,
		borderTopColor: color,
		borderRightColor: color,
		borderBottomColor: color,
		borderLeftColor: color,
		filter,
		WebkitFilter: filter
	});
	/**
	* Gets the default ValueType for the provided value key
	*/
	var getDefaultValueType = (key) => defaultValueTypes[key];
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/dom/value-types/animatable-none.mjs
	function getAnimatableNone(key, value) {
		let defaultValueType = getDefaultValueType(key);
		if (defaultValueType !== filter) defaultValueType = complex;
		return defaultValueType.getAnimatableNone ? defaultValueType.getAnimatableNone(value) : void 0;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/html/utils/make-none-animatable.mjs
	/**
	* If we encounter keyframes like "none" or "0" and we also have keyframes like
	* "#fff" or "200px 200px" we want to find a keyframe to serve as a template for
	* the "none" keyframes. In this case "#fff" or "200px 200px" - then these get turned into
	* zero equivalents, i.e. "#fff0" or "0px 0px".
	*/
	var invalidTemplates = /* @__PURE__ */ new Set([
		"auto",
		"none",
		"0"
	]);
	function makeNoneKeyframesAnimatable(unresolvedKeyframes, noneKeyframeIndexes, name) {
		let i = 0;
		let animatableTemplate = void 0;
		while (i < unresolvedKeyframes.length && !animatableTemplate) {
			const keyframe = unresolvedKeyframes[i];
			if (typeof keyframe === "string" && !invalidTemplates.has(keyframe) && analyseComplexValue(keyframe).values.length) animatableTemplate = unresolvedKeyframes[i];
			i++;
		}
		if (animatableTemplate && name) for (const noneIndex of noneKeyframeIndexes) unresolvedKeyframes[noneIndex] = getAnimatableNone(name, animatableTemplate);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/dom/utils/unit-conversion.mjs
	var isNumOrPxType = (v) => v === number || v === px;
	var getPosFromMatrix = (matrix, pos) => parseFloat(matrix.split(", ")[pos]);
	var getTranslateFromMatrix = (pos2, pos3) => (_bbox, { transform }) => {
		if (transform === "none" || !transform) return 0;
		const matrix3d = transform.match(/^matrix3d\((.+)\)$/u);
		if (matrix3d) return getPosFromMatrix(matrix3d[1], pos3);
		else {
			const matrix = transform.match(/^matrix\((.+)\)$/u);
			if (matrix) return getPosFromMatrix(matrix[1], pos2);
			else return 0;
		}
	};
	var transformKeys = /* @__PURE__ */ new Set([
		"x",
		"y",
		"z"
	]);
	var nonTranslationalTransformKeys = transformPropOrder.filter((key) => !transformKeys.has(key));
	function removeNonTranslationalTransform(visualElement) {
		const removedTransforms = [];
		nonTranslationalTransformKeys.forEach((key) => {
			const value = visualElement.getValue(key);
			if (value !== void 0) {
				removedTransforms.push([key, value.get()]);
				value.set(key.startsWith("scale") ? 1 : 0);
			}
		});
		return removedTransforms;
	}
	var positionalValues = {
		width: ({ x }, { paddingLeft = "0", paddingRight = "0" }) => x.max - x.min - parseFloat(paddingLeft) - parseFloat(paddingRight),
		height: ({ y }, { paddingTop = "0", paddingBottom = "0" }) => y.max - y.min - parseFloat(paddingTop) - parseFloat(paddingBottom),
		top: (_bbox, { top }) => parseFloat(top),
		left: (_bbox, { left }) => parseFloat(left),
		bottom: ({ y }, { top }) => parseFloat(top) + (y.max - y.min),
		right: ({ x }, { left }) => parseFloat(left) + (x.max - x.min),
		x: getTranslateFromMatrix(4, 13),
		y: getTranslateFromMatrix(5, 14)
	};
	positionalValues.translateX = positionalValues.x;
	positionalValues.translateY = positionalValues.y;
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/utils/KeyframesResolver.mjs
	var toResolve = /* @__PURE__ */ new Set();
	var isScheduled = false;
	var anyNeedsMeasurement = false;
	function measureAllKeyframes() {
		if (anyNeedsMeasurement) {
			const resolversToMeasure = Array.from(toResolve).filter((resolver) => resolver.needsMeasurement);
			const elementsToMeasure = new Set(resolversToMeasure.map((resolver) => resolver.element));
			const transformsToRestore = /* @__PURE__ */ new Map();
			/**
			* Write pass
			* If we're measuring elements we want to remove bounding box-changing transforms.
			*/
			elementsToMeasure.forEach((element) => {
				const removedTransforms = removeNonTranslationalTransform(element);
				if (!removedTransforms.length) return;
				transformsToRestore.set(element, removedTransforms);
				element.render();
			});
			resolversToMeasure.forEach((resolver) => resolver.measureInitialState());
			elementsToMeasure.forEach((element) => {
				element.render();
				const restore = transformsToRestore.get(element);
				if (restore) restore.forEach(([key, value]) => {
					var _a;
					(_a = element.getValue(key)) === null || _a === void 0 || _a.set(value);
				});
			});
			resolversToMeasure.forEach((resolver) => resolver.measureEndState());
			resolversToMeasure.forEach((resolver) => {
				if (resolver.suspendedScrollY !== void 0) window.scrollTo(0, resolver.suspendedScrollY);
			});
		}
		anyNeedsMeasurement = false;
		isScheduled = false;
		toResolve.forEach((resolver) => resolver.complete());
		toResolve.clear();
	}
	function readAllKeyframes() {
		toResolve.forEach((resolver) => {
			resolver.readKeyframes();
			if (resolver.needsMeasurement) anyNeedsMeasurement = true;
		});
	}
	function flushKeyframeResolvers() {
		readAllKeyframes();
		measureAllKeyframes();
	}
	var KeyframeResolver = class {
		constructor(unresolvedKeyframes, onComplete, name, motionValue, element, isAsync = false) {
			/**
			* Track whether this resolver has completed. Once complete, it never
			* needs to attempt keyframe resolution again.
			*/
			this.isComplete = false;
			/**
			* Track whether this resolver is async. If it is, it'll be added to the
			* resolver queue and flushed in the next frame. Resolvers that aren't going
			* to trigger read/write thrashing don't need to be async.
			*/
			this.isAsync = false;
			/**
			* Track whether this resolver needs to perform a measurement
			* to resolve its keyframes.
			*/
			this.needsMeasurement = false;
			/**
			* Track whether this resolver is currently scheduled to resolve
			* to allow it to be cancelled and resumed externally.
			*/
			this.isScheduled = false;
			this.unresolvedKeyframes = [...unresolvedKeyframes];
			this.onComplete = onComplete;
			this.name = name;
			this.motionValue = motionValue;
			this.element = element;
			this.isAsync = isAsync;
		}
		scheduleResolve() {
			this.isScheduled = true;
			if (this.isAsync) {
				toResolve.add(this);
				if (!isScheduled) {
					isScheduled = true;
					frame.read(readAllKeyframes);
					frame.resolveKeyframes(measureAllKeyframes);
				}
			} else {
				this.readKeyframes();
				this.complete();
			}
		}
		readKeyframes() {
			const { unresolvedKeyframes, name, element, motionValue } = this;
			/**
			* If a keyframe is null, we hydrate it either by reading it from
			* the instance, or propagating from previous keyframes.
			*/
			for (let i = 0; i < unresolvedKeyframes.length; i++) if (unresolvedKeyframes[i] === null) {
				/**
				* If the first keyframe is null, we need to find its value by sampling the element
				*/
				if (i === 0) {
					const currentValue = motionValue === null || motionValue === void 0 ? void 0 : motionValue.get();
					const finalKeyframe = unresolvedKeyframes[unresolvedKeyframes.length - 1];
					if (currentValue !== void 0) unresolvedKeyframes[0] = currentValue;
					else if (element && name) {
						const valueAsRead = element.readValue(name, finalKeyframe);
						if (valueAsRead !== void 0 && valueAsRead !== null) unresolvedKeyframes[0] = valueAsRead;
					}
					if (unresolvedKeyframes[0] === void 0) unresolvedKeyframes[0] = finalKeyframe;
					if (motionValue && currentValue === void 0) motionValue.set(unresolvedKeyframes[0]);
				} else unresolvedKeyframes[i] = unresolvedKeyframes[i - 1];
			}
		}
		setFinalKeyframe() {}
		measureInitialState() {}
		renderEndStyles() {}
		measureEndState() {}
		complete() {
			this.isComplete = true;
			this.onComplete(this.unresolvedKeyframes, this.finalKeyframe);
			toResolve.delete(this);
		}
		cancel() {
			if (!this.isComplete) {
				this.isScheduled = false;
				toResolve.delete(this);
			}
		}
		resume() {
			if (!this.isComplete) this.scheduleResolve();
		}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/is-numerical-string.mjs
	/**
	* Check if value is a numerical string, ie a string that is purely a number eg "100" or "-100.1"
	*/
	var isNumericalString = (v) => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(v);
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/dom/utils/css-variables-conversion.mjs
	/**
	* Parse Framer's special CSS variable format into a CSS token and a fallback.
	*
	* ```
	* `var(--foo, #fff)` => [`--foo`, '#fff']
	* ```
	*
	* @param current
	*/
	var splitCSSVariableRegex = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;
	function parseCSSVariable(current) {
		const match = splitCSSVariableRegex.exec(current);
		if (!match) return [,];
		const [, token1, token2, fallback] = match;
		return [`--${token1 !== null && token1 !== void 0 ? token1 : token2}`, fallback];
	}
	var maxDepth = 4;
	function getVariableValue(current, element, depth = 1) {
		invariant(depth <= maxDepth, `Max CSS variable fallback depth detected in property "${current}". This may indicate a circular fallback dependency.`);
		const [token, fallback] = parseCSSVariable(current);
		if (!token) return;
		const resolved = window.getComputedStyle(element).getPropertyValue(token);
		if (resolved) {
			const trimmed = resolved.trim();
			return isNumericalString(trimmed) ? parseFloat(trimmed) : trimmed;
		}
		return isCSSVariableToken(fallback) ? getVariableValue(fallback, element, depth + 1) : fallback;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/dom/value-types/test.mjs
	/**
	* Tests a provided value against a ValueType
	*/
	var testValueType = (v) => (type) => type.test(v);
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/dom/value-types/dimensions.mjs
	/**
	* A list of value types commonly used for dimensions
	*/
	var dimensionValueTypes = [
		number,
		px,
		percent,
		degrees,
		vw,
		vh,
		{
			test: (v) => v === "auto",
			parse: (v) => v
		}
	];
	/**
	* Tests a dimensional value against the list of dimension ValueTypes
	*/
	var findDimensionValueType = (v) => dimensionValueTypes.find(testValueType(v));
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/dom/DOMKeyframesResolver.mjs
	var DOMKeyframesResolver = class extends KeyframeResolver {
		constructor(unresolvedKeyframes, onComplete, name, motionValue, element) {
			super(unresolvedKeyframes, onComplete, name, motionValue, element, true);
		}
		readKeyframes() {
			const { unresolvedKeyframes, element, name } = this;
			if (!element || !element.current) return;
			super.readKeyframes();
			/**
			* If any keyframe is a CSS variable, we need to find its value by sampling the element
			*/
			for (let i = 0; i < unresolvedKeyframes.length; i++) {
				let keyframe = unresolvedKeyframes[i];
				if (typeof keyframe === "string") {
					keyframe = keyframe.trim();
					if (isCSSVariableToken(keyframe)) {
						const resolved = getVariableValue(keyframe, element.current);
						if (resolved !== void 0) unresolvedKeyframes[i] = resolved;
						if (i === unresolvedKeyframes.length - 1) this.finalKeyframe = keyframe;
					}
				}
			}
			/**
			* Resolve "none" values. We do this potentially twice - once before and once after measuring keyframes.
			* This could be seen as inefficient but it's a trade-off to avoid measurements in more situations, which
			* have a far bigger performance impact.
			*/
			this.resolveNoneKeyframes();
			/**
			* Check to see if unit type has changed. If so schedule jobs that will
			* temporarily set styles to the destination keyframes.
			* Skip if we have more than two keyframes or this isn't a positional value.
			* TODO: We can throw if there are multiple keyframes and the value type changes.
			*/
			if (!positionalKeys.has(name) || unresolvedKeyframes.length !== 2) return;
			const [origin, target] = unresolvedKeyframes;
			const originType = findDimensionValueType(origin);
			const targetType = findDimensionValueType(target);
			/**
			* Either we don't recognise these value types or we can animate between them.
			*/
			if (originType === targetType) return;
			/**
			* If both values are numbers or pixels, we can animate between them by
			* converting them to numbers.
			*/
			if (isNumOrPxType(originType) && isNumOrPxType(targetType)) for (let i = 0; i < unresolvedKeyframes.length; i++) {
				const value = unresolvedKeyframes[i];
				if (typeof value === "string") unresolvedKeyframes[i] = parseFloat(value);
			}
			else
 /**
			* Else, the only way to resolve this is by measuring the element.
			*/
			this.needsMeasurement = true;
		}
		resolveNoneKeyframes() {
			const { unresolvedKeyframes, name } = this;
			const noneKeyframeIndexes = [];
			for (let i = 0; i < unresolvedKeyframes.length; i++) if (isNone(unresolvedKeyframes[i])) noneKeyframeIndexes.push(i);
			if (noneKeyframeIndexes.length) makeNoneKeyframesAnimatable(unresolvedKeyframes, noneKeyframeIndexes, name);
		}
		measureInitialState() {
			const { element, unresolvedKeyframes, name } = this;
			if (!element || !element.current) return;
			if (name === "height") this.suspendedScrollY = window.pageYOffset;
			this.measuredOrigin = positionalValues[name](element.measureViewportBox(), window.getComputedStyle(element.current));
			unresolvedKeyframes[0] = this.measuredOrigin;
			const measureKeyframe = unresolvedKeyframes[unresolvedKeyframes.length - 1];
			if (measureKeyframe !== void 0) element.getValue(name, measureKeyframe).jump(measureKeyframe, false);
		}
		measureEndState() {
			var _a;
			const { element, name, unresolvedKeyframes } = this;
			if (!element || !element.current) return;
			const value = element.getValue(name);
			value && value.jump(this.measuredOrigin, false);
			const finalKeyframeIndex = unresolvedKeyframes.length - 1;
			const finalKeyframe = unresolvedKeyframes[finalKeyframeIndex];
			unresolvedKeyframes[finalKeyframeIndex] = positionalValues[name](element.measureViewportBox(), window.getComputedStyle(element.current));
			if (finalKeyframe !== null && this.finalKeyframe === void 0) this.finalKeyframe = finalKeyframe;
			if ((_a = this.removedTransforms) === null || _a === void 0 ? void 0 : _a.length) this.removedTransforms.forEach(([unsetTransformName, unsetTransformValue]) => {
				element.getValue(unsetTransformName).set(unsetTransformValue);
			});
			this.resolveNoneKeyframes();
		}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/utils/is-animatable.mjs
	/**
	* Check if a value is animatable. Examples:
	*
	* ✅: 100, "100px", "#fff"
	* ❌: "block", "url(2.jpg)"
	* @param value
	*
	* @internal
	*/
	var isAnimatable = (value, name) => {
		if (name === "zIndex") return false;
		if (typeof value === "number" || Array.isArray(value)) return true;
		if (typeof value === "string" && (complex.test(value) || value === "0") && !value.startsWith("url(")) return true;
		return false;
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/animators/utils/can-animate.mjs
	function hasKeyframesChanged(keyframes) {
		const current = keyframes[0];
		if (keyframes.length === 1) return true;
		for (let i = 0; i < keyframes.length; i++) if (keyframes[i] !== current) return true;
	}
	function canAnimate(keyframes, name, type, velocity) {
		/**
		* Check if we're able to animate between the start and end keyframes,
		* and throw a warning if we're attempting to animate between one that's
		* animatable and another that isn't.
		*/
		const originKeyframe = keyframes[0];
		if (originKeyframe === null) return false;
		/**
		* These aren't traditionally animatable but we do support them.
		* In future we could look into making this more generic or replacing
		* this function with mix() === mixImmediate
		*/
		if (name === "display" || name === "visibility") return true;
		const targetKeyframe = keyframes[keyframes.length - 1];
		const isOriginAnimatable = isAnimatable(originKeyframe, name);
		const isTargetAnimatable = isAnimatable(targetKeyframe, name);
		warning(isOriginAnimatable === isTargetAnimatable, `You are trying to animate ${name} from "${originKeyframe}" to "${targetKeyframe}". ${originKeyframe} is not an animatable value - to enable this animation set ${originKeyframe} to a value animatable to ${targetKeyframe} via the \`style\` property.`);
		if (!isOriginAnimatable || !isTargetAnimatable) return false;
		return hasKeyframesChanged(keyframes) || (type === "spring" || isGenerator(type)) && velocity;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/animators/waapi/utils/get-final-keyframe.mjs
	var isNotNull = (value) => value !== null;
	function getFinalKeyframe(keyframes, { repeat, repeatType = "loop" }, finalKeyframe) {
		const resolvedKeyframes = keyframes.filter(isNotNull);
		const index = repeat && repeatType !== "loop" && repeat % 2 === 1 ? 0 : resolvedKeyframes.length - 1;
		return !index || finalKeyframe === void 0 ? resolvedKeyframes[index] : finalKeyframe;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/animators/BaseAnimation.mjs
	init_objectWithoutProperties();
	init_objectSpread2();
	var _excluded$6 = [
		"autoplay",
		"delay",
		"type",
		"repeat",
		"repeatDelay",
		"repeatType"
	];
	/**
	* Maximum time allowed between an animation being created and it being
	* resolved for us to use the latter as the start time.
	*
	* This is to ensure that while we prefer to "start" an animation as soon
	* as it's triggered, we also want to avoid a visual jump if there's a big delay
	* between these two moments.
	*/
	var MAX_RESOLVE_DELAY = 40;
	var BaseAnimation = class {
		constructor(_ref) {
			let { autoplay = true, delay = 0, type = "keyframes", repeat = 0, repeatDelay = 0, repeatType = "loop" } = _ref, options = _objectWithoutProperties(_ref, _excluded$6);
			this.isStopped = false;
			this.hasAttemptedResolve = false;
			this.createdAt = time.now();
			this.options = _objectSpread2({
				autoplay,
				delay,
				type,
				repeat,
				repeatDelay,
				repeatType
			}, options);
			this.updateFinishedPromise();
		}
		/**
		* This method uses the createdAt and resolvedAt to calculate the
		* animation startTime. *Ideally*, we would use the createdAt time as t=0
		* as the following frame would then be the first frame of the animation in
		* progress, which would feel snappier.
		*
		* However, if there's a delay (main thread work) between the creation of
		* the animation and the first commited frame, we prefer to use resolvedAt
		* to avoid a sudden jump into the animation.
		*/
		calcStartTime() {
			if (!this.resolvedAt) return this.createdAt;
			return this.resolvedAt - this.createdAt > MAX_RESOLVE_DELAY ? this.resolvedAt : this.createdAt;
		}
		/**
		* A getter for resolved data. If keyframes are not yet resolved, accessing
		* this.resolved will synchronously flush all pending keyframe resolvers.
		* This is a deoptimisation, but at its worst still batches read/writes.
		*/
		get resolved() {
			if (!this._resolved && !this.hasAttemptedResolve) flushKeyframeResolvers();
			return this._resolved;
		}
		/**
		* A method to be called when the keyframes resolver completes. This method
		* will check if its possible to run the animation and, if not, skip it.
		* Otherwise, it will call initPlayback on the implementing class.
		*/
		onKeyframesResolved(keyframes, finalKeyframe) {
			this.resolvedAt = time.now();
			this.hasAttemptedResolve = true;
			const { name, type, velocity, delay, onComplete, onUpdate, isGenerator } = this.options;
			/**
			* If we can't animate this value with the resolved keyframes
			* then we should complete it immediately.
			*/
			if (!isGenerator && !canAnimate(keyframes, name, type, velocity)) {
				if (instantAnimationState.current || !delay) {
					onUpdate && onUpdate(getFinalKeyframe(keyframes, this.options, finalKeyframe));
					onComplete && onComplete();
					this.resolveFinishedPromise();
					return;
				} else this.options.duration = 0;
			}
			const resolvedAnimation = this.initPlayback(keyframes, finalKeyframe);
			if (resolvedAnimation === false) return;
			this._resolved = _objectSpread2({
				keyframes,
				finalKeyframe
			}, resolvedAnimation);
			this.onPostResolved();
		}
		onPostResolved() {}
		/**
		* Allows the returned animation to be awaited or promise-chained. Currently
		* resolves when the animation finishes at all but in a future update could/should
		* reject if its cancels.
		*/
		then(resolve, reject) {
			return this.currentFinishedPromise.then(resolve, reject);
		}
		flatten() {
			this.options.type = "keyframes";
			this.options.ease = "linear";
		}
		updateFinishedPromise() {
			this.currentFinishedPromise = new Promise((resolve) => {
				this.resolveFinishedPromise = resolve;
			});
		}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/mix/number.mjs
	var mixNumber$1 = (from, to, progress) => {
		return from + (to - from) * progress;
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/hsla-to-rgba.mjs
	function hueToRgb(p, q, t) {
		if (t < 0) t += 1;
		if (t > 1) t -= 1;
		if (t < 1 / 6) return p + (q - p) * 6 * t;
		if (t < 1 / 2) return q;
		if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
		return p;
	}
	function hslaToRgba({ hue, saturation, lightness, alpha }) {
		hue /= 360;
		saturation /= 100;
		lightness /= 100;
		let red = 0;
		let green = 0;
		let blue = 0;
		if (!saturation) red = green = blue = lightness;
		else {
			const q = lightness < .5 ? lightness * (1 + saturation) : lightness + saturation - lightness * saturation;
			const p = 2 * lightness - q;
			red = hueToRgb(p, q, hue + 1 / 3);
			green = hueToRgb(p, q, hue);
			blue = hueToRgb(p, q, hue - 1 / 3);
		}
		return {
			red: Math.round(red * 255),
			green: Math.round(green * 255),
			blue: Math.round(blue * 255),
			alpha
		};
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/mix/immediate.mjs
	function mixImmediate(a, b) {
		return (p) => p > 0 ? b : a;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/mix/color.mjs
	init_objectSpread2();
	var mixLinearColor = (from, to, v) => {
		const fromExpo = from * from;
		const expo = v * (to * to - fromExpo) + fromExpo;
		return expo < 0 ? 0 : Math.sqrt(expo);
	};
	var colorTypes = [
		hex,
		rgba,
		hsla
	];
	var getColorType = (v) => colorTypes.find((type) => type.test(v));
	function asRGBA(color) {
		const type = getColorType(color);
		warning(Boolean(type), `'${color}' is not an animatable color. Use the equivalent color code instead.`);
		if (!Boolean(type)) return false;
		let model = type.parse(color);
		if (type === hsla) model = hslaToRgba(model);
		return model;
	}
	var mixColor = (from, to) => {
		const fromRGBA = asRGBA(from);
		const toRGBA = asRGBA(to);
		if (!fromRGBA || !toRGBA) return mixImmediate(from, to);
		const blended = _objectSpread2({}, fromRGBA);
		return (v) => {
			blended.red = mixLinearColor(fromRGBA.red, toRGBA.red, v);
			blended.green = mixLinearColor(fromRGBA.green, toRGBA.green, v);
			blended.blue = mixLinearColor(fromRGBA.blue, toRGBA.blue, v);
			blended.alpha = mixNumber$1(fromRGBA.alpha, toRGBA.alpha, v);
			return rgba.transform(blended);
		};
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/pipe.mjs
	/**
	* Pipe
	* Compose other transformers to run linearily
	* pipe(min(20), max(40))
	* @param  {...functions} transformers
	* @return {function}
	*/
	var combineFunctions = (a, b) => (v) => b(a(v));
	var pipe = (...transformers) => transformers.reduce(combineFunctions);
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/mix/visibility.mjs
	var invisibleValues = /* @__PURE__ */ new Set(["none", "hidden"]);
	/**
	* Returns a function that, when provided a progress value between 0 and 1,
	* will return the "none" or "hidden" string only when the progress is that of
	* the origin or target.
	*/
	function mixVisibility(origin, target) {
		if (invisibleValues.has(origin)) return (p) => p <= 0 ? origin : target;
		else return (p) => p >= 1 ? target : origin;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/mix/complex.mjs
	init_objectSpread2();
	function mixNumber(a, b) {
		return (p) => mixNumber$1(a, b, p);
	}
	function getMixer(a) {
		if (typeof a === "number") return mixNumber;
		else if (typeof a === "string") return isCSSVariableToken(a) ? mixImmediate : color.test(a) ? mixColor : mixComplex;
		else if (Array.isArray(a)) return mixArray;
		else if (typeof a === "object") return color.test(a) ? mixColor : mixObject;
		return mixImmediate;
	}
	function mixArray(a, b) {
		const output = [...a];
		const numValues = output.length;
		const blendValue = a.map((v, i) => getMixer(v)(v, b[i]));
		return (p) => {
			for (let i = 0; i < numValues; i++) output[i] = blendValue[i](p);
			return output;
		};
	}
	function mixObject(a, b) {
		const output = _objectSpread2(_objectSpread2({}, a), b);
		const blendValue = {};
		for (const key in output) if (a[key] !== void 0 && b[key] !== void 0) blendValue[key] = getMixer(a[key])(a[key], b[key]);
		return (v) => {
			for (const key in blendValue) output[key] = blendValue[key](v);
			return output;
		};
	}
	function matchOrder(origin, target) {
		var _a;
		const orderedOrigin = [];
		const pointers = {
			color: 0,
			var: 0,
			number: 0
		};
		for (let i = 0; i < target.values.length; i++) {
			const type = target.types[i];
			const originIndex = origin.indexes[type][pointers[type]];
			const originValue = (_a = origin.values[originIndex]) !== null && _a !== void 0 ? _a : 0;
			orderedOrigin[i] = originValue;
			pointers[type]++;
		}
		return orderedOrigin;
	}
	var mixComplex = (origin, target) => {
		const template = complex.createTransformer(target);
		const originStats = analyseComplexValue(origin);
		const targetStats = analyseComplexValue(target);
		if (originStats.indexes.var.length === targetStats.indexes.var.length && originStats.indexes.color.length === targetStats.indexes.color.length && originStats.indexes.number.length >= targetStats.indexes.number.length) {
			if (invisibleValues.has(origin) && !targetStats.values.length || invisibleValues.has(target) && !originStats.values.length) return mixVisibility(origin, target);
			return pipe(mixArray(matchOrder(originStats, targetStats), targetStats.values), template);
		} else {
			warning(true, `Complex values '${origin}' and '${target}' too different to mix. Ensure all colors are of the same type, and that each contains the same quantity of number and color values. Falling back to instant transition.`);
			return mixImmediate(origin, target);
		}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/mix/index.mjs
	function mix(from, to, p) {
		if (typeof from === "number" && typeof to === "number" && typeof p === "number") return mixNumber$1(from, to, p);
		return getMixer(from)(from, to);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/generators/utils/velocity.mjs
	var velocitySampleDuration = 5;
	function calcGeneratorVelocity(resolveValue, t, current) {
		const prevT = Math.max(t - velocitySampleDuration, 0);
		return velocityPerSecond(current - resolveValue(prevT), t - prevT);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/generators/spring/defaults.mjs
	var springDefaults = {
		stiffness: 100,
		damping: 10,
		mass: 1,
		velocity: 0,
		duration: 800,
		bounce: .3,
		visualDuration: .3,
		restSpeed: {
			granular: .01,
			default: 2
		},
		restDelta: {
			granular: .005,
			default: .5
		},
		minDuration: .01,
		maxDuration: 10,
		minDamping: .05,
		maxDamping: 1
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/generators/spring/find.mjs
	var safeMin = .001;
	function findSpring({ duration = springDefaults.duration, bounce = springDefaults.bounce, velocity = springDefaults.velocity, mass = springDefaults.mass }) {
		let envelope;
		let derivative;
		warning(duration <= /* @__PURE__ */ secondsToMilliseconds(springDefaults.maxDuration), "Spring duration must be 10 seconds or less");
		let dampingRatio = 1 - bounce;
		/**
		* Restrict dampingRatio and duration to within acceptable ranges.
		*/
		dampingRatio = clamp(springDefaults.minDamping, springDefaults.maxDamping, dampingRatio);
		duration = clamp(springDefaults.minDuration, springDefaults.maxDuration, /* @__PURE__ */ millisecondsToSeconds(duration));
		if (dampingRatio < 1) {
			/**
			* Underdamped spring
			*/
			envelope = (undampedFreq) => {
				const exponentialDecay = undampedFreq * dampingRatio;
				const delta = exponentialDecay * duration;
				const a = exponentialDecay - velocity;
				const b = calcAngularFreq(undampedFreq, dampingRatio);
				const c = Math.exp(-delta);
				return safeMin - a / b * c;
			};
			derivative = (undampedFreq) => {
				const delta = undampedFreq * dampingRatio * duration;
				const d = delta * velocity + velocity;
				const e = Math.pow(dampingRatio, 2) * Math.pow(undampedFreq, 2) * duration;
				const f = Math.exp(-delta);
				const g = calcAngularFreq(Math.pow(undampedFreq, 2), dampingRatio);
				return (-envelope(undampedFreq) + safeMin > 0 ? -1 : 1) * ((d - e) * f) / g;
			};
		} else {
			/**
			* Critically-damped spring
			*/
			envelope = (undampedFreq) => {
				return -.001 + Math.exp(-undampedFreq * duration) * ((undampedFreq - velocity) * duration + 1);
			};
			derivative = (undampedFreq) => {
				return Math.exp(-undampedFreq * duration) * ((velocity - undampedFreq) * (duration * duration));
			};
		}
		const initialGuess = 5 / duration;
		const undampedFreq = approximateRoot(envelope, derivative, initialGuess);
		duration = /* @__PURE__ */ secondsToMilliseconds(duration);
		if (isNaN(undampedFreq)) return {
			stiffness: springDefaults.stiffness,
			damping: springDefaults.damping,
			duration
		};
		else {
			const stiffness = Math.pow(undampedFreq, 2) * mass;
			return {
				stiffness,
				damping: dampingRatio * 2 * Math.sqrt(mass * stiffness),
				duration
			};
		}
	}
	var rootIterations = 12;
	function approximateRoot(envelope, derivative, initialGuess) {
		let result = initialGuess;
		for (let i = 1; i < rootIterations; i++) result = result - envelope(result) / derivative(result);
		return result;
	}
	function calcAngularFreq(undampedFreq, dampingRatio) {
		return undampedFreq * Math.sqrt(1 - dampingRatio * dampingRatio);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/generators/spring/index.mjs
	init_objectSpread2();
	var durationKeys = ["duration", "bounce"];
	var physicsKeys = [
		"stiffness",
		"damping",
		"mass"
	];
	function isSpringType(options, keys) {
		return keys.some((key) => options[key] !== void 0);
	}
	function getSpringOptions(options) {
		let springOptions = _objectSpread2({
			velocity: springDefaults.velocity,
			stiffness: springDefaults.stiffness,
			damping: springDefaults.damping,
			mass: springDefaults.mass,
			isResolvedFromDuration: false
		}, options);
		if (!isSpringType(options, physicsKeys) && isSpringType(options, durationKeys)) {
			if (options.visualDuration) {
				const visualDuration = options.visualDuration;
				const root = 2 * Math.PI / (visualDuration * 1.2);
				const stiffness = root * root;
				const damping = 2 * clamp(.05, 1, 1 - (options.bounce || 0)) * Math.sqrt(stiffness);
				springOptions = _objectSpread2(_objectSpread2({}, springOptions), {}, {
					mass: springDefaults.mass,
					stiffness,
					damping
				});
			} else {
				const derived = findSpring(options);
				springOptions = _objectSpread2(_objectSpread2(_objectSpread2({}, springOptions), derived), {}, { mass: springDefaults.mass });
				springOptions.isResolvedFromDuration = true;
			}
		}
		return springOptions;
	}
	function spring(optionsOrVisualDuration = springDefaults.visualDuration, bounce = springDefaults.bounce) {
		const options = typeof optionsOrVisualDuration !== "object" ? {
			visualDuration: optionsOrVisualDuration,
			keyframes: [0, 1],
			bounce
		} : optionsOrVisualDuration;
		let { restSpeed, restDelta } = options;
		const origin = options.keyframes[0];
		const target = options.keyframes[options.keyframes.length - 1];
		/**
		* This is the Iterator-spec return value. We ensure it's mutable rather than using a generator
		* to reduce GC during animation.
		*/
		const state = {
			done: false,
			value: origin
		};
		const { stiffness, damping, mass, duration, velocity, isResolvedFromDuration } = getSpringOptions(_objectSpread2(_objectSpread2({}, options), {}, { velocity: -/* @__PURE__ */ millisecondsToSeconds(options.velocity || 0) }));
		const initialVelocity = velocity || 0;
		const dampingRatio = damping / (2 * Math.sqrt(stiffness * mass));
		const initialDelta = target - origin;
		const undampedAngularFreq = /* @__PURE__ */ millisecondsToSeconds(Math.sqrt(stiffness / mass));
		/**
		* If we're working on a granular scale, use smaller defaults for determining
		* when the spring is finished.
		*
		* These defaults have been selected emprically based on what strikes a good
		* ratio between feeling good and finishing as soon as changes are imperceptible.
		*/
		const isGranularScale = Math.abs(initialDelta) < 5;
		restSpeed || (restSpeed = isGranularScale ? springDefaults.restSpeed.granular : springDefaults.restSpeed.default);
		restDelta || (restDelta = isGranularScale ? springDefaults.restDelta.granular : springDefaults.restDelta.default);
		let resolveSpring;
		if (dampingRatio < 1) {
			const angularFreq = calcAngularFreq(undampedAngularFreq, dampingRatio);
			resolveSpring = (t) => {
				const envelope = Math.exp(-dampingRatio * undampedAngularFreq * t);
				return target - envelope * ((initialVelocity + dampingRatio * undampedAngularFreq * initialDelta) / angularFreq * Math.sin(angularFreq * t) + initialDelta * Math.cos(angularFreq * t));
			};
		} else if (dampingRatio === 1) resolveSpring = (t) => target - Math.exp(-undampedAngularFreq * t) * (initialDelta + (initialVelocity + undampedAngularFreq * initialDelta) * t);
		else {
			const dampedAngularFreq = undampedAngularFreq * Math.sqrt(dampingRatio * dampingRatio - 1);
			resolveSpring = (t) => {
				const envelope = Math.exp(-dampingRatio * undampedAngularFreq * t);
				const freqForT = Math.min(dampedAngularFreq * t, 300);
				return target - envelope * ((initialVelocity + dampingRatio * undampedAngularFreq * initialDelta) * Math.sinh(freqForT) + dampedAngularFreq * initialDelta * Math.cosh(freqForT)) / dampedAngularFreq;
			};
		}
		const generator = {
			calculatedDuration: isResolvedFromDuration ? duration || null : null,
			next: (t) => {
				const current = resolveSpring(t);
				if (!isResolvedFromDuration) {
					let currentVelocity = 0;
					/**
					* We only need to calculate velocity for under-damped springs
					* as over- and critically-damped springs can't overshoot, so
					* checking only for displacement is enough.
					*/
					if (dampingRatio < 1) currentVelocity = t === 0 ? /* @__PURE__ */ secondsToMilliseconds(initialVelocity) : calcGeneratorVelocity(resolveSpring, t, current);
					const isBelowVelocityThreshold = Math.abs(currentVelocity) <= restSpeed;
					const isBelowDisplacementThreshold = Math.abs(target - current) <= restDelta;
					state.done = isBelowVelocityThreshold && isBelowDisplacementThreshold;
				} else state.done = t >= duration;
				state.value = state.done ? target : current;
				return state;
			},
			toString: () => {
				const calculatedDuration = Math.min(calcGeneratorDuration(generator), maxGeneratorDuration);
				const easing = generateLinearEasing((progress) => generator.next(calculatedDuration * progress).value, calculatedDuration, 30);
				return calculatedDuration + "ms " + easing;
			}
		};
		return generator;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/generators/inertia.mjs
	function inertia({ keyframes, velocity = 0, power = .8, timeConstant = 325, bounceDamping = 10, bounceStiffness = 500, modifyTarget, min, max, restDelta = .5, restSpeed }) {
		const origin = keyframes[0];
		const state = {
			done: false,
			value: origin
		};
		const isOutOfBounds = (v) => min !== void 0 && v < min || max !== void 0 && v > max;
		const nearestBoundary = (v) => {
			if (min === void 0) return max;
			if (max === void 0) return min;
			return Math.abs(min - v) < Math.abs(max - v) ? min : max;
		};
		let amplitude = power * velocity;
		const ideal = origin + amplitude;
		const target = modifyTarget === void 0 ? ideal : modifyTarget(ideal);
		/**
		* If the target has changed we need to re-calculate the amplitude, otherwise
		* the animation will start from the wrong position.
		*/
		if (target !== ideal) amplitude = target - origin;
		const calcDelta = (t) => -amplitude * Math.exp(-t / timeConstant);
		const calcLatest = (t) => target + calcDelta(t);
		const applyFriction = (t) => {
			const delta = calcDelta(t);
			const latest = calcLatest(t);
			state.done = Math.abs(delta) <= restDelta;
			state.value = state.done ? target : latest;
		};
		/**
		* Ideally this would resolve for t in a stateless way, we could
		* do that by always precalculating the animation but as we know
		* this will be done anyway we can assume that spring will
		* be discovered during that.
		*/
		let timeReachedBoundary;
		let spring$1;
		const checkCatchBoundary = (t) => {
			if (!isOutOfBounds(state.value)) return;
			timeReachedBoundary = t;
			spring$1 = spring({
				keyframes: [state.value, nearestBoundary(state.value)],
				velocity: calcGeneratorVelocity(calcLatest, t, state.value),
				damping: bounceDamping,
				stiffness: bounceStiffness,
				restDelta,
				restSpeed
			});
		};
		checkCatchBoundary(0);
		return {
			calculatedDuration: null,
			next: (t) => {
				/**
				* We need to resolve the friction to figure out if we need a
				* spring but we don't want to do this twice per frame. So here
				* we flag if we updated for this frame and later if we did
				* we can skip doing it again.
				*/
				let hasUpdatedFrame = false;
				if (!spring$1 && timeReachedBoundary === void 0) {
					hasUpdatedFrame = true;
					applyFriction(t);
					checkCatchBoundary(t);
				}
				/**
				* If we have a spring and the provided t is beyond the moment the friction
				* animation crossed the min/max boundary, use the spring.
				*/
				if (timeReachedBoundary !== void 0 && t >= timeReachedBoundary) return spring$1.next(t - timeReachedBoundary);
				else {
					!hasUpdatedFrame && applyFriction(t);
					return state;
				}
			}
		};
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/easing/ease.mjs
	var easeIn = /*@__PURE__*/ cubicBezier(.42, 0, 1, 1);
	var easeOut = /*@__PURE__*/ cubicBezier(0, 0, .58, 1);
	var easeInOut = /*@__PURE__*/ cubicBezier(.42, 0, .58, 1);
	//#endregion
	//#region node_modules/framer-motion/dist/es/easing/utils/is-easing-array.mjs
	var isEasingArray = (ease) => {
		return Array.isArray(ease) && typeof ease[0] !== "number";
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/easing/utils/map.mjs
	var easingLookup = {
		linear: noop,
		easeIn,
		easeInOut,
		easeOut,
		circIn,
		circInOut,
		circOut,
		backIn,
		backInOut,
		backOut,
		anticipate
	};
	var easingDefinitionToFunction = (definition) => {
		if (isBezierDefinition(definition)) {
			invariant(definition.length === 4, `Cubic bezier arrays must contain four numerical values.`);
			const [x1, y1, x2, y2] = definition;
			return cubicBezier(x1, y1, x2, y2);
		} else if (typeof definition === "string") {
			invariant(easingLookup[definition] !== void 0, `Invalid easing type '${definition}'`);
			return easingLookup[definition];
		}
		return definition;
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/interpolate.mjs
	function createMixers(output, ease, customMixer) {
		const mixers = [];
		const mixerFactory = customMixer || mix;
		const numMixers = output.length - 1;
		for (let i = 0; i < numMixers; i++) {
			let mixer = mixerFactory(output[i], output[i + 1]);
			if (ease) mixer = pipe(Array.isArray(ease) ? ease[i] || noop : ease, mixer);
			mixers.push(mixer);
		}
		return mixers;
	}
	/**
	* Create a function that maps from a numerical input array to a generic output array.
	*
	* Accepts:
	*   - Numbers
	*   - Colors (hex, hsl, hsla, rgb, rgba)
	*   - Complex (combinations of one or more numbers or strings)
	*
	* ```jsx
	* const mixColor = interpolate([0, 1], ['#fff', '#000'])
	*
	* mixColor(0.5) // 'rgba(128, 128, 128, 1)'
	* ```
	*
	* TODO Revist this approach once we've moved to data models for values,
	* probably not needed to pregenerate mixer functions.
	*
	* @public
	*/
	function interpolate(input, output, { clamp: isClamp = true, ease, mixer } = {}) {
		const inputLength = input.length;
		invariant(inputLength === output.length, "Both input and output ranges must be the same length");
		/**
		* If we're only provided a single input, we can just make a function
		* that returns the output.
		*/
		if (inputLength === 1) return () => output[0];
		if (inputLength === 2 && output[0] === output[1]) return () => output[1];
		const isZeroDeltaRange = input[0] === input[1];
		if (input[0] > input[inputLength - 1]) {
			input = [...input].reverse();
			output = [...output].reverse();
		}
		const mixers = createMixers(output, ease, mixer);
		const numMixers = mixers.length;
		const interpolator = (v) => {
			if (isZeroDeltaRange && v < input[0]) return output[0];
			let i = 0;
			if (numMixers > 1) {
				for (; i < input.length - 2; i++) if (v < input[i + 1]) break;
			}
			const progressInRange = /* @__PURE__ */ progress(input[i], input[i + 1], v);
			return mixers[i](progressInRange);
		};
		return isClamp ? (v) => interpolator(clamp(input[0], input[inputLength - 1], v)) : interpolator;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/offsets/fill.mjs
	function fillOffset(offset, remaining) {
		const min = offset[offset.length - 1];
		for (let i = 1; i <= remaining; i++) {
			const offsetProgress = /* @__PURE__ */ progress(0, remaining, i);
			offset.push(mixNumber$1(min, 1, offsetProgress));
		}
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/offsets/default.mjs
	function defaultOffset(arr) {
		const offset = [0];
		fillOffset(offset, arr.length - 1);
		return offset;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/offsets/time.mjs
	function convertOffsetToTimes(offset, duration) {
		return offset.map((o) => o * duration);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/generators/keyframes.mjs
	function defaultEasing(values, easing) {
		return values.map(() => easing || easeInOut).splice(0, values.length - 1);
	}
	function keyframes({ duration = 300, keyframes: keyframeValues, times, ease = "easeInOut" }) {
		/**
		* Easing functions can be externally defined as strings. Here we convert them
		* into actual functions.
		*/
		const easingFunctions = isEasingArray(ease) ? ease.map(easingDefinitionToFunction) : easingDefinitionToFunction(ease);
		/**
		* This is the Iterator-spec return value. We ensure it's mutable rather than using a generator
		* to reduce GC during animation.
		*/
		const state = {
			done: false,
			value: keyframeValues[0]
		};
		const mapTimeToKeyframe = interpolate(convertOffsetToTimes(times && times.length === keyframeValues.length ? times : defaultOffset(keyframeValues), duration), keyframeValues, { ease: Array.isArray(easingFunctions) ? easingFunctions : defaultEasing(keyframeValues, easingFunctions) });
		return {
			calculatedDuration: duration,
			next: (t) => {
				state.value = mapTimeToKeyframe(t);
				state.done = t >= duration;
				return state;
			}
		};
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/animators/drivers/driver-frameloop.mjs
	var frameloopDriver = (update) => {
		const passTimestamp = ({ timestamp }) => update(timestamp);
		return {
			start: () => frame.update(passTimestamp, true),
			stop: () => cancelFrame(passTimestamp),
			/**
			* If we're processing this frame we can use the
			* framelocked timestamp to keep things in sync.
			*/
			now: () => frameData.isProcessing ? frameData.timestamp : time.now()
		};
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/animators/MainThreadAnimation.mjs
	init_objectSpread2();
	var generators = {
		decay: inertia,
		inertia,
		tween: keyframes,
		keyframes,
		spring
	};
	var percentToProgress = (percent) => percent / 100;
	/**
	* Animation that runs on the main thread. Designed to be WAAPI-spec in the subset of
	* features we expose publically. Mostly the compatibility is to ensure visual identity
	* between both WAAPI and main thread animations.
	*/
	var MainThreadAnimation = class extends BaseAnimation {
		constructor(options) {
			super(options);
			/**
			* The time at which the animation was paused.
			*/
			this.holdTime = null;
			/**
			* The time at which the animation was cancelled.
			*/
			this.cancelTime = null;
			/**
			* The current time of the animation.
			*/
			this.currentTime = 0;
			/**
			* Playback speed as a factor. 0 would be stopped, -1 reverse and 2 double speed.
			*/
			this.playbackSpeed = 1;
			/**
			* The state of the animation to apply when the animation is resolved. This
			* allows calls to the public API to control the animation before it is resolved,
			* without us having to resolve it first.
			*/
			this.pendingPlayState = "running";
			/**
			* The time at which the animation was started.
			*/
			this.startTime = null;
			this.state = "idle";
			/**
			* This method is bound to the instance to fix a pattern where
			* animation.stop is returned as a reference from a useEffect.
			*/
			this.stop = () => {
				this.resolver.cancel();
				this.isStopped = true;
				if (this.state === "idle") return;
				this.teardown();
				const { onStop } = this.options;
				onStop && onStop();
			};
			const { name, motionValue, element, keyframes } = this.options;
			const KeyframeResolver$1 = (element === null || element === void 0 ? void 0 : element.KeyframeResolver) || KeyframeResolver;
			const onResolved = (resolvedKeyframes, finalKeyframe) => this.onKeyframesResolved(resolvedKeyframes, finalKeyframe);
			this.resolver = new KeyframeResolver$1(keyframes, onResolved, name, motionValue, element);
			this.resolver.scheduleResolve();
		}
		flatten() {
			super.flatten();
			if (this._resolved) Object.assign(this._resolved, this.initPlayback(this._resolved.keyframes));
		}
		initPlayback(keyframes$1) {
			const { type = "keyframes", repeat = 0, repeatDelay = 0, repeatType, velocity = 0 } = this.options;
			const generatorFactory = isGenerator(type) ? type : generators[type] || keyframes;
			/**
			* If our generator doesn't support mixing numbers, we need to replace keyframes with
			* [0, 100] and then make a function that maps that to the actual keyframes.
			*
			* 100 is chosen instead of 1 as it works nicer with spring animations.
			*/
			let mapPercentToKeyframes;
			let mirroredGenerator;
			if (generatorFactory !== keyframes && typeof keyframes$1[0] !== "number") {
				mapPercentToKeyframes = pipe(percentToProgress, mix(keyframes$1[0], keyframes$1[1]));
				keyframes$1 = [0, 100];
			}
			const generator = generatorFactory(_objectSpread2(_objectSpread2({}, this.options), {}, { keyframes: keyframes$1 }));
			/**
			* If we have a mirror repeat type we need to create a second generator that outputs the
			* mirrored (not reversed) animation and later ping pong between the two generators.
			*/
			if (repeatType === "mirror") mirroredGenerator = generatorFactory(_objectSpread2(_objectSpread2({}, this.options), {}, {
				keyframes: [...keyframes$1].reverse(),
				velocity: -velocity
			}));
			/**
			* If duration is undefined and we have repeat options,
			* we need to calculate a duration from the generator.
			*
			* We set it to the generator itself to cache the duration.
			* Any timeline resolver will need to have already precalculated
			* the duration by this step.
			*/
			if (generator.calculatedDuration === null) generator.calculatedDuration = calcGeneratorDuration(generator);
			const { calculatedDuration } = generator;
			const resolvedDuration = calculatedDuration + repeatDelay;
			const totalDuration = resolvedDuration * (repeat + 1) - repeatDelay;
			return {
				generator,
				mirroredGenerator,
				mapPercentToKeyframes,
				calculatedDuration,
				resolvedDuration,
				totalDuration
			};
		}
		onPostResolved() {
			const { autoplay = true } = this.options;
			this.play();
			if (this.pendingPlayState === "paused" || !autoplay) this.pause();
			else this.state = this.pendingPlayState;
		}
		tick(timestamp, sample = false) {
			const { resolved } = this;
			if (!resolved) {
				const { keyframes } = this.options;
				return {
					done: true,
					value: keyframes[keyframes.length - 1]
				};
			}
			const { finalKeyframe, generator, mirroredGenerator, mapPercentToKeyframes, keyframes, calculatedDuration, totalDuration, resolvedDuration } = resolved;
			if (this.startTime === null) return generator.next(0);
			const { delay, repeat, repeatType, repeatDelay, onUpdate } = this.options;
			/**
			* requestAnimationFrame timestamps can come through as lower than
			* the startTime as set by performance.now(). Here we prevent this,
			* though in the future it could be possible to make setting startTime
			* a pending operation that gets resolved here.
			*/
			if (this.speed > 0) this.startTime = Math.min(this.startTime, timestamp);
			else if (this.speed < 0) this.startTime = Math.min(timestamp - totalDuration / this.speed, this.startTime);
			if (sample) this.currentTime = timestamp;
			else if (this.holdTime !== null) this.currentTime = this.holdTime;
			else this.currentTime = Math.round(timestamp - this.startTime) * this.speed;
			const timeWithoutDelay = this.currentTime - delay * (this.speed >= 0 ? 1 : -1);
			const isInDelayPhase = this.speed >= 0 ? timeWithoutDelay < 0 : timeWithoutDelay > totalDuration;
			this.currentTime = Math.max(timeWithoutDelay, 0);
			if (this.state === "finished" && this.holdTime === null) this.currentTime = totalDuration;
			let elapsed = this.currentTime;
			let frameGenerator = generator;
			if (repeat) {
				/**
				* Get the current progress (0-1) of the animation. If t is >
				* than duration we'll get values like 2.5 (midway through the
				* third iteration)
				*/
				const progress = Math.min(this.currentTime, totalDuration) / resolvedDuration;
				/**
				* Get the current iteration (0 indexed). For instance the floor of
				* 2.5 is 2.
				*/
				let currentIteration = Math.floor(progress);
				/**
				* Get the current progress of the iteration by taking the remainder
				* so 2.5 is 0.5 through iteration 2
				*/
				let iterationProgress = progress % 1;
				/**
				* If iteration progress is 1 we count that as the end
				* of the previous iteration.
				*/
				if (!iterationProgress && progress >= 1) iterationProgress = 1;
				iterationProgress === 1 && currentIteration--;
				currentIteration = Math.min(currentIteration, repeat + 1);
				if (Boolean(currentIteration % 2)) {
					if (repeatType === "reverse") {
						iterationProgress = 1 - iterationProgress;
						if (repeatDelay) iterationProgress -= repeatDelay / resolvedDuration;
					} else if (repeatType === "mirror") frameGenerator = mirroredGenerator;
				}
				elapsed = clamp(0, 1, iterationProgress) * resolvedDuration;
			}
			/**
			* If we're in negative time, set state as the initial keyframe.
			* This prevents delay: x, duration: 0 animations from finishing
			* instantly.
			*/
			const state = isInDelayPhase ? {
				done: false,
				value: keyframes[0]
			} : frameGenerator.next(elapsed);
			if (mapPercentToKeyframes) state.value = mapPercentToKeyframes(state.value);
			let { done } = state;
			if (!isInDelayPhase && calculatedDuration !== null) done = this.speed >= 0 ? this.currentTime >= totalDuration : this.currentTime <= 0;
			const isAnimationFinished = this.holdTime === null && (this.state === "finished" || this.state === "running" && done);
			if (isAnimationFinished && finalKeyframe !== void 0) state.value = getFinalKeyframe(keyframes, this.options, finalKeyframe);
			if (onUpdate) onUpdate(state.value);
			if (isAnimationFinished) this.finish();
			return state;
		}
		get duration() {
			const { resolved } = this;
			return resolved ? /* @__PURE__ */ millisecondsToSeconds(resolved.calculatedDuration) : 0;
		}
		get time() {
			return /* @__PURE__ */ millisecondsToSeconds(this.currentTime);
		}
		set time(newTime) {
			newTime = /* @__PURE__ */ secondsToMilliseconds(newTime);
			this.currentTime = newTime;
			if (this.holdTime !== null || this.speed === 0) this.holdTime = newTime;
			else if (this.driver) this.startTime = this.driver.now() - newTime / this.speed;
		}
		get speed() {
			return this.playbackSpeed;
		}
		set speed(newSpeed) {
			const hasChanged = this.playbackSpeed !== newSpeed;
			this.playbackSpeed = newSpeed;
			if (hasChanged) this.time = /* @__PURE__ */ millisecondsToSeconds(this.currentTime);
		}
		play() {
			if (!this.resolver.isScheduled) this.resolver.resume();
			if (!this._resolved) {
				this.pendingPlayState = "running";
				return;
			}
			if (this.isStopped) return;
			const { driver = frameloopDriver, onPlay, startTime } = this.options;
			if (!this.driver) this.driver = driver((timestamp) => this.tick(timestamp));
			onPlay && onPlay();
			const now = this.driver.now();
			if (this.holdTime !== null) this.startTime = now - this.holdTime;
			else if (!this.startTime) this.startTime = startTime !== null && startTime !== void 0 ? startTime : this.calcStartTime();
			else if (this.state === "finished") this.startTime = now;
			if (this.state === "finished") this.updateFinishedPromise();
			this.cancelTime = this.startTime;
			this.holdTime = null;
			/**
			* Set playState to running only after we've used it in
			* the previous logic.
			*/
			this.state = "running";
			this.driver.start();
		}
		pause() {
			var _a;
			if (!this._resolved) {
				this.pendingPlayState = "paused";
				return;
			}
			this.state = "paused";
			this.holdTime = (_a = this.currentTime) !== null && _a !== void 0 ? _a : 0;
		}
		complete() {
			if (this.state !== "running") this.play();
			this.pendingPlayState = this.state = "finished";
			this.holdTime = null;
		}
		finish() {
			this.teardown();
			this.state = "finished";
			const { onComplete } = this.options;
			onComplete && onComplete();
		}
		cancel() {
			if (this.cancelTime !== null) this.tick(this.cancelTime);
			this.teardown();
			this.updateFinishedPromise();
		}
		teardown() {
			this.state = "idle";
			this.stopDriver();
			this.resolveFinishedPromise();
			this.updateFinishedPromise();
			this.startTime = this.cancelTime = null;
			this.resolver.cancel();
		}
		stopDriver() {
			if (!this.driver) return;
			this.driver.stop();
			this.driver = void 0;
		}
		sample(time) {
			this.startTime = 0;
			return this.tick(time, true);
		}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/animators/utils/accelerated-values.mjs
	/**
	* A list of values that can be hardware-accelerated.
	*/
	var acceleratedValues = /* @__PURE__ */ new Set([
		"opacity",
		"clipPath",
		"filter",
		"transform"
	]);
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/animators/waapi/index.mjs
	function startWaapiAnimation(element, valueName, keyframes, { delay = 0, duration = 300, repeat = 0, repeatType = "loop", ease = "easeInOut", times } = {}) {
		const keyframeOptions = { [valueName]: keyframes };
		if (times) keyframeOptions.offset = times;
		const easing = mapEasingToNativeEasing(ease, duration);
		/**
		* If this is an easing array, apply to keyframes, not animation as a whole
		*/
		if (Array.isArray(easing)) keyframeOptions.easing = easing;
		return element.animate(keyframeOptions, {
			delay,
			duration,
			easing: !Array.isArray(easing) ? easing : "linear",
			fill: "both",
			iterations: repeat + 1,
			direction: repeatType === "reverse" ? "alternate" : "normal"
		});
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/animators/waapi/utils/supports-waapi.mjs
	var supportsWaapi = /*@__PURE__*/ memo(() => Object.hasOwnProperty.call(Element.prototype, "animate"));
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/animators/AcceleratedAnimation.mjs
	init_objectSpread2();
	init_objectWithoutProperties();
	var _excluded$5 = [
		"onComplete",
		"onUpdate",
		"motionValue",
		"element"
	];
	var _excluded2 = [
		"motionValue",
		"onUpdate",
		"onComplete",
		"element"
	];
	/**
	* 10ms is chosen here as it strikes a balance between smooth
	* results (more than one keyframe per frame at 60fps) and
	* keyframe quantity.
	*/
	var sampleDelta = 10;
	/**
	* Implement a practical max duration for keyframe generation
	* to prevent infinite loops
	*/
	var maxDuration = 2e4;
	/**
	* Check if an animation can run natively via WAAPI or requires pregenerated keyframes.
	* WAAPI doesn't support spring or function easings so we run these as JS animation before
	* handing off.
	*/
	function requiresPregeneratedKeyframes(options) {
		return isGenerator(options.type) || options.type === "spring" || !isWaapiSupportedEasing(options.ease);
	}
	function pregenerateKeyframes(keyframes, options) {
		/**
		* Create a main-thread animation to pregenerate keyframes.
		* We sample this at regular intervals to generate keyframes that we then
		* linearly interpolate between.
		*/
		const sampleAnimation = new MainThreadAnimation(_objectSpread2(_objectSpread2({}, options), {}, {
			keyframes,
			repeat: 0,
			delay: 0,
			isGenerator: true
		}));
		let state = {
			done: false,
			value: keyframes[0]
		};
		const pregeneratedKeyframes = [];
		/**
		* Bail after 20 seconds of pre-generated keyframes as it's likely
		* we're heading for an infinite loop.
		*/
		let t = 0;
		while (!state.done && t < maxDuration) {
			state = sampleAnimation.sample(t);
			pregeneratedKeyframes.push(state.value);
			t += sampleDelta;
		}
		return {
			times: void 0,
			keyframes: pregeneratedKeyframes,
			duration: t - sampleDelta,
			ease: "linear"
		};
	}
	var unsupportedEasingFunctions = {
		anticipate,
		backInOut,
		circInOut
	};
	function isUnsupportedEase(key) {
		return key in unsupportedEasingFunctions;
	}
	var AcceleratedAnimation = class extends BaseAnimation {
		constructor(options) {
			super(options);
			const { name, motionValue, element, keyframes } = this.options;
			this.resolver = new DOMKeyframesResolver(keyframes, (resolvedKeyframes, finalKeyframe) => this.onKeyframesResolved(resolvedKeyframes, finalKeyframe), name, motionValue, element);
			this.resolver.scheduleResolve();
		}
		initPlayback(keyframes, finalKeyframe) {
			let { duration = 300, times, ease, type, motionValue, name, startTime } = this.options;
			/**
			* If element has since been unmounted, return false to indicate
			* the animation failed to initialised.
			*/
			if (!motionValue.owner || !motionValue.owner.current) return false;
			/**
			* If the user has provided an easing function name that isn't supported
			* by WAAPI (like "anticipate"), we need to provide the corressponding
			* function. This will later get converted to a linear() easing function.
			*/
			if (typeof ease === "string" && supportsLinearEasing() && isUnsupportedEase(ease)) ease = unsupportedEasingFunctions[ease];
			/**
			* If this animation needs pre-generated keyframes then generate.
			*/
			if (requiresPregeneratedKeyframes(this.options)) {
				const _this$options = this.options, { onComplete, onUpdate, motionValue, element } = _this$options, options = _objectWithoutProperties(_this$options, _excluded$5);
				const pregeneratedAnimation = pregenerateKeyframes(keyframes, options);
				keyframes = pregeneratedAnimation.keyframes;
				if (keyframes.length === 1) keyframes[1] = keyframes[0];
				duration = pregeneratedAnimation.duration;
				times = pregeneratedAnimation.times;
				ease = pregeneratedAnimation.ease;
				type = "keyframes";
			}
			const animation = startWaapiAnimation(motionValue.owner.current, name, keyframes, _objectSpread2(_objectSpread2({}, this.options), {}, {
				duration,
				times,
				ease
			}));
			animation.startTime = startTime !== null && startTime !== void 0 ? startTime : this.calcStartTime();
			if (this.pendingTimeline) {
				attachTimeline(animation, this.pendingTimeline);
				this.pendingTimeline = void 0;
			} else
 /**
			* Prefer the `onfinish` prop as it's more widely supported than
			* the `finished` promise.
			*
			* Here, we synchronously set the provided MotionValue to the end
			* keyframe. If we didn't, when the WAAPI animation is finished it would
			* be removed from the element which would then revert to its old styles.
			*/
			animation.onfinish = () => {
				const { onComplete } = this.options;
				motionValue.set(getFinalKeyframe(keyframes, this.options, finalKeyframe));
				onComplete && onComplete();
				this.cancel();
				this.resolveFinishedPromise();
			};
			return {
				animation,
				duration,
				times,
				type,
				ease,
				keyframes
			};
		}
		get duration() {
			const { resolved } = this;
			if (!resolved) return 0;
			const { duration } = resolved;
			return /* @__PURE__ */ millisecondsToSeconds(duration);
		}
		get time() {
			const { resolved } = this;
			if (!resolved) return 0;
			const { animation } = resolved;
			return /* @__PURE__ */ millisecondsToSeconds(animation.currentTime || 0);
		}
		set time(newTime) {
			const { resolved } = this;
			if (!resolved) return;
			const { animation } = resolved;
			animation.currentTime = /* @__PURE__ */ secondsToMilliseconds(newTime);
		}
		get speed() {
			const { resolved } = this;
			if (!resolved) return 1;
			const { animation } = resolved;
			return animation.playbackRate;
		}
		set speed(newSpeed) {
			const { resolved } = this;
			if (!resolved) return;
			const { animation } = resolved;
			animation.playbackRate = newSpeed;
		}
		get state() {
			const { resolved } = this;
			if (!resolved) return "idle";
			const { animation } = resolved;
			return animation.playState;
		}
		get startTime() {
			const { resolved } = this;
			if (!resolved) return null;
			const { animation } = resolved;
			return animation.startTime;
		}
		/**
		* Replace the default DocumentTimeline with another AnimationTimeline.
		* Currently used for scroll animations.
		*/
		attachTimeline(timeline) {
			if (!this._resolved) this.pendingTimeline = timeline;
			else {
				const { resolved } = this;
				if (!resolved) return noop;
				const { animation } = resolved;
				attachTimeline(animation, timeline);
			}
			return noop;
		}
		play() {
			if (this.isStopped) return;
			const { resolved } = this;
			if (!resolved) return;
			const { animation } = resolved;
			if (animation.playState === "finished") this.updateFinishedPromise();
			animation.play();
		}
		pause() {
			const { resolved } = this;
			if (!resolved) return;
			const { animation } = resolved;
			animation.pause();
		}
		stop() {
			this.resolver.cancel();
			this.isStopped = true;
			if (this.state === "idle") return;
			this.resolveFinishedPromise();
			this.updateFinishedPromise();
			const { resolved } = this;
			if (!resolved) return;
			const { animation, keyframes, duration, type, ease, times } = resolved;
			if (animation.playState === "idle" || animation.playState === "finished") return;
			/**
			* WAAPI doesn't natively have any interruption capabilities.
			*
			* Rather than read commited styles back out of the DOM, we can
			* create a renderless JS animation and sample it twice to calculate
			* its current value, "previous" value, and therefore allow
			* Motion to calculate velocity for any subsequent animation.
			*/
			if (this.time) {
				const _this$options2 = this.options, { motionValue, onUpdate, onComplete, element } = _this$options2;
				const sampleAnimation = new MainThreadAnimation(_objectSpread2(_objectSpread2({}, _objectWithoutProperties(_this$options2, _excluded2)), {}, {
					keyframes,
					duration,
					type,
					ease,
					times,
					isGenerator: true
				}));
				const sampleTime = /* @__PURE__ */ secondsToMilliseconds(this.time);
				motionValue.setWithVelocity(sampleAnimation.sample(sampleTime - sampleDelta).value, sampleAnimation.sample(sampleTime).value, sampleDelta);
			}
			const { onStop } = this.options;
			onStop && onStop();
			this.cancel();
		}
		complete() {
			const { resolved } = this;
			if (!resolved) return;
			resolved.animation.finish();
		}
		cancel() {
			const { resolved } = this;
			if (!resolved) return;
			resolved.animation.cancel();
		}
		static supports(options) {
			const { motionValue, name, repeatDelay, repeatType, damping, type } = options;
			if (!motionValue || !motionValue.owner || !(motionValue.owner.current instanceof HTMLElement)) return false;
			const { onUpdate, transformTemplate } = motionValue.owner.getProps();
			return supportsWaapi() && name && acceleratedValues.has(name) && !onUpdate && !transformTemplate && !repeatDelay && repeatType !== "mirror" && damping !== 0 && type !== "inertia";
		}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/utils/default-transitions.mjs
	var underDampedSpring = {
		type: "spring",
		stiffness: 500,
		damping: 25,
		restSpeed: 10
	};
	var criticallyDampedSpring = (target) => ({
		type: "spring",
		stiffness: 550,
		damping: target === 0 ? 2 * Math.sqrt(550) : 30,
		restSpeed: 10
	});
	var keyframesTransition = {
		type: "keyframes",
		duration: .8
	};
	/**
	* Default easing curve is a slightly shallower version of
	* the default browser easing curve.
	*/
	var ease = {
		type: "keyframes",
		ease: [
			.25,
			.1,
			.35,
			1
		],
		duration: .3
	};
	var getDefaultTransition = (valueKey, { keyframes }) => {
		if (keyframes.length > 2) return keyframesTransition;
		else if (transformProps.has(valueKey)) return valueKey.startsWith("scale") ? criticallyDampedSpring(keyframes[1]) : underDampedSpring;
		return ease;
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/utils/is-transition-defined.mjs
	init_objectWithoutProperties();
	var _excluded$4 = [
		"when",
		"delay",
		"delayChildren",
		"staggerChildren",
		"staggerDirection",
		"repeat",
		"repeatType",
		"repeatDelay",
		"from",
		"elapsed"
	];
	/**
	* Decide whether a transition is defined on a given Transition.
	* This filters out orchestration options and returns true
	* if any options are left.
	*/
	function isTransitionDefined(_ref) {
		let { when, delay: _delay, delayChildren, staggerChildren, staggerDirection, repeat, repeatType, repeatDelay, from, elapsed } = _ref, transition = _objectWithoutProperties(_ref, _excluded$4);
		return !!Object.keys(transition).length;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/interfaces/motion-value.mjs
	init_objectSpread2();
	var animateMotionValue = (name, value, target, transition = {}, element, isHandoff) => (onComplete) => {
		const valueTransition = getValueTransition(transition, name) || {};
		/**
		* Most transition values are currently completely overwritten by value-specific
		* transitions. In the future it'd be nicer to blend these transitions. But for now
		* delay actually does inherit from the root transition if not value-specific.
		*/
		const delay = valueTransition.delay || transition.delay || 0;
		/**
		* Elapsed isn't a public transition option but can be passed through from
		* optimized appear effects in milliseconds.
		*/
		let { elapsed = 0 } = transition;
		elapsed = elapsed - /* @__PURE__ */ secondsToMilliseconds(delay);
		let options = _objectSpread2(_objectSpread2({
			keyframes: Array.isArray(target) ? target : [null, target],
			ease: "easeOut",
			velocity: value.getVelocity()
		}, valueTransition), {}, {
			delay: -elapsed,
			onUpdate: (v) => {
				value.set(v);
				valueTransition.onUpdate && valueTransition.onUpdate(v);
			},
			onComplete: () => {
				onComplete();
				valueTransition.onComplete && valueTransition.onComplete();
			},
			name,
			motionValue: value,
			element: isHandoff ? void 0 : element
		});
		/**
		* If there's no transition defined for this value, we can generate
		* unqiue transition settings for this value.
		*/
		if (!isTransitionDefined(valueTransition)) options = _objectSpread2(_objectSpread2({}, options), getDefaultTransition(name, options));
		/**
		* Both WAAPI and our internal animation functions use durations
		* as defined by milliseconds, while our external API defines them
		* as seconds.
		*/
		if (options.duration) options.duration = /* @__PURE__ */ secondsToMilliseconds(options.duration);
		if (options.repeatDelay) options.repeatDelay = /* @__PURE__ */ secondsToMilliseconds(options.repeatDelay);
		if (options.from !== void 0) options.keyframes[0] = options.from;
		let shouldSkip = false;
		if (options.type === false || options.duration === 0 && !options.repeatDelay) {
			options.duration = 0;
			if (options.delay === 0) shouldSkip = true;
		}
		if (instantAnimationState.current || MotionGlobalConfig.skipAnimations) {
			shouldSkip = true;
			options.duration = 0;
			options.delay = 0;
		}
		/**
		* If we can or must skip creating the animation, and apply only
		* the final keyframe, do so. We also check once keyframes are resolved but
		* this early check prevents the need to create an animation at all.
		*/
		if (shouldSkip && !isHandoff && value.get() !== void 0) {
			const finalKeyframe = getFinalKeyframe(options.keyframes, valueTransition);
			if (finalKeyframe !== void 0) {
				frame.update(() => {
					options.onUpdate(finalKeyframe);
					options.onComplete();
				});
				return new GroupPlaybackControls([]);
			}
		}
		/**
		* Animate via WAAPI if possible. If this is a handoff animation, the optimised animation will be running via
		* WAAPI. Therefore, this animation must be JS to ensure it runs "under" the
		* optimised animation.
		*/
		if (!isHandoff && AcceleratedAnimation.supports(options)) return new AcceleratedAnimation(options);
		else return new MainThreadAnimation(options);
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/interfaces/visual-element-target.mjs
	init_objectWithoutProperties();
	init_objectSpread2();
	var _excluded$3 = ["transition", "transitionEnd"];
	/**
	* Decide whether we should block this animation. Previously, we achieved this
	* just by checking whether the key was listed in protectedKeys, but this
	* posed problems if an animation was triggered by afterChildren and protectedKeys
	* had been set to true in the meantime.
	*/
	function shouldBlockAnimation({ protectedKeys, needsAnimating }, key) {
		const shouldBlock = protectedKeys.hasOwnProperty(key) && needsAnimating[key] !== true;
		needsAnimating[key] = false;
		return shouldBlock;
	}
	function animateTarget(visualElement, targetAndTransition, { delay = 0, transitionOverride, type } = {}) {
		var _a;
		let { transition = visualElement.getDefaultTransition(), transitionEnd } = targetAndTransition, target = _objectWithoutProperties(targetAndTransition, _excluded$3);
		if (transitionOverride) transition = transitionOverride;
		const animations = [];
		const animationTypeState = type && visualElement.animationState && visualElement.animationState.getState()[type];
		for (const key in target) {
			const value = visualElement.getValue(key, (_a = visualElement.latestValues[key]) !== null && _a !== void 0 ? _a : null);
			const valueTarget = target[key];
			if (valueTarget === void 0 || animationTypeState && shouldBlockAnimation(animationTypeState, key)) continue;
			const valueTransition = _objectSpread2({ delay }, getValueTransition(transition || {}, key));
			/**
			* If this is the first time a value is being animated, check
			* to see if we're handling off from an existing animation.
			*/
			let isHandoff = false;
			if (window.MotionHandoffAnimation) {
				const appearId = getOptimisedAppearId(visualElement);
				if (appearId) {
					const startTime = window.MotionHandoffAnimation(appearId, key, frame);
					if (startTime !== null) {
						valueTransition.startTime = startTime;
						isHandoff = true;
					}
				}
			}
			addValueToWillChange(visualElement, key);
			value.start(animateMotionValue(key, value, valueTarget, visualElement.shouldReduceMotion && positionalKeys.has(key) ? { type: false } : valueTransition, visualElement, isHandoff));
			const animation = value.animation;
			if (animation) animations.push(animation);
		}
		if (transitionEnd) Promise.all(animations).then(() => {
			frame.update(() => {
				transitionEnd && setTarget(visualElement, transitionEnd);
			});
		});
		return animations;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/interfaces/visual-element-variant.mjs
	init_objectSpread2();
	function animateVariant(visualElement, variant, options = {}) {
		var _a;
		const resolved = resolveVariant(visualElement, variant, options.type === "exit" ? (_a = visualElement.presenceContext) === null || _a === void 0 ? void 0 : _a.custom : void 0);
		let { transition = visualElement.getDefaultTransition() || {} } = resolved || {};
		if (options.transitionOverride) transition = options.transitionOverride;
		/**
		* If we have a variant, create a callback that runs it as an animation.
		* Otherwise, we resolve a Promise immediately for a composable no-op.
		*/
		const getAnimation = resolved ? () => Promise.all(animateTarget(visualElement, resolved, options)) : () => Promise.resolve();
		/**
		* If we have children, create a callback that runs all their animations.
		* Otherwise, we resolve a Promise immediately for a composable no-op.
		*/
		const getChildAnimations = visualElement.variantChildren && visualElement.variantChildren.size ? (forwardDelay = 0) => {
			const { delayChildren = 0, staggerChildren, staggerDirection } = transition;
			return animateChildren(visualElement, variant, delayChildren + forwardDelay, staggerChildren, staggerDirection, options);
		} : () => Promise.resolve();
		/**
		* If the transition explicitly defines a "when" option, we need to resolve either
		* this animation or all children animations before playing the other.
		*/
		const { when } = transition;
		if (when) {
			const [first, last] = when === "beforeChildren" ? [getAnimation, getChildAnimations] : [getChildAnimations, getAnimation];
			return first().then(() => last());
		} else return Promise.all([getAnimation(), getChildAnimations(options.delay)]);
	}
	function animateChildren(visualElement, variant, delayChildren = 0, staggerChildren = 0, staggerDirection = 1, options) {
		const animations = [];
		const maxStaggerDuration = (visualElement.variantChildren.size - 1) * staggerChildren;
		const generateStaggerDuration = staggerDirection === 1 ? (i = 0) => i * staggerChildren : (i = 0) => maxStaggerDuration - i * staggerChildren;
		Array.from(visualElement.variantChildren).sort(sortByTreeOrder).forEach((child, i) => {
			child.notify("AnimationStart", variant);
			animations.push(animateVariant(child, variant, _objectSpread2(_objectSpread2({}, options), {}, { delay: delayChildren + generateStaggerDuration(i) })).then(() => child.notify("AnimationComplete", variant)));
		});
		return Promise.all(animations);
	}
	function sortByTreeOrder(a, b) {
		return a.sortNodePosition(b);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/interfaces/visual-element.mjs
	function animateVisualElement(visualElement, definition, options = {}) {
		visualElement.notify("AnimationStart", definition);
		let animation;
		if (Array.isArray(definition)) {
			const animations = definition.map((variant) => animateVariant(visualElement, variant, options));
			animation = Promise.all(animations);
		} else if (typeof definition === "string") animation = animateVariant(visualElement, definition, options);
		else {
			const resolvedDefinition = typeof definition === "function" ? resolveVariant(visualElement, definition, options.custom) : definition;
			animation = Promise.all(animateTarget(visualElement, resolvedDefinition, options));
		}
		return animation.then(() => {
			visualElement.notify("AnimationComplete", definition);
		});
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/utils/get-variant-context.mjs
	var numVariantProps = variantProps.length;
	function getVariantContext(visualElement) {
		if (!visualElement) return void 0;
		if (!visualElement.isControllingVariants) {
			const context = visualElement.parent ? getVariantContext(visualElement.parent) || {} : {};
			if (visualElement.props.initial !== void 0) context.initial = visualElement.props.initial;
			return context;
		}
		const context = {};
		for (let i = 0; i < numVariantProps; i++) {
			const name = variantProps[i];
			const prop = visualElement.props[name];
			if (isVariantLabel(prop) || prop === false) context[name] = prop;
		}
		return context;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/utils/animation-state.mjs
	init_objectWithoutProperties();
	init_objectSpread2();
	var _excluded$2 = ["transition", "transitionEnd"];
	var reversePriorityOrder = [...variantPriorityOrder].reverse();
	var numAnimationTypes = variantPriorityOrder.length;
	function animateList(visualElement) {
		return (animations) => Promise.all(animations.map(({ animation, options }) => animateVisualElement(visualElement, animation, options)));
	}
	function createAnimationState(visualElement) {
		let animate = animateList(visualElement);
		let state = createState();
		let isInitialRender = true;
		/**
		* This function will be used to reduce the animation definitions for
		* each active animation type into an object of resolved values for it.
		*/
		const buildResolvedTypeValues = (type) => (acc, definition) => {
			var _a;
			const resolved = resolveVariant(visualElement, definition, type === "exit" ? (_a = visualElement.presenceContext) === null || _a === void 0 ? void 0 : _a.custom : void 0);
			if (resolved) {
				const { transition, transitionEnd } = resolved, target = _objectWithoutProperties(resolved, _excluded$2);
				acc = _objectSpread2(_objectSpread2(_objectSpread2({}, acc), target), transitionEnd);
			}
			return acc;
		};
		/**
		* This just allows us to inject mocked animation functions
		* @internal
		*/
		function setAnimateFunction(makeAnimator) {
			animate = makeAnimator(visualElement);
		}
		/**
		* When we receive new props, we need to:
		* 1. Create a list of protected keys for each type. This is a directory of
		*    value keys that are currently being "handled" by types of a higher priority
		*    so that whenever an animation is played of a given type, these values are
		*    protected from being animated.
		* 2. Determine if an animation type needs animating.
		* 3. Determine if any values have been removed from a type and figure out
		*    what to animate those to.
		*/
		function animateChanges(changedActiveType) {
			const { props } = visualElement;
			const context = getVariantContext(visualElement.parent) || {};
			/**
			* A list of animations that we'll build into as we iterate through the animation
			* types. This will get executed at the end of the function.
			*/
			const animations = [];
			/**
			* Keep track of which values have been removed. Then, as we hit lower priority
			* animation types, we can check if they contain removed values and animate to that.
			*/
			const removedKeys = /* @__PURE__ */ new Set();
			/**
			* A dictionary of all encountered keys. This is an object to let us build into and
			* copy it without iteration. Each time we hit an animation type we set its protected
			* keys - the keys its not allowed to animate - to the latest version of this object.
			*/
			let encounteredKeys = {};
			/**
			* If a variant has been removed at a given index, and this component is controlling
			* variant animations, we want to ensure lower-priority variants are forced to animate.
			*/
			let removedVariantIndex = Infinity;
			/**
			* Iterate through all animation types in reverse priority order. For each, we want to
			* detect which values it's handling and whether or not they've changed (and therefore
			* need to be animated). If any values have been removed, we want to detect those in
			* lower priority props and flag for animation.
			*/
			for (let i = 0; i < numAnimationTypes; i++) {
				const type = reversePriorityOrder[i];
				const typeState = state[type];
				const prop = props[type] !== void 0 ? props[type] : context[type];
				const propIsVariant = isVariantLabel(prop);
				/**
				* If this type has *just* changed isActive status, set activeDelta
				* to that status. Otherwise set to null.
				*/
				const activeDelta = type === changedActiveType ? typeState.isActive : null;
				if (activeDelta === false) removedVariantIndex = i;
				/**
				* If this prop is an inherited variant, rather than been set directly on the
				* component itself, we want to make sure we allow the parent to trigger animations.
				*
				* TODO: Can probably change this to a !isControllingVariants check
				*/
				let isInherited = prop === context[type] && prop !== props[type] && propIsVariant;
				/**
				*
				*/
				if (isInherited && isInitialRender && visualElement.manuallyAnimateOnMount) isInherited = false;
				/**
				* Set all encountered keys so far as the protected keys for this type. This will
				* be any key that has been animated or otherwise handled by active, higher-priortiy types.
				*/
				typeState.protectedKeys = _objectSpread2({}, encounteredKeys);
				if (!typeState.isActive && activeDelta === null || !prop && !typeState.prevProp || isAnimationControls(prop) || typeof prop === "boolean") continue;
				/**
				* As we go look through the values defined on this type, if we detect
				* a changed value or a value that was removed in a higher priority, we set
				* this to true and add this prop to the animation list.
				*/
				const variantDidChange = checkVariantsDidChange(typeState.prevProp, prop);
				let shouldAnimateType = variantDidChange || type === changedActiveType && typeState.isActive && !isInherited && propIsVariant || i > removedVariantIndex && propIsVariant;
				let handledRemovedValues = false;
				/**
				* As animations can be set as variant lists, variants or target objects, we
				* coerce everything to an array if it isn't one already
				*/
				const definitionList = Array.isArray(prop) ? prop : [prop];
				/**
				* Build an object of all the resolved values. We'll use this in the subsequent
				* animateChanges calls to determine whether a value has changed.
				*/
				let resolvedValues = definitionList.reduce(buildResolvedTypeValues(type), {});
				if (activeDelta === false) resolvedValues = {};
				/**
				* Now we need to loop through all the keys in the prev prop and this prop,
				* and decide:
				* 1. If the value has changed, and needs animating
				* 2. If it has been removed, and needs adding to the removedKeys set
				* 3. If it has been removed in a higher priority type and needs animating
				* 4. If it hasn't been removed in a higher priority but hasn't changed, and
				*    needs adding to the type's protectedKeys list.
				*/
				const { prevResolvedValues = {} } = typeState;
				const allKeys = _objectSpread2(_objectSpread2({}, prevResolvedValues), resolvedValues);
				const markToAnimate = (key) => {
					shouldAnimateType = true;
					if (removedKeys.has(key)) {
						handledRemovedValues = true;
						removedKeys.delete(key);
					}
					typeState.needsAnimating[key] = true;
					const motionValue = visualElement.getValue(key);
					if (motionValue) motionValue.liveStyle = false;
				};
				for (const key in allKeys) {
					const next = resolvedValues[key];
					const prev = prevResolvedValues[key];
					if (encounteredKeys.hasOwnProperty(key)) continue;
					/**
					* If the value has changed, we probably want to animate it.
					*/
					let valueHasChanged = false;
					if (isKeyframesTarget(next) && isKeyframesTarget(prev)) valueHasChanged = !shallowCompare(next, prev);
					else valueHasChanged = next !== prev;
					if (valueHasChanged) {
						if (next !== void 0 && next !== null) markToAnimate(key);
						else removedKeys.add(key);
					} else if (next !== void 0 && removedKeys.has(key))
 /**
					* If next hasn't changed and it isn't undefined, we want to check if it's
					* been removed by a higher priority
					*/
					markToAnimate(key);
					else
 /**
					* If it hasn't changed, we add it to the list of protected values
					* to ensure it doesn't get animated.
					*/
					typeState.protectedKeys[key] = true;
				}
				/**
				* Update the typeState so next time animateChanges is called we can compare the
				* latest prop and resolvedValues to these.
				*/
				typeState.prevProp = prop;
				typeState.prevResolvedValues = resolvedValues;
				/**
				*
				*/
				if (typeState.isActive) encounteredKeys = _objectSpread2(_objectSpread2({}, encounteredKeys), resolvedValues);
				if (isInitialRender && visualElement.blockInitialAnimation) shouldAnimateType = false;
				if (shouldAnimateType && (!(isInherited && variantDidChange) || handledRemovedValues)) animations.push(...definitionList.map((animation) => ({
					animation,
					options: { type }
				})));
			}
			/**
			* If there are some removed value that haven't been dealt with,
			* we need to create a new animation that falls back either to the value
			* defined in the style prop, or the last read value.
			*/
			if (removedKeys.size) {
				const fallbackAnimation = {};
				removedKeys.forEach((key) => {
					const fallbackTarget = visualElement.getBaseTarget(key);
					const motionValue = visualElement.getValue(key);
					if (motionValue) motionValue.liveStyle = true;
					fallbackAnimation[key] = fallbackTarget !== null && fallbackTarget !== void 0 ? fallbackTarget : null;
				});
				animations.push({ animation: fallbackAnimation });
			}
			let shouldAnimate = Boolean(animations.length);
			if (isInitialRender && (props.initial === false || props.initial === props.animate) && !visualElement.manuallyAnimateOnMount) shouldAnimate = false;
			isInitialRender = false;
			return shouldAnimate ? animate(animations) : Promise.resolve();
		}
		/**
		* Change whether a certain animation type is active.
		*/
		function setActive(type, isActive) {
			var _a;
			if (state[type].isActive === isActive) return Promise.resolve();
			(_a = visualElement.variantChildren) === null || _a === void 0 || _a.forEach((child) => {
				var _a;
				return (_a = child.animationState) === null || _a === void 0 ? void 0 : _a.setActive(type, isActive);
			});
			state[type].isActive = isActive;
			const animations = animateChanges(type);
			for (const key in state) state[key].protectedKeys = {};
			return animations;
		}
		return {
			animateChanges,
			setActive,
			setAnimateFunction,
			getState: () => state,
			reset: () => {
				state = createState();
				isInitialRender = true;
			}
		};
	}
	function checkVariantsDidChange(prev, next) {
		if (typeof next === "string") return next !== prev;
		else if (Array.isArray(next)) return !shallowCompare(next, prev);
		return false;
	}
	function createTypeState(isActive = false) {
		return {
			isActive,
			protectedKeys: {},
			needsAnimating: {},
			prevResolvedValues: {}
		};
	}
	function createState() {
		return {
			animate: createTypeState(true),
			whileInView: createTypeState(),
			whileHover: createTypeState(),
			whileTap: createTypeState(),
			whileDrag: createTypeState(),
			whileFocus: createTypeState(),
			exit: createTypeState()
		};
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/motion/features/Feature.mjs
	var Feature = class {
		constructor(node) {
			this.isMounted = false;
			this.node = node;
		}
		update() {}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/motion/features/animation/index.mjs
	var AnimationFeature = class extends Feature {
		/**
		* We dynamically generate the AnimationState manager as it contains a reference
		* to the underlying animation library. We only want to load that if we load this,
		* so people can optionally code split it out using the `m` component.
		*/
		constructor(node) {
			super(node);
			node.animationState || (node.animationState = createAnimationState(node));
		}
		updateAnimationControlsSubscription() {
			const { animate } = this.node.getProps();
			if (isAnimationControls(animate)) this.unmountControls = animate.subscribe(this.node);
		}
		/**
		* Subscribe any provided AnimationControls to the component's VisualElement
		*/
		mount() {
			this.updateAnimationControlsSubscription();
		}
		update() {
			const { animate } = this.node.getProps();
			const { animate: prevAnimate } = this.node.prevProps || {};
			if (animate !== prevAnimate) this.updateAnimationControlsSubscription();
		}
		unmount() {
			var _a;
			this.node.animationState.reset();
			(_a = this.unmountControls) === null || _a === void 0 || _a.call(this);
		}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/motion/features/animation/exit.mjs
	var id$1 = 0;
	var ExitAnimationFeature = class extends Feature {
		constructor() {
			super(...arguments);
			this.id = id$1++;
		}
		update() {
			if (!this.node.presenceContext) return;
			const { isPresent, onExitComplete } = this.node.presenceContext;
			const { isPresent: prevIsPresent } = this.node.prevPresenceContext || {};
			if (!this.node.animationState || isPresent === prevIsPresent) return;
			const exitAnimation = this.node.animationState.setActive("exit", !isPresent);
			if (onExitComplete && !isPresent) exitAnimation.then(() => onExitComplete(this.id));
		}
		mount() {
			const { register } = this.node.presenceContext || {};
			if (register) this.unmount = register(this.id);
		}
		unmount() {}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/motion/features/animations.mjs
	var animations = {
		animation: { Feature: AnimationFeature },
		exit: { Feature: ExitAnimationFeature }
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/events/add-dom-event.mjs
	function addDomEvent(target, eventName, handler, options = { passive: true }) {
		target.addEventListener(eventName, handler, options);
		return () => target.removeEventListener(eventName, handler);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/events/event-info.mjs
	function extractEventInfo(event) {
		return { point: {
			x: event.pageX,
			y: event.pageY
		} };
	}
	var addPointerInfo = (handler) => {
		return (event) => isPrimaryPointer(event) && handler(event, extractEventInfo(event));
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/events/add-pointer-event.mjs
	function addPointerEvent(target, eventName, handler, options) {
		return addDomEvent(target, eventName, addPointerInfo(handler), options);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/distance.mjs
	var distance = (a, b) => Math.abs(a - b);
	function distance2D(a, b) {
		const xDelta = distance(a.x, b.x);
		const yDelta = distance(a.y, b.y);
		return Math.sqrt(Math.pow(xDelta, 2) + Math.pow(yDelta, 2));
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/gestures/pan/PanSession.mjs
	init_objectSpread2();
	/**
	* @internal
	*/
	var PanSession = class {
		constructor(event, handlers, { transformPagePoint, contextWindow, dragSnapToOrigin = false } = {}) {
			/**
			* @internal
			*/
			this.startEvent = null;
			/**
			* @internal
			*/
			this.lastMoveEvent = null;
			/**
			* @internal
			*/
			this.lastMoveEventInfo = null;
			/**
			* @internal
			*/
			this.handlers = {};
			/**
			* @internal
			*/
			this.contextWindow = window;
			this.updatePoint = () => {
				if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
				const info = getPanInfo(this.lastMoveEventInfo, this.history);
				const isPanStarted = this.startEvent !== null;
				const isDistancePastThreshold = distance2D(info.offset, {
					x: 0,
					y: 0
				}) >= 3;
				if (!isPanStarted && !isDistancePastThreshold) return;
				const { point } = info;
				const { timestamp } = frameData;
				this.history.push(_objectSpread2(_objectSpread2({}, point), {}, { timestamp }));
				const { onStart, onMove } = this.handlers;
				if (!isPanStarted) {
					onStart && onStart(this.lastMoveEvent, info);
					this.startEvent = this.lastMoveEvent;
				}
				onMove && onMove(this.lastMoveEvent, info);
			};
			this.handlePointerMove = (event, info) => {
				this.lastMoveEvent = event;
				this.lastMoveEventInfo = transformPoint(info, this.transformPagePoint);
				frame.update(this.updatePoint, true);
			};
			this.handlePointerUp = (event, info) => {
				this.end();
				const { onEnd, onSessionEnd, resumeAnimation } = this.handlers;
				if (this.dragSnapToOrigin) resumeAnimation && resumeAnimation();
				if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
				const panInfo = getPanInfo(event.type === "pointercancel" ? this.lastMoveEventInfo : transformPoint(info, this.transformPagePoint), this.history);
				if (this.startEvent && onEnd) onEnd(event, panInfo);
				onSessionEnd && onSessionEnd(event, panInfo);
			};
			if (!isPrimaryPointer(event)) return;
			this.dragSnapToOrigin = dragSnapToOrigin;
			this.handlers = handlers;
			this.transformPagePoint = transformPagePoint;
			this.contextWindow = contextWindow || window;
			const initialInfo = transformPoint(extractEventInfo(event), this.transformPagePoint);
			const { point } = initialInfo;
			const { timestamp } = frameData;
			this.history = [_objectSpread2(_objectSpread2({}, point), {}, { timestamp })];
			const { onSessionStart } = handlers;
			onSessionStart && onSessionStart(event, getPanInfo(initialInfo, this.history));
			this.removeListeners = pipe(addPointerEvent(this.contextWindow, "pointermove", this.handlePointerMove), addPointerEvent(this.contextWindow, "pointerup", this.handlePointerUp), addPointerEvent(this.contextWindow, "pointercancel", this.handlePointerUp));
		}
		updateHandlers(handlers) {
			this.handlers = handlers;
		}
		end() {
			this.removeListeners && this.removeListeners();
			cancelFrame(this.updatePoint);
		}
	};
	function transformPoint(info, transformPagePoint) {
		return transformPagePoint ? { point: transformPagePoint(info.point) } : info;
	}
	function subtractPoint(a, b) {
		return {
			x: a.x - b.x,
			y: a.y - b.y
		};
	}
	function getPanInfo({ point }, history) {
		return {
			point,
			delta: subtractPoint(point, lastDevicePoint(history)),
			offset: subtractPoint(point, startDevicePoint(history)),
			velocity: getVelocity(history, .1)
		};
	}
	function startDevicePoint(history) {
		return history[0];
	}
	function lastDevicePoint(history) {
		return history[history.length - 1];
	}
	function getVelocity(history, timeDelta) {
		if (history.length < 2) return {
			x: 0,
			y: 0
		};
		let i = history.length - 1;
		let timestampedPoint = null;
		const lastPoint = lastDevicePoint(history);
		while (i >= 0) {
			timestampedPoint = history[i];
			if (lastPoint.timestamp - timestampedPoint.timestamp > /* @__PURE__ */ secondsToMilliseconds(timeDelta)) break;
			i--;
		}
		if (!timestampedPoint) return {
			x: 0,
			y: 0
		};
		const time = /* @__PURE__ */ millisecondsToSeconds(lastPoint.timestamp - timestampedPoint.timestamp);
		if (time === 0) return {
			x: 0,
			y: 0
		};
		const currentVelocity = {
			x: (lastPoint.x - timestampedPoint.x) / time,
			y: (lastPoint.y - timestampedPoint.y) / time
		};
		if (currentVelocity.x === Infinity) currentVelocity.x = 0;
		if (currentVelocity.y === Infinity) currentVelocity.y = 0;
		return currentVelocity;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/projection/geometry/delta-calc.mjs
	var SCALE_MIN = .9999;
	var SCALE_MAX = 1.0001;
	var TRANSLATE_MIN = -.01;
	var TRANSLATE_MAX = .01;
	function calcLength(axis) {
		return axis.max - axis.min;
	}
	function isNear(value, target, maxDistance) {
		return Math.abs(value - target) <= maxDistance;
	}
	function calcAxisDelta(delta, source, target, origin = .5) {
		delta.origin = origin;
		delta.originPoint = mixNumber$1(source.min, source.max, delta.origin);
		delta.scale = calcLength(target) / calcLength(source);
		delta.translate = mixNumber$1(target.min, target.max, delta.origin) - delta.originPoint;
		if (delta.scale >= SCALE_MIN && delta.scale <= SCALE_MAX || isNaN(delta.scale)) delta.scale = 1;
		if (delta.translate >= TRANSLATE_MIN && delta.translate <= TRANSLATE_MAX || isNaN(delta.translate)) delta.translate = 0;
	}
	function calcBoxDelta(delta, source, target, origin) {
		calcAxisDelta(delta.x, source.x, target.x, origin ? origin.originX : void 0);
		calcAxisDelta(delta.y, source.y, target.y, origin ? origin.originY : void 0);
	}
	function calcRelativeAxis(target, relative, parent) {
		target.min = parent.min + relative.min;
		target.max = target.min + calcLength(relative);
	}
	function calcRelativeBox(target, relative, parent) {
		calcRelativeAxis(target.x, relative.x, parent.x);
		calcRelativeAxis(target.y, relative.y, parent.y);
	}
	function calcRelativeAxisPosition(target, layout, parent) {
		target.min = layout.min - parent.min;
		target.max = target.min + calcLength(layout);
	}
	function calcRelativePosition(target, layout, parent) {
		calcRelativeAxisPosition(target.x, layout.x, parent.x);
		calcRelativeAxisPosition(target.y, layout.y, parent.y);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/gestures/drag/utils/constraints.mjs
	/**
	* Apply constraints to a point. These constraints are both physical along an
	* axis, and an elastic factor that determines how much to constrain the point
	* by if it does lie outside the defined parameters.
	*/
	function applyConstraints(point, { min, max }, elastic) {
		if (min !== void 0 && point < min) point = elastic ? mixNumber$1(min, point, elastic.min) : Math.max(point, min);
		else if (max !== void 0 && point > max) point = elastic ? mixNumber$1(max, point, elastic.max) : Math.min(point, max);
		return point;
	}
	/**
	* Calculate constraints in terms of the viewport when defined relatively to the
	* measured axis. This is measured from the nearest edge, so a max constraint of 200
	* on an axis with a max value of 300 would return a constraint of 500 - axis length
	*/
	function calcRelativeAxisConstraints(axis, min, max) {
		return {
			min: min !== void 0 ? axis.min + min : void 0,
			max: max !== void 0 ? axis.max + max - (axis.max - axis.min) : void 0
		};
	}
	/**
	* Calculate constraints in terms of the viewport when
	* defined relatively to the measured bounding box.
	*/
	function calcRelativeConstraints(layoutBox, { top, left, bottom, right }) {
		return {
			x: calcRelativeAxisConstraints(layoutBox.x, left, right),
			y: calcRelativeAxisConstraints(layoutBox.y, top, bottom)
		};
	}
	/**
	* Calculate viewport constraints when defined as another viewport-relative axis
	*/
	function calcViewportAxisConstraints(layoutAxis, constraintsAxis) {
		let min = constraintsAxis.min - layoutAxis.min;
		let max = constraintsAxis.max - layoutAxis.max;
		if (constraintsAxis.max - constraintsAxis.min < layoutAxis.max - layoutAxis.min) [min, max] = [max, min];
		return {
			min,
			max
		};
	}
	/**
	* Calculate viewport constraints when defined as another viewport-relative box
	*/
	function calcViewportConstraints(layoutBox, constraintsBox) {
		return {
			x: calcViewportAxisConstraints(layoutBox.x, constraintsBox.x),
			y: calcViewportAxisConstraints(layoutBox.y, constraintsBox.y)
		};
	}
	/**
	* Calculate a transform origin relative to the source axis, between 0-1, that results
	* in an asthetically pleasing scale/transform needed to project from source to target.
	*/
	function calcOrigin(source, target) {
		let origin = .5;
		const sourceLength = calcLength(source);
		const targetLength = calcLength(target);
		if (targetLength > sourceLength) origin = /* @__PURE__ */ progress(target.min, target.max - sourceLength, source.min);
		else if (sourceLength > targetLength) origin = /* @__PURE__ */ progress(source.min, source.max - targetLength, target.min);
		return clamp(0, 1, origin);
	}
	/**
	* Rebase the calculated viewport constraints relative to the layout.min point.
	*/
	function rebaseAxisConstraints(layout, constraints) {
		const relativeConstraints = {};
		if (constraints.min !== void 0) relativeConstraints.min = constraints.min - layout.min;
		if (constraints.max !== void 0) relativeConstraints.max = constraints.max - layout.min;
		return relativeConstraints;
	}
	var defaultElastic = .35;
	/**
	* Accepts a dragElastic prop and returns resolved elastic values for each axis.
	*/
	function resolveDragElastic(dragElastic = defaultElastic) {
		if (dragElastic === false) dragElastic = 0;
		else if (dragElastic === true) dragElastic = defaultElastic;
		return {
			x: resolveAxisElastic(dragElastic, "left", "right"),
			y: resolveAxisElastic(dragElastic, "top", "bottom")
		};
	}
	function resolveAxisElastic(dragElastic, minLabel, maxLabel) {
		return {
			min: resolvePointElastic(dragElastic, minLabel),
			max: resolvePointElastic(dragElastic, maxLabel)
		};
	}
	function resolvePointElastic(dragElastic, label) {
		return typeof dragElastic === "number" ? dragElastic : dragElastic[label] || 0;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/projection/geometry/models.mjs
	var createAxisDelta = () => ({
		translate: 0,
		scale: 1,
		origin: 0,
		originPoint: 0
	});
	var createDelta = () => ({
		x: createAxisDelta(),
		y: createAxisDelta()
	});
	var createAxis = () => ({
		min: 0,
		max: 0
	});
	var createBox = () => ({
		x: createAxis(),
		y: createAxis()
	});
	//#endregion
	//#region node_modules/framer-motion/dist/es/projection/utils/each-axis.mjs
	function eachAxis(callback) {
		return [callback("x"), callback("y")];
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/projection/geometry/conversion.mjs
	/**
	* Bounding boxes tend to be defined as top, left, right, bottom. For various operations
	* it's easier to consider each axis individually. This function returns a bounding box
	* as a map of single-axis min/max values.
	*/
	function convertBoundingBoxToBox({ top, left, right, bottom }) {
		return {
			x: {
				min: left,
				max: right
			},
			y: {
				min: top,
				max: bottom
			}
		};
	}
	function convertBoxToBoundingBox({ x, y }) {
		return {
			top: y.min,
			right: x.max,
			bottom: y.max,
			left: x.min
		};
	}
	/**
	* Applies a TransformPoint function to a bounding box. TransformPoint is usually a function
	* provided by Framer to allow measured points to be corrected for device scaling. This is used
	* when measuring DOM elements and DOM event points.
	*/
	function transformBoxPoints(point, transformPoint) {
		if (!transformPoint) return point;
		const topLeft = transformPoint({
			x: point.left,
			y: point.top
		});
		const bottomRight = transformPoint({
			x: point.right,
			y: point.bottom
		});
		return {
			top: topLeft.y,
			left: topLeft.x,
			bottom: bottomRight.y,
			right: bottomRight.x
		};
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/projection/utils/has-transform.mjs
	function isIdentityScale(scale) {
		return scale === void 0 || scale === 1;
	}
	function hasScale({ scale, scaleX, scaleY }) {
		return !isIdentityScale(scale) || !isIdentityScale(scaleX) || !isIdentityScale(scaleY);
	}
	function hasTransform(values) {
		return hasScale(values) || has2DTranslate(values) || values.z || values.rotate || values.rotateX || values.rotateY || values.skewX || values.skewY;
	}
	function has2DTranslate(values) {
		return is2DTranslate(values.x) || is2DTranslate(values.y);
	}
	function is2DTranslate(value) {
		return value && value !== "0%";
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/projection/geometry/delta-apply.mjs
	/**
	* Scales a point based on a factor and an originPoint
	*/
	function scalePoint(point, scale, originPoint) {
		return originPoint + scale * (point - originPoint);
	}
	/**
	* Applies a translate/scale delta to a point
	*/
	function applyPointDelta(point, translate, scale, originPoint, boxScale) {
		if (boxScale !== void 0) point = scalePoint(point, boxScale, originPoint);
		return scalePoint(point, scale, originPoint) + translate;
	}
	/**
	* Applies a translate/scale delta to an axis
	*/
	function applyAxisDelta(axis, translate = 0, scale = 1, originPoint, boxScale) {
		axis.min = applyPointDelta(axis.min, translate, scale, originPoint, boxScale);
		axis.max = applyPointDelta(axis.max, translate, scale, originPoint, boxScale);
	}
	/**
	* Applies a translate/scale delta to a box
	*/
	function applyBoxDelta(box, { x, y }) {
		applyAxisDelta(box.x, x.translate, x.scale, x.originPoint);
		applyAxisDelta(box.y, y.translate, y.scale, y.originPoint);
	}
	var TREE_SCALE_SNAP_MIN = .999999999999;
	var TREE_SCALE_SNAP_MAX = 1.0000000000001;
	/**
	* Apply a tree of deltas to a box. We do this to calculate the effect of all the transforms
	* in a tree upon our box before then calculating how to project it into our desired viewport-relative box
	*
	* This is the final nested loop within updateLayoutDelta for future refactoring
	*/
	function applyTreeDeltas(box, treeScale, treePath, isSharedTransition = false) {
		const treeLength = treePath.length;
		if (!treeLength) return;
		treeScale.x = treeScale.y = 1;
		let node;
		let delta;
		for (let i = 0; i < treeLength; i++) {
			node = treePath[i];
			delta = node.projectionDelta;
			/**
			* TODO: Prefer to remove this, but currently we have motion components with
			* display: contents in Framer.
			*/
			const { visualElement } = node.options;
			if (visualElement && visualElement.props.style && visualElement.props.style.display === "contents") continue;
			if (isSharedTransition && node.options.layoutScroll && node.scroll && node !== node.root) transformBox(box, {
				x: -node.scroll.offset.x,
				y: -node.scroll.offset.y
			});
			if (delta) {
				treeScale.x *= delta.x.scale;
				treeScale.y *= delta.y.scale;
				applyBoxDelta(box, delta);
			}
			if (isSharedTransition && hasTransform(node.latestValues)) transformBox(box, node.latestValues);
		}
		/**
		* Snap tree scale back to 1 if it's within a non-perceivable threshold.
		* This will help reduce useless scales getting rendered.
		*/
		if (treeScale.x < TREE_SCALE_SNAP_MAX && treeScale.x > TREE_SCALE_SNAP_MIN) treeScale.x = 1;
		if (treeScale.y < TREE_SCALE_SNAP_MAX && treeScale.y > TREE_SCALE_SNAP_MIN) treeScale.y = 1;
	}
	function translateAxis(axis, distance) {
		axis.min = axis.min + distance;
		axis.max = axis.max + distance;
	}
	/**
	* Apply a transform to an axis from the latest resolved motion values.
	* This function basically acts as a bridge between a flat motion value map
	* and applyAxisDelta
	*/
	function transformAxis(axis, axisTranslate, axisScale, boxScale, axisOrigin = .5) {
		applyAxisDelta(axis, axisTranslate, axisScale, mixNumber$1(axis.min, axis.max, axisOrigin), boxScale);
	}
	/**
	* Apply a transform to a box from the latest resolved motion values.
	*/
	function transformBox(box, transform) {
		transformAxis(box.x, transform.x, transform.scaleX, transform.scale, transform.originX);
		transformAxis(box.y, transform.y, transform.scaleY, transform.scale, transform.originY);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/projection/utils/measure.mjs
	function measureViewportBox(instance, transformPoint) {
		return convertBoundingBoxToBox(transformBoxPoints(instance.getBoundingClientRect(), transformPoint));
	}
	function measurePageBox(element, rootProjectionNode, transformPagePoint) {
		const viewportBox = measureViewportBox(element, transformPagePoint);
		const { scroll } = rootProjectionNode;
		if (scroll) {
			translateAxis(viewportBox.x, scroll.offset.x);
			translateAxis(viewportBox.y, scroll.offset.y);
		}
		return viewportBox;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/get-context-window.mjs
	var getContextWindow = ({ current }) => {
		return current ? current.ownerDocument.defaultView : null;
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/gestures/drag/VisualElementDragControls.mjs
	init_objectSpread2();
	var elementDragControls = /* @__PURE__ */ new WeakMap();
	/**
	*
	*/
	var VisualElementDragControls = class {
		constructor(visualElement) {
			this.openDragLock = null;
			this.isDragging = false;
			this.currentDirection = null;
			this.originPoint = {
				x: 0,
				y: 0
			};
			/**
			* The permitted boundaries of travel, in pixels.
			*/
			this.constraints = false;
			this.hasMutatedConstraints = false;
			/**
			* The per-axis resolved elastic values.
			*/
			this.elastic = createBox();
			this.visualElement = visualElement;
		}
		start(originEvent, { snapToCursor = false } = {}) {
			/**
			* Don't start dragging if this component is exiting
			*/
			const { presenceContext } = this.visualElement;
			if (presenceContext && presenceContext.isPresent === false) return;
			const onSessionStart = (event) => {
				const { dragSnapToOrigin } = this.getProps();
				dragSnapToOrigin ? this.pauseAnimation() : this.stopAnimation();
				if (snapToCursor) this.snapToCursor(extractEventInfo(event).point);
			};
			const onStart = (event, info) => {
				const { drag, dragPropagation, onDragStart } = this.getProps();
				if (drag && !dragPropagation) {
					if (this.openDragLock) this.openDragLock();
					this.openDragLock = setDragLock(drag);
					if (!this.openDragLock) return;
				}
				this.isDragging = true;
				this.currentDirection = null;
				this.resolveConstraints();
				if (this.visualElement.projection) {
					this.visualElement.projection.isAnimationBlocked = true;
					this.visualElement.projection.target = void 0;
				}
				/**
				* Record gesture origin
				*/
				eachAxis((axis) => {
					let current = this.getAxisMotionValue(axis).get() || 0;
					/**
					* If the MotionValue is a percentage value convert to px
					*/
					if (percent.test(current)) {
						const { projection } = this.visualElement;
						if (projection && projection.layout) {
							const measuredAxis = projection.layout.layoutBox[axis];
							if (measuredAxis) current = calcLength(measuredAxis) * (parseFloat(current) / 100);
						}
					}
					this.originPoint[axis] = current;
				});
				if (onDragStart) frame.postRender(() => onDragStart(event, info));
				addValueToWillChange(this.visualElement, "transform");
				const { animationState } = this.visualElement;
				animationState && animationState.setActive("whileDrag", true);
			};
			const onMove = (event, info) => {
				const { dragPropagation, dragDirectionLock, onDirectionLock, onDrag } = this.getProps();
				if (!dragPropagation && !this.openDragLock) return;
				const { offset } = info;
				if (dragDirectionLock && this.currentDirection === null) {
					this.currentDirection = getCurrentDirection(offset);
					if (this.currentDirection !== null) onDirectionLock && onDirectionLock(this.currentDirection);
					return;
				}
				this.updateAxis("x", info.point, offset);
				this.updateAxis("y", info.point, offset);
				/**
				* Ideally we would leave the renderer to fire naturally at the end of
				* this frame but if the element is about to change layout as the result
				* of a re-render we want to ensure the browser can read the latest
				* bounding box to ensure the pointer and element don't fall out of sync.
				*/
				this.visualElement.render();
				/**
				* This must fire after the render call as it might trigger a state
				* change which itself might trigger a layout update.
				*/
				onDrag && onDrag(event, info);
			};
			const onSessionEnd = (event, info) => this.stop(event, info);
			const resumeAnimation = () => eachAxis((axis) => {
				var _a;
				return this.getAnimationState(axis) === "paused" && ((_a = this.getAxisMotionValue(axis).animation) === null || _a === void 0 ? void 0 : _a.play());
			});
			const { dragSnapToOrigin } = this.getProps();
			this.panSession = new PanSession(originEvent, {
				onSessionStart,
				onStart,
				onMove,
				onSessionEnd,
				resumeAnimation
			}, {
				transformPagePoint: this.visualElement.getTransformPagePoint(),
				dragSnapToOrigin,
				contextWindow: getContextWindow(this.visualElement)
			});
		}
		stop(event, info) {
			const isDragging = this.isDragging;
			this.cancel();
			if (!isDragging) return;
			const { velocity } = info;
			this.startAnimation(velocity);
			const { onDragEnd } = this.getProps();
			if (onDragEnd) frame.postRender(() => onDragEnd(event, info));
		}
		cancel() {
			this.isDragging = false;
			const { projection, animationState } = this.visualElement;
			if (projection) projection.isAnimationBlocked = false;
			this.panSession && this.panSession.end();
			this.panSession = void 0;
			const { dragPropagation } = this.getProps();
			if (!dragPropagation && this.openDragLock) {
				this.openDragLock();
				this.openDragLock = null;
			}
			animationState && animationState.setActive("whileDrag", false);
		}
		updateAxis(axis, _point, offset) {
			const { drag } = this.getProps();
			if (!offset || !shouldDrag(axis, drag, this.currentDirection)) return;
			const axisValue = this.getAxisMotionValue(axis);
			let next = this.originPoint[axis] + offset[axis];
			if (this.constraints && this.constraints[axis]) next = applyConstraints(next, this.constraints[axis], this.elastic[axis]);
			axisValue.set(next);
		}
		resolveConstraints() {
			var _a;
			const { dragConstraints, dragElastic } = this.getProps();
			const layout = this.visualElement.projection && !this.visualElement.projection.layout ? this.visualElement.projection.measure(false) : (_a = this.visualElement.projection) === null || _a === void 0 ? void 0 : _a.layout;
			const prevConstraints = this.constraints;
			if (dragConstraints && isRefObject(dragConstraints)) {
				if (!this.constraints) this.constraints = this.resolveRefConstraints();
			} else if (dragConstraints && layout) this.constraints = calcRelativeConstraints(layout.layoutBox, dragConstraints);
			else this.constraints = false;
			this.elastic = resolveDragElastic(dragElastic);
			/**
			* If we're outputting to external MotionValues, we want to rebase the measured constraints
			* from viewport-relative to component-relative.
			*/
			if (prevConstraints !== this.constraints && layout && this.constraints && !this.hasMutatedConstraints) eachAxis((axis) => {
				if (this.constraints !== false && this.getAxisMotionValue(axis)) this.constraints[axis] = rebaseAxisConstraints(layout.layoutBox[axis], this.constraints[axis]);
			});
		}
		resolveRefConstraints() {
			const { dragConstraints: constraints, onMeasureDragConstraints } = this.getProps();
			if (!constraints || !isRefObject(constraints)) return false;
			const constraintsElement = constraints.current;
			invariant(constraintsElement !== null, "If `dragConstraints` is set as a React ref, that ref must be passed to another component's `ref` prop.");
			const { projection } = this.visualElement;
			if (!projection || !projection.layout) return false;
			const constraintsBox = measurePageBox(constraintsElement, projection.root, this.visualElement.getTransformPagePoint());
			let measuredConstraints = calcViewportConstraints(projection.layout.layoutBox, constraintsBox);
			/**
			* If there's an onMeasureDragConstraints listener we call it and
			* if different constraints are returned, set constraints to that
			*/
			if (onMeasureDragConstraints) {
				const userConstraints = onMeasureDragConstraints(convertBoxToBoundingBox(measuredConstraints));
				this.hasMutatedConstraints = !!userConstraints;
				if (userConstraints) measuredConstraints = convertBoundingBoxToBox(userConstraints);
			}
			return measuredConstraints;
		}
		startAnimation(velocity) {
			const { drag, dragMomentum, dragElastic, dragTransition, dragSnapToOrigin, onDragTransitionEnd } = this.getProps();
			const constraints = this.constraints || {};
			const momentumAnimations = eachAxis((axis) => {
				if (!shouldDrag(axis, drag, this.currentDirection)) return;
				let transition = constraints && constraints[axis] || {};
				if (dragSnapToOrigin) transition = {
					min: 0,
					max: 0
				};
				/**
				* Overdamp the boundary spring if `dragElastic` is disabled. There's still a frame
				* of spring animations so we should look into adding a disable spring option to `inertia`.
				* We could do something here where we affect the `bounceStiffness` and `bounceDamping`
				* using the value of `dragElastic`.
				*/
				const bounceStiffness = dragElastic ? 200 : 1e6;
				const bounceDamping = dragElastic ? 40 : 1e7;
				const inertia = _objectSpread2(_objectSpread2({
					type: "inertia",
					velocity: dragMomentum ? velocity[axis] : 0,
					bounceStiffness,
					bounceDamping,
					timeConstant: 750,
					restDelta: 1,
					restSpeed: 10
				}, dragTransition), transition);
				return this.startAxisValueAnimation(axis, inertia);
			});
			return Promise.all(momentumAnimations).then(onDragTransitionEnd);
		}
		startAxisValueAnimation(axis, transition) {
			const axisValue = this.getAxisMotionValue(axis);
			addValueToWillChange(this.visualElement, axis);
			return axisValue.start(animateMotionValue(axis, axisValue, 0, transition, this.visualElement, false));
		}
		stopAnimation() {
			eachAxis((axis) => this.getAxisMotionValue(axis).stop());
		}
		pauseAnimation() {
			eachAxis((axis) => {
				var _a;
				return (_a = this.getAxisMotionValue(axis).animation) === null || _a === void 0 ? void 0 : _a.pause();
			});
		}
		getAnimationState(axis) {
			var _a;
			return (_a = this.getAxisMotionValue(axis).animation) === null || _a === void 0 ? void 0 : _a.state;
		}
		/**
		* Drag works differently depending on which props are provided.
		*
		* - If _dragX and _dragY are provided, we output the gesture delta directly to those motion values.
		* - Otherwise, we apply the delta to the x/y motion values.
		*/
		getAxisMotionValue(axis) {
			const dragKey = `_drag${axis.toUpperCase()}`;
			const props = this.visualElement.getProps();
			const externalMotionValue = props[dragKey];
			return externalMotionValue ? externalMotionValue : this.visualElement.getValue(axis, (props.initial ? props.initial[axis] : void 0) || 0);
		}
		snapToCursor(point) {
			eachAxis((axis) => {
				const { drag } = this.getProps();
				if (!shouldDrag(axis, drag, this.currentDirection)) return;
				const { projection } = this.visualElement;
				const axisValue = this.getAxisMotionValue(axis);
				if (projection && projection.layout) {
					const { min, max } = projection.layout.layoutBox[axis];
					axisValue.set(point[axis] - mixNumber$1(min, max, .5));
				}
			});
		}
		/**
		* When the viewport resizes we want to check if the measured constraints
		* have changed and, if so, reposition the element within those new constraints
		* relative to where it was before the resize.
		*/
		scalePositionWithinConstraints() {
			if (!this.visualElement.current) return;
			const { drag, dragConstraints } = this.getProps();
			const { projection } = this.visualElement;
			if (!isRefObject(dragConstraints) || !projection || !this.constraints) return;
			/**
			* Stop current animations as there can be visual glitching if we try to do
			* this mid-animation
			*/
			this.stopAnimation();
			/**
			* Record the relative position of the dragged element relative to the
			* constraints box and save as a progress value.
			*/
			const boxProgress = {
				x: 0,
				y: 0
			};
			eachAxis((axis) => {
				const axisValue = this.getAxisMotionValue(axis);
				if (axisValue && this.constraints !== false) {
					const latest = axisValue.get();
					boxProgress[axis] = calcOrigin({
						min: latest,
						max: latest
					}, this.constraints[axis]);
				}
			});
			/**
			* Update the layout of this element and resolve the latest drag constraints
			*/
			const { transformTemplate } = this.visualElement.getProps();
			this.visualElement.current.style.transform = transformTemplate ? transformTemplate({}, "") : "none";
			projection.root && projection.root.updateScroll();
			projection.updateLayout();
			this.resolveConstraints();
			/**
			* For each axis, calculate the current progress of the layout axis
			* within the new constraints.
			*/
			eachAxis((axis) => {
				if (!shouldDrag(axis, drag, null)) return;
				/**
				* Calculate a new transform based on the previous box progress
				*/
				const axisValue = this.getAxisMotionValue(axis);
				const { min, max } = this.constraints[axis];
				axisValue.set(mixNumber$1(min, max, boxProgress[axis]));
			});
		}
		addListeners() {
			if (!this.visualElement.current) return;
			elementDragControls.set(this.visualElement, this);
			const element = this.visualElement.current;
			/**
			* Attach a pointerdown event listener on this DOM element to initiate drag tracking.
			*/
			const stopPointerListener = addPointerEvent(element, "pointerdown", (event) => {
				const { drag, dragListener = true } = this.getProps();
				drag && dragListener && this.start(event);
			});
			const measureDragConstraints = () => {
				const { dragConstraints } = this.getProps();
				if (isRefObject(dragConstraints) && dragConstraints.current) this.constraints = this.resolveRefConstraints();
			};
			const { projection } = this.visualElement;
			const stopMeasureLayoutListener = projection.addEventListener("measure", measureDragConstraints);
			if (projection && !projection.layout) {
				projection.root && projection.root.updateScroll();
				projection.updateLayout();
			}
			frame.read(measureDragConstraints);
			/**
			* Attach a window resize listener to scale the draggable target within its defined
			* constraints as the window resizes.
			*/
			const stopResizeListener = addDomEvent(window, "resize", () => this.scalePositionWithinConstraints());
			/**
			* If the element's layout changes, calculate the delta and apply that to
			* the drag gesture's origin point.
			*/
			const stopLayoutUpdateListener = projection.addEventListener("didUpdate", (({ delta, hasLayoutChanged }) => {
				if (this.isDragging && hasLayoutChanged) {
					eachAxis((axis) => {
						const motionValue = this.getAxisMotionValue(axis);
						if (!motionValue) return;
						this.originPoint[axis] += delta[axis].translate;
						motionValue.set(motionValue.get() + delta[axis].translate);
					});
					this.visualElement.render();
				}
			}));
			return () => {
				stopResizeListener();
				stopPointerListener();
				stopMeasureLayoutListener();
				stopLayoutUpdateListener && stopLayoutUpdateListener();
			};
		}
		getProps() {
			const props = this.visualElement.getProps();
			const { drag = false, dragDirectionLock = false, dragPropagation = false, dragConstraints = false, dragElastic = defaultElastic, dragMomentum = true } = props;
			return _objectSpread2(_objectSpread2({}, props), {}, {
				drag,
				dragDirectionLock,
				dragPropagation,
				dragConstraints,
				dragElastic,
				dragMomentum
			});
		}
	};
	function shouldDrag(direction, drag, currentDirection) {
		return (drag === true || drag === direction) && (currentDirection === null || currentDirection === direction);
	}
	/**
	* Based on an x/y offset determine the current drag direction. If both axis' offsets are lower
	* than the provided threshold, return `null`.
	*
	* @param offset - The x/y offset from origin.
	* @param lockThreshold - (Optional) - the minimum absolute offset before we can determine a drag direction.
	*/
	function getCurrentDirection(offset, lockThreshold = 10) {
		let direction = null;
		if (Math.abs(offset.y) > lockThreshold) direction = "y";
		else if (Math.abs(offset.x) > lockThreshold) direction = "x";
		return direction;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/gestures/drag/index.mjs
	var DragGesture = class extends Feature {
		constructor(node) {
			super(node);
			this.removeGroupControls = noop;
			this.removeListeners = noop;
			this.controls = new VisualElementDragControls(node);
		}
		mount() {
			const { dragControls } = this.node.getProps();
			if (dragControls) this.removeGroupControls = dragControls.subscribe(this.controls);
			this.removeListeners = this.controls.addListeners() || noop;
		}
		unmount() {
			this.removeGroupControls();
			this.removeListeners();
		}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/gestures/pan/index.mjs
	var asyncHandler = (handler) => (event, info) => {
		if (handler) frame.postRender(() => handler(event, info));
	};
	var PanGesture = class extends Feature {
		constructor() {
			super(...arguments);
			this.removePointerDownListener = noop;
		}
		onPointerDown(pointerDownEvent) {
			this.session = new PanSession(pointerDownEvent, this.createPanHandlers(), {
				transformPagePoint: this.node.getTransformPagePoint(),
				contextWindow: getContextWindow(this.node)
			});
		}
		createPanHandlers() {
			const { onPanSessionStart, onPanStart, onPan, onPanEnd } = this.node.getProps();
			return {
				onSessionStart: asyncHandler(onPanSessionStart),
				onStart: asyncHandler(onPanStart),
				onMove: onPan,
				onEnd: (event, info) => {
					delete this.session;
					if (onPanEnd) frame.postRender(() => onPanEnd(event, info));
				}
			};
		}
		mount() {
			this.removePointerDownListener = addPointerEvent(this.node.current, "pointerdown", (event) => this.onPointerDown(event));
		}
		update() {
			this.session && this.session.updateHandlers(this.createPanHandlers());
		}
		unmount() {
			this.removePointerDownListener();
			this.session && this.session.end();
		}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/projection/node/state.mjs
	/**
	* This should only ever be modified on the client otherwise it'll
	* persist through server requests. If we need instanced states we
	* could lazy-init via root.
	*/
	var globalProjectionState = {
		/**
		* Global flag as to whether the tree has animated since the last time
		* we resized the window
		*/
		hasAnimatedSinceResize: true,
		/**
		* We set this to true once, on the first update. Any nodes added to the tree beyond that
		* update will be given a `data-projection-id` attribute.
		*/
		hasEverUpdated: false
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/projection/styles/scale-border-radius.mjs
	function pixelsToPercent(pixels, axis) {
		if (axis.max === axis.min) return 0;
		return pixels / (axis.max - axis.min) * 100;
	}
	/**
	* We always correct borderRadius as a percentage rather than pixels to reduce paints.
	* For example, if you are projecting a box that is 100px wide with a 10px borderRadius
	* into a box that is 200px wide with a 20px borderRadius, that is actually a 10%
	* borderRadius in both states. If we animate between the two in pixels that will trigger
	* a paint each time. If we animate between the two in percentage we'll avoid a paint.
	*/
	var correctBorderRadius = { correct: (latest, node) => {
		if (!node.target) return latest;
		/**
		* If latest is a string, if it's a percentage we can return immediately as it's
		* going to be stretched appropriately. Otherwise, if it's a pixel, convert it to a number.
		*/
		if (typeof latest === "string") {
			if (px.test(latest)) latest = parseFloat(latest);
			else return latest;
		}
		return `${pixelsToPercent(latest, node.target.x)}% ${pixelsToPercent(latest, node.target.y)}%`;
	} };
	//#endregion
	//#region node_modules/framer-motion/dist/es/projection/styles/scale-box-shadow.mjs
	var correctBoxShadow = { correct: (latest, { treeScale, projectionDelta }) => {
		const original = latest;
		const shadow = complex.parse(latest);
		if (shadow.length > 5) return original;
		const template = complex.createTransformer(latest);
		const offset = typeof shadow[0] !== "number" ? 1 : 0;
		const xScale = projectionDelta.x.scale * treeScale.x;
		const yScale = projectionDelta.y.scale * treeScale.y;
		shadow[0 + offset] /= xScale;
		shadow[1 + offset] /= yScale;
		/**
		* Ideally we'd correct x and y scales individually, but because blur and
		* spread apply to both we have to take a scale average and apply that instead.
		* We could potentially improve the outcome of this by incorporating the ratio between
		* the two scales.
		*/
		const averageScale = mixNumber$1(xScale, yScale, .5);
		if (typeof shadow[2 + offset] === "number") shadow[2 + offset] /= averageScale;
		if (typeof shadow[3 + offset] === "number") shadow[3 + offset] /= averageScale;
		return template(shadow);
	} };
	//#endregion
	//#region node_modules/framer-motion/dist/es/motion/features/layout/MeasureLayout.mjs
	init_objectSpread2();
	var MeasureLayoutWithContext = class extends import_react.Component {
		/**
		* This only mounts projection nodes for components that
		* need measuring, we might want to do it for all components
		* in order to incorporate transforms
		*/
		componentDidMount() {
			const { visualElement, layoutGroup, switchLayoutGroup, layoutId } = this.props;
			const { projection } = visualElement;
			addScaleCorrector(defaultScaleCorrectors);
			if (projection) {
				if (layoutGroup.group) layoutGroup.group.add(projection);
				if (switchLayoutGroup && switchLayoutGroup.register && layoutId) switchLayoutGroup.register(projection);
				projection.root.didUpdate();
				projection.addEventListener("animationComplete", () => {
					this.safeToRemove();
				});
				projection.setOptions(_objectSpread2(_objectSpread2({}, projection.options), {}, { onExitComplete: () => this.safeToRemove() }));
			}
			globalProjectionState.hasEverUpdated = true;
		}
		getSnapshotBeforeUpdate(prevProps) {
			const { layoutDependency, visualElement, drag, isPresent } = this.props;
			const projection = visualElement.projection;
			if (!projection) return null;
			/**
			* TODO: We use this data in relegate to determine whether to
			* promote a previous element. There's no guarantee its presence data
			* will have updated by this point - if a bug like this arises it will
			* have to be that we markForRelegation and then find a new lead some other way,
			* perhaps in didUpdate
			*/
			projection.isPresent = isPresent;
			if (drag || prevProps.layoutDependency !== layoutDependency || layoutDependency === void 0) projection.willUpdate();
			else this.safeToRemove();
			if (prevProps.isPresent !== isPresent) {
				if (isPresent) projection.promote();
				else if (!projection.relegate())
 /**
				* If there's another stack member taking over from this one,
				* it's in charge of the exit animation and therefore should
				* be in charge of the safe to remove. Otherwise we call it here.
				*/
				frame.postRender(() => {
					const stack = projection.getStack();
					if (!stack || !stack.members.length) this.safeToRemove();
				});
			}
			return null;
		}
		componentDidUpdate() {
			const { projection } = this.props.visualElement;
			if (projection) {
				projection.root.didUpdate();
				microtask.postRender(() => {
					if (!projection.currentAnimation && projection.isLead()) this.safeToRemove();
				});
			}
		}
		componentWillUnmount() {
			const { visualElement, layoutGroup, switchLayoutGroup: promoteContext } = this.props;
			const { projection } = visualElement;
			if (projection) {
				projection.scheduleCheckAfterUnmount();
				if (layoutGroup && layoutGroup.group) layoutGroup.group.remove(projection);
				if (promoteContext && promoteContext.deregister) promoteContext.deregister(projection);
			}
		}
		safeToRemove() {
			const { safeToRemove } = this.props;
			safeToRemove && safeToRemove();
		}
		render() {
			return null;
		}
	};
	function MeasureLayout(props) {
		const [isPresent, safeToRemove] = usePresence();
		const layoutGroup = (0, import_react.useContext)(LayoutGroupContext);
		return (0, import_jsx_runtime.jsx)(MeasureLayoutWithContext, _objectSpread2(_objectSpread2({}, props), {}, {
			layoutGroup,
			switchLayoutGroup: (0, import_react.useContext)(SwitchLayoutGroupContext),
			isPresent,
			safeToRemove
		}));
	}
	var defaultScaleCorrectors = {
		borderRadius: _objectSpread2(_objectSpread2({}, correctBorderRadius), {}, { applyTo: [
			"borderTopLeftRadius",
			"borderTopRightRadius",
			"borderBottomLeftRadius",
			"borderBottomRightRadius"
		] }),
		borderTopLeftRadius: correctBorderRadius,
		borderTopRightRadius: correctBorderRadius,
		borderBottomLeftRadius: correctBorderRadius,
		borderBottomRightRadius: correctBorderRadius,
		boxShadow: correctBoxShadow
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/animation/animate/single-value.mjs
	function animateSingleValue(value, keyframes, options) {
		const motionValue$1 = isMotionValue(value) ? value : motionValue(value);
		motionValue$1.start(animateMotionValue("", motionValue$1, keyframes, options));
		return motionValue$1.animation;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/dom/utils/is-svg-element.mjs
	function isSVGElement(element) {
		return element instanceof SVGElement && element.tagName !== "svg";
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/utils/compare-by-depth.mjs
	var compareByDepth = (a, b) => a.depth - b.depth;
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/utils/flat-tree.mjs
	var FlatTree = class {
		constructor() {
			this.children = [];
			this.isDirty = false;
		}
		add(child) {
			addUniqueItem(this.children, child);
			this.isDirty = true;
		}
		remove(child) {
			removeItem(this.children, child);
			this.isDirty = true;
		}
		forEach(callback) {
			this.isDirty && this.children.sort(compareByDepth);
			this.isDirty = false;
			this.children.forEach(callback);
		}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/delay.mjs
	/**
	* Timeout defined in ms
	*/
	function delay(callback, timeout) {
		const start = time.now();
		const checkElapsed = ({ timestamp }) => {
			const elapsed = timestamp - start;
			if (elapsed >= timeout) {
				cancelFrame(checkElapsed);
				callback(elapsed - timeout);
			}
		};
		frame.read(checkElapsed, true);
		return () => cancelFrame(checkElapsed);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/projection/animation/mix-values.mjs
	var borders = [
		"TopLeft",
		"TopRight",
		"BottomLeft",
		"BottomRight"
	];
	var numBorders = borders.length;
	var asNumber = (value) => typeof value === "string" ? parseFloat(value) : value;
	var isPx = (value) => typeof value === "number" || px.test(value);
	function mixValues(target, follow, lead, progress, shouldCrossfadeOpacity, isOnlyMember) {
		if (shouldCrossfadeOpacity) {
			target.opacity = mixNumber$1(0, lead.opacity !== void 0 ? lead.opacity : 1, easeCrossfadeIn(progress));
			target.opacityExit = mixNumber$1(follow.opacity !== void 0 ? follow.opacity : 1, 0, easeCrossfadeOut(progress));
		} else if (isOnlyMember) target.opacity = mixNumber$1(follow.opacity !== void 0 ? follow.opacity : 1, lead.opacity !== void 0 ? lead.opacity : 1, progress);
		/**
		* Mix border radius
		*/
		for (let i = 0; i < numBorders; i++) {
			const borderLabel = `border${borders[i]}Radius`;
			let followRadius = getRadius(follow, borderLabel);
			let leadRadius = getRadius(lead, borderLabel);
			if (followRadius === void 0 && leadRadius === void 0) continue;
			followRadius || (followRadius = 0);
			leadRadius || (leadRadius = 0);
			if (followRadius === 0 || leadRadius === 0 || isPx(followRadius) === isPx(leadRadius)) {
				target[borderLabel] = Math.max(mixNumber$1(asNumber(followRadius), asNumber(leadRadius), progress), 0);
				if (percent.test(leadRadius) || percent.test(followRadius)) target[borderLabel] += "%";
			} else target[borderLabel] = leadRadius;
		}
		/**
		* Mix rotation
		*/
		if (follow.rotate || lead.rotate) target.rotate = mixNumber$1(follow.rotate || 0, lead.rotate || 0, progress);
	}
	function getRadius(values, radiusName) {
		return values[radiusName] !== void 0 ? values[radiusName] : values.borderRadius;
	}
	var easeCrossfadeIn = /*@__PURE__*/ compress(0, .5, circOut);
	var easeCrossfadeOut = /*@__PURE__*/ compress(.5, .95, noop);
	function compress(min, max, easing) {
		return (p) => {
			if (p < min) return 0;
			if (p > max) return 1;
			return easing(/* @__PURE__ */ progress(min, max, p));
		};
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/projection/geometry/copy.mjs
	/**
	* Reset an axis to the provided origin box.
	*
	* This is a mutative operation.
	*/
	function copyAxisInto(axis, originAxis) {
		axis.min = originAxis.min;
		axis.max = originAxis.max;
	}
	/**
	* Reset a box to the provided origin box.
	*
	* This is a mutative operation.
	*/
	function copyBoxInto(box, originBox) {
		copyAxisInto(box.x, originBox.x);
		copyAxisInto(box.y, originBox.y);
	}
	/**
	* Reset a delta to the provided origin box.
	*
	* This is a mutative operation.
	*/
	function copyAxisDeltaInto(delta, originDelta) {
		delta.translate = originDelta.translate;
		delta.scale = originDelta.scale;
		delta.originPoint = originDelta.originPoint;
		delta.origin = originDelta.origin;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/projection/geometry/delta-remove.mjs
	/**
	* Remove a delta from a point. This is essentially the steps of applyPointDelta in reverse
	*/
	function removePointDelta(point, translate, scale, originPoint, boxScale) {
		point -= translate;
		point = scalePoint(point, 1 / scale, originPoint);
		if (boxScale !== void 0) point = scalePoint(point, 1 / boxScale, originPoint);
		return point;
	}
	/**
	* Remove a delta from an axis. This is essentially the steps of applyAxisDelta in reverse
	*/
	function removeAxisDelta(axis, translate = 0, scale = 1, origin = .5, boxScale, originAxis = axis, sourceAxis = axis) {
		if (percent.test(translate)) {
			translate = parseFloat(translate);
			translate = mixNumber$1(sourceAxis.min, sourceAxis.max, translate / 100) - sourceAxis.min;
		}
		if (typeof translate !== "number") return;
		let originPoint = mixNumber$1(originAxis.min, originAxis.max, origin);
		if (axis === originAxis) originPoint -= translate;
		axis.min = removePointDelta(axis.min, translate, scale, originPoint, boxScale);
		axis.max = removePointDelta(axis.max, translate, scale, originPoint, boxScale);
	}
	/**
	* Remove a transforms from an axis. This is essentially the steps of applyAxisTransforms in reverse
	* and acts as a bridge between motion values and removeAxisDelta
	*/
	function removeAxisTransforms(axis, transforms, [key, scaleKey, originKey], origin, sourceAxis) {
		removeAxisDelta(axis, transforms[key], transforms[scaleKey], transforms[originKey], transforms.scale, origin, sourceAxis);
	}
	/**
	* The names of the motion values we want to apply as translation, scale and origin.
	*/
	var xKeys = [
		"x",
		"scaleX",
		"originX"
	];
	var yKeys = [
		"y",
		"scaleY",
		"originY"
	];
	/**
	* Remove a transforms from an box. This is essentially the steps of applyAxisBox in reverse
	* and acts as a bridge between motion values and removeAxisDelta
	*/
	function removeBoxTransforms(box, transforms, originBox, sourceBox) {
		removeAxisTransforms(box.x, transforms, xKeys, originBox ? originBox.x : void 0, sourceBox ? sourceBox.x : void 0);
		removeAxisTransforms(box.y, transforms, yKeys, originBox ? originBox.y : void 0, sourceBox ? sourceBox.y : void 0);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/projection/geometry/utils.mjs
	function isAxisDeltaZero(delta) {
		return delta.translate === 0 && delta.scale === 1;
	}
	function isDeltaZero(delta) {
		return isAxisDeltaZero(delta.x) && isAxisDeltaZero(delta.y);
	}
	function axisEquals(a, b) {
		return a.min === b.min && a.max === b.max;
	}
	function boxEquals(a, b) {
		return axisEquals(a.x, b.x) && axisEquals(a.y, b.y);
	}
	function axisEqualsRounded(a, b) {
		return Math.round(a.min) === Math.round(b.min) && Math.round(a.max) === Math.round(b.max);
	}
	function boxEqualsRounded(a, b) {
		return axisEqualsRounded(a.x, b.x) && axisEqualsRounded(a.y, b.y);
	}
	function aspectRatio(box) {
		return calcLength(box.x) / calcLength(box.y);
	}
	function axisDeltaEquals(a, b) {
		return a.translate === b.translate && a.scale === b.scale && a.originPoint === b.originPoint;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/projection/shared/stack.mjs
	var NodeStack = class {
		constructor() {
			this.members = [];
		}
		add(node) {
			addUniqueItem(this.members, node);
			node.scheduleRender();
		}
		remove(node) {
			removeItem(this.members, node);
			if (node === this.prevLead) this.prevLead = void 0;
			if (node === this.lead) {
				const prevLead = this.members[this.members.length - 1];
				if (prevLead) this.promote(prevLead);
			}
		}
		relegate(node) {
			const indexOfNode = this.members.findIndex((member) => node === member);
			if (indexOfNode === 0) return false;
			/**
			* Find the next projection node that is present
			*/
			let prevLead;
			for (let i = indexOfNode; i >= 0; i--) {
				const member = this.members[i];
				if (member.isPresent !== false) {
					prevLead = member;
					break;
				}
			}
			if (prevLead) {
				this.promote(prevLead);
				return true;
			} else return false;
		}
		promote(node, preserveFollowOpacity) {
			const prevLead = this.lead;
			if (node === prevLead) return;
			this.prevLead = prevLead;
			this.lead = node;
			node.show();
			if (prevLead) {
				prevLead.instance && prevLead.scheduleRender();
				node.scheduleRender();
				node.resumeFrom = prevLead;
				if (preserveFollowOpacity) node.resumeFrom.preserveOpacity = true;
				if (prevLead.snapshot) {
					node.snapshot = prevLead.snapshot;
					node.snapshot.latestValues = prevLead.animationValues || prevLead.latestValues;
				}
				if (node.root && node.root.isUpdating) node.isLayoutDirty = true;
				const { crossfade } = node.options;
				if (crossfade === false) prevLead.hide();
			}
		}
		exitAnimationComplete() {
			this.members.forEach((node) => {
				const { options, resumingFrom } = node;
				options.onExitComplete && options.onExitComplete();
				if (resumingFrom) resumingFrom.options.onExitComplete && resumingFrom.options.onExitComplete();
			});
		}
		scheduleRender() {
			this.members.forEach((node) => {
				node.instance && node.scheduleRender(false);
			});
		}
		/**
		* Clear any leads that have been removed this render to prevent them from being
		* used in future animations and to prevent memory leaks
		*/
		removeLeadSnapshot() {
			if (this.lead && this.lead.snapshot) this.lead.snapshot = void 0;
		}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/projection/styles/transform.mjs
	function buildProjectionTransform(delta, treeScale, latestTransform) {
		let transform = "";
		/**
		* The translations we use to calculate are always relative to the viewport coordinate space.
		* But when we apply scales, we also scale the coordinate space of an element and its children.
		* For instance if we have a treeScale (the culmination of all parent scales) of 0.5 and we need
		* to move an element 100 pixels, we actually need to move it 200 in within that scaled space.
		*/
		const xTranslate = delta.x.translate / treeScale.x;
		const yTranslate = delta.y.translate / treeScale.y;
		const zTranslate = (latestTransform === null || latestTransform === void 0 ? void 0 : latestTransform.z) || 0;
		if (xTranslate || yTranslate || zTranslate) transform = `translate3d(${xTranslate}px, ${yTranslate}px, ${zTranslate}px) `;
		/**
		* Apply scale correction for the tree transform.
		* This will apply scale to the screen-orientated axes.
		*/
		if (treeScale.x !== 1 || treeScale.y !== 1) transform += `scale(${1 / treeScale.x}, ${1 / treeScale.y}) `;
		if (latestTransform) {
			const { transformPerspective, rotate, rotateX, rotateY, skewX, skewY } = latestTransform;
			if (transformPerspective) transform = `perspective(${transformPerspective}px) ${transform}`;
			if (rotate) transform += `rotate(${rotate}deg) `;
			if (rotateX) transform += `rotateX(${rotateX}deg) `;
			if (rotateY) transform += `rotateY(${rotateY}deg) `;
			if (skewX) transform += `skewX(${skewX}deg) `;
			if (skewY) transform += `skewY(${skewY}deg) `;
		}
		/**
		* Apply scale to match the size of the element to the size we want it.
		* This will apply scale to the element-orientated axes.
		*/
		const elementScaleX = delta.x.scale * treeScale.x;
		const elementScaleY = delta.y.scale * treeScale.y;
		if (elementScaleX !== 1 || elementScaleY !== 1) transform += `scale(${elementScaleX}, ${elementScaleY})`;
		return transform || "none";
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/projection/node/create-projection-node.mjs
	init_objectSpread2();
	var metrics = {
		type: "projectionFrame",
		totalNodes: 0,
		resolvedTargetDeltas: 0,
		recalculatedProjection: 0
	};
	var isDebug = typeof window !== "undefined" && window.MotionDebug !== void 0;
	var transformAxes = [
		"",
		"X",
		"Y",
		"Z"
	];
	var hiddenVisibility = { visibility: "hidden" };
	/**
	* We use 1000 as the animation target as 0-1000 maps better to pixels than 0-1
	* which has a noticeable difference in spring animations
	*/
	var animationTarget = 1e3;
	var id = 0;
	function resetDistortingTransform(key, visualElement, values, sharedAnimationValues) {
		const { latestValues } = visualElement;
		if (latestValues[key]) {
			values[key] = latestValues[key];
			visualElement.setStaticValue(key, 0);
			if (sharedAnimationValues) sharedAnimationValues[key] = 0;
		}
	}
	function cancelTreeOptimisedTransformAnimations(projectionNode) {
		projectionNode.hasCheckedOptimisedAppear = true;
		if (projectionNode.root === projectionNode) return;
		const { visualElement } = projectionNode.options;
		if (!visualElement) return;
		const appearId = getOptimisedAppearId(visualElement);
		if (window.MotionHasOptimisedAnimation(appearId, "transform")) {
			const { layout, layoutId } = projectionNode.options;
			window.MotionCancelOptimisedAnimation(appearId, "transform", frame, !(layout || layoutId));
		}
		const { parent } = projectionNode;
		if (parent && !parent.hasCheckedOptimisedAppear) cancelTreeOptimisedTransformAnimations(parent);
	}
	function createProjectionNode({ attachResizeListener, defaultParent, measureScroll, checkIsScrollRoot, resetTransform }) {
		return class ProjectionNode {
			constructor(latestValues = {}, parent = defaultParent === null || defaultParent === void 0 ? void 0 : defaultParent()) {
				/**
				* A unique ID generated for every projection node.
				*/
				this.id = id++;
				/**
				* An id that represents a unique session instigated by startUpdate.
				*/
				this.animationId = 0;
				/**
				* A Set containing all this component's children. This is used to iterate
				* through the children.
				*
				* TODO: This could be faster to iterate as a flat array stored on the root node.
				*/
				this.children = /* @__PURE__ */ new Set();
				/**
				* Options for the node. We use this to configure what kind of layout animations
				* we should perform (if any).
				*/
				this.options = {};
				/**
				* We use this to detect when its safe to shut down part of a projection tree.
				* We have to keep projecting children for scale correction and relative projection
				* until all their parents stop performing layout animations.
				*/
				this.isTreeAnimating = false;
				this.isAnimationBlocked = false;
				/**
				* Flag to true if we think this layout has been changed. We can't always know this,
				* currently we set it to true every time a component renders, or if it has a layoutDependency
				* if that has changed between renders. Additionally, components can be grouped by LayoutGroup
				* and if one node is dirtied, they all are.
				*/
				this.isLayoutDirty = false;
				/**
				* Flag to true if we think the projection calculations for this node needs
				* recalculating as a result of an updated transform or layout animation.
				*/
				this.isProjectionDirty = false;
				/**
				* Flag to true if the layout *or* transform has changed. This then gets propagated
				* throughout the projection tree, forcing any element below to recalculate on the next frame.
				*/
				this.isSharedProjectionDirty = false;
				/**
				* Flag transform dirty. This gets propagated throughout the whole tree but is only
				* respected by shared nodes.
				*/
				this.isTransformDirty = false;
				/**
				* Block layout updates for instant layout transitions throughout the tree.
				*/
				this.updateManuallyBlocked = false;
				this.updateBlockedByResize = false;
				/**
				* Set to true between the start of the first `willUpdate` call and the end of the `didUpdate`
				* call.
				*/
				this.isUpdating = false;
				/**
				* If this is an SVG element we currently disable projection transforms
				*/
				this.isSVG = false;
				/**
				* Flag to true (during promotion) if a node doing an instant layout transition needs to reset
				* its projection styles.
				*/
				this.needsReset = false;
				/**
				* Flags whether this node should have its transform reset prior to measuring.
				*/
				this.shouldResetTransform = false;
				/**
				* Store whether this node has been checked for optimised appear animations. As
				* effects fire bottom-up, and we want to look up the tree for appear animations,
				* this makes sure we only check each path once, stopping at nodes that
				* have already been checked.
				*/
				this.hasCheckedOptimisedAppear = false;
				/**
				* An object representing the calculated contextual/accumulated/tree scale.
				* This will be used to scale calculcated projection transforms, as these are
				* calculated in screen-space but need to be scaled for elements to layoutly
				* make it to their calculated destinations.
				*
				* TODO: Lazy-init
				*/
				this.treeScale = {
					x: 1,
					y: 1
				};
				/**
				*
				*/
				this.eventHandlers = /* @__PURE__ */ new Map();
				this.hasTreeAnimated = false;
				this.updateScheduled = false;
				this.scheduleUpdate = () => this.update();
				this.projectionUpdateScheduled = false;
				this.checkUpdateFailed = () => {
					if (this.isUpdating) {
						this.isUpdating = false;
						this.clearAllSnapshots();
					}
				};
				/**
				* This is a multi-step process as shared nodes might be of different depths. Nodes
				* are sorted by depth order, so we need to resolve the entire tree before moving to
				* the next step.
				*/
				this.updateProjection = () => {
					this.projectionUpdateScheduled = false;
					/**
					* Reset debug counts. Manually resetting rather than creating a new
					* object each frame.
					*/
					if (isDebug) metrics.totalNodes = metrics.resolvedTargetDeltas = metrics.recalculatedProjection = 0;
					this.nodes.forEach(propagateDirtyNodes);
					this.nodes.forEach(resolveTargetDelta);
					this.nodes.forEach(calcProjection);
					this.nodes.forEach(cleanDirtyNodes);
					if (isDebug) window.MotionDebug.record(metrics);
				};
				/**
				* Frame calculations
				*/
				this.resolvedRelativeTargetAt = 0;
				this.hasProjected = false;
				this.isVisible = true;
				this.animationProgress = 0;
				/**
				* Shared layout
				*/
				this.sharedNodes = /* @__PURE__ */ new Map();
				this.latestValues = latestValues;
				this.root = parent ? parent.root || parent : this;
				this.path = parent ? [...parent.path, parent] : [];
				this.parent = parent;
				this.depth = parent ? parent.depth + 1 : 0;
				for (let i = 0; i < this.path.length; i++) this.path[i].shouldResetTransform = true;
				if (this.root === this) this.nodes = new FlatTree();
			}
			addEventListener(name, handler) {
				if (!this.eventHandlers.has(name)) this.eventHandlers.set(name, new SubscriptionManager());
				return this.eventHandlers.get(name).add(handler);
			}
			notifyListeners(name, ...args) {
				const subscriptionManager = this.eventHandlers.get(name);
				subscriptionManager && subscriptionManager.notify(...args);
			}
			hasListeners(name) {
				return this.eventHandlers.has(name);
			}
			/**
			* Lifecycles
			*/
			mount(instance, isLayoutDirty = this.root.hasTreeAnimated) {
				if (this.instance) return;
				this.isSVG = isSVGElement(instance);
				this.instance = instance;
				const { layoutId, layout, visualElement } = this.options;
				if (visualElement && !visualElement.current) visualElement.mount(instance);
				this.root.nodes.add(this);
				this.parent && this.parent.children.add(this);
				if (isLayoutDirty && (layout || layoutId)) this.isLayoutDirty = true;
				if (attachResizeListener) {
					let cancelDelay;
					const resizeUnblockUpdate = () => this.root.updateBlockedByResize = false;
					attachResizeListener(instance, () => {
						this.root.updateBlockedByResize = true;
						cancelDelay && cancelDelay();
						cancelDelay = delay(resizeUnblockUpdate, 250);
						if (globalProjectionState.hasAnimatedSinceResize) {
							globalProjectionState.hasAnimatedSinceResize = false;
							this.nodes.forEach(finishAnimation);
						}
					});
				}
				if (layoutId) this.root.registerSharedNode(layoutId, this);
				if (this.options.animate !== false && visualElement && (layoutId || layout)) this.addEventListener("didUpdate", ({ delta, hasLayoutChanged, hasRelativeTargetChanged, layout: newLayout }) => {
					if (this.isTreeAnimationBlocked()) {
						this.target = void 0;
						this.relativeTarget = void 0;
						return;
					}
					const layoutTransition = this.options.transition || visualElement.getDefaultTransition() || defaultLayoutTransition;
					const { onLayoutAnimationStart, onLayoutAnimationComplete } = visualElement.getProps();
					/**
					* The target layout of the element might stay the same,
					* but its position relative to its parent has changed.
					*/
					const targetChanged = !this.targetLayout || !boxEqualsRounded(this.targetLayout, newLayout) || hasRelativeTargetChanged;
					/**
					* If the layout hasn't seemed to have changed, it might be that the
					* element is visually in the same place in the document but its position
					* relative to its parent has indeed changed. So here we check for that.
					*/
					const hasOnlyRelativeTargetChanged = !hasLayoutChanged && hasRelativeTargetChanged;
					if (this.options.layoutRoot || this.resumeFrom && this.resumeFrom.instance || hasOnlyRelativeTargetChanged || hasLayoutChanged && (targetChanged || !this.currentAnimation)) {
						if (this.resumeFrom) {
							this.resumingFrom = this.resumeFrom;
							this.resumingFrom.resumingFrom = void 0;
						}
						this.setAnimationOrigin(delta, hasOnlyRelativeTargetChanged);
						const animationOptions = _objectSpread2(_objectSpread2({}, getValueTransition(layoutTransition, "layout")), {}, {
							onPlay: onLayoutAnimationStart,
							onComplete: onLayoutAnimationComplete
						});
						if (visualElement.shouldReduceMotion || this.options.layoutRoot) {
							animationOptions.delay = 0;
							animationOptions.type = false;
						}
						this.startAnimation(animationOptions);
					} else {
						/**
						* If the layout hasn't changed and we have an animation that hasn't started yet,
						* finish it immediately. Otherwise it will be animating from a location
						* that was probably never commited to screen and look like a jumpy box.
						*/
						if (!hasLayoutChanged) finishAnimation(this);
						if (this.isLead() && this.options.onExitComplete) this.options.onExitComplete();
					}
					this.targetLayout = newLayout;
				});
			}
			unmount() {
				this.options.layoutId && this.willUpdate();
				this.root.nodes.remove(this);
				const stack = this.getStack();
				stack && stack.remove(this);
				this.parent && this.parent.children.delete(this);
				this.instance = void 0;
				cancelFrame(this.updateProjection);
			}
			blockUpdate() {
				this.updateManuallyBlocked = true;
			}
			unblockUpdate() {
				this.updateManuallyBlocked = false;
			}
			isUpdateBlocked() {
				return this.updateManuallyBlocked || this.updateBlockedByResize;
			}
			isTreeAnimationBlocked() {
				return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || false;
			}
			startUpdate() {
				if (this.isUpdateBlocked()) return;
				this.isUpdating = true;
				this.nodes && this.nodes.forEach(resetSkewAndRotation);
				this.animationId++;
			}
			getTransformTemplate() {
				const { visualElement } = this.options;
				return visualElement && visualElement.getProps().transformTemplate;
			}
			willUpdate(shouldNotifyListeners = true) {
				this.root.hasTreeAnimated = true;
				if (this.root.isUpdateBlocked()) {
					this.options.onExitComplete && this.options.onExitComplete();
					return;
				}
				/**
				* If we're running optimised appear animations then these must be
				* cancelled before measuring the DOM. This is so we can measure
				* the true layout of the element rather than the WAAPI animation
				* which will be unaffected by the resetSkewAndRotate step.
				*
				* Note: This is a DOM write. Worst case scenario is this is sandwiched
				* between other snapshot reads which will cause unnecessary style recalculations.
				* This has to happen here though, as we don't yet know which nodes will need
				* snapshots in startUpdate(), but we only want to cancel optimised animations
				* if a layout animation measurement is actually going to be affected by them.
				*/
				if (window.MotionCancelOptimisedAnimation && !this.hasCheckedOptimisedAppear) cancelTreeOptimisedTransformAnimations(this);
				!this.root.isUpdating && this.root.startUpdate();
				if (this.isLayoutDirty) return;
				this.isLayoutDirty = true;
				for (let i = 0; i < this.path.length; i++) {
					const node = this.path[i];
					node.shouldResetTransform = true;
					node.updateScroll("snapshot");
					if (node.options.layoutRoot) node.willUpdate(false);
				}
				const { layoutId, layout } = this.options;
				if (layoutId === void 0 && !layout) return;
				const transformTemplate = this.getTransformTemplate();
				this.prevTransformTemplateValue = transformTemplate ? transformTemplate(this.latestValues, "") : void 0;
				this.updateSnapshot();
				shouldNotifyListeners && this.notifyListeners("willUpdate");
			}
			update() {
				this.updateScheduled = false;
				if (this.isUpdateBlocked()) {
					this.unblockUpdate();
					this.clearAllSnapshots();
					this.nodes.forEach(clearMeasurements);
					return;
				}
				if (!this.isUpdating) this.nodes.forEach(clearIsLayoutDirty);
				this.isUpdating = false;
				/**
				* Write
				*/
				this.nodes.forEach(resetTransformStyle);
				/**
				* Read ==================
				*/
				this.nodes.forEach(updateLayout);
				/**
				* Write
				*/
				this.nodes.forEach(notifyLayoutUpdate);
				this.clearAllSnapshots();
				/**
				* Manually flush any pending updates. Ideally
				* we could leave this to the following requestAnimationFrame but this seems
				* to leave a flash of incorrectly styled content.
				*/
				const now = time.now();
				frameData.delta = clamp(0, 1e3 / 60, now - frameData.timestamp);
				frameData.timestamp = now;
				frameData.isProcessing = true;
				frameSteps.update.process(frameData);
				frameSteps.preRender.process(frameData);
				frameSteps.render.process(frameData);
				frameData.isProcessing = false;
			}
			didUpdate() {
				if (!this.updateScheduled) {
					this.updateScheduled = true;
					microtask.read(this.scheduleUpdate);
				}
			}
			clearAllSnapshots() {
				this.nodes.forEach(clearSnapshot);
				this.sharedNodes.forEach(removeLeadSnapshots);
			}
			scheduleUpdateProjection() {
				if (!this.projectionUpdateScheduled) {
					this.projectionUpdateScheduled = true;
					frame.preRender(this.updateProjection, false, true);
				}
			}
			scheduleCheckAfterUnmount() {
				/**
				* If the unmounting node is in a layoutGroup and did trigger a willUpdate,
				* we manually call didUpdate to give a chance to the siblings to animate.
				* Otherwise, cleanup all snapshots to prevents future nodes from reusing them.
				*/
				frame.postRender(() => {
					if (this.isLayoutDirty) this.root.didUpdate();
					else this.root.checkUpdateFailed();
				});
			}
			/**
			* Update measurements
			*/
			updateSnapshot() {
				if (this.snapshot || !this.instance) return;
				this.snapshot = this.measure();
			}
			updateLayout() {
				if (!this.instance) return;
				this.updateScroll();
				if (!(this.options.alwaysMeasureLayout && this.isLead()) && !this.isLayoutDirty) return;
				/**
				* When a node is mounted, it simply resumes from the prevLead's
				* snapshot instead of taking a new one, but the ancestors scroll
				* might have updated while the prevLead is unmounted. We need to
				* update the scroll again to make sure the layout we measure is
				* up to date.
				*/
				if (this.resumeFrom && !this.resumeFrom.instance) for (let i = 0; i < this.path.length; i++) this.path[i].updateScroll();
				const prevLayout = this.layout;
				this.layout = this.measure(false);
				this.layoutCorrected = createBox();
				this.isLayoutDirty = false;
				this.projectionDelta = void 0;
				this.notifyListeners("measure", this.layout.layoutBox);
				const { visualElement } = this.options;
				visualElement && visualElement.notify("LayoutMeasure", this.layout.layoutBox, prevLayout ? prevLayout.layoutBox : void 0);
			}
			updateScroll(phase = "measure") {
				let needsMeasurement = Boolean(this.options.layoutScroll && this.instance);
				if (this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === phase) needsMeasurement = false;
				if (needsMeasurement) {
					const isRoot = checkIsScrollRoot(this.instance);
					this.scroll = {
						animationId: this.root.animationId,
						phase,
						isRoot,
						offset: measureScroll(this.instance),
						wasRoot: this.scroll ? this.scroll.isRoot : isRoot
					};
				}
			}
			resetTransform() {
				if (!resetTransform) return;
				const isResetRequested = this.isLayoutDirty || this.shouldResetTransform || this.options.alwaysMeasureLayout;
				const hasProjection = this.projectionDelta && !isDeltaZero(this.projectionDelta);
				const transformTemplate = this.getTransformTemplate();
				const transformTemplateValue = transformTemplate ? transformTemplate(this.latestValues, "") : void 0;
				const transformTemplateHasChanged = transformTemplateValue !== this.prevTransformTemplateValue;
				if (isResetRequested && (hasProjection || hasTransform(this.latestValues) || transformTemplateHasChanged)) {
					resetTransform(this.instance, transformTemplateValue);
					this.shouldResetTransform = false;
					this.scheduleRender();
				}
			}
			measure(removeTransform = true) {
				const pageBox = this.measurePageBox();
				let layoutBox = this.removeElementScroll(pageBox);
				/**
				* Measurements taken during the pre-render stage
				* still have transforms applied so we remove them
				* via calculation.
				*/
				if (removeTransform) layoutBox = this.removeTransform(layoutBox);
				roundBox(layoutBox);
				return {
					animationId: this.root.animationId,
					measuredBox: pageBox,
					layoutBox,
					latestValues: {},
					source: this.id
				};
			}
			measurePageBox() {
				var _a;
				const { visualElement } = this.options;
				if (!visualElement) return createBox();
				const box = visualElement.measureViewportBox();
				if (!(((_a = this.scroll) === null || _a === void 0 ? void 0 : _a.wasRoot) || this.path.some(checkNodeWasScrollRoot))) {
					const { scroll } = this.root;
					if (scroll) {
						translateAxis(box.x, scroll.offset.x);
						translateAxis(box.y, scroll.offset.y);
					}
				}
				return box;
			}
			removeElementScroll(box) {
				var _a;
				const boxWithoutScroll = createBox();
				copyBoxInto(boxWithoutScroll, box);
				if ((_a = this.scroll) === null || _a === void 0 ? void 0 : _a.wasRoot) return boxWithoutScroll;
				/**
				* Performance TODO: Keep a cumulative scroll offset down the tree
				* rather than loop back up the path.
				*/
				for (let i = 0; i < this.path.length; i++) {
					const node = this.path[i];
					const { scroll, options } = node;
					if (node !== this.root && scroll && options.layoutScroll) {
						/**
						* If this is a new scroll root, we want to remove all previous scrolls
						* from the viewport box.
						*/
						if (scroll.wasRoot) copyBoxInto(boxWithoutScroll, box);
						translateAxis(boxWithoutScroll.x, scroll.offset.x);
						translateAxis(boxWithoutScroll.y, scroll.offset.y);
					}
				}
				return boxWithoutScroll;
			}
			applyTransform(box, transformOnly = false) {
				const withTransforms = createBox();
				copyBoxInto(withTransforms, box);
				for (let i = 0; i < this.path.length; i++) {
					const node = this.path[i];
					if (!transformOnly && node.options.layoutScroll && node.scroll && node !== node.root) transformBox(withTransforms, {
						x: -node.scroll.offset.x,
						y: -node.scroll.offset.y
					});
					if (!hasTransform(node.latestValues)) continue;
					transformBox(withTransforms, node.latestValues);
				}
				if (hasTransform(this.latestValues)) transformBox(withTransforms, this.latestValues);
				return withTransforms;
			}
			removeTransform(box) {
				const boxWithoutTransform = createBox();
				copyBoxInto(boxWithoutTransform, box);
				for (let i = 0; i < this.path.length; i++) {
					const node = this.path[i];
					if (!node.instance) continue;
					if (!hasTransform(node.latestValues)) continue;
					hasScale(node.latestValues) && node.updateSnapshot();
					const sourceBox = createBox();
					copyBoxInto(sourceBox, node.measurePageBox());
					removeBoxTransforms(boxWithoutTransform, node.latestValues, node.snapshot ? node.snapshot.layoutBox : void 0, sourceBox);
				}
				if (hasTransform(this.latestValues)) removeBoxTransforms(boxWithoutTransform, this.latestValues);
				return boxWithoutTransform;
			}
			setTargetDelta(delta) {
				this.targetDelta = delta;
				this.root.scheduleUpdateProjection();
				this.isProjectionDirty = true;
			}
			setOptions(options) {
				this.options = _objectSpread2(_objectSpread2(_objectSpread2({}, this.options), options), {}, { crossfade: options.crossfade !== void 0 ? options.crossfade : true });
			}
			clearMeasurements() {
				this.scroll = void 0;
				this.layout = void 0;
				this.snapshot = void 0;
				this.prevTransformTemplateValue = void 0;
				this.targetDelta = void 0;
				this.target = void 0;
				this.isLayoutDirty = false;
			}
			forceRelativeParentToResolveTarget() {
				if (!this.relativeParent) return;
				/**
				* If the parent target isn't up-to-date, force it to update.
				* This is an unfortunate de-optimisation as it means any updating relative
				* projection will cause all the relative parents to recalculate back
				* up the tree.
				*/
				if (this.relativeParent.resolvedRelativeTargetAt !== frameData.timestamp) this.relativeParent.resolveTargetDelta(true);
			}
			resolveTargetDelta(forceRecalculation = false) {
				var _a;
				/**
				* Once the dirty status of nodes has been spread through the tree, we also
				* need to check if we have a shared node of a different depth that has itself
				* been dirtied.
				*/
				const lead = this.getLead();
				this.isProjectionDirty || (this.isProjectionDirty = lead.isProjectionDirty);
				this.isTransformDirty || (this.isTransformDirty = lead.isTransformDirty);
				this.isSharedProjectionDirty || (this.isSharedProjectionDirty = lead.isSharedProjectionDirty);
				const isShared = Boolean(this.resumingFrom) || this !== lead;
				if (!(forceRecalculation || isShared && this.isSharedProjectionDirty || this.isProjectionDirty || ((_a = this.parent) === null || _a === void 0 ? void 0 : _a.isProjectionDirty) || this.attemptToResolveRelativeTarget || this.root.updateBlockedByResize)) return;
				const { layout, layoutId } = this.options;
				/**
				* If we have no layout, we can't perform projection, so early return
				*/
				if (!this.layout || !(layout || layoutId)) return;
				this.resolvedRelativeTargetAt = frameData.timestamp;
				/**
				* If we don't have a targetDelta but do have a layout, we can attempt to resolve
				* a relativeParent. This will allow a component to perform scale correction
				* even if no animation has started.
				*/
				if (!this.targetDelta && !this.relativeTarget) {
					const relativeParent = this.getClosestProjectingParent();
					if (relativeParent && relativeParent.layout && this.animationProgress !== 1) {
						this.relativeParent = relativeParent;
						this.forceRelativeParentToResolveTarget();
						this.relativeTarget = createBox();
						this.relativeTargetOrigin = createBox();
						calcRelativePosition(this.relativeTargetOrigin, this.layout.layoutBox, relativeParent.layout.layoutBox);
						copyBoxInto(this.relativeTarget, this.relativeTargetOrigin);
					} else this.relativeParent = this.relativeTarget = void 0;
				}
				/**
				* If we have no relative target or no target delta our target isn't valid
				* for this frame.
				*/
				if (!this.relativeTarget && !this.targetDelta) return;
				/**
				* Lazy-init target data structure
				*/
				if (!this.target) {
					this.target = createBox();
					this.targetWithTransforms = createBox();
				}
				/**
				* If we've got a relative box for this component, resolve it into a target relative to the parent.
				*/
				if (this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target) {
					this.forceRelativeParentToResolveTarget();
					calcRelativeBox(this.target, this.relativeTarget, this.relativeParent.target);
				} else if (this.targetDelta) {
					if (Boolean(this.resumingFrom)) this.target = this.applyTransform(this.layout.layoutBox);
					else copyBoxInto(this.target, this.layout.layoutBox);
					applyBoxDelta(this.target, this.targetDelta);
				} else
 /**
				* If no target, use own layout as target
				*/
				copyBoxInto(this.target, this.layout.layoutBox);
				/**
				* If we've been told to attempt to resolve a relative target, do so.
				*/
				if (this.attemptToResolveRelativeTarget) {
					this.attemptToResolveRelativeTarget = false;
					const relativeParent = this.getClosestProjectingParent();
					if (relativeParent && Boolean(relativeParent.resumingFrom) === Boolean(this.resumingFrom) && !relativeParent.options.layoutScroll && relativeParent.target && this.animationProgress !== 1) {
						this.relativeParent = relativeParent;
						this.forceRelativeParentToResolveTarget();
						this.relativeTarget = createBox();
						this.relativeTargetOrigin = createBox();
						calcRelativePosition(this.relativeTargetOrigin, this.target, relativeParent.target);
						copyBoxInto(this.relativeTarget, this.relativeTargetOrigin);
					} else this.relativeParent = this.relativeTarget = void 0;
				}
				/**
				* Increase debug counter for resolved target deltas
				*/
				if (isDebug) metrics.resolvedTargetDeltas++;
			}
			getClosestProjectingParent() {
				if (!this.parent || hasScale(this.parent.latestValues) || has2DTranslate(this.parent.latestValues)) return;
				if (this.parent.isProjecting()) return this.parent;
				else return this.parent.getClosestProjectingParent();
			}
			isProjecting() {
				return Boolean((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout);
			}
			calcProjection() {
				var _a;
				const lead = this.getLead();
				const isShared = Boolean(this.resumingFrom) || this !== lead;
				let canSkip = true;
				/**
				* If this is a normal layout animation and neither this node nor its nearest projecting
				* is dirty then we can't skip.
				*/
				if (this.isProjectionDirty || ((_a = this.parent) === null || _a === void 0 ? void 0 : _a.isProjectionDirty)) canSkip = false;
				/**
				* If this is a shared layout animation and this node's shared projection is dirty then
				* we can't skip.
				*/
				if (isShared && (this.isSharedProjectionDirty || this.isTransformDirty)) canSkip = false;
				/**
				* If we have resolved the target this frame we must recalculate the
				* projection to ensure it visually represents the internal calculations.
				*/
				if (this.resolvedRelativeTargetAt === frameData.timestamp) canSkip = false;
				if (canSkip) return;
				const { layout, layoutId } = this.options;
				/**
				* If this section of the tree isn't animating we can
				* delete our target sources for the following frame.
				*/
				this.isTreeAnimating = Boolean(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation);
				if (!this.isTreeAnimating) this.targetDelta = this.relativeTarget = void 0;
				if (!this.layout || !(layout || layoutId)) return;
				/**
				* Reset the corrected box with the latest values from box, as we're then going
				* to perform mutative operations on it.
				*/
				copyBoxInto(this.layoutCorrected, this.layout.layoutBox);
				/**
				* Record previous tree scales before updating.
				*/
				const prevTreeScaleX = this.treeScale.x;
				const prevTreeScaleY = this.treeScale.y;
				/**
				* Apply all the parent deltas to this box to produce the corrected box. This
				* is the layout box, as it will appear on screen as a result of the transforms of its parents.
				*/
				applyTreeDeltas(this.layoutCorrected, this.treeScale, this.path, isShared);
				/**
				* If this layer needs to perform scale correction but doesn't have a target,
				* use the layout as the target.
				*/
				if (lead.layout && !lead.target && (this.treeScale.x !== 1 || this.treeScale.y !== 1)) {
					lead.target = lead.layout.layoutBox;
					lead.targetWithTransforms = createBox();
				}
				const { target } = lead;
				if (!target) {
					/**
					* If we don't have a target to project into, but we were previously
					* projecting, we want to remove the stored transform and schedule
					* a render to ensure the elements reflect the removed transform.
					*/
					if (this.prevProjectionDelta) {
						this.createProjectionDeltas();
						this.scheduleRender();
					}
					return;
				}
				if (!this.projectionDelta || !this.prevProjectionDelta) this.createProjectionDeltas();
				else {
					copyAxisDeltaInto(this.prevProjectionDelta.x, this.projectionDelta.x);
					copyAxisDeltaInto(this.prevProjectionDelta.y, this.projectionDelta.y);
				}
				/**
				* Update the delta between the corrected box and the target box before user-set transforms were applied.
				* This will allow us to calculate the corrected borderRadius and boxShadow to compensate
				* for our layout reprojection, but still allow them to be scaled correctly by the user.
				* It might be that to simplify this we may want to accept that user-set scale is also corrected
				* and we wouldn't have to keep and calc both deltas, OR we could support a user setting
				* to allow people to choose whether these styles are corrected based on just the
				* layout reprojection or the final bounding box.
				*/
				calcBoxDelta(this.projectionDelta, this.layoutCorrected, target, this.latestValues);
				if (this.treeScale.x !== prevTreeScaleX || this.treeScale.y !== prevTreeScaleY || !axisDeltaEquals(this.projectionDelta.x, this.prevProjectionDelta.x) || !axisDeltaEquals(this.projectionDelta.y, this.prevProjectionDelta.y)) {
					this.hasProjected = true;
					this.scheduleRender();
					this.notifyListeners("projectionUpdate", target);
				}
				/**
				* Increase debug counter for recalculated projections
				*/
				if (isDebug) metrics.recalculatedProjection++;
			}
			hide() {
				this.isVisible = false;
			}
			show() {
				this.isVisible = true;
			}
			scheduleRender(notifyAll = true) {
				var _a;
				(_a = this.options.visualElement) === null || _a === void 0 || _a.scheduleRender();
				if (notifyAll) {
					const stack = this.getStack();
					stack && stack.scheduleRender();
				}
				if (this.resumingFrom && !this.resumingFrom.instance) this.resumingFrom = void 0;
			}
			createProjectionDeltas() {
				this.prevProjectionDelta = createDelta();
				this.projectionDelta = createDelta();
				this.projectionDeltaWithTransform = createDelta();
			}
			setAnimationOrigin(delta, hasOnlyRelativeTargetChanged = false) {
				const snapshot = this.snapshot;
				const snapshotLatestValues = snapshot ? snapshot.latestValues : {};
				const mixedValues = _objectSpread2({}, this.latestValues);
				const targetDelta = createDelta();
				if (!this.relativeParent || !this.relativeParent.options.layoutRoot) this.relativeTarget = this.relativeTargetOrigin = void 0;
				this.attemptToResolveRelativeTarget = !hasOnlyRelativeTargetChanged;
				const relativeLayout = createBox();
				const isSharedLayoutAnimation = (snapshot ? snapshot.source : void 0) !== (this.layout ? this.layout.source : void 0);
				const stack = this.getStack();
				const isOnlyMember = !stack || stack.members.length <= 1;
				const shouldCrossfadeOpacity = Boolean(isSharedLayoutAnimation && !isOnlyMember && this.options.crossfade === true && !this.path.some(hasOpacityCrossfade));
				this.animationProgress = 0;
				let prevRelativeTarget;
				this.mixTargetDelta = (latest) => {
					const progress = latest / 1e3;
					mixAxisDelta(targetDelta.x, delta.x, progress);
					mixAxisDelta(targetDelta.y, delta.y, progress);
					this.setTargetDelta(targetDelta);
					if (this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout) {
						calcRelativePosition(relativeLayout, this.layout.layoutBox, this.relativeParent.layout.layoutBox);
						mixBox(this.relativeTarget, this.relativeTargetOrigin, relativeLayout, progress);
						/**
						* If this is an unchanged relative target we can consider the
						* projection not dirty.
						*/
						if (prevRelativeTarget && boxEquals(this.relativeTarget, prevRelativeTarget)) this.isProjectionDirty = false;
						if (!prevRelativeTarget) prevRelativeTarget = createBox();
						copyBoxInto(prevRelativeTarget, this.relativeTarget);
					}
					if (isSharedLayoutAnimation) {
						this.animationValues = mixedValues;
						mixValues(mixedValues, snapshotLatestValues, this.latestValues, progress, shouldCrossfadeOpacity, isOnlyMember);
					}
					this.root.scheduleUpdateProjection();
					this.scheduleRender();
					this.animationProgress = progress;
				};
				this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0);
			}
			startAnimation(options) {
				this.notifyListeners("animationStart");
				this.currentAnimation && this.currentAnimation.stop();
				if (this.resumingFrom && this.resumingFrom.currentAnimation) this.resumingFrom.currentAnimation.stop();
				if (this.pendingAnimation) {
					cancelFrame(this.pendingAnimation);
					this.pendingAnimation = void 0;
				}
				/**
				* Start the animation in the next frame to have a frame with progress 0,
				* where the target is the same as when the animation started, so we can
				* calculate the relative positions correctly for instant transitions.
				*/
				this.pendingAnimation = frame.update(() => {
					globalProjectionState.hasAnimatedSinceResize = true;
					this.currentAnimation = animateSingleValue(0, animationTarget, _objectSpread2(_objectSpread2({}, options), {}, {
						onUpdate: (latest) => {
							this.mixTargetDelta(latest);
							options.onUpdate && options.onUpdate(latest);
						},
						onComplete: () => {
							options.onComplete && options.onComplete();
							this.completeAnimation();
						}
					}));
					if (this.resumingFrom) this.resumingFrom.currentAnimation = this.currentAnimation;
					this.pendingAnimation = void 0;
				});
			}
			completeAnimation() {
				if (this.resumingFrom) {
					this.resumingFrom.currentAnimation = void 0;
					this.resumingFrom.preserveOpacity = void 0;
				}
				const stack = this.getStack();
				stack && stack.exitAnimationComplete();
				this.resumingFrom = this.currentAnimation = this.animationValues = void 0;
				this.notifyListeners("animationComplete");
			}
			finishAnimation() {
				if (this.currentAnimation) {
					this.mixTargetDelta && this.mixTargetDelta(animationTarget);
					this.currentAnimation.stop();
				}
				this.completeAnimation();
			}
			applyTransformsToTarget() {
				const lead = this.getLead();
				let { targetWithTransforms, target, layout, latestValues } = lead;
				if (!targetWithTransforms || !target || !layout) return;
				/**
				* If we're only animating position, and this element isn't the lead element,
				* then instead of projecting into the lead box we instead want to calculate
				* a new target that aligns the two boxes but maintains the layout shape.
				*/
				if (this !== lead && this.layout && layout && shouldAnimatePositionOnly(this.options.animationType, this.layout.layoutBox, layout.layoutBox)) {
					target = this.target || createBox();
					const xLength = calcLength(this.layout.layoutBox.x);
					target.x.min = lead.target.x.min;
					target.x.max = target.x.min + xLength;
					const yLength = calcLength(this.layout.layoutBox.y);
					target.y.min = lead.target.y.min;
					target.y.max = target.y.min + yLength;
				}
				copyBoxInto(targetWithTransforms, target);
				/**
				* Apply the latest user-set transforms to the targetBox to produce the targetBoxFinal.
				* This is the final box that we will then project into by calculating a transform delta and
				* applying it to the corrected box.
				*/
				transformBox(targetWithTransforms, latestValues);
				/**
				* Update the delta between the corrected box and the final target box, after
				* user-set transforms are applied to it. This will be used by the renderer to
				* create a transform style that will reproject the element from its layout layout
				* into the desired bounding box.
				*/
				calcBoxDelta(this.projectionDeltaWithTransform, this.layoutCorrected, targetWithTransforms, latestValues);
			}
			registerSharedNode(layoutId, node) {
				if (!this.sharedNodes.has(layoutId)) this.sharedNodes.set(layoutId, new NodeStack());
				this.sharedNodes.get(layoutId).add(node);
				const config = node.options.initialPromotionConfig;
				node.promote({
					transition: config ? config.transition : void 0,
					preserveFollowOpacity: config && config.shouldPreserveFollowOpacity ? config.shouldPreserveFollowOpacity(node) : void 0
				});
			}
			isLead() {
				const stack = this.getStack();
				return stack ? stack.lead === this : true;
			}
			getLead() {
				var _a;
				const { layoutId } = this.options;
				return layoutId ? ((_a = this.getStack()) === null || _a === void 0 ? void 0 : _a.lead) || this : this;
			}
			getPrevLead() {
				var _a;
				const { layoutId } = this.options;
				return layoutId ? (_a = this.getStack()) === null || _a === void 0 ? void 0 : _a.prevLead : void 0;
			}
			getStack() {
				const { layoutId } = this.options;
				if (layoutId) return this.root.sharedNodes.get(layoutId);
			}
			promote({ needsReset, transition, preserveFollowOpacity } = {}) {
				const stack = this.getStack();
				if (stack) stack.promote(this, preserveFollowOpacity);
				if (needsReset) {
					this.projectionDelta = void 0;
					this.needsReset = true;
				}
				if (transition) this.setOptions({ transition });
			}
			relegate() {
				const stack = this.getStack();
				if (stack) return stack.relegate(this);
				else return false;
			}
			resetSkewAndRotation() {
				const { visualElement } = this.options;
				if (!visualElement) return;
				let hasDistortingTransform = false;
				/**
				* An unrolled check for rotation values. Most elements don't have any rotation and
				* skipping the nested loop and new object creation is 50% faster.
				*/
				const { latestValues } = visualElement;
				if (latestValues.z || latestValues.rotate || latestValues.rotateX || latestValues.rotateY || latestValues.rotateZ || latestValues.skewX || latestValues.skewY) hasDistortingTransform = true;
				if (!hasDistortingTransform) return;
				const resetValues = {};
				if (latestValues.z) resetDistortingTransform("z", visualElement, resetValues, this.animationValues);
				for (let i = 0; i < transformAxes.length; i++) {
					resetDistortingTransform(`rotate${transformAxes[i]}`, visualElement, resetValues, this.animationValues);
					resetDistortingTransform(`skew${transformAxes[i]}`, visualElement, resetValues, this.animationValues);
				}
				visualElement.render();
				for (const key in resetValues) {
					visualElement.setStaticValue(key, resetValues[key]);
					if (this.animationValues) this.animationValues[key] = resetValues[key];
				}
				visualElement.scheduleRender();
			}
			getProjectionStyles(styleProp) {
				var _a, _b;
				if (!this.instance || this.isSVG) return void 0;
				if (!this.isVisible) return hiddenVisibility;
				const styles = { visibility: "" };
				const transformTemplate = this.getTransformTemplate();
				if (this.needsReset) {
					this.needsReset = false;
					styles.opacity = "";
					styles.pointerEvents = resolveMotionValue(styleProp === null || styleProp === void 0 ? void 0 : styleProp.pointerEvents) || "";
					styles.transform = transformTemplate ? transformTemplate(this.latestValues, "") : "none";
					return styles;
				}
				const lead = this.getLead();
				if (!this.projectionDelta || !this.layout || !lead.target) {
					const emptyStyles = {};
					if (this.options.layoutId) {
						emptyStyles.opacity = this.latestValues.opacity !== void 0 ? this.latestValues.opacity : 1;
						emptyStyles.pointerEvents = resolveMotionValue(styleProp === null || styleProp === void 0 ? void 0 : styleProp.pointerEvents) || "";
					}
					if (this.hasProjected && !hasTransform(this.latestValues)) {
						emptyStyles.transform = transformTemplate ? transformTemplate({}, "") : "none";
						this.hasProjected = false;
					}
					return emptyStyles;
				}
				const valuesToRender = lead.animationValues || lead.latestValues;
				this.applyTransformsToTarget();
				styles.transform = buildProjectionTransform(this.projectionDeltaWithTransform, this.treeScale, valuesToRender);
				if (transformTemplate) styles.transform = transformTemplate(valuesToRender, styles.transform);
				const { x, y } = this.projectionDelta;
				styles.transformOrigin = `${x.origin * 100}% ${y.origin * 100}% 0`;
				if (lead.animationValues)
 /**
				* If the lead component is animating, assign this either the entering/leaving
				* opacity
				*/
				styles.opacity = lead === this ? (_b = (_a = valuesToRender.opacity) !== null && _a !== void 0 ? _a : this.latestValues.opacity) !== null && _b !== void 0 ? _b : 1 : this.preserveOpacity ? this.latestValues.opacity : valuesToRender.opacityExit;
				else
 /**
				* Or we're not animating at all, set the lead component to its layout
				* opacity and other components to hidden.
				*/
				styles.opacity = lead === this ? valuesToRender.opacity !== void 0 ? valuesToRender.opacity : "" : valuesToRender.opacityExit !== void 0 ? valuesToRender.opacityExit : 0;
				/**
				* Apply scale correction
				*/
				for (const key in scaleCorrectors) {
					if (valuesToRender[key] === void 0) continue;
					const { correct, applyTo } = scaleCorrectors[key];
					/**
					* Only apply scale correction to the value if we have an
					* active projection transform. Otherwise these values become
					* vulnerable to distortion if the element changes size without
					* a corresponding layout animation.
					*/
					const corrected = styles.transform === "none" ? valuesToRender[key] : correct(valuesToRender[key], lead);
					if (applyTo) {
						const num = applyTo.length;
						for (let i = 0; i < num; i++) styles[applyTo[i]] = corrected;
					} else styles[key] = corrected;
				}
				/**
				* Disable pointer events on follow components. This is to ensure
				* that if a follow component covers a lead component it doesn't block
				* pointer events on the lead.
				*/
				if (this.options.layoutId) styles.pointerEvents = lead === this ? resolveMotionValue(styleProp === null || styleProp === void 0 ? void 0 : styleProp.pointerEvents) || "" : "none";
				return styles;
			}
			clearSnapshot() {
				this.resumeFrom = this.snapshot = void 0;
			}
			resetTree() {
				this.root.nodes.forEach((node) => {
					var _a;
					return (_a = node.currentAnimation) === null || _a === void 0 ? void 0 : _a.stop();
				});
				this.root.nodes.forEach(clearMeasurements);
				this.root.sharedNodes.clear();
			}
		};
	}
	function updateLayout(node) {
		node.updateLayout();
	}
	function notifyLayoutUpdate(node) {
		var _a;
		const snapshot = ((_a = node.resumeFrom) === null || _a === void 0 ? void 0 : _a.snapshot) || node.snapshot;
		if (node.isLead() && node.layout && snapshot && node.hasListeners("didUpdate")) {
			const { layoutBox: layout, measuredBox: measuredLayout } = node.layout;
			const { animationType } = node.options;
			const isShared = snapshot.source !== node.layout.source;
			if (animationType === "size") eachAxis((axis) => {
				const axisSnapshot = isShared ? snapshot.measuredBox[axis] : snapshot.layoutBox[axis];
				const length = calcLength(axisSnapshot);
				axisSnapshot.min = layout[axis].min;
				axisSnapshot.max = axisSnapshot.min + length;
			});
			else if (shouldAnimatePositionOnly(animationType, snapshot.layoutBox, layout)) eachAxis((axis) => {
				const axisSnapshot = isShared ? snapshot.measuredBox[axis] : snapshot.layoutBox[axis];
				const length = calcLength(layout[axis]);
				axisSnapshot.max = axisSnapshot.min + length;
				/**
				* Ensure relative target gets resized and rerendererd
				*/
				if (node.relativeTarget && !node.currentAnimation) {
					node.isProjectionDirty = true;
					node.relativeTarget[axis].max = node.relativeTarget[axis].min + length;
				}
			});
			const layoutDelta = createDelta();
			calcBoxDelta(layoutDelta, layout, snapshot.layoutBox);
			const visualDelta = createDelta();
			if (isShared) calcBoxDelta(visualDelta, node.applyTransform(measuredLayout, true), snapshot.measuredBox);
			else calcBoxDelta(visualDelta, layout, snapshot.layoutBox);
			const hasLayoutChanged = !isDeltaZero(layoutDelta);
			let hasRelativeTargetChanged = false;
			if (!node.resumeFrom) {
				const relativeParent = node.getClosestProjectingParent();
				/**
				* If the relativeParent is itself resuming from a different element then
				* the relative snapshot is not relavent
				*/
				if (relativeParent && !relativeParent.resumeFrom) {
					const { snapshot: parentSnapshot, layout: parentLayout } = relativeParent;
					if (parentSnapshot && parentLayout) {
						const relativeSnapshot = createBox();
						calcRelativePosition(relativeSnapshot, snapshot.layoutBox, parentSnapshot.layoutBox);
						const relativeLayout = createBox();
						calcRelativePosition(relativeLayout, layout, parentLayout.layoutBox);
						if (!boxEqualsRounded(relativeSnapshot, relativeLayout)) hasRelativeTargetChanged = true;
						if (relativeParent.options.layoutRoot) {
							node.relativeTarget = relativeLayout;
							node.relativeTargetOrigin = relativeSnapshot;
							node.relativeParent = relativeParent;
						}
					}
				}
			}
			node.notifyListeners("didUpdate", {
				layout,
				snapshot,
				delta: visualDelta,
				layoutDelta,
				hasLayoutChanged,
				hasRelativeTargetChanged
			});
		} else if (node.isLead()) {
			const { onExitComplete } = node.options;
			onExitComplete && onExitComplete();
		}
		/**
		* Clearing transition
		* TODO: Investigate why this transition is being passed in as {type: false } from Framer
		* and why we need it at all
		*/
		node.options.transition = void 0;
	}
	function propagateDirtyNodes(node) {
		/**
		* Increase debug counter for nodes encountered this frame
		*/
		if (isDebug) metrics.totalNodes++;
		if (!node.parent) return;
		/**
		* If this node isn't projecting, propagate isProjectionDirty. It will have
		* no performance impact but it will allow the next child that *is* projecting
		* but *isn't* dirty to just check its parent to see if *any* ancestor needs
		* correcting.
		*/
		if (!node.isProjecting()) node.isProjectionDirty = node.parent.isProjectionDirty;
		/**
		* Propagate isSharedProjectionDirty and isTransformDirty
		* throughout the whole tree. A future revision can take another look at
		* this but for safety we still recalcualte shared nodes.
		*/
		node.isSharedProjectionDirty || (node.isSharedProjectionDirty = Boolean(node.isProjectionDirty || node.parent.isProjectionDirty || node.parent.isSharedProjectionDirty));
		node.isTransformDirty || (node.isTransformDirty = node.parent.isTransformDirty);
	}
	function cleanDirtyNodes(node) {
		node.isProjectionDirty = node.isSharedProjectionDirty = node.isTransformDirty = false;
	}
	function clearSnapshot(node) {
		node.clearSnapshot();
	}
	function clearMeasurements(node) {
		node.clearMeasurements();
	}
	function clearIsLayoutDirty(node) {
		node.isLayoutDirty = false;
	}
	function resetTransformStyle(node) {
		const { visualElement } = node.options;
		if (visualElement && visualElement.getProps().onBeforeLayoutMeasure) visualElement.notify("BeforeLayoutMeasure");
		node.resetTransform();
	}
	function finishAnimation(node) {
		node.finishAnimation();
		node.targetDelta = node.relativeTarget = node.target = void 0;
		node.isProjectionDirty = true;
	}
	function resolveTargetDelta(node) {
		node.resolveTargetDelta();
	}
	function calcProjection(node) {
		node.calcProjection();
	}
	function resetSkewAndRotation(node) {
		node.resetSkewAndRotation();
	}
	function removeLeadSnapshots(stack) {
		stack.removeLeadSnapshot();
	}
	function mixAxisDelta(output, delta, p) {
		output.translate = mixNumber$1(delta.translate, 0, p);
		output.scale = mixNumber$1(delta.scale, 1, p);
		output.origin = delta.origin;
		output.originPoint = delta.originPoint;
	}
	function mixAxis(output, from, to, p) {
		output.min = mixNumber$1(from.min, to.min, p);
		output.max = mixNumber$1(from.max, to.max, p);
	}
	function mixBox(output, from, to, p) {
		mixAxis(output.x, from.x, to.x, p);
		mixAxis(output.y, from.y, to.y, p);
	}
	function hasOpacityCrossfade(node) {
		return node.animationValues && node.animationValues.opacityExit !== void 0;
	}
	var defaultLayoutTransition = {
		duration: .45,
		ease: [
			.4,
			0,
			.1,
			1
		]
	};
	var userAgentContains = (string) => typeof navigator !== "undefined" && navigator.userAgent && navigator.userAgent.toLowerCase().includes(string);
	/**
	* Measured bounding boxes must be rounded in Safari and
	* left untouched in Chrome, otherwise non-integer layouts within scaled-up elements
	* can appear to jump.
	*/
	var roundPoint = userAgentContains("applewebkit/") && !userAgentContains("chrome/") ? Math.round : noop;
	function roundAxis(axis) {
		axis.min = roundPoint(axis.min);
		axis.max = roundPoint(axis.max);
	}
	function roundBox(box) {
		roundAxis(box.x);
		roundAxis(box.y);
	}
	function shouldAnimatePositionOnly(animationType, snapshot, layout) {
		return animationType === "position" || animationType === "preserve-aspect" && !isNear(aspectRatio(snapshot), aspectRatio(layout), .2);
	}
	function checkNodeWasScrollRoot(node) {
		var _a;
		return node !== node.root && ((_a = node.scroll) === null || _a === void 0 ? void 0 : _a.wasRoot);
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/projection/node/DocumentProjectionNode.mjs
	var DocumentProjectionNode = createProjectionNode({
		attachResizeListener: (ref, notify) => addDomEvent(ref, "resize", notify),
		measureScroll: () => ({
			x: document.documentElement.scrollLeft || document.body.scrollLeft,
			y: document.documentElement.scrollTop || document.body.scrollTop
		}),
		checkIsScrollRoot: () => true
	});
	//#endregion
	//#region node_modules/framer-motion/dist/es/projection/node/HTMLProjectionNode.mjs
	var rootProjectionNode = { current: void 0 };
	var HTMLProjectionNode = createProjectionNode({
		measureScroll: (instance) => ({
			x: instance.scrollLeft,
			y: instance.scrollTop
		}),
		defaultParent: () => {
			if (!rootProjectionNode.current) {
				const documentNode = new DocumentProjectionNode({});
				documentNode.mount(window);
				documentNode.setOptions({ layoutScroll: true });
				rootProjectionNode.current = documentNode;
			}
			return rootProjectionNode.current;
		},
		resetTransform: (instance, value) => {
			instance.style.transform = value !== void 0 ? value : "none";
		},
		checkIsScrollRoot: (instance) => Boolean(window.getComputedStyle(instance).position === "fixed")
	});
	//#endregion
	//#region node_modules/framer-motion/dist/es/motion/features/drag.mjs
	var drag = {
		pan: { Feature: PanGesture },
		drag: {
			Feature: DragGesture,
			ProjectionNode: HTMLProjectionNode,
			MeasureLayout
		}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/gestures/hover.mjs
	function handleHoverEvent(node, event, lifecycle) {
		const { props } = node;
		if (node.animationState && props.whileHover) node.animationState.setActive("whileHover", lifecycle === "Start");
		const callback = props["onHover" + lifecycle];
		if (callback) frame.postRender(() => callback(event, extractEventInfo(event)));
	}
	var HoverGesture = class extends Feature {
		mount() {
			const { current } = this.node;
			if (!current) return;
			this.unmount = hover(current, (startEvent) => {
				handleHoverEvent(this.node, startEvent, "Start");
				return (endEvent) => handleHoverEvent(this.node, endEvent, "End");
			});
		}
		unmount() {}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/gestures/focus.mjs
	var FocusGesture = class extends Feature {
		constructor() {
			super(...arguments);
			this.isActive = false;
		}
		onFocus() {
			let isFocusVisible = false;
			/**
			* If this element doesn't match focus-visible then don't
			* apply whileHover. But, if matches throws that focus-visible
			* is not a valid selector then in that browser outline styles will be applied
			* to the element by default and we want to match that behaviour with whileFocus.
			*/
			try {
				isFocusVisible = this.node.current.matches(":focus-visible");
			} catch (e) {
				isFocusVisible = true;
			}
			if (!isFocusVisible || !this.node.animationState) return;
			this.node.animationState.setActive("whileFocus", true);
			this.isActive = true;
		}
		onBlur() {
			if (!this.isActive || !this.node.animationState) return;
			this.node.animationState.setActive("whileFocus", false);
			this.isActive = false;
		}
		mount() {
			this.unmount = pipe(addDomEvent(this.node.current, "focus", () => this.onFocus()), addDomEvent(this.node.current, "blur", () => this.onBlur()));
		}
		unmount() {}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/gestures/press.mjs
	function handlePressEvent(node, event, lifecycle) {
		const { props } = node;
		if (node.animationState && props.whileTap) node.animationState.setActive("whileTap", lifecycle === "Start");
		const callback = props["onTap" + (lifecycle === "End" ? "" : lifecycle)];
		if (callback) frame.postRender(() => callback(event, extractEventInfo(event)));
	}
	var PressGesture = class extends Feature {
		mount() {
			const { current } = this.node;
			if (!current) return;
			this.unmount = press(current, (startEvent) => {
				handlePressEvent(this.node, startEvent, "Start");
				return (endEvent, { success }) => handlePressEvent(this.node, endEvent, success ? "End" : "Cancel");
			}, { useGlobalTarget: this.node.props.globalTapTarget });
		}
		unmount() {}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/motion/features/viewport/observers.mjs
	init_objectWithoutProperties();
	init_objectSpread2();
	var _excluded$1 = ["root"];
	/**
	* Map an IntersectionHandler callback to an element. We only ever make one handler for one
	* element, so even though these handlers might all be triggered by different
	* observers, we can keep them in the same map.
	*/
	var observerCallbacks = /* @__PURE__ */ new WeakMap();
	/**
	* Multiple observers can be created for multiple element/document roots. Each with
	* different settings. So here we store dictionaries of observers to each root,
	* using serialised settings (threshold/margin) as lookup keys.
	*/
	var observers = /* @__PURE__ */ new WeakMap();
	var fireObserverCallback = (entry) => {
		const callback = observerCallbacks.get(entry.target);
		callback && callback(entry);
	};
	var fireAllObserverCallbacks = (entries) => {
		entries.forEach(fireObserverCallback);
	};
	function initIntersectionObserver(_ref) {
		let { root } = _ref, options = _objectWithoutProperties(_ref, _excluded$1);
		const lookupRoot = root || document;
		/**
		* If we don't have an observer lookup map for this root, create one.
		*/
		if (!observers.has(lookupRoot)) observers.set(lookupRoot, {});
		const rootObservers = observers.get(lookupRoot);
		const key = JSON.stringify(options);
		/**
		* If we don't have an observer for this combination of root and settings,
		* create one.
		*/
		if (!rootObservers[key]) rootObservers[key] = new IntersectionObserver(fireAllObserverCallbacks, _objectSpread2({ root }, options));
		return rootObservers[key];
	}
	function observeIntersection(element, options, callback) {
		const rootInteresectionObserver = initIntersectionObserver(options);
		observerCallbacks.set(element, callback);
		rootInteresectionObserver.observe(element);
		return () => {
			observerCallbacks.delete(element);
			rootInteresectionObserver.unobserve(element);
		};
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/motion/features/viewport/index.mjs
	var thresholdNames = {
		some: 0,
		all: 1
	};
	var InViewFeature = class extends Feature {
		constructor() {
			super(...arguments);
			this.hasEnteredView = false;
			this.isInView = false;
		}
		startObserver() {
			this.unmount();
			const { viewport = {} } = this.node.getProps();
			const { root, margin: rootMargin, amount = "some", once } = viewport;
			const options = {
				root: root ? root.current : void 0,
				rootMargin,
				threshold: typeof amount === "number" ? amount : thresholdNames[amount]
			};
			const onIntersectionUpdate = (entry) => {
				const { isIntersecting } = entry;
				/**
				* If there's been no change in the viewport state, early return.
				*/
				if (this.isInView === isIntersecting) return;
				this.isInView = isIntersecting;
				/**
				* Handle hasEnteredView. If this is only meant to run once, and
				* element isn't visible, early return. Otherwise set hasEnteredView to true.
				*/
				if (once && !isIntersecting && this.hasEnteredView) return;
				else if (isIntersecting) this.hasEnteredView = true;
				if (this.node.animationState) this.node.animationState.setActive("whileInView", isIntersecting);
				/**
				* Use the latest committed props rather than the ones in scope
				* when this observer is created
				*/
				const { onViewportEnter, onViewportLeave } = this.node.getProps();
				const callback = isIntersecting ? onViewportEnter : onViewportLeave;
				callback && callback(entry);
			};
			return observeIntersection(this.node.current, options, onIntersectionUpdate);
		}
		mount() {
			this.startObserver();
		}
		update() {
			if (typeof IntersectionObserver === "undefined") return;
			const { props, prevProps } = this.node;
			if ([
				"amount",
				"margin",
				"root"
			].some(hasViewportOptionChanged(props, prevProps))) this.startObserver();
		}
		unmount() {}
	};
	function hasViewportOptionChanged({ viewport = {} }, { viewport: prevViewport = {} } = {}) {
		return (name) => viewport[name] !== prevViewport[name];
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/motion/features/gestures.mjs
	var gestureAnimations = {
		inView: { Feature: InViewFeature },
		tap: { Feature: PressGesture },
		focus: { Feature: FocusGesture },
		hover: { Feature: HoverGesture }
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/motion/features/layout.mjs
	var layout = { layout: {
		ProjectionNode: HTMLProjectionNode,
		MeasureLayout
	} };
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/reduced-motion/state.mjs
	var prefersReducedMotion = { current: null };
	var hasReducedMotionListener = { current: false };
	//#endregion
	//#region node_modules/framer-motion/dist/es/utils/reduced-motion/index.mjs
	function initPrefersReducedMotion() {
		hasReducedMotionListener.current = true;
		if (!isBrowser) return;
		if (window.matchMedia) {
			const motionMediaQuery = window.matchMedia("(prefers-reduced-motion)");
			const setReducedMotionPreferences = () => prefersReducedMotion.current = motionMediaQuery.matches;
			motionMediaQuery.addListener(setReducedMotionPreferences);
			setReducedMotionPreferences();
		} else prefersReducedMotion.current = false;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/dom/value-types/find.mjs
	/**
	* A list of all ValueTypes
	*/
	var valueTypes = [
		...dimensionValueTypes,
		color,
		complex
	];
	/**
	* Tests a value against the list of ValueTypes
	*/
	var findValueType = (v) => valueTypes.find(testValueType(v));
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/store.mjs
	var visualElementStore = /* @__PURE__ */ new WeakMap();
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/utils/motion-values.mjs
	function updateMotionValuesFromProps(element, next, prev) {
		for (const key in next) {
			const nextValue = next[key];
			const prevValue = prev[key];
			if (isMotionValue(nextValue))
 /**
			* If this is a motion value found in props or style, we want to add it
			* to our visual element's motion value map.
			*/
			element.addValue(key, nextValue);
			else if (isMotionValue(prevValue))
 /**
			* If we're swapping from a motion value to a static value,
			* create a new motion value from that
			*/
			element.addValue(key, motionValue(nextValue, { owner: element }));
			else if (prevValue !== nextValue) {
				/**
				* If this is a flat value that has changed, update the motion value
				* or create one if it doesn't exist. We only want to do this if we're
				* not handling the value with our animation state.
				*/
				if (element.hasValue(key)) {
					const existingValue = element.getValue(key);
					if (existingValue.liveStyle === true) existingValue.jump(nextValue);
					else if (!existingValue.hasAnimated) existingValue.set(nextValue);
				} else {
					const latestValue = element.getStaticValue(key);
					element.addValue(key, motionValue(latestValue !== void 0 ? latestValue : nextValue, { owner: element }));
				}
			}
		}
		for (const key in prev) if (next[key] === void 0) element.removeValue(key);
		return next;
	}
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/VisualElement.mjs
	init_objectSpread2();
	init_objectWithoutProperties();
	var _excluded = ["willChange"];
	var propEventHandlers = [
		"AnimationStart",
		"AnimationComplete",
		"Update",
		"BeforeLayoutMeasure",
		"LayoutMeasure",
		"LayoutAnimationStart",
		"LayoutAnimationComplete"
	];
	/**
	* A VisualElement is an imperative abstraction around UI elements such as
	* HTMLElement, SVGElement, Three.Object3D etc.
	*/
	var VisualElement = class {
		/**
		* This method takes React props and returns found MotionValues. For example, HTML
		* MotionValues will be found within the style prop, whereas for Three.js within attribute arrays.
		*
		* This isn't an abstract method as it needs calling in the constructor, but it is
		* intended to be one.
		*/
		scrapeMotionValuesFromProps(_props, _prevProps, _visualElement) {
			return {};
		}
		constructor({ parent, props, presenceContext, reducedMotionConfig, blockInitialAnimation, visualState }, options = {}) {
			/**
			* A reference to the current underlying Instance, e.g. a HTMLElement
			* or Three.Mesh etc.
			*/
			this.current = null;
			/**
			* A set containing references to this VisualElement's children.
			*/
			this.children = /* @__PURE__ */ new Set();
			/**
			* Determine what role this visual element should take in the variant tree.
			*/
			this.isVariantNode = false;
			this.isControllingVariants = false;
			/**
			* Decides whether this VisualElement should animate in reduced motion
			* mode.
			*
			* TODO: This is currently set on every individual VisualElement but feels
			* like it could be set globally.
			*/
			this.shouldReduceMotion = null;
			/**
			* A map of all motion values attached to this visual element. Motion
			* values are source of truth for any given animated value. A motion
			* value might be provided externally by the component via props.
			*/
			this.values = /* @__PURE__ */ new Map();
			this.KeyframeResolver = KeyframeResolver;
			/**
			* Cleanup functions for active features (hover/tap/exit etc)
			*/
			this.features = {};
			/**
			* A map of every subscription that binds the provided or generated
			* motion values onChange listeners to this visual element.
			*/
			this.valueSubscriptions = /* @__PURE__ */ new Map();
			/**
			* A reference to the previously-provided motion values as returned
			* from scrapeMotionValuesFromProps. We use the keys in here to determine
			* if any motion values need to be removed after props are updated.
			*/
			this.prevMotionValues = {};
			/**
			* An object containing a SubscriptionManager for each active event.
			*/
			this.events = {};
			/**
			* An object containing an unsubscribe function for each prop event subscription.
			* For example, every "Update" event can have multiple subscribers via
			* VisualElement.on(), but only one of those can be defined via the onUpdate prop.
			*/
			this.propEventSubscriptions = {};
			this.notifyUpdate = () => this.notify("Update", this.latestValues);
			this.render = () => {
				if (!this.current) return;
				this.triggerBuild();
				this.renderInstance(this.current, this.renderState, this.props.style, this.projection);
			};
			this.renderScheduledAt = 0;
			this.scheduleRender = () => {
				const now = time.now();
				if (this.renderScheduledAt < now) {
					this.renderScheduledAt = now;
					frame.render(this.render, false, true);
				}
			};
			const { latestValues, renderState, onUpdate } = visualState;
			this.onUpdate = onUpdate;
			this.latestValues = latestValues;
			this.baseTarget = _objectSpread2({}, latestValues);
			this.initialValues = props.initial ? _objectSpread2({}, latestValues) : {};
			this.renderState = renderState;
			this.parent = parent;
			this.props = props;
			this.presenceContext = presenceContext;
			this.depth = parent ? parent.depth + 1 : 0;
			this.reducedMotionConfig = reducedMotionConfig;
			this.options = options;
			this.blockInitialAnimation = Boolean(blockInitialAnimation);
			this.isControllingVariants = isControllingVariants(props);
			this.isVariantNode = isVariantNode(props);
			if (this.isVariantNode) this.variantChildren = /* @__PURE__ */ new Set();
			this.manuallyAnimateOnMount = Boolean(parent && parent.current);
			/**
			* Any motion values that are provided to the element when created
			* aren't yet bound to the element, as this would technically be impure.
			* However, we iterate through the motion values and set them to the
			* initial values for this component.
			*
			* TODO: This is impure and we should look at changing this to run on mount.
			* Doing so will break some tests but this isn't necessarily a breaking change,
			* more a reflection of the test.
			*/
			const _this$scrapeMotionVal = this.scrapeMotionValuesFromProps(props, {}, this), { willChange } = _this$scrapeMotionVal, initialMotionValues = _objectWithoutProperties(_this$scrapeMotionVal, _excluded);
			for (const key in initialMotionValues) {
				const value = initialMotionValues[key];
				if (latestValues[key] !== void 0 && isMotionValue(value)) value.set(latestValues[key], false);
			}
		}
		mount(instance) {
			this.current = instance;
			visualElementStore.set(instance, this);
			if (this.projection && !this.projection.instance) this.projection.mount(instance);
			if (this.parent && this.isVariantNode && !this.isControllingVariants) this.removeFromVariantTree = this.parent.addVariantChild(this);
			this.values.forEach((value, key) => this.bindToMotionValue(key, value));
			if (!hasReducedMotionListener.current) initPrefersReducedMotion();
			this.shouldReduceMotion = this.reducedMotionConfig === "never" ? false : this.reducedMotionConfig === "always" ? true : prefersReducedMotion.current;
			if (this.parent) this.parent.children.add(this);
			this.update(this.props, this.presenceContext);
		}
		unmount() {
			visualElementStore.delete(this.current);
			this.projection && this.projection.unmount();
			cancelFrame(this.notifyUpdate);
			cancelFrame(this.render);
			this.valueSubscriptions.forEach((remove) => remove());
			this.valueSubscriptions.clear();
			this.removeFromVariantTree && this.removeFromVariantTree();
			this.parent && this.parent.children.delete(this);
			for (const key in this.events) this.events[key].clear();
			for (const key in this.features) {
				const feature = this.features[key];
				if (feature) {
					feature.unmount();
					feature.isMounted = false;
				}
			}
			this.current = null;
		}
		bindToMotionValue(key, value) {
			if (this.valueSubscriptions.has(key)) this.valueSubscriptions.get(key)();
			const valueIsTransform = transformProps.has(key);
			const removeOnChange = value.on("change", (latestValue) => {
				this.latestValues[key] = latestValue;
				this.props.onUpdate && frame.preRender(this.notifyUpdate);
				if (valueIsTransform && this.projection) this.projection.isTransformDirty = true;
			});
			const removeOnRenderRequest = value.on("renderRequest", this.scheduleRender);
			let removeSyncCheck;
			if (window.MotionCheckAppearSync) removeSyncCheck = window.MotionCheckAppearSync(this, key, value);
			this.valueSubscriptions.set(key, () => {
				removeOnChange();
				removeOnRenderRequest();
				if (removeSyncCheck) removeSyncCheck();
				if (value.owner) value.stop();
			});
		}
		sortNodePosition(other) {
			/**
			* If these nodes aren't even of the same type we can't compare their depth.
			*/
			if (!this.current || !this.sortInstanceNodePosition || this.type !== other.type) return 0;
			return this.sortInstanceNodePosition(this.current, other.current);
		}
		updateFeatures() {
			let key = "animation";
			for (key in featureDefinitions) {
				const featureDefinition = featureDefinitions[key];
				if (!featureDefinition) continue;
				const { isEnabled, Feature: FeatureConstructor } = featureDefinition;
				/**
				* If this feature is enabled but not active, make a new instance.
				*/
				if (!this.features[key] && FeatureConstructor && isEnabled(this.props)) this.features[key] = new FeatureConstructor(this);
				/**
				* If we have a feature, mount or update it.
				*/
				if (this.features[key]) {
					const feature = this.features[key];
					if (feature.isMounted) feature.update();
					else {
						feature.mount();
						feature.isMounted = true;
					}
				}
			}
		}
		triggerBuild() {
			this.build(this.renderState, this.latestValues, this.props);
		}
		/**
		* Measure the current viewport box with or without transforms.
		* Only measures axis-aligned boxes, rotate and skew must be manually
		* removed with a re-render to work.
		*/
		measureViewportBox() {
			return this.current ? this.measureInstanceViewportBox(this.current, this.props) : createBox();
		}
		getStaticValue(key) {
			return this.latestValues[key];
		}
		setStaticValue(key, value) {
			this.latestValues[key] = value;
		}
		/**
		* Update the provided props. Ensure any newly-added motion values are
		* added to our map, old ones removed, and listeners updated.
		*/
		update(props, presenceContext) {
			if (props.transformTemplate || this.props.transformTemplate) this.scheduleRender();
			this.prevProps = this.props;
			this.props = props;
			this.prevPresenceContext = this.presenceContext;
			this.presenceContext = presenceContext;
			/**
			* Update prop event handlers ie onAnimationStart, onAnimationComplete
			*/
			for (let i = 0; i < propEventHandlers.length; i++) {
				const key = propEventHandlers[i];
				if (this.propEventSubscriptions[key]) {
					this.propEventSubscriptions[key]();
					delete this.propEventSubscriptions[key];
				}
				const listener = props["on" + key];
				if (listener) this.propEventSubscriptions[key] = this.on(key, listener);
			}
			this.prevMotionValues = updateMotionValuesFromProps(this, this.scrapeMotionValuesFromProps(props, this.prevProps, this), this.prevMotionValues);
			if (this.handleChildMotionValue) this.handleChildMotionValue();
			this.onUpdate && this.onUpdate(this);
		}
		getProps() {
			return this.props;
		}
		/**
		* Returns the variant definition with a given name.
		*/
		getVariant(name) {
			return this.props.variants ? this.props.variants[name] : void 0;
		}
		/**
		* Returns the defined default transition on this component.
		*/
		getDefaultTransition() {
			return this.props.transition;
		}
		getTransformPagePoint() {
			return this.props.transformPagePoint;
		}
		getClosestVariantNode() {
			return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0;
		}
		/**
		* Add a child visual element to our set of children.
		*/
		addVariantChild(child) {
			const closestVariantNode = this.getClosestVariantNode();
			if (closestVariantNode) {
				closestVariantNode.variantChildren && closestVariantNode.variantChildren.add(child);
				return () => closestVariantNode.variantChildren.delete(child);
			}
		}
		/**
		* Add a motion value and bind it to this visual element.
		*/
		addValue(key, value) {
			const existingValue = this.values.get(key);
			if (value !== existingValue) {
				if (existingValue) this.removeValue(key);
				this.bindToMotionValue(key, value);
				this.values.set(key, value);
				this.latestValues[key] = value.get();
			}
		}
		/**
		* Remove a motion value and unbind any active subscriptions.
		*/
		removeValue(key) {
			this.values.delete(key);
			const unsubscribe = this.valueSubscriptions.get(key);
			if (unsubscribe) {
				unsubscribe();
				this.valueSubscriptions.delete(key);
			}
			delete this.latestValues[key];
			this.removeValueFromRenderState(key, this.renderState);
		}
		/**
		* Check whether we have a motion value for this key
		*/
		hasValue(key) {
			return this.values.has(key);
		}
		getValue(key, defaultValue) {
			if (this.props.values && this.props.values[key]) return this.props.values[key];
			let value = this.values.get(key);
			if (value === void 0 && defaultValue !== void 0) {
				value = motionValue(defaultValue === null ? void 0 : defaultValue, { owner: this });
				this.addValue(key, value);
			}
			return value;
		}
		/**
		* If we're trying to animate to a previously unencountered value,
		* we need to check for it in our state and as a last resort read it
		* directly from the instance (which might have performance implications).
		*/
		readValue(key, target) {
			var _a;
			let value = this.latestValues[key] !== void 0 || !this.current ? this.latestValues[key] : (_a = this.getBaseTargetFromProps(this.props, key)) !== null && _a !== void 0 ? _a : this.readValueFromInstance(this.current, key, this.options);
			if (value !== void 0 && value !== null) {
				if (typeof value === "string" && (isNumericalString(value) || isZeroValueString(value))) value = parseFloat(value);
				else if (!findValueType(value) && complex.test(target)) value = getAnimatableNone(key, target);
				this.setBaseTarget(key, isMotionValue(value) ? value.get() : value);
			}
			return isMotionValue(value) ? value.get() : value;
		}
		/**
		* Set the base target to later animate back to. This is currently
		* only hydrated on creation and when we first read a value.
		*/
		setBaseTarget(key, value) {
			this.baseTarget[key] = value;
		}
		/**
		* Find the base target for a value thats been removed from all animation
		* props.
		*/
		getBaseTarget(key) {
			var _a;
			const { initial } = this.props;
			let valueFromInitial;
			if (typeof initial === "string" || typeof initial === "object") {
				const variant = resolveVariantFromProps(this.props, initial, (_a = this.presenceContext) === null || _a === void 0 ? void 0 : _a.custom);
				if (variant) valueFromInitial = variant[key];
			}
			/**
			* If this value still exists in the current initial variant, read that.
			*/
			if (initial && valueFromInitial !== void 0) return valueFromInitial;
			/**
			* Alternatively, if this VisualElement config has defined a getBaseTarget
			* so we can read the value from an alternative source, try that.
			*/
			const target = this.getBaseTargetFromProps(this.props, key);
			if (target !== void 0 && !isMotionValue(target)) return target;
			/**
			* If the value was initially defined on initial, but it doesn't any more,
			* return undefined. Otherwise return the value as initially read from the DOM.
			*/
			return this.initialValues[key] !== void 0 && valueFromInitial === void 0 ? void 0 : this.baseTarget[key];
		}
		on(eventName, callback) {
			if (!this.events[eventName]) this.events[eventName] = new SubscriptionManager();
			return this.events[eventName].add(callback);
		}
		notify(eventName, ...args) {
			if (this.events[eventName]) this.events[eventName].notify(...args);
		}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/dom/DOMVisualElement.mjs
	var DOMVisualElement = class extends VisualElement {
		constructor() {
			super(...arguments);
			this.KeyframeResolver = DOMKeyframesResolver;
		}
		sortInstanceNodePosition(a, b) {
			/**
			* compareDocumentPosition returns a bitmask, by using the bitwise &
			* we're returning true if 2 in that bitmask is set to true. 2 is set
			* to true if b preceeds a.
			*/
			return a.compareDocumentPosition(b) & 2 ? 1 : -1;
		}
		getBaseTargetFromProps(props, key) {
			return props.style ? props.style[key] : void 0;
		}
		removeValueFromRenderState(key, { vars, style }) {
			delete vars[key];
			delete style[key];
		}
		handleChildMotionValue() {
			if (this.childSubscription) {
				this.childSubscription();
				delete this.childSubscription;
			}
			const { children } = this.props;
			if (isMotionValue(children)) this.childSubscription = children.on("change", (latest) => {
				if (this.current) this.current.textContent = `${latest}`;
			});
		}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/html/HTMLVisualElement.mjs
	function getComputedStyle(element) {
		return window.getComputedStyle(element);
	}
	var HTMLVisualElement = class extends DOMVisualElement {
		constructor() {
			super(...arguments);
			this.type = "html";
			this.renderInstance = renderHTML;
		}
		readValueFromInstance(instance, key) {
			if (transformProps.has(key)) {
				const defaultType = getDefaultValueType(key);
				return defaultType ? defaultType.default || 0 : 0;
			} else {
				const computedStyle = getComputedStyle(instance);
				const value = (isCSSVariableName(key) ? computedStyle.getPropertyValue(key) : computedStyle[key]) || 0;
				return typeof value === "string" ? value.trim() : value;
			}
		}
		measureInstanceViewportBox(instance, { transformPagePoint }) {
			return measureViewportBox(instance, transformPagePoint);
		}
		build(renderState, latestValues, props) {
			buildHTMLStyles(renderState, latestValues, props.transformTemplate);
		}
		scrapeMotionValuesFromProps(props, prevProps, visualElement) {
			return scrapeMotionValuesFromProps$1(props, prevProps, visualElement);
		}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/svg/SVGVisualElement.mjs
	var SVGVisualElement = class extends DOMVisualElement {
		constructor() {
			super(...arguments);
			this.type = "svg";
			this.isSVGTag = false;
			this.measureInstanceViewportBox = createBox;
		}
		getBaseTargetFromProps(props, key) {
			return props[key];
		}
		readValueFromInstance(instance, key) {
			if (transformProps.has(key)) {
				const defaultType = getDefaultValueType(key);
				return defaultType ? defaultType.default || 0 : 0;
			}
			key = !camelCaseAttributes.has(key) ? camelToDash(key) : key;
			return instance.getAttribute(key);
		}
		scrapeMotionValuesFromProps(props, prevProps, visualElement) {
			return scrapeMotionValuesFromProps(props, prevProps, visualElement);
		}
		build(renderState, latestValues, props) {
			buildSVGAttrs(renderState, latestValues, this.isSVGTag, props.transformTemplate);
		}
		renderInstance(instance, renderState, styleProp, projection) {
			renderSVG(instance, renderState, styleProp, projection);
		}
		mount(instance) {
			this.isSVGTag = isSVGTag(instance.tagName);
			super.mount(instance);
		}
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/dom/create-visual-element.mjs
	var createDomVisualElement = (Component, options) => {
		return isSVGComponent(Component) ? new SVGVisualElement(options) : new HTMLVisualElement(options, { allowProjection: Component !== import_react.Fragment });
	};
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/components/motion/create.mjs
	init_objectSpread2();
	//#endregion
	//#region node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs
	var motion = /*@__PURE__*/ createDOMMotionComponentProxy(/* @__PURE__ */ createMotionComponentFactory(_objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, animations), gestureAnimations), drag), layout), createDomVisualElement));
	//#endregion
	//#region node_modules/clsx/dist/clsx.mjs
	function r(e) {
		var t, f, n = "";
		if ("string" == typeof e || "number" == typeof e) n += e;
		else if ("object" == typeof e) if (Array.isArray(e)) {
			var o = e.length;
			for (t = 0; t < o; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
		} else for (f in e) e[f] && (n && (n += " "), n += f);
		return n;
	}
	function clsx() {
		for (var e, t, f = 0, n = "", o = arguments.length; f < o; f++) (e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
		return n;
	}
	//#endregion
	//#region src/components/ColorRangeSelector.tsx
	function useWheelToHorizontalScroll() {
		const ref = (0, import_react.useRef)(null);
		const onWheel = (e) => {
			const el = ref.current;
			if (!el) return;
			const isHorizontallyScrollable = el.scrollWidth > el.clientWidth;
			const isPrimarilyVertical = Math.abs(e.deltaY) > Math.abs(e.deltaX);
			if (isHorizontallyScrollable && isPrimarilyVertical) {
				e.preventDefault();
				el.scrollLeft += e.deltaY;
			}
		};
		return {
			ref,
			onWheel
		};
	}
	function ColorRangeSelector({ families, isLoading }) {
		const selectedFamilyId = useFandeckStore((s) => s.selectedFamilyId);
		const setSelectedFamilyId = useFandeckStore((s) => s.setSelectedFamilyId);
		const isDown = (0, import_react.useRef)(false);
		const startX = (0, import_react.useRef)(0);
		const scrollLeft = (0, import_react.useRef)(0);
		const onMouseDown = (e) => {
			var _scrollRef$current$of, _scrollRef$current, _scrollRef$current$sc, _scrollRef$current2;
			isDown.current = true;
			startX.current = e.pageX - ((_scrollRef$current$of = (_scrollRef$current = scrollRef.current) === null || _scrollRef$current === void 0 ? void 0 : _scrollRef$current.offsetLeft) !== null && _scrollRef$current$of !== void 0 ? _scrollRef$current$of : 0);
			scrollLeft.current = (_scrollRef$current$sc = (_scrollRef$current2 = scrollRef.current) === null || _scrollRef$current2 === void 0 ? void 0 : _scrollRef$current2.scrollLeft) !== null && _scrollRef$current$sc !== void 0 ? _scrollRef$current$sc : 0;
		};
		const onMouseLeave = () => {
			isDown.current = false;
		};
		const onMouseUp = () => {
			isDown.current = false;
		};
		const onMouseMove = (e) => {
			var _scrollRef$current$of2, _scrollRef$current3;
			if (!isDown.current) return;
			e.preventDefault();
			const walk = (e.pageX - ((_scrollRef$current$of2 = (_scrollRef$current3 = scrollRef.current) === null || _scrollRef$current3 === void 0 ? void 0 : _scrollRef$current3.offsetLeft) !== null && _scrollRef$current$of2 !== void 0 ? _scrollRef$current$of2 : 0) - startX.current) * 1.5;
			if (scrollRef.current) scrollRef.current.scrollLeft = scrollLeft.current - walk;
		};
		const { ref: scrollRef, onWheel } = useWheelToHorizontalScroll();
		if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "shrink-0 border-b border-gray-100 bg-white/90 backdrop-blur-md",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hide-scrollbar mx-auto flex max-w-7xl gap-2 overflow-x-auto px-4 py-2 md:gap-3 md:px-4 md:py-3",
				children: Array.from({ length: 9 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex h-8 w-20 shrink-0 animate-pulse items-center gap-2 rounded-full bg-gray-100 px-3 md:h-12 md:w-28 md:px-4" }, i))
			})
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "shrink-0 border-b border-gray-100 bg-white/90 backdrop-blur-md",
			role: "tablist",
			"aria-label": "Colour family selector",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: scrollRef,
				onWheel,
				onMouseDown,
				onMouseLeave,
				onMouseUp,
				onMouseMove,
				className: "hide-scrollbar mx-auto flex max-w-7xl gap-1.5 overflow-x-auto px-3 py-2 md:gap-3 md:px-4 md:py-3 cursor-grab active:cursor-grabbing select-none",
				children: families.map((family) => {
					const isActive = selectedFamilyId === family.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
						role: "tab",
						"aria-selected": isActive,
						"aria-label": `${family.name} — ${family.colorCount} colours`,
						onClick: () => setSelectedFamilyId(family.id),
						className: clsx("group relative flex shrink-0 items-center gap-2 rounded-full px-4 py-1.5 text-xs font-medium transition-all duration-300 ease-natural-decel md:gap-2 md:px-4 md:py-2 md:text-sm", isActive ? "bg-brand-charcoal text-white shadow-lg" : "bg-gray-50 text-gray-600 hover:bg-gray-100"),
						whileTap: { scale: .97 },
						animate: isActive ? { scale: 1.05 } : { scale: 1 },
						transition: {
							type: "spring",
							stiffness: 400,
							damping: 25
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: clsx("h-4 w-4 shrink-0 rounded-full border-2 transition-shadow md:h-5 md:w-5", isActive ? "border-white shadow-md" : "border-gray-200 group-hover:border-gray-300"),
								style: { backgroundColor: family.representativeHex },
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "whitespace-nowrap",
								children: family.name
							}),
							isActive && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-0.5 rounded-full bg-white/20 px-1 py-0.5 text-[10px] md:ml-1 md:px-1.5 md:text-xs",
								children: family.colorCount
							})
						]
					}, family.id);
				})
			})
		});
	}
	//#endregion
	//#region src/lib/utils.ts
	/**
	* Returns white or dark text color based on LRV threshold.
	*/
	function getTextColor(lrv) {
		return lrv < 50 ? "#ffffff" : "#1a1a1a";
	}
	//#endregion
	//#region src/components/FanCard.tsx
	function FanCard({ familyId }) {
		var _data$content, _data$totalPages;
		const fanPage = useFandeckStore((s) => s.fanPage);
		const setFanPage = useFandeckStore((s) => s.setFanPage);
		const setActiveShade = useFandeckStore((s) => s.setActiveShade);
		const [previewedIndex, setPreviewedIndex] = (0, import_react.useState)(null);
		const [lastOpenedIndex, setLastOpenedIndex] = (0, import_react.useState)(null);
		const [hoveredIndex, setHoveredIndex] = (0, import_react.useState)(null);
		const activeShade = useFandeckStore((s) => s.activeShade);
		(0, import_react.useEffect)(() => {
			if (activeShade === null) {
				setHoveredIndex(null);
				setPreviewedIndex(null);
				setLastOpenedIndex(null);
			}
		}, [activeShade]);
		(0, import_react.useEffect)(() => {
			setHoveredIndex(null);
			setPreviewedIndex(null);
		}, [familyId]);
		(0, import_react.useEffect)(() => {
			const reset = (e) => {
				if (e.target.closest("[role=\"option\"]")) return;
				setHoveredIndex(null);
				setPreviewedIndex(null);
				setLastOpenedIndex(null);
			};
			document.addEventListener("mousedown", reset);
			document.addEventListener("touchstart", reset);
			return () => {
				document.removeEventListener("mousedown", reset);
				document.removeEventListener("touchstart", reset);
			};
		}, []);
		const [isMobile, setIsMobile] = (0, import_react.useState)(false);
		const touchStartX = (0, import_react.useRef)(null);
		const [containerNode, setContainerNode] = (0, import_react.useState)(null);
		const containerRef = (0, import_react.useCallback)((node) => {
			setContainerNode(node);
		}, []);
		const [containerSize, setContainerSize] = (0, import_react.useState)({
			width: 0,
			height: 0
		});
		(0, import_react.useEffect)(() => {
			const check = () => setIsMobile(window.innerWidth < 768);
			check();
			window.addEventListener("resize", check);
			return () => window.removeEventListener("resize", check);
		}, []);
		(0, import_react.useEffect)(() => {
			if (!containerNode) return;
			const observer = new ResizeObserver((entries) => {
				const entry = entries[0];
				if (!entry) return;
				setContainerSize({
					width: entry.contentRect.width,
					height: entry.contentRect.height
				});
			});
			observer.observe(containerNode);
			return () => observer.disconnect();
		}, [containerNode]);
		const handleTouchStart = (e) => {
			touchStartX.current = e.touches[0].clientX;
		};
		const handleTouchMove = (e) => {
			if (!isMobile) return;
			const touch = e.touches[0];
			if (!touch) return;
			const el = document.elementFromPoint(touch.clientX, touch.clientY);
			const bladeEl = el === null || el === void 0 ? void 0 : el.closest("[data-blade-index]");
			if (!bladeEl) return;
			const idx = Number(bladeEl.getAttribute("data-blade-index"));
			if (!Number.isNaN(idx)) setPreviewedIndex(idx);
		};
		const handleTouchEnd = (e) => {
			if (touchStartX.current === null) return;
			const diff = e.changedTouches[0].clientX - touchStartX.current;
			if (Math.abs(diff) > 20) setHoveredIndex((prev) => {
				if (prev === null) return 0;
				if (diff < 0) return Math.min(prev + 1, colors.length - 1);
				if (diff > 0) return Math.max(prev - 1, 0);
				return prev;
			});
			touchStartX.current = null;
		};
		const bladesPerPage = 14;
		const { data, isLoading } = useQuery({
			queryKey: [
				"familyColors",
				familyId,
				fanPage,
				bladesPerPage
			],
			queryFn: () => api.families.getColors(familyId, fanPage, bladesPerPage, "lrv,asc")
		});
		const colors = (_data$content = data === null || data === void 0 ? void 0 : data.content) !== null && _data$content !== void 0 ? _data$content : [];
		const totalPages = (_data$totalPages = data === null || data === void 0 ? void 0 : data.totalPages) !== null && _data$totalPages !== void 0 ? _data$totalPages : 1;
		const n = colors.length;
		if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FanCardSkeleton, {
			count: bladesPerPage,
			isMobile
		});
		if (colors.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-[50vh] flex-col items-center justify-center text-gray-400",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					width: "64",
					height: "64",
					viewBox: "0 0 24 24",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "1",
					className: "text-gray-300",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "12",
						cy: "12",
						r: "10"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 15h8M9 9h.01M15 9h.01" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-lg font-medium",
					children: "No colours found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: "Try selecting a different colour family"
				})
			]
		});
		const bladeWidth = 90;
		let totalSpread = 90;
		if (isMobile && containerSize.width > 0 && containerSize.height > 0 && n > 1) {
			const bladeHeightPx = containerSize.height * .88;
			const safeHalfWidth = containerSize.width * .47;
			const reachAt = (halfAngleDeg) => {
				const rad = halfAngleDeg * Math.PI / 180;
				return bladeHeightPx * Math.sin(rad) + bladeWidth / 2 * Math.cos(rad);
			};
			let half = totalSpread / 2;
			while (half > 6 && reachAt(half) > safeHalfWidth) half -= 1;
			totalSpread = half * 2;
		}
		const startAngle = -totalSpread / 2;
		const angleStep = n > 1 ? totalSpread / (n - 1) : 0;
		const handleLeafActivate = (index, targetColor) => {
			if (!isMobile) {
				setActiveShade(targetColor);
				setLastOpenedIndex(index);
				return;
			}
			if (previewedIndex === index) {
				setActiveShade(targetColor);
				setLastOpenedIndex(index);
			} else setPreviewedIndex(index);
		};
		const effectiveHoveredIndex = isMobile ? previewedIndex !== null && previewedIndex !== void 0 ? previewedIndex : lastOpenedIndex : hoveredIndex !== null && hoveredIndex !== void 0 ? hoveredIndex : lastOpenedIndex;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-full flex-col items-center overflow-hidden arrows-wp",
			onTouchStart: handleTouchStart,
			onTouchMove: handleTouchMove,
			onTouchEnd: handleTouchEnd,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: containerRef,
					className: "relative flex flex-1 items-end justify-center overflow-hidden",
					style: {
						width: "100%",
						maxWidth: "1200px",
						minHeight: isMobile ? "260px" : void 0
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "black-dot absolute bottom-0 left-1/2 z-20 h-6 w-6 -translate-x-1/2 translate-y-1/2 rounded-full bg-brand-charcoal shadow-lg ring-4 ring-white",
						"aria-hidden": "true"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
						mode: "wait",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
							className: "relative h-full w-full",
							initial: { opacity: 0 },
							animate: { opacity: 1 },
							exit: { opacity: 0 },
							transition: { duration: .3 },
							role: "listbox",
							"aria-label": "Paint Shades",
							children: colors.map((color, index) => {
								const targetAngle = startAngle + index * angleStep;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FanBlade, {
									color,
									index,
									targetAngle,
									isHovered: effectiveHoveredIndex === index,
									isMobile,
									onHover: () => {
										if (!isMobile) setHoveredIndex(index);
									},
									onLeave: () => {
										if (!isMobile) setHoveredIndex(null);
									},
									onClick: () => handleLeafActivate(index, color),
									onSelectSibling: (sibling) => handleLeafActivate(index, sibling),
									totalCount: colors.length,
									hoveredIndex: effectiveHoveredIndex
								}, color.id);
							})
						}, `fan-${familyId}-${fanPage}`)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 hidden text-xs text-gray-400 md:block",
					"aria-hidden": "true",
					children: "Click on any shade to view details"
				}),
				totalPages > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1 flex items-center gap-3 md:gap-4 arrows-wrapper",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setFanPage(Math.max(0, fanPage - 1)),
							disabled: fanPage === 0,
							className: "flex shdow-md h-8 w-8 items-center justify-center rounded-full bg-white text-brand-charcoal shadow-md transition-all hover:shadow-lg disabled:opacity-30 disabled:shadow-none md:h-8 md:w-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								width: "16",
								height: "16",
								viewBox: "0 0 24 24",
								fill: "none",
								stroke: "currentColor",
								strokeWidth: "2.5",
								strokeLinecap: "round",
								strokeLinejoin: "round",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "m15 18-6-6 6-6" })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-sm text-gray-500",
							children: [
								fanPage + 1,
								" / ",
								totalPages
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setFanPage(Math.min(totalPages - 1, fanPage + 1)),
							disabled: fanPage >= totalPages - 1,
							className: "flex h-8 w-8 items-center shdow-md justify-center rounded-full bg-white text-brand-charcoal shadow-md transition-all hover:shadow-lg disabled:opacity-30 disabled:shadow-none",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								width: "16",
								height: "16",
								viewBox: "0 0 24 24",
								fill: "none",
								stroke: "currentColor",
								strokeWidth: "2.5",
								strokeLinecap: "round",
								strokeLinejoin: "round",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "m9 18 6-6-6-6" })
							})
						})
					]
				})
			]
		});
	}
	function FanBlade({ color, index, targetAngle, isHovered, isMobile, onHover, onLeave, onClick, onSelectSibling, totalCount, hoveredIndex }) {
		const bladeHeight = isMobile ? "88%" : "90%";
		const bladeWidth = 90;
		const textColor = getTextColor(color.lrv);
		let adjustedAngle = targetAngle;
		if (hoveredIndex !== null && hoveredIndex !== index) {
			const diff = index - hoveredIndex;
			if (Math.abs(diff) === 1) adjustedAngle += diff > 0 ? 2 : -2;
		}
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
			role: "option",
			tabIndex: 0,
			"data-blade-index": index,
			className: "absolute fans-leaf bottom-0 left-1/2 cursor-pointer",
			style: {
				width: bladeWidth,
				height: bladeHeight,
				marginLeft: -45,
				transformOrigin: "bottom center",
				zIndex: isHovered ? totalCount + 10 : hoveredIndex !== null ? Math.abs(index - hoveredIndex) === 0 ? totalCount + 10 : totalCount - Math.abs(index - hoveredIndex) : index + 1
			},
			initial: {
				rotate: 0,
				opacity: 0
			},
			animate: {
				rotate: adjustedAngle,
				opacity: 1,
				y: isHovered ? -8 : 0
			},
			transition: {
				rotate: {
					delay: index * .03,
					duration: .5,
					ease: [
						.16,
						1,
						.3,
						1
					]
				},
				y: { duration: .2 },
				opacity: {
					delay: index * .03,
					duration: .3
				}
			},
			onMouseEnter: onHover,
			onMouseLeave: onLeave,
			onFocus: onHover,
			onBlur: onLeave,
			onClick,
			onKeyDown: (e) => {
				if (e.key === "Enter" || e.key === " ") {
					e.preventDefault();
					onClick();
				}
			},
			"aria-label": `${color.name} — ${color.code}`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-full w-full flex-col overflow-hidden rounded-t-xl shadow-md transition-shadow duration-200",
				style: {
					backgroundColor: color.hexValue,
					boxShadow: isHovered ? "0 8px 30px rgba(0,0,0,0.25)" : "0 2px 8px rgba(0,0,0,0.1)"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 px-2 pt-3 pb-3 md:px-3 md:pt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-[11px] text-center font-semibold leading-tight md:text-sm",
							style: { color: textColor },
							children: color.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-center mt-1 truncate text-[10px] opacity-75 md:text-xs",
							style: { color: textColor },
							children: color.code
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeafPartitions, {
						color,
						isMobile,
						onSelectSibling
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-10 shrink-0 items-center justify-center bg-black/10 md:h-14",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hot-spot h-3 w-3 rounded-full bg-white/30" })
					})
				]
			})
		});
	}
	function LeafPartitions({ color, isMobile, onSelectSibling }) {
		const { data: siblings } = useQuery({
			queryKey: ["pageSiblings", color.id],
			queryFn: () => api.colors.getPageSiblings(color.id),
			staleTime: Infinity
		});
		const otherSiblings = (siblings !== null && siblings !== void 0 ? siblings : []).filter((c) => c.id !== color.id);
		if (otherSiblings.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex-1" });
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-1 flex-col",
			children: otherSiblings.map((sibling) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: (e) => {
					e.stopPropagation();
					onSelectSibling(sibling);
					const leafEl = e.currentTarget.closest("[data-blade-index]");
					leafEl === null || leafEl === void 0 || leafEl.focus();
				},
				className: "relative min-h-0 w-full flex-1 transition-transform hover:brightness-95",
				style: { backgroundColor: sibling.hexValue },
				"aria-label": `${sibling.name} — ${sibling.code}`
			}, sibling.id))
		});
	}
	function FanCardSkeleton({ count, isMobile }) {
		const totalSpread = isMobile ? 34 : 90;
		const startAngle = -totalSpread / 2;
		const angleStep = count > 1 ? totalSpread / (count - 1) : 0;
		const bladeWidth = 110;
		const bladeHeight = isMobile ? "88%" : "90%";
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex h-full flex-col items-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative flex flex-1 items-end justify-center",
				style: {
					width: "100%",
					maxWidth: "1200px",
					minHeight: isMobile ? "260px" : void 0,
					overflow: "hidden"
				},
				children: Array.from({ length: count }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute bottom-0 left-1/2 animate-pulse rounded-t-xl bg-gray-200",
					style: {
						width: bladeWidth,
						height: bladeHeight,
						marginLeft: -55,
						transformOrigin: "bottom center",
						transform: `rotate(${startAngle + i * angleStep}deg)`
					}
				}, i))
			})
		});
	}
	//#endregion
	//#region node_modules/@swc/helpers/cjs/_interop_require_default.cjs
	var require__interop_require_default = /* @__PURE__ */ __commonJSMin(((exports) => {
		exports._ = exports._interop_require_default = _interop_require_default;
		function _interop_require_default(obj) {
			return obj && obj.__esModule ? obj : { default: obj };
		}
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/router/utils/querystring.js
	var require_querystring = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		0 && (module.exports = {
			assign: null,
			searchParamsToUrlQuery: null,
			urlQueryToSearchParams: null
		});
		function _export(target, all) {
			for (var name in all) Object.defineProperty(target, name, {
				enumerable: true,
				get: all[name]
			});
		}
		_export(exports, {
			assign: function() {
				return assign;
			},
			searchParamsToUrlQuery: function() {
				return searchParamsToUrlQuery;
			},
			urlQueryToSearchParams: function() {
				return urlQueryToSearchParams;
			}
		});
		function searchParamsToUrlQuery(searchParams) {
			const query = {};
			searchParams.forEach((value, key) => {
				if (typeof query[key] === "undefined") query[key] = value;
				else if (Array.isArray(query[key])) query[key].push(value);
				else query[key] = [query[key], value];
			});
			return query;
		}
		function stringifyUrlQueryParam(param) {
			if (typeof param === "string" || typeof param === "number" && !isNaN(param) || typeof param === "boolean") return String(param);
			else return "";
		}
		function urlQueryToSearchParams(urlQuery) {
			const result = new URLSearchParams();
			Object.entries(urlQuery).forEach((param) => {
				let [key, value] = param;
				if (Array.isArray(value)) value.forEach((item) => result.append(key, stringifyUrlQueryParam(item)));
				else result.set(key, stringifyUrlQueryParam(value));
			});
			return result;
		}
		function assign(target) {
			for (var _len = arguments.length, searchParamsList = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) searchParamsList[_key - 1] = arguments[_key];
			searchParamsList.forEach((searchParams) => {
				Array.from(searchParams.keys()).forEach((key) => target.delete(key));
				searchParams.forEach((value, key) => target.append(key, value));
			});
			return target;
		}
	}));
	//#endregion
	//#region node_modules/@swc/helpers/cjs/_interop_require_wildcard.cjs
	var require__interop_require_wildcard = /* @__PURE__ */ __commonJSMin(((exports) => {
		function _getRequireWildcardCache(nodeInterop) {
			if (typeof WeakMap !== "function") return null;
			var cacheBabelInterop = /* @__PURE__ */ new WeakMap();
			var cacheNodeInterop = /* @__PURE__ */ new WeakMap();
			return (_getRequireWildcardCache = function(nodeInterop) {
				return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
			})(nodeInterop);
		}
		exports._ = exports._interop_require_wildcard = _interop_require_wildcard;
		function _interop_require_wildcard(obj, nodeInterop) {
			if (!nodeInterop && obj && obj.__esModule) return obj;
			if (obj === null || typeof obj !== "object" && typeof obj !== "function") return { default: obj };
			var cache = _getRequireWildcardCache(nodeInterop);
			if (cache && cache.has(obj)) return cache.get(obj);
			var newObj = { __proto__: null };
			var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
			for (var key in obj) if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
				var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
				if (desc && (desc.get || desc.set)) Object.defineProperty(newObj, key, desc);
				else newObj[key] = obj[key];
			}
			newObj.default = obj;
			if (cache) cache.set(obj, newObj);
			return newObj;
		}
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/router/utils/format-url.js
	var require_format_url = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		0 && (module.exports = {
			formatUrl: null,
			formatWithValidation: null,
			urlObjectKeys: null
		});
		function _export(target, all) {
			for (var name in all) Object.defineProperty(target, name, {
				enumerable: true,
				get: all[name]
			});
		}
		_export(exports, {
			formatUrl: function() {
				return formatUrl;
			},
			formatWithValidation: function() {
				return formatWithValidation;
			},
			urlObjectKeys: function() {
				return urlObjectKeys;
			}
		});
		var _querystring = /*#__PURE__*/ require__interop_require_wildcard()._(require_querystring());
		var slashedProtocols = /https?|ftp|gopher|file/;
		function formatUrl(urlObj) {
			let { auth, hostname } = urlObj;
			let protocol = urlObj.protocol || "";
			let pathname = urlObj.pathname || "";
			let hash = urlObj.hash || "";
			let query = urlObj.query || "";
			let host = false;
			auth = auth ? encodeURIComponent(auth).replace(/%3A/i, ":") + "@" : "";
			if (urlObj.host) host = auth + urlObj.host;
			else if (hostname) {
				host = auth + (~hostname.indexOf(":") ? "[" + hostname + "]" : hostname);
				if (urlObj.port) host += ":" + urlObj.port;
			}
			if (query && typeof query === "object") query = String(_querystring.urlQueryToSearchParams(query));
			let search = urlObj.search || query && "?" + query || "";
			if (protocol && !protocol.endsWith(":")) protocol += ":";
			if (urlObj.slashes || (!protocol || slashedProtocols.test(protocol)) && host !== false) {
				host = "//" + (host || "");
				if (pathname && pathname[0] !== "/") pathname = "/" + pathname;
			} else if (!host) host = "";
			if (hash && hash[0] !== "#") hash = "#" + hash;
			if (search && search[0] !== "?") search = "?" + search;
			pathname = pathname.replace(/[?#]/g, encodeURIComponent);
			search = search.replace("#", "%23");
			return "" + protocol + host + pathname + search + hash;
		}
		var urlObjectKeys = [
			"auth",
			"hash",
			"host",
			"hostname",
			"href",
			"path",
			"pathname",
			"port",
			"protocol",
			"query",
			"search",
			"slashes"
		];
		function formatWithValidation(url) {
			return formatUrl(url);
		}
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/router/utils/omit.js
	var require_omit = /* @__PURE__ */ __commonJSMin(((exports) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "omit", {
			enumerable: true,
			get: function() {
				return omit;
			}
		});
		function omit(object, keys) {
			const omitted = {};
			Object.keys(object).forEach((key) => {
				if (!keys.includes(key)) omitted[key] = object[key];
			});
			return omitted;
		}
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/utils.js
	var require_utils$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		init_asyncToGenerator();
		Object.defineProperty(exports, "__esModule", { value: true });
		0 && (module.exports = {
			DecodeError: null,
			MiddlewareNotFoundError: null,
			MissingStaticPage: null,
			NormalizeError: null,
			PageNotFoundError: null,
			SP: null,
			ST: null,
			WEB_VITALS: null,
			execOnce: null,
			getDisplayName: null,
			getLocationOrigin: null,
			getURL: null,
			isAbsoluteUrl: null,
			isResSent: null,
			loadGetInitialProps: null,
			normalizeRepeatedSlashes: null,
			stringifyError: null
		});
		function _export(target, all) {
			for (var name in all) Object.defineProperty(target, name, {
				enumerable: true,
				get: all[name]
			});
		}
		_export(exports, {
			DecodeError: function() {
				return DecodeError;
			},
			MiddlewareNotFoundError: function() {
				return MiddlewareNotFoundError;
			},
			MissingStaticPage: function() {
				return MissingStaticPage;
			},
			NormalizeError: function() {
				return NormalizeError;
			},
			PageNotFoundError: function() {
				return PageNotFoundError;
			},
			SP: function() {
				return SP;
			},
			ST: function() {
				return ST;
			},
			WEB_VITALS: function() {
				return WEB_VITALS;
			},
			execOnce: function() {
				return execOnce;
			},
			getDisplayName: function() {
				return getDisplayName;
			},
			getLocationOrigin: function() {
				return getLocationOrigin;
			},
			getURL: function() {
				return getURL;
			},
			isAbsoluteUrl: function() {
				return isAbsoluteUrl;
			},
			isResSent: function() {
				return isResSent;
			},
			loadGetInitialProps: function() {
				return loadGetInitialProps;
			},
			normalizeRepeatedSlashes: function() {
				return normalizeRepeatedSlashes;
			},
			stringifyError: function() {
				return stringifyError;
			}
		});
		var WEB_VITALS = [
			"CLS",
			"FCP",
			"FID",
			"INP",
			"LCP",
			"TTFB"
		];
		function execOnce(fn) {
			let used = false;
			let result;
			return function() {
				for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
				if (!used) {
					used = true;
					result = fn(...args);
				}
				return result;
			};
		}
		var ABSOLUTE_URL_REGEX = /^[a-zA-Z][a-zA-Z\d+\-.]*?:/;
		var isAbsoluteUrl = (url) => ABSOLUTE_URL_REGEX.test(url);
		function getLocationOrigin() {
			const { protocol, hostname, port } = window.location;
			return protocol + "//" + hostname + (port ? ":" + port : "");
		}
		function getURL() {
			const { href } = window.location;
			const origin = getLocationOrigin();
			return href.substring(origin.length);
		}
		function getDisplayName(Component) {
			return typeof Component === "string" ? Component : Component.displayName || Component.name || "Unknown";
		}
		function isResSent(res) {
			return res.finished || res.headersSent;
		}
		function normalizeRepeatedSlashes(url) {
			const urlParts = url.split("?");
			return urlParts[0].replace(/\\/g, "/").replace(/\/\/+/g, "/") + (urlParts[1] ? "?" + urlParts.slice(1).join("?") : "");
		}
		function loadGetInitialProps(_x, _x2) {
			return _loadGetInitialProps.apply(this, arguments);
		}
		function _loadGetInitialProps() {
			_loadGetInitialProps = _asyncToGenerator(function* (App, ctx) {
				const res = ctx.res || ctx.ctx && ctx.ctx.res;
				if (!App.getInitialProps) {
					if (ctx.ctx && ctx.Component) return { pageProps: yield loadGetInitialProps(ctx.Component, ctx.ctx) };
					return {};
				}
				const props = yield App.getInitialProps(ctx);
				if (res && isResSent(res)) return props;
				if (!props) {
					const message = "\"" + getDisplayName(App) + ".getInitialProps()\" should resolve to an object. But found \"" + props + "\" instead.";
					throw new Error(message);
				}
				return props;
			});
			return _loadGetInitialProps.apply(this, arguments);
		}
		var SP = typeof performance !== "undefined";
		var ST = SP && [
			"mark",
			"measure",
			"getEntriesByName"
		].every((method) => typeof performance[method] === "function");
		var DecodeError = class extends Error {};
		var NormalizeError = class extends Error {};
		var PageNotFoundError = class extends Error {
			constructor(page) {
				super();
				this.code = "ENOENT";
				this.name = "PageNotFoundError";
				this.message = "Cannot find module for page: " + page;
			}
		};
		var MissingStaticPage = class extends Error {
			constructor(page, message) {
				super();
				this.message = "Failed to load static file for page: " + page + " " + message;
			}
		};
		var MiddlewareNotFoundError = class extends Error {
			constructor() {
				super();
				this.code = "ENOENT";
				this.message = "Cannot find the middleware module";
			}
		};
		function stringifyError(error) {
			return JSON.stringify({
				message: error.message,
				stack: error.stack
			});
		}
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/router/utils/remove-trailing-slash.js
	/**
	* Removes the trailing slash for a given route or page path. Preserves the
	* root page. Examples:
	*   - `/foo/bar/` -> `/foo/bar`
	*   - `/foo/bar` -> `/foo/bar`
	*   - `/` -> `/`
	*/ var require_remove_trailing_slash = /* @__PURE__ */ __commonJSMin(((exports) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "removeTrailingSlash", {
			enumerable: true,
			get: function() {
				return removeTrailingSlash;
			}
		});
		function removeTrailingSlash(route) {
			return route.replace(/\/$/, "") || "/";
		}
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/router/utils/parse-path.js
	/**
	* Given a path this function will find the pathname, query and hash and return
	* them. This is useful to parse full paths on the client side.
	* @param path A path to parse e.g. /foo/bar?id=1#hash
	*/ var require_parse_path = /* @__PURE__ */ __commonJSMin(((exports) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "parsePath", {
			enumerable: true,
			get: function() {
				return parsePath;
			}
		});
		function parsePath(path) {
			const hashIndex = path.indexOf("#");
			const queryIndex = path.indexOf("?");
			const hasQuery = queryIndex > -1 && (hashIndex < 0 || queryIndex < hashIndex);
			if (hasQuery || hashIndex > -1) return {
				pathname: path.substring(0, hasQuery ? queryIndex : hashIndex),
				query: hasQuery ? path.substring(queryIndex, hashIndex > -1 ? hashIndex : void 0) : "",
				hash: hashIndex > -1 ? path.slice(hashIndex) : ""
			};
			return {
				pathname: path,
				query: "",
				hash: ""
			};
		}
	}));
	//#endregion
	//#region node_modules/next/dist/client/normalize-trailing-slash.js
	var require_normalize_trailing_slash = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "normalizePathTrailingSlash", {
			enumerable: true,
			get: function() {
				return normalizePathTrailingSlash;
			}
		});
		var _removetrailingslash = require_remove_trailing_slash();
		var _parsepath = require_parse_path();
		var normalizePathTrailingSlash = (path) => {
			if (!path.startsWith("/") || {}.__NEXT_MANUAL_TRAILING_SLASH) return path;
			const { pathname, query, hash } = (0, _parsepath.parsePath)(path);
			if ({}.__NEXT_TRAILING_SLASH) {
				if (/\.[^/]+\/?$/.test(pathname)) return "" + (0, _removetrailingslash.removeTrailingSlash)(pathname) + query + hash;
				else if (pathname.endsWith("/")) return "" + pathname + query + hash;
				else return pathname + "/" + query + hash;
			}
			return "" + (0, _removetrailingslash.removeTrailingSlash)(pathname) + query + hash;
		};
		if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && typeof exports.default.__esModule === "undefined") {
			Object.defineProperty(exports.default, "__esModule", { value: true });
			Object.assign(exports.default, exports);
			module.exports = exports.default;
		}
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/router/utils/path-has-prefix.js
	var require_path_has_prefix = /* @__PURE__ */ __commonJSMin(((exports) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "pathHasPrefix", {
			enumerable: true,
			get: function() {
				return pathHasPrefix;
			}
		});
		var _parsepath = require_parse_path();
		function pathHasPrefix(path, prefix) {
			if (typeof path !== "string") return false;
			const { pathname } = (0, _parsepath.parsePath)(path);
			return pathname === prefix || pathname.startsWith(prefix + "/");
		}
	}));
	//#endregion
	//#region node_modules/next/dist/client/has-base-path.js
	var require_has_base_path = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "hasBasePath", {
			enumerable: true,
			get: function() {
				return hasBasePath;
			}
		});
		var _pathhasprefix = require_path_has_prefix();
		var basePath = {}.__NEXT_ROUTER_BASEPATH || "";
		function hasBasePath(path) {
			return (0, _pathhasprefix.pathHasPrefix)(path, basePath);
		}
		if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && typeof exports.default.__esModule === "undefined") {
			Object.defineProperty(exports.default, "__esModule", { value: true });
			Object.assign(exports.default, exports);
			module.exports = exports.default;
		}
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/router/utils/is-local-url.js
	var require_is_local_url = /* @__PURE__ */ __commonJSMin(((exports) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "isLocalURL", {
			enumerable: true,
			get: function() {
				return isLocalURL;
			}
		});
		var _utils = require_utils$1();
		var _hasbasepath = require_has_base_path();
		function isLocalURL(url) {
			if (!(0, _utils.isAbsoluteUrl)(url)) return true;
			try {
				const locationOrigin = (0, _utils.getLocationOrigin)();
				const resolved = new URL(url, locationOrigin);
				return resolved.origin === locationOrigin && (0, _hasbasepath.hasBasePath)(resolved.pathname);
			} catch (_) {
				return false;
			}
		}
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/router/utils/sorted-routes.js
	var require_sorted_routes = /* @__PURE__ */ __commonJSMin(((exports) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "getSortedRoutes", {
			enumerable: true,
			get: function() {
				return getSortedRoutes;
			}
		});
		var UrlNode = class UrlNode {
			insert(urlPath) {
				this._insert(urlPath.split("/").filter(Boolean), [], false);
			}
			smoosh() {
				return this._smoosh();
			}
			_smoosh(prefix) {
				if (prefix === void 0) prefix = "/";
				const childrenPaths = [...this.children.keys()].sort();
				if (this.slugName !== null) childrenPaths.splice(childrenPaths.indexOf("[]"), 1);
				if (this.restSlugName !== null) childrenPaths.splice(childrenPaths.indexOf("[...]"), 1);
				if (this.optionalRestSlugName !== null) childrenPaths.splice(childrenPaths.indexOf("[[...]]"), 1);
				const routes = childrenPaths.map((c) => this.children.get(c)._smoosh("" + prefix + c + "/")).reduce((prev, curr) => [...prev, ...curr], []);
				if (this.slugName !== null) routes.push(...this.children.get("[]")._smoosh(prefix + "[" + this.slugName + "]/"));
				if (!this.placeholder) {
					const r = prefix === "/" ? "/" : prefix.slice(0, -1);
					if (this.optionalRestSlugName != null) throw new Error("You cannot define a route with the same specificity as a optional catch-all route (\"" + r + "\" and \"" + r + "[[..." + this.optionalRestSlugName + "]]\").");
					routes.unshift(r);
				}
				if (this.restSlugName !== null) routes.push(...this.children.get("[...]")._smoosh(prefix + "[..." + this.restSlugName + "]/"));
				if (this.optionalRestSlugName !== null) routes.push(...this.children.get("[[...]]")._smoosh(prefix + "[[..." + this.optionalRestSlugName + "]]/"));
				return routes;
			}
			_insert(urlPaths, slugNames, isCatchAll) {
				if (urlPaths.length === 0) {
					this.placeholder = false;
					return;
				}
				if (isCatchAll) throw new Error("Catch-all must be the last part of the URL.");
				let nextSegment = urlPaths[0];
				if (nextSegment.startsWith("[") && nextSegment.endsWith("]")) {
					let segmentName = nextSegment.slice(1, -1);
					let isOptional = false;
					if (segmentName.startsWith("[") && segmentName.endsWith("]")) {
						segmentName = segmentName.slice(1, -1);
						isOptional = true;
					}
					if (segmentName.startsWith("...")) {
						segmentName = segmentName.substring(3);
						isCatchAll = true;
					}
					if (segmentName.startsWith("[") || segmentName.endsWith("]")) throw new Error("Segment names may not start or end with extra brackets ('" + segmentName + "').");
					if (segmentName.startsWith(".")) throw new Error("Segment names may not start with erroneous periods ('" + segmentName + "').");
					function handleSlug(previousSlug, nextSlug) {
						if (previousSlug !== null) {
							if (previousSlug !== nextSlug) throw new Error("You cannot use different slug names for the same dynamic path ('" + previousSlug + "' !== '" + nextSlug + "').");
						}
						slugNames.forEach((slug) => {
							if (slug === nextSlug) throw new Error("You cannot have the same slug name \"" + nextSlug + "\" repeat within a single dynamic path");
							if (slug.replace(/\W/g, "") === nextSegment.replace(/\W/g, "")) throw new Error("You cannot have the slug names \"" + slug + "\" and \"" + nextSlug + "\" differ only by non-word symbols within a single dynamic path");
						});
						slugNames.push(nextSlug);
					}
					if (isCatchAll) {
						if (isOptional) {
							if (this.restSlugName != null) throw new Error("You cannot use both an required and optional catch-all route at the same level (\"[..." + this.restSlugName + "]\" and \"" + urlPaths[0] + "\" ).");
							handleSlug(this.optionalRestSlugName, segmentName);
							this.optionalRestSlugName = segmentName;
							nextSegment = "[[...]]";
						} else {
							if (this.optionalRestSlugName != null) throw new Error("You cannot use both an optional and required catch-all route at the same level (\"[[..." + this.optionalRestSlugName + "]]\" and \"" + urlPaths[0] + "\").");
							handleSlug(this.restSlugName, segmentName);
							this.restSlugName = segmentName;
							nextSegment = "[...]";
						}
					} else {
						if (isOptional) throw new Error("Optional route parameters are not yet supported (\"" + urlPaths[0] + "\").");
						handleSlug(this.slugName, segmentName);
						this.slugName = segmentName;
						nextSegment = "[]";
					}
				}
				if (!this.children.has(nextSegment)) this.children.set(nextSegment, new UrlNode());
				this.children.get(nextSegment)._insert(urlPaths.slice(1), slugNames, isCatchAll);
			}
			constructor() {
				this.placeholder = true;
				this.children = /* @__PURE__ */ new Map();
				this.slugName = null;
				this.restSlugName = null;
				this.optionalRestSlugName = null;
			}
		};
		function getSortedRoutes(normalizedPages) {
			const root = new UrlNode();
			normalizedPages.forEach((pagePath) => root.insert(pagePath));
			return root.smoosh();
		}
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/page-path/ensure-leading-slash.js
	/**
	* For a given page path, this function ensures that there is a leading slash.
	* If there is not a leading slash, one is added, otherwise it is noop.
	*/ var require_ensure_leading_slash = /* @__PURE__ */ __commonJSMin(((exports) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "ensureLeadingSlash", {
			enumerable: true,
			get: function() {
				return ensureLeadingSlash;
			}
		});
		function ensureLeadingSlash(path) {
			return path.startsWith("/") ? path : "/" + path;
		}
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/segment.js
	var require_segment = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		0 && (module.exports = {
			DEFAULT_SEGMENT_KEY: null,
			PAGE_SEGMENT_KEY: null,
			isGroupSegment: null
		});
		function _export(target, all) {
			for (var name in all) Object.defineProperty(target, name, {
				enumerable: true,
				get: all[name]
			});
		}
		_export(exports, {
			DEFAULT_SEGMENT_KEY: function() {
				return DEFAULT_SEGMENT_KEY;
			},
			PAGE_SEGMENT_KEY: function() {
				return PAGE_SEGMENT_KEY;
			},
			isGroupSegment: function() {
				return isGroupSegment;
			}
		});
		function isGroupSegment(segment) {
			return segment[0] === "(" && segment.endsWith(")");
		}
		var PAGE_SEGMENT_KEY = "__PAGE__";
		var DEFAULT_SEGMENT_KEY = "__DEFAULT__";
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/router/utils/app-paths.js
	var require_app_paths = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		0 && (module.exports = {
			normalizeAppPath: null,
			normalizeRscURL: null
		});
		function _export(target, all) {
			for (var name in all) Object.defineProperty(target, name, {
				enumerable: true,
				get: all[name]
			});
		}
		_export(exports, {
			normalizeAppPath: function() {
				return normalizeAppPath;
			},
			normalizeRscURL: function() {
				return normalizeRscURL;
			}
		});
		var _ensureleadingslash = require_ensure_leading_slash();
		var _segment = require_segment();
		function normalizeAppPath(route) {
			return (0, _ensureleadingslash.ensureLeadingSlash)(route.split("/").reduce((pathname, segment, index, segments) => {
				if (!segment) return pathname;
				if ((0, _segment.isGroupSegment)(segment)) return pathname;
				if (segment[0] === "@") return pathname;
				if ((segment === "page" || segment === "route") && index === segments.length - 1) return pathname;
				return pathname + "/" + segment;
			}, ""));
		}
		function normalizeRscURL(url) {
			return url.replace(/\.rsc($|\?)/, "$1");
		}
	}));
	//#endregion
	//#region node_modules/next/dist/server/future/helpers/interception-routes.js
	var require_interception_routes = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		0 && (module.exports = {
			INTERCEPTION_ROUTE_MARKERS: null,
			extractInterceptionRouteInformation: null,
			isInterceptionRouteAppPath: null
		});
		function _export(target, all) {
			for (var name in all) Object.defineProperty(target, name, {
				enumerable: true,
				get: all[name]
			});
		}
		_export(exports, {
			INTERCEPTION_ROUTE_MARKERS: function() {
				return INTERCEPTION_ROUTE_MARKERS;
			},
			extractInterceptionRouteInformation: function() {
				return extractInterceptionRouteInformation;
			},
			isInterceptionRouteAppPath: function() {
				return isInterceptionRouteAppPath;
			}
		});
		var _apppaths = require_app_paths();
		var INTERCEPTION_ROUTE_MARKERS = [
			"(..)(..)",
			"(.)",
			"(..)",
			"(...)"
		];
		function isInterceptionRouteAppPath(path) {
			return path.split("/").find((segment) => INTERCEPTION_ROUTE_MARKERS.find((m) => segment.startsWith(m))) !== void 0;
		}
		function extractInterceptionRouteInformation(path) {
			let interceptingRoute, marker, interceptedRoute;
			for (const segment of path.split("/")) {
				marker = INTERCEPTION_ROUTE_MARKERS.find((m) => segment.startsWith(m));
				if (marker) {
					[interceptingRoute, interceptedRoute] = path.split(marker, 2);
					break;
				}
			}
			if (!interceptingRoute || !marker || !interceptedRoute) throw new Error(`Invalid interception route: ${path}. Must be in the format /<intercepting route>/(..|...|..)(..)/<intercepted route>`);
			interceptingRoute = (0, _apppaths.normalizeAppPath)(interceptingRoute);
			switch (marker) {
				case "(.)":
					if (interceptingRoute === "/") interceptedRoute = `/${interceptedRoute}`;
					else interceptedRoute = interceptingRoute + "/" + interceptedRoute;
					break;
				case "(..)":
					if (interceptingRoute === "/") throw new Error(`Invalid interception route: ${path}. Cannot use (..) marker at the root level, use (.) instead.`);
					interceptedRoute = interceptingRoute.split("/").slice(0, -1).concat(interceptedRoute).join("/");
					break;
				case "(...)":
					interceptedRoute = "/" + interceptedRoute;
					break;
				case "(..)(..)":
					const splitInterceptingRoute = interceptingRoute.split("/");
					if (splitInterceptingRoute.length <= 2) throw new Error(`Invalid interception route: ${path}. Cannot use (..)(..) marker at the root level or one level up.`);
					interceptedRoute = splitInterceptingRoute.slice(0, -2).concat(interceptedRoute).join("/");
					break;
				default: throw new Error("Invariant: unexpected marker");
			}
			return {
				interceptingRoute,
				interceptedRoute
			};
		}
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/router/utils/is-dynamic.js
	var require_is_dynamic = /* @__PURE__ */ __commonJSMin(((exports) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "isDynamicRoute", {
			enumerable: true,
			get: function() {
				return isDynamicRoute;
			}
		});
		var _interceptionroutes = require_interception_routes();
		var TEST_ROUTE = /\/\[[^/]+?\](?=\/|$)/;
		function isDynamicRoute(route) {
			if ((0, _interceptionroutes.isInterceptionRouteAppPath)(route)) route = (0, _interceptionroutes.extractInterceptionRouteInformation)(route).interceptedRoute;
			return TEST_ROUTE.test(route);
		}
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/router/utils/index.js
	var require_utils = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		0 && (module.exports = {
			getSortedRoutes: null,
			isDynamicRoute: null
		});
		function _export(target, all) {
			for (var name in all) Object.defineProperty(target, name, {
				enumerable: true,
				get: all[name]
			});
		}
		_export(exports, {
			getSortedRoutes: function() {
				return _sortedroutes.getSortedRoutes;
			},
			isDynamicRoute: function() {
				return _isdynamic.isDynamicRoute;
			}
		});
		var _sortedroutes = require_sorted_routes();
		var _isdynamic = require_is_dynamic();
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/router/utils/route-matcher.js
	var require_route_matcher = /* @__PURE__ */ __commonJSMin(((exports) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "getRouteMatcher", {
			enumerable: true,
			get: function() {
				return getRouteMatcher;
			}
		});
		var _utils = require_utils$1();
		function getRouteMatcher(param) {
			let { re, groups } = param;
			return (pathname) => {
				const routeMatch = re.exec(pathname);
				if (!routeMatch) return false;
				const decode = (param) => {
					try {
						return decodeURIComponent(param);
					} catch (_) {
						throw new _utils.DecodeError("failed to decode param");
					}
				};
				const params = {};
				Object.keys(groups).forEach((slugName) => {
					const g = groups[slugName];
					const m = routeMatch[g.pos];
					if (m !== void 0) params[slugName] = ~m.indexOf("/") ? m.split("/").map((entry) => decode(entry)) : g.repeat ? [decode(m)] : decode(m);
				});
				return params;
			};
		}
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/escape-regexp.js
	var require_escape_regexp = /* @__PURE__ */ __commonJSMin(((exports) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "escapeStringRegexp", {
			enumerable: true,
			get: function() {
				return escapeStringRegexp;
			}
		});
		var reHasRegExp = /[|\\{}()[\]^$+*?.-]/;
		var reReplaceRegExp = /[|\\{}()[\]^$+*?.-]/g;
		function escapeStringRegexp(str) {
			if (reHasRegExp.test(str)) return str.replace(reReplaceRegExp, "\\$&");
			return str;
		}
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/router/utils/route-regex.js
	var require_route_regex = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		init_objectSpread2();
		Object.defineProperty(exports, "__esModule", { value: true });
		0 && (module.exports = {
			getNamedMiddlewareRegex: null,
			getNamedRouteRegex: null,
			getRouteRegex: null
		});
		function _export(target, all) {
			for (var name in all) Object.defineProperty(target, name, {
				enumerable: true,
				get: all[name]
			});
		}
		_export(exports, {
			getNamedMiddlewareRegex: function() {
				return getNamedMiddlewareRegex;
			},
			getNamedRouteRegex: function() {
				return getNamedRouteRegex;
			},
			getRouteRegex: function() {
				return getRouteRegex;
			}
		});
		var _interceptionroutes = require_interception_routes();
		var _escaperegexp = require_escape_regexp();
		var _removetrailingslash = require_remove_trailing_slash();
		var NEXT_QUERY_PARAM_PREFIX = "nxtP";
		var NEXT_INTERCEPTION_MARKER_PREFIX = "nxtI";
		/**
		* Parses a given parameter from a route to a data structure that can be used
		* to generate the parametrized route. Examples:
		*   - `[...slug]` -> `{ key: 'slug', repeat: true, optional: true }`
		*   - `...slug` -> `{ key: 'slug', repeat: true, optional: false }`
		*   - `[foo]` -> `{ key: 'foo', repeat: false, optional: true }`
		*   - `bar` -> `{ key: 'bar', repeat: false, optional: false }`
		*/ function parseParameter(param) {
			const optional = param.startsWith("[") && param.endsWith("]");
			if (optional) param = param.slice(1, -1);
			const repeat = param.startsWith("...");
			if (repeat) param = param.slice(3);
			return {
				key: param,
				repeat,
				optional
			};
		}
		function getParametrizedRoute(route) {
			const segments = (0, _removetrailingslash.removeTrailingSlash)(route).slice(1).split("/");
			const groups = {};
			let groupIndex = 1;
			return {
				parameterizedRoute: segments.map((segment) => {
					const markerMatch = _interceptionroutes.INTERCEPTION_ROUTE_MARKERS.find((m) => segment.startsWith(m));
					const paramMatches = segment.match(/\[((?:\[.*\])|.+)\]/);
					if (markerMatch && paramMatches) {
						const { key, optional, repeat } = parseParameter(paramMatches[1]);
						groups[key] = {
							pos: groupIndex++,
							repeat,
							optional
						};
						return "/" + (0, _escaperegexp.escapeStringRegexp)(markerMatch) + "([^/]+?)";
					} else if (paramMatches) {
						const { key, repeat, optional } = parseParameter(paramMatches[1]);
						groups[key] = {
							pos: groupIndex++,
							repeat,
							optional
						};
						return repeat ? optional ? "(?:/(.+?))?" : "/(.+?)" : "/([^/]+?)";
					} else return "/" + (0, _escaperegexp.escapeStringRegexp)(segment);
				}).join(""),
				groups
			};
		}
		function getRouteRegex(normalizedRoute) {
			const { parameterizedRoute, groups } = getParametrizedRoute(normalizedRoute);
			return {
				re: new RegExp("^" + parameterizedRoute + "(?:/)?$"),
				groups
			};
		}
		/**
		* Builds a function to generate a minimal routeKey using only a-z and minimal
		* number of characters.
		*/ function buildGetSafeRouteKey() {
			let i = 0;
			return () => {
				let routeKey = "";
				let j = ++i;
				while (j > 0) {
					routeKey += String.fromCharCode(97 + (j - 1) % 26);
					j = Math.floor((j - 1) / 26);
				}
				return routeKey;
			};
		}
		function getSafeKeyFromSegment(param) {
			let { interceptionMarker, getSafeRouteKey, segment, routeKeys, keyPrefix } = param;
			const { key, optional, repeat } = parseParameter(segment);
			let cleanedKey = key.replace(/\W/g, "");
			if (keyPrefix) cleanedKey = "" + keyPrefix + cleanedKey;
			let invalidKey = false;
			if (cleanedKey.length === 0 || cleanedKey.length > 30) invalidKey = true;
			if (!isNaN(parseInt(cleanedKey.slice(0, 1)))) invalidKey = true;
			if (invalidKey) cleanedKey = getSafeRouteKey();
			if (keyPrefix) routeKeys[cleanedKey] = "" + keyPrefix + key;
			else routeKeys[cleanedKey] = key;
			const interceptionPrefix = interceptionMarker ? (0, _escaperegexp.escapeStringRegexp)(interceptionMarker) : "";
			return repeat ? optional ? "(?:/" + interceptionPrefix + "(?<" + cleanedKey + ">.+?))?" : "/" + interceptionPrefix + "(?<" + cleanedKey + ">.+?)" : "/" + interceptionPrefix + "(?<" + cleanedKey + ">[^/]+?)";
		}
		function getNamedParametrizedRoute(route, prefixRouteKeys) {
			const segments = (0, _removetrailingslash.removeTrailingSlash)(route).slice(1).split("/");
			const getSafeRouteKey = buildGetSafeRouteKey();
			const routeKeys = {};
			return {
				namedParameterizedRoute: segments.map((segment) => {
					const hasInterceptionMarker = _interceptionroutes.INTERCEPTION_ROUTE_MARKERS.some((m) => segment.startsWith(m));
					const paramMatches = segment.match(/\[((?:\[.*\])|.+)\]/);
					if (hasInterceptionMarker && paramMatches) {
						const [usedMarker] = segment.split(paramMatches[0]);
						return getSafeKeyFromSegment({
							getSafeRouteKey,
							interceptionMarker: usedMarker,
							segment: paramMatches[1],
							routeKeys,
							keyPrefix: prefixRouteKeys ? NEXT_INTERCEPTION_MARKER_PREFIX : void 0
						});
					} else if (paramMatches) return getSafeKeyFromSegment({
						getSafeRouteKey,
						segment: paramMatches[1],
						routeKeys,
						keyPrefix: prefixRouteKeys ? NEXT_QUERY_PARAM_PREFIX : void 0
					});
					else return "/" + (0, _escaperegexp.escapeStringRegexp)(segment);
				}).join(""),
				routeKeys
			};
		}
		function getNamedRouteRegex(normalizedRoute, prefixRouteKey) {
			const result = getNamedParametrizedRoute(normalizedRoute, prefixRouteKey);
			return _objectSpread2(_objectSpread2({}, getRouteRegex(normalizedRoute)), {}, {
				namedRegex: "^" + result.namedParameterizedRoute + "(?:/)?$",
				routeKeys: result.routeKeys
			});
		}
		function getNamedMiddlewareRegex(normalizedRoute, options) {
			const { parameterizedRoute } = getParametrizedRoute(normalizedRoute);
			const { catchAll = true } = options;
			if (parameterizedRoute === "/") return { namedRegex: "^/" + (catchAll ? ".*" : "") + "$" };
			const { namedParameterizedRoute } = getNamedParametrizedRoute(normalizedRoute, false);
			let catchAllGroupedRegex = catchAll ? "(?:(/.*)?)" : "";
			return { namedRegex: "^" + namedParameterizedRoute + catchAllGroupedRegex + "$" };
		}
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/router/utils/interpolate-as.js
	var require_interpolate_as = /* @__PURE__ */ __commonJSMin(((exports) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "interpolateAs", {
			enumerable: true,
			get: function() {
				return interpolateAs;
			}
		});
		var _routematcher = require_route_matcher();
		var _routeregex = require_route_regex();
		function interpolateAs(route, asPathname, query) {
			let interpolatedRoute = "";
			const dynamicRegex = (0, _routeregex.getRouteRegex)(route);
			const dynamicGroups = dynamicRegex.groups;
			const dynamicMatches = (asPathname !== route ? (0, _routematcher.getRouteMatcher)(dynamicRegex)(asPathname) : "") || query;
			interpolatedRoute = route;
			const params = Object.keys(dynamicGroups);
			if (!params.every((param) => {
				let value = dynamicMatches[param] || "";
				const { repeat, optional } = dynamicGroups[param];
				let replaced = "[" + (repeat ? "..." : "") + param + "]";
				if (optional) replaced = (!value ? "/" : "") + "[" + replaced + "]";
				if (repeat && !Array.isArray(value)) value = [value];
				return (optional || param in dynamicMatches) && (interpolatedRoute = interpolatedRoute.replace(replaced, repeat ? value.map((segment) => encodeURIComponent(segment)).join("/") : encodeURIComponent(value)) || "/");
			})) interpolatedRoute = "";
			return {
				params,
				result: interpolatedRoute
			};
		}
	}));
	//#endregion
	//#region node_modules/next/dist/client/resolve-href.js
	var require_resolve_href = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "resolveHref", {
			enumerable: true,
			get: function() {
				return resolveHref;
			}
		});
		var _querystring = require_querystring();
		var _formaturl = require_format_url();
		var _omit = require_omit();
		var _utils = require_utils$1();
		var _normalizetrailingslash = require_normalize_trailing_slash();
		var _islocalurl = require_is_local_url();
		var _utils1 = require_utils();
		var _interpolateas = require_interpolate_as();
		function resolveHref(router, href, resolveAs) {
			let base;
			let urlAsString = typeof href === "string" ? href : (0, _formaturl.formatWithValidation)(href);
			const urlProtoMatch = urlAsString.match(/^[a-zA-Z]{1,}:\/\//);
			const urlAsStringNoProto = urlProtoMatch ? urlAsString.slice(urlProtoMatch[0].length) : urlAsString;
			if ((urlAsStringNoProto.split("?", 1)[0] || "").match(/(\/\/|\\)/)) {
				console.error("Invalid href '" + urlAsString + "' passed to next/router in page: '" + router.pathname + "'. Repeated forward-slashes (//) or backslashes \\ are not valid in the href.");
				const normalizedUrl = (0, _utils.normalizeRepeatedSlashes)(urlAsStringNoProto);
				urlAsString = (urlProtoMatch ? urlProtoMatch[0] : "") + normalizedUrl;
			}
			if (!(0, _islocalurl.isLocalURL)(urlAsString)) return resolveAs ? [urlAsString] : urlAsString;
			try {
				base = new URL(urlAsString.startsWith("#") ? router.asPath : router.pathname, "http://n");
			} catch (_) {
				base = new URL("/", "http://n");
			}
			try {
				const finalUrl = new URL(urlAsString, base);
				finalUrl.pathname = (0, _normalizetrailingslash.normalizePathTrailingSlash)(finalUrl.pathname);
				let interpolatedAs = "";
				if ((0, _utils1.isDynamicRoute)(finalUrl.pathname) && finalUrl.searchParams && resolveAs) {
					const query = (0, _querystring.searchParamsToUrlQuery)(finalUrl.searchParams);
					const { result, params } = (0, _interpolateas.interpolateAs)(finalUrl.pathname, finalUrl.pathname, query);
					if (result) interpolatedAs = (0, _formaturl.formatWithValidation)({
						pathname: result,
						hash: finalUrl.hash,
						query: (0, _omit.omit)(query, params)
					});
				}
				const resolvedHref = finalUrl.origin === base.origin ? finalUrl.href.slice(finalUrl.origin.length) : finalUrl.href;
				return resolveAs ? [resolvedHref, interpolatedAs || resolvedHref] : resolvedHref;
			} catch (_) {
				return resolveAs ? [urlAsString] : urlAsString;
			}
		}
		if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && typeof exports.default.__esModule === "undefined") {
			Object.defineProperty(exports.default, "__esModule", { value: true });
			Object.assign(exports.default, exports);
			module.exports = exports.default;
		}
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/router/utils/add-path-prefix.js
	var require_add_path_prefix = /* @__PURE__ */ __commonJSMin(((exports) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "addPathPrefix", {
			enumerable: true,
			get: function() {
				return addPathPrefix;
			}
		});
		var _parsepath = require_parse_path();
		function addPathPrefix(path, prefix) {
			if (!path.startsWith("/") || !prefix) return path;
			const { pathname, query, hash } = (0, _parsepath.parsePath)(path);
			return "" + prefix + pathname + query + hash;
		}
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/router/utils/add-locale.js
	var require_add_locale$1 = /* @__PURE__ */ __commonJSMin(((exports) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "addLocale", {
			enumerable: true,
			get: function() {
				return addLocale;
			}
		});
		var _addpathprefix = require_add_path_prefix();
		var _pathhasprefix = require_path_has_prefix();
		function addLocale(path, locale, defaultLocale, ignorePrefix) {
			if (!locale || locale === defaultLocale) return path;
			const lower = path.toLowerCase();
			if (!ignorePrefix) {
				if ((0, _pathhasprefix.pathHasPrefix)(lower, "/api")) return path;
				if ((0, _pathhasprefix.pathHasPrefix)(lower, "/" + locale.toLowerCase())) return path;
			}
			return (0, _addpathprefix.addPathPrefix)(path, "/" + locale);
		}
	}));
	//#endregion
	//#region node_modules/next/dist/client/add-locale.js
	var require_add_locale = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "addLocale", {
			enumerable: true,
			get: function() {
				return addLocale;
			}
		});
		var _normalizetrailingslash = require_normalize_trailing_slash();
		var addLocale = function(path) {
			for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) args[_key - 1] = arguments[_key];
			if ({}.__NEXT_I18N_SUPPORT) return (0, _normalizetrailingslash.normalizePathTrailingSlash)(require_add_locale$1().addLocale(path, ...args));
			return path;
		};
		if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && typeof exports.default.__esModule === "undefined") {
			Object.defineProperty(exports.default, "__esModule", { value: true });
			Object.assign(exports.default, exports);
			module.exports = exports.default;
		}
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/router-context.shared-runtime.js
	var require_router_context_shared_runtime = /* @__PURE__ */ __commonJSMin(((exports) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "RouterContext", {
			enumerable: true,
			get: function() {
				return RouterContext;
			}
		});
		var RouterContext = (/* @__PURE__ */ require__interop_require_default()._(require_react())).default.createContext(null);
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/app-router-context.shared-runtime.js
	var require_app_router_context_shared_runtime = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		0 && (module.exports = {
			AppRouterContext: null,
			GlobalLayoutRouterContext: null,
			LayoutRouterContext: null,
			MissingSlotContext: null,
			TemplateContext: null
		});
		function _export(target, all) {
			for (var name in all) Object.defineProperty(target, name, {
				enumerable: true,
				get: all[name]
			});
		}
		_export(exports, {
			AppRouterContext: function() {
				return AppRouterContext;
			},
			GlobalLayoutRouterContext: function() {
				return GlobalLayoutRouterContext;
			},
			LayoutRouterContext: function() {
				return LayoutRouterContext;
			},
			MissingSlotContext: function() {
				return MissingSlotContext;
			},
			TemplateContext: function() {
				return TemplateContext;
			}
		});
		var _react = /*#__PURE__*/ require__interop_require_default()._(require_react());
		var AppRouterContext = _react.default.createContext(null);
		var LayoutRouterContext = _react.default.createContext(null);
		var GlobalLayoutRouterContext = _react.default.createContext(null);
		var TemplateContext = _react.default.createContext(null);
		var MissingSlotContext = _react.default.createContext(/* @__PURE__ */ new Set());
	}));
	//#endregion
	//#region node_modules/next/dist/client/request-idle-callback.js
	var require_request_idle_callback = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		0 && (module.exports = {
			cancelIdleCallback: null,
			requestIdleCallback: null
		});
		function _export(target, all) {
			for (var name in all) Object.defineProperty(target, name, {
				enumerable: true,
				get: all[name]
			});
		}
		_export(exports, {
			cancelIdleCallback: function() {
				return cancelIdleCallback;
			},
			requestIdleCallback: function() {
				return requestIdleCallback;
			}
		});
		var requestIdleCallback = typeof self !== "undefined" && self.requestIdleCallback && self.requestIdleCallback.bind(window) || function(cb) {
			let start = Date.now();
			return self.setTimeout(function() {
				cb({
					didTimeout: false,
					timeRemaining: function() {
						return Math.max(0, 50 - (Date.now() - start));
					}
				});
			}, 1);
		};
		var cancelIdleCallback = typeof self !== "undefined" && self.cancelIdleCallback && self.cancelIdleCallback.bind(window) || function(id) {
			return clearTimeout(id);
		};
		if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && typeof exports.default.__esModule === "undefined") {
			Object.defineProperty(exports.default, "__esModule", { value: true });
			Object.assign(exports.default, exports);
			module.exports = exports.default;
		}
	}));
	//#endregion
	//#region node_modules/next/dist/client/use-intersection.js
	var require_use_intersection = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "useIntersection", {
			enumerable: true,
			get: function() {
				return useIntersection;
			}
		});
		var _react = require_react();
		var _requestidlecallback = require_request_idle_callback();
		var hasIntersectionObserver = typeof IntersectionObserver === "function";
		var observers = /* @__PURE__ */ new Map();
		var idList = [];
		function createObserver(options) {
			const id = {
				root: options.root || null,
				margin: options.rootMargin || ""
			};
			const existing = idList.find((obj) => obj.root === id.root && obj.margin === id.margin);
			let instance;
			if (existing) {
				instance = observers.get(existing);
				if (instance) return instance;
			}
			const elements = /* @__PURE__ */ new Map();
			instance = {
				id,
				observer: new IntersectionObserver((entries) => {
					entries.forEach((entry) => {
						const callback = elements.get(entry.target);
						const isVisible = entry.isIntersecting || entry.intersectionRatio > 0;
						if (callback && isVisible) callback(isVisible);
					});
				}, options),
				elements
			};
			idList.push(id);
			observers.set(id, instance);
			return instance;
		}
		function observe(element, callback, options) {
			const { id, observer, elements } = createObserver(options);
			elements.set(element, callback);
			observer.observe(element);
			return function unobserve() {
				elements.delete(element);
				observer.unobserve(element);
				if (elements.size === 0) {
					observer.disconnect();
					observers.delete(id);
					const index = idList.findIndex((obj) => obj.root === id.root && obj.margin === id.margin);
					if (index > -1) idList.splice(index, 1);
				}
			};
		}
		function useIntersection(param) {
			let { rootRef, rootMargin, disabled } = param;
			const isDisabled = disabled || !hasIntersectionObserver;
			const [visible, setVisible] = (0, _react.useState)(false);
			const elementRef = (0, _react.useRef)(null);
			const setElement = (0, _react.useCallback)((element) => {
				elementRef.current = element;
			}, []);
			(0, _react.useEffect)(() => {
				if (hasIntersectionObserver) {
					if (isDisabled || visible) return;
					const element = elementRef.current;
					if (element && element.tagName) return observe(element, (isVisible) => isVisible && setVisible(isVisible), {
						root: rootRef == null ? void 0 : rootRef.current,
						rootMargin
					});
				} else if (!visible) {
					const idleCallback = (0, _requestidlecallback.requestIdleCallback)(() => setVisible(true));
					return () => (0, _requestidlecallback.cancelIdleCallback)(idleCallback);
				}
			}, [
				isDisabled,
				rootMargin,
				rootRef,
				visible,
				elementRef.current
			]);
			return [
				setElement,
				visible,
				(0, _react.useCallback)(() => {
					setVisible(false);
				}, [])
			];
		}
		if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && typeof exports.default.__esModule === "undefined") {
			Object.defineProperty(exports.default, "__esModule", { value: true });
			Object.assign(exports.default, exports);
			module.exports = exports.default;
		}
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/i18n/normalize-locale-path.js
	var require_normalize_locale_path$1 = /* @__PURE__ */ __commonJSMin(((exports) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "normalizeLocalePath", {
			enumerable: true,
			get: function() {
				return normalizeLocalePath;
			}
		});
		function normalizeLocalePath(pathname, locales) {
			let detectedLocale;
			const pathnameParts = pathname.split("/");
			(locales || []).some((locale) => {
				if (pathnameParts[1] && pathnameParts[1].toLowerCase() === locale.toLowerCase()) {
					detectedLocale = locale;
					pathnameParts.splice(1, 1);
					pathname = pathnameParts.join("/") || "/";
					return true;
				}
				return false;
			});
			return {
				pathname,
				detectedLocale
			};
		}
	}));
	//#endregion
	//#region node_modules/next/dist/client/normalize-locale-path.js
	var require_normalize_locale_path = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "normalizeLocalePath", {
			enumerable: true,
			get: function() {
				return normalizeLocalePath;
			}
		});
		var normalizeLocalePath = (pathname, locales) => {
			if ({}.__NEXT_I18N_SUPPORT) return require_normalize_locale_path$1().normalizeLocalePath(pathname, locales);
			return {
				pathname,
				detectedLocale: void 0
			};
		};
		if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && typeof exports.default.__esModule === "undefined") {
			Object.defineProperty(exports.default, "__esModule", { value: true });
			Object.assign(exports.default, exports);
			module.exports = exports.default;
		}
	}));
	//#endregion
	//#region node_modules/next/dist/shared/lib/i18n/detect-domain-locale.js
	var require_detect_domain_locale$1 = /* @__PURE__ */ __commonJSMin(((exports) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "detectDomainLocale", {
			enumerable: true,
			get: function() {
				return detectDomainLocale;
			}
		});
		function detectDomainLocale(domainItems, hostname, detectedLocale) {
			if (!domainItems) return;
			if (detectedLocale) detectedLocale = detectedLocale.toLowerCase();
			for (const item of domainItems) {
				var _item_domain, _item_locales;
				if (hostname === ((_item_domain = item.domain) == null ? void 0 : _item_domain.split(":", 1)[0].toLowerCase()) || detectedLocale === item.defaultLocale.toLowerCase() || ((_item_locales = item.locales) == null ? void 0 : _item_locales.some((locale) => locale.toLowerCase() === detectedLocale))) return item;
			}
		}
	}));
	//#endregion
	//#region node_modules/next/dist/client/detect-domain-locale.js
	var require_detect_domain_locale = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "detectDomainLocale", {
			enumerable: true,
			get: function() {
				return detectDomainLocale;
			}
		});
		var detectDomainLocale = function() {
			for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
			if ({}.__NEXT_I18N_SUPPORT) return require_detect_domain_locale$1().detectDomainLocale(...args);
		};
		if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && typeof exports.default.__esModule === "undefined") {
			Object.defineProperty(exports.default, "__esModule", { value: true });
			Object.assign(exports.default, exports);
			module.exports = exports.default;
		}
	}));
	//#endregion
	//#region node_modules/next/dist/client/get-domain-locale.js
	var require_get_domain_locale = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "getDomainLocale", {
			enumerable: true,
			get: function() {
				return getDomainLocale;
			}
		});
		var _normalizetrailingslash = require_normalize_trailing_slash();
		var basePath = {}.__NEXT_ROUTER_BASEPATH || "";
		function getDomainLocale(path, locale, locales, domainLocales) {
			if ({}.__NEXT_I18N_SUPPORT) {
				const normalizeLocalePath = require_normalize_locale_path().normalizeLocalePath;
				const detectDomainLocale = require_detect_domain_locale().detectDomainLocale;
				const target = locale || normalizeLocalePath(path, locales).detectedLocale;
				const domain = detectDomainLocale(domainLocales, void 0, target);
				if (domain) {
					const proto = "http" + (domain.http ? "" : "s") + "://";
					const finalLocale = target === domain.defaultLocale ? "" : "/" + target;
					return "" + proto + domain.domain + (0, _normalizetrailingslash.normalizePathTrailingSlash)("" + basePath + finalLocale + path);
				}
				return false;
			} else return false;
		}
		if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && typeof exports.default.__esModule === "undefined") {
			Object.defineProperty(exports.default, "__esModule", { value: true });
			Object.assign(exports.default, exports);
			module.exports = exports.default;
		}
	}));
	//#endregion
	//#region node_modules/next/dist/client/add-base-path.js
	var require_add_base_path = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "addBasePath", {
			enumerable: true,
			get: function() {
				return addBasePath;
			}
		});
		var _addpathprefix = require_add_path_prefix();
		var _normalizetrailingslash = require_normalize_trailing_slash();
		var basePath = {}.__NEXT_ROUTER_BASEPATH || "";
		function addBasePath(path, required) {
			return (0, _normalizetrailingslash.normalizePathTrailingSlash)({}.__NEXT_MANUAL_CLIENT_BASE_PATH && !required ? path : (0, _addpathprefix.addPathPrefix)(path, basePath));
		}
		if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && typeof exports.default.__esModule === "undefined") {
			Object.defineProperty(exports.default, "__esModule", { value: true });
			Object.assign(exports.default, exports);
			module.exports = exports.default;
		}
	}));
	//#endregion
	//#region node_modules/next/dist/client/components/router-reducer/router-reducer-types.js
	var require_router_reducer_types = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		Object.defineProperty(exports, "__esModule", { value: true });
		0 && (module.exports = {
			ACTION_FAST_REFRESH: null,
			ACTION_NAVIGATE: null,
			ACTION_PREFETCH: null,
			ACTION_REFRESH: null,
			ACTION_RESTORE: null,
			ACTION_SERVER_ACTION: null,
			ACTION_SERVER_PATCH: null,
			PrefetchCacheEntryStatus: null,
			PrefetchKind: null,
			isThenable: null
		});
		function _export(target, all) {
			for (var name in all) Object.defineProperty(target, name, {
				enumerable: true,
				get: all[name]
			});
		}
		_export(exports, {
			ACTION_FAST_REFRESH: function() {
				return ACTION_FAST_REFRESH;
			},
			ACTION_NAVIGATE: function() {
				return ACTION_NAVIGATE;
			},
			ACTION_PREFETCH: function() {
				return ACTION_PREFETCH;
			},
			ACTION_REFRESH: function() {
				return ACTION_REFRESH;
			},
			ACTION_RESTORE: function() {
				return ACTION_RESTORE;
			},
			ACTION_SERVER_ACTION: function() {
				return ACTION_SERVER_ACTION;
			},
			ACTION_SERVER_PATCH: function() {
				return ACTION_SERVER_PATCH;
			},
			PrefetchCacheEntryStatus: function() {
				return PrefetchCacheEntryStatus;
			},
			PrefetchKind: function() {
				return PrefetchKind;
			},
			isThenable: function() {
				return isThenable;
			}
		});
		var ACTION_REFRESH = "refresh";
		var ACTION_NAVIGATE = "navigate";
		var ACTION_RESTORE = "restore";
		var ACTION_SERVER_PATCH = "server-patch";
		var ACTION_PREFETCH = "prefetch";
		var ACTION_FAST_REFRESH = "fast-refresh";
		var ACTION_SERVER_ACTION = "server-action";
		var PrefetchKind;
		(function(PrefetchKind) {
			PrefetchKind["AUTO"] = "auto";
			PrefetchKind["FULL"] = "full";
			PrefetchKind["TEMPORARY"] = "temporary";
		})(PrefetchKind || (PrefetchKind = {}));
		var PrefetchCacheEntryStatus;
		(function(PrefetchCacheEntryStatus) {
			PrefetchCacheEntryStatus["fresh"] = "fresh";
			PrefetchCacheEntryStatus["reusable"] = "reusable";
			PrefetchCacheEntryStatus["expired"] = "expired";
			PrefetchCacheEntryStatus["stale"] = "stale";
		})(PrefetchCacheEntryStatus || (PrefetchCacheEntryStatus = {}));
		function isThenable(value) {
			return value && (typeof value === "object" || typeof value === "function") && typeof value.then === "function";
		}
		if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && typeof exports.default.__esModule === "undefined") {
			Object.defineProperty(exports.default, "__esModule", { value: true });
			Object.assign(exports.default, exports);
			module.exports = exports.default;
		}
	}));
	//#endregion
	//#region node_modules/next/dist/client/link.js
	var require_link$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
		init_asyncToGenerator();
		init_objectWithoutProperties();
		init_objectSpread2();
		var _excluded = [
			"href",
			"as",
			"children",
			"prefetch",
			"passHref",
			"replace",
			"shallow",
			"scroll",
			"locale",
			"onClick",
			"onMouseEnter",
			"onTouchStart",
			"legacyBehavior"
		];
		Object.defineProperty(exports, "__esModule", { value: true });
		Object.defineProperty(exports, "default", {
			enumerable: true,
			get: function() {
				return _default;
			}
		});
		var _interop_require_default = require__interop_require_default();
		var _jsxruntime = require_jsx_runtime();
		var _react = /*#__PURE__*/ _interop_require_default._(require_react());
		var _resolvehref = require_resolve_href();
		var _islocalurl = require_is_local_url();
		var _formaturl = require_format_url();
		var _utils = require_utils$1();
		var _addlocale = require_add_locale();
		var _routercontextsharedruntime = require_router_context_shared_runtime();
		var _approutercontextsharedruntime = require_app_router_context_shared_runtime();
		var _useintersection = require_use_intersection();
		var _getdomainlocale = require_get_domain_locale();
		var _addbasepath = require_add_base_path();
		var _routerreducertypes = require_router_reducer_types();
		var prefetched = /* @__PURE__ */ new Set();
		function prefetch(router, href, as, options, appOptions, isAppRouter) {
			if (typeof window === "undefined") return;
			if (!isAppRouter && !(0, _islocalurl.isLocalURL)(href)) return;
			if (!options.bypassPrefetchedCheck) {
				const locale = typeof options.locale !== "undefined" ? options.locale : "locale" in router ? router.locale : void 0;
				const prefetchedKey = href + "%" + as + "%" + locale;
				if (prefetched.has(prefetchedKey)) return;
				prefetched.add(prefetchedKey);
			}
			(function() {
				var _ref = _asyncToGenerator(function* () {
					if (isAppRouter) return router.prefetch(href, appOptions);
					else return router.prefetch(href, as, options);
				});
				return function doPrefetch() {
					return _ref.apply(this, arguments);
				};
			})()().catch((err) => {});
		}
		function isModifiedEvent(event) {
			const target = event.currentTarget.getAttribute("target");
			return target && target !== "_self" || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.nativeEvent && event.nativeEvent.which === 2;
		}
		function linkClicked(e, router, href, as, replace, shallow, scroll, locale, isAppRouter) {
			const { nodeName } = e.currentTarget;
			if (nodeName.toUpperCase() === "A" && (isModifiedEvent(e) || !isAppRouter && !(0, _islocalurl.isLocalURL)(href))) return;
			e.preventDefault();
			const navigate = () => {
				const routerScroll = scroll != null ? scroll : true;
				if ("beforePopState" in router) router[replace ? "replace" : "push"](href, as, {
					shallow,
					locale,
					scroll: routerScroll
				});
				else router[replace ? "replace" : "push"](as || href, { scroll: routerScroll });
			};
			if (isAppRouter) _react.default.startTransition(navigate);
			else navigate();
		}
		function formatStringOrUrl(urlObjOrString) {
			if (typeof urlObjOrString === "string") return urlObjOrString;
			return (0, _formaturl.formatUrl)(urlObjOrString);
		}
		var _default = /* @__PURE__ */ _react.default.forwardRef(function LinkComponent(props, forwardedRef) {
			let children;
			const { href: hrefProp, as: asProp, children: childrenProp, prefetch: prefetchProp = null, passHref, replace, shallow, scroll, locale, onClick, onMouseEnter: onMouseEnterProp, onTouchStart: onTouchStartProp, legacyBehavior = false } = props, restProps = _objectWithoutProperties(props, _excluded);
			children = childrenProp;
			if (legacyBehavior && (typeof children === "string" || typeof children === "number")) children = /*#__PURE__*/ (0, _jsxruntime.jsx)("a", { children });
			const pagesRouter = _react.default.useContext(_routercontextsharedruntime.RouterContext);
			const appRouter = _react.default.useContext(_approutercontextsharedruntime.AppRouterContext);
			const router = pagesRouter != null ? pagesRouter : appRouter;
			const isAppRouter = !pagesRouter;
			const prefetchEnabled = prefetchProp !== false;
			/**
			* The possible states for prefetch are:
			* - null: this is the default "auto" mode, where we will prefetch partially if the link is in the viewport
			* - true: we will prefetch if the link is visible and prefetch the full page, not just partially
			* - false: we will not prefetch if in the viewport at all
			*/ const appPrefetchKind = prefetchProp === null ? _routerreducertypes.PrefetchKind.AUTO : _routerreducertypes.PrefetchKind.FULL;
			const { href, as } = _react.default.useMemo(() => {
				if (!pagesRouter) {
					const resolvedHref = formatStringOrUrl(hrefProp);
					return {
						href: resolvedHref,
						as: asProp ? formatStringOrUrl(asProp) : resolvedHref
					};
				}
				const [resolvedHref, resolvedAs] = (0, _resolvehref.resolveHref)(pagesRouter, hrefProp, true);
				return {
					href: resolvedHref,
					as: asProp ? (0, _resolvehref.resolveHref)(pagesRouter, asProp) : resolvedAs || resolvedHref
				};
			}, [
				pagesRouter,
				hrefProp,
				asProp
			]);
			const previousHref = _react.default.useRef(href);
			const previousAs = _react.default.useRef(as);
			let child;
			if (legacyBehavior) child = _react.default.Children.only(children);
			const childRef = legacyBehavior ? child && typeof child === "object" && child.ref : forwardedRef;
			const [setIntersectionRef, isVisible, resetVisible] = (0, _useintersection.useIntersection)({ rootMargin: "200px" });
			const setRef = _react.default.useCallback((el) => {
				if (previousAs.current !== as || previousHref.current !== href) {
					resetVisible();
					previousAs.current = as;
					previousHref.current = href;
				}
				setIntersectionRef(el);
				if (childRef) {
					if (typeof childRef === "function") childRef(el);
					else if (typeof childRef === "object") childRef.current = el;
				}
			}, [
				as,
				childRef,
				href,
				resetVisible,
				setIntersectionRef
			]);
			_react.default.useEffect(() => {
				if (!router) return;
				if (!isVisible || !prefetchEnabled) return;
				prefetch(router, href, as, { locale }, { kind: appPrefetchKind }, isAppRouter);
			}, [
				as,
				href,
				isVisible,
				locale,
				prefetchEnabled,
				pagesRouter == null ? void 0 : pagesRouter.locale,
				router,
				isAppRouter,
				appPrefetchKind
			]);
			const childProps = {
				ref: setRef,
				onClick(e) {
					if (!legacyBehavior && typeof onClick === "function") onClick(e);
					if (legacyBehavior && child.props && typeof child.props.onClick === "function") child.props.onClick(e);
					if (!router) return;
					if (e.defaultPrevented) return;
					linkClicked(e, router, href, as, replace, shallow, scroll, locale, isAppRouter);
				},
				onMouseEnter(e) {
					if (!legacyBehavior && typeof onMouseEnterProp === "function") onMouseEnterProp(e);
					if (legacyBehavior && child.props && typeof child.props.onMouseEnter === "function") child.props.onMouseEnter(e);
					if (!router) return;
					if ((!prefetchEnabled || false) && isAppRouter) return;
					prefetch(router, href, as, {
						locale,
						priority: true,
						bypassPrefetchedCheck: true
					}, { kind: appPrefetchKind }, isAppRouter);
				},
				onTouchStart: {}.__NEXT_LINK_NO_TOUCH_START ? void 0 : function onTouchStart(e) {
					if (!legacyBehavior && typeof onTouchStartProp === "function") onTouchStartProp(e);
					if (legacyBehavior && child.props && typeof child.props.onTouchStart === "function") child.props.onTouchStart(e);
					if (!router) return;
					if (!prefetchEnabled && isAppRouter) return;
					prefetch(router, href, as, {
						locale,
						priority: true,
						bypassPrefetchedCheck: true
					}, { kind: appPrefetchKind }, isAppRouter);
				}
			};
			if ((0, _utils.isAbsoluteUrl)(as)) childProps.href = as;
			else if (!legacyBehavior || passHref || child.type === "a" && !("href" in child.props)) {
				const curLocale = typeof locale !== "undefined" ? locale : pagesRouter == null ? void 0 : pagesRouter.locale;
				childProps.href = (pagesRouter == null ? void 0 : pagesRouter.isLocaleDomain) && (0, _getdomainlocale.getDomainLocale)(as, curLocale, pagesRouter == null ? void 0 : pagesRouter.locales, pagesRouter == null ? void 0 : pagesRouter.domainLocales) || (0, _addbasepath.addBasePath)((0, _addlocale.addLocale)(as, curLocale, pagesRouter == null ? void 0 : pagesRouter.defaultLocale));
			}
			return legacyBehavior ? /*#__PURE__*/ _react.default.cloneElement(child, childProps) : /*#__PURE__*/ (0, _jsxruntime.jsx)("a", _objectSpread2(_objectSpread2(_objectSpread2({}, restProps), childProps), {}, { children }));
		});
		if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && typeof exports.default.__esModule === "undefined") {
			Object.defineProperty(exports.default, "__esModule", { value: true });
			Object.assign(exports.default, exports);
			module.exports = exports.default;
		}
	}));
	//#endregion
	//#region src/components/ColorDetailDrawer.tsx
	var import_link = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
		module.exports = require_link$1();
	})))());
	init_asyncToGenerator();
	function ColorDetailDrawer() {
		const activeShade = useFandeckStore((s) => s.activeShade);
		const setActiveShade = useFandeckStore((s) => s.setActiveShade);
		const addToShortlist = useFandeckStore((s) => s.addToShortlist);
		const removeFromShortlist = useFandeckStore((s) => s.removeFromShortlist);
		const shortlistedIds = useFandeckStore((s) => s.shortlistedIds);
		const isOpen = activeShade !== null;
		const [justAdded, setJustAdded] = (0, import_react.useState)(false);
		const [shareCopied, setShareCopied] = (0, import_react.useState)(false);
		(0, import_react.useEffect)(() => {
			document.body.style.overflow = isOpen ? "hidden" : "";
			return () => {
				document.body.style.overflow = "";
			};
		}, [isOpen]);
		(0, import_react.useEffect)(() => {
			const handler = (e) => {
				if (e.key === "Escape") setActiveShade(null);
			};
			window.addEventListener("keydown", handler);
			return () => window.removeEventListener("keydown", handler);
		}, [setActiveShade]);
		(0, import_react.useEffect)(() => {
			setJustAdded(false);
			setShareCopied(false);
		}, [activeShade === null || activeShade === void 0 ? void 0 : activeShade.id]);
		const { data: detail } = useQuery({
			queryKey: ["colorDetail", activeShade === null || activeShade === void 0 ? void 0 : activeShade.id],
			queryFn: () => api.colors.getById(activeShade.id),
			enabled: !!activeShade
		});
		const { data: similar } = useQuery({
			queryKey: ["similarColors", activeShade === null || activeShade === void 0 ? void 0 : activeShade.id],
			queryFn: () => api.colors.getSimilar(activeShade.id),
			enabled: !!activeShade
		});
		detail !== null && detail !== void 0 && detail.complementary && detail.complementary.length > 0 && detail.complementary;
		const similarColors = similar ? similar : [];
		const color = detail !== null && detail !== void 0 ? detail : activeShade;
		if (!color) return null;
		const shortlisted = shortlistedIds.includes(color.id);
		const textColor = getTextColor(color.lrv);
		const handleShortlist = () => {
			if (shortlisted) {
				removeFromShortlist(color.id);
				setJustAdded(false);
			} else {
				addToShortlist(color.id);
				setJustAdded(true);
				setTimeout(() => setJustAdded(false), 1800);
			}
		};
		const handleShare = function() {
			var _ref = _asyncToGenerator(function* () {
				var _navigator$canShare, _navigator;
				const shareUrl = `${window.location.origin}/color/${color.code}`;
				const shareData = {
					title: `${color.name} — Asian Paints`,
					text: `Check out this colour: ${color.name} (${color.code}) from Asian Paints`,
					url: shareUrl
				};
				if (navigator.share && ((_navigator$canShare = (_navigator = navigator).canShare) === null || _navigator$canShare === void 0 ? void 0 : _navigator$canShare.call(_navigator, shareData))) try {
					yield navigator.share(shareData);
					return;
				} catch (_unused) {}
				try {
					yield navigator.clipboard.writeText(shareUrl);
					setShareCopied(true);
					setTimeout(() => setShareCopied(false), 4e3);
				} catch (_unused2) {}
			});
			return function handleShare() {
				return _ref.apply(this, arguments);
			};
		}();
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: isOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
			className: "fixed inset-0 z-40 bg-black/40 backdrop-blur-sm",
			initial: { opacity: 0 },
			animate: { opacity: 1 },
			exit: { opacity: 0 },
			onClick: () => setActiveShade(null),
			"aria-hidden": "true"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.aside, {
			className: "fixed bottom-0 right-0 top-0 z-50 flex w-full flex-col bg-white shadow-2xl md:w-[440px]",
			initial: { x: "100%" },
			animate: { x: 0 },
			exit: { x: "100%" },
			transition: {
				type: "spring",
				damping: 30,
				stiffness: 300
			},
			role: "dialog",
			"aria-label": `Colour detail: ${color.name}`,
			"aria-modal": "true",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setActiveShade(null),
					className: "absolute right-4 top-4 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-black/20 text-white transition-colors hover:bg-black/40",
					"aria-label": "Close colour detail",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
						width: "16",
						height: "16",
						viewBox: "0 0 24 24",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "2.5",
						strokeLinecap: "round",
						strokeLinejoin: "round",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M18 6 6 18M6 6l12 12" })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex min-h-[25%] flex-col items-center justify-center p-8",
					style: { backgroundColor: color.hexValue },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-0 opacity-5",
							style: { backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='6' height='6' viewBox='0 0 6 6' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23000' fill-opacity='0.4'%3E%3Cpath d='M5 0h1L0 5V4zM6 5v1H5z'/%3E%3C/g%3E%3C/svg%3E\")" },
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "relative text-center text-2xl font-bold md:text-3xl",
							style: { color: textColor },
							children: color.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "relative mt-1 text-sm opacity-75",
							style: { color: textColor },
							children: color.code
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: justAdded && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
							initial: {
								opacity: 0,
								y: 10,
								scale: .9
							},
							animate: {
								opacity: 1,
								y: 0,
								scale: 1
							},
							exit: {
								opacity: 0,
								y: -6,
								scale: .9
							},
							className: "absolute bottom-6 flex items-center gap-1.5 rounded-full bg-white/90 px-4 py-1.5 text-sm font-semibold text-brand-charcoal shadow-lg backdrop-blur-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								width: "14",
								height: "14",
								viewBox: "0 0 24 24",
								fill: "currentColor",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" })
							}), "Added to shortlist!"]
						}) })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto p-6",
					children: [
						color.collection && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium uppercase tracking-wider text-gray-400",
							children: "Collection"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm font-semibold",
							children: color.collection
						})] }),
						"tags" in color && color.tags && color.tags.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-wrap gap-1.5",
							children: color.tags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-gray-100 px-2.5 py-1 text-xs text-gray-600",
								children: tag
							}, tag))
						}),
						similarColors.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-xs font-medium uppercase tracking-wider text-gray-400",
									children: "Similar Shades"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-2 text-[11px] text-gray-400",
									children: "Close tones from the same family"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "hide-scrollbar flex gap-2 overflow-x-auto pb-2",
									children: similarColors.map((sim) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => {
											const store = useFandeckStore.getState();
											store.setSelectedFamilyId(sim.colorFamilyId);
											store.setFanPage(0);
											store.setActiveShade(sim);
										},
										className: "group flex shrink-0 flex-col items-center",
										"aria-label": `View similar shade: ${sim.name}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "similar-tiles-color h-14 w-14 rounded-lg shadow-sm ring-2 ring-transparent transition-all group-hover:ring-brand-red",
											style: { backgroundColor: sim.hexValue }
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-1 w-14 truncate text-center text-[10px] text-gray-500",
											children: sim.name
										})]
									}, sim.id))
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-col gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
									onClick: handleShortlist,
									whileTap: { scale: .97 },
									className: `flex items-center justify-center gap-2 rounded-xl px-6 py-3 text-sm font-semibold transition-all duration-300 ${shortlisted ? "bg-brand-charcoal text-white" : "bg-brand-red text-white hover:bg-red-700"}`,
									"aria-label": shortlisted ? "Remove from shortlist" : "Add to shortlist",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.svg, {
										width: "16",
										height: "16",
										viewBox: "0 0 24 24",
										fill: shortlisted ? "currentColor" : "none",
										stroke: "currentColor",
										strokeWidth: "2",
										animate: { scale: justAdded ? [
											1,
											1.4,
											1
										] : 1 },
										transition: { duration: .3 },
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" })
									}), shortlisted ? "Remove from Shortlist" : "Add to Shortlist"]
								}),
								color.pageUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: color.pageUrl,
									target: "_blank",
									rel: "noopener noreferrer",
									className: "flex items-center justify-center gap-2 rounded-xl bg-brand-charcoal px-6 py-3 text-sm font-semibold text-white transition-all hover:bg-gray-800",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
										width: "16",
										height: "16",
										viewBox: "0 0 24 24",
										fill: "none",
										stroke: "currentColor",
										strokeWidth: "2",
										strokeLinecap: "round",
										strokeLinejoin: "round",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "15 3 21 3 21 9" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
												x1: "10",
												y1: "14",
												x2: "21",
												y2: "3"
											})
										]
									}), "View on Asian Paints"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_link.default, {
									href: `/color/${color.code}`,
									className: "flex items-center justify-center gap-2 rounded-xl border-2 border-gray-200 px-6 py-3 text-sm font-semibold text-brand-charcoal transition-all hover:border-brand-charcoal",
									children: "View Full Detail"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
									onClick: handleShare,
									whileTap: { scale: .97 },
									className: `flex items-center justify-center gap-2 rounded-xl border-2 px-6 py-3 text-sm font-semibold transition-all duration-300 ${shareCopied ? "bg-green-50 text-green-700" : " hover:border-gray-900"}`,
									"aria-label": "Share this colour",
									children: shareCopied ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
										width: "14",
										height: "14",
										viewBox: "0 0 24 24",
										fill: "none",
										stroke: "currentColor",
										strokeWidth: "2.5",
										strokeLinecap: "round",
										strokeLinejoin: "round",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "20 6 9 17 4 12" })
									}), "Link copied!"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
										width: "14",
										height: "14",
										viewBox: "0 0 24 24",
										fill: "none",
										stroke: "currentColor",
										strokeWidth: "2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "16 6 12 2 8 6" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
												x1: "12",
												x2: "12",
												y1: "2",
												y2: "15"
											})
										]
									}), "Share"] })
								})
							]
						})
					]
				})
			]
		})] }) });
	}
	//#endregion
	//#region src/components/SearchBar.tsx
	function SearchBar({ fullWidth = false }) {
		var _data$content;
		const [query, setQuery] = (0, import_react.useState)("");
		const [isOpen, setIsOpen] = (0, import_react.useState)(false);
		const [debouncedQuery, setDebouncedQuery] = (0, import_react.useState)("");
		const inputRef = (0, import_react.useRef)(null);
		const containerRef = (0, import_react.useRef)(null);
		const setActiveShade = useFandeckStore((s) => s.setActiveShade);
		(0, import_react.useEffect)(() => {
			const timer = setTimeout(() => setDebouncedQuery(query), 300);
			return () => clearTimeout(timer);
		}, [query]);
		const { data } = useQuery({
			queryKey: ["searchColors", debouncedQuery],
			queryFn: () => api.colors.search({
				q: debouncedQuery,
				size: 8
			}),
			enabled: debouncedQuery.length >= 2
		});
		const results = (_data$content = data === null || data === void 0 ? void 0 : data.content) !== null && _data$content !== void 0 ? _data$content : [];
		(0, import_react.useEffect)(() => {
			const handler = (e) => {
				if (containerRef.current && !containerRef.current.contains(e.target)) setIsOpen(false);
			};
			document.addEventListener("mousedown", handler);
			return () => document.removeEventListener("mousedown", handler);
		}, []);
		const handleSelect = (0, import_react.useCallback)((color) => {
			setActiveShade(color);
			setQuery("");
			setIsOpen(false);
		}, [setActiveShade]);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			ref: containerRef,
			className: fullWidth ? "relative w-full" : "relative",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 rounded-full bg-gray-100 px-3 py-2 transition-all focus-within:bg-white focus-within:ring-2 focus-within:ring-brand-red/30",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						width: "16",
						height: "16",
						viewBox: "0 0 24 24",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "2",
						className: "shrink-0 text-gray-400",
						"aria-hidden": "true",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "11",
							cy: "11",
							r: "8"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: "21",
							x2: "16.65",
							y1: "21",
							y2: "16.65"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "shade-search",
						children: "Search Paint Shades"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: inputRef,
						type: "search",
						value: query,
						onChange: (e) => {
							setQuery(e.target.value);
							setIsOpen(true);
						},
						id: "shade-search",
						onFocus: () => setIsOpen(true),
						placeholder: "Search by name or code...",
						className: fullWidth ? "min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-gray-400" : "w-32 bg-transparent text-sm outline-none placeholder:text-gray-400 md:w-48",
						"aria-label": "Search colours",
						"aria-expanded": isOpen && results.length > 0,
						role: "combobox",
						"aria-controls": "search-results",
						"aria-autocomplete": "list"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: isOpen && results.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.ul, {
				id: "search-results",
				role: "listbox",
				initial: {
					opacity: 0,
					y: -8
				},
				animate: {
					opacity: 1,
					y: 0
				},
				exit: {
					opacity: 0,
					y: -8
				},
				transition: { duration: .15 },
				className: fullWidth ? "absolute left-0 right-0 top-full z-50 mt-2 overflow-hidden rounded-xl bg-white shadow-xl ring-1 ring-black/5" : "absolute right-0 top-full z-50 mt-2 w-72 overflow-hidden rounded-xl bg-white shadow-xl ring-1 ring-black/5",
				children: results.map((color) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => handleSelect(color),
					className: "flex w-full items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-gray-50",
					role: "option",
					"aria-label": `${color.name} — ${color.code}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-8 w-8 shrink-0 rounded-lg shadow-sm",
							style: { backgroundColor: color.hexValue }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm font-medium",
								children: color.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-gray-400",
								children: color.code
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 text-[10px] text-gray-400",
							children: color.colorFamilyName
						})
					]
				}) }, color.id))
			}) })]
		});
	}
	//#endregion
	//#region src/components/ShortlistFloatingButton.tsx
	function ShortlistFloatingButton() {
		const count = useFandeckStore((s) => s.shortlistedIds.length);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_link.default, {
			href: "/shortlist",
			className: "fixed bottom-4 right-4 z-30 md:bottom-6 md:right-6",
			"aria-label": `View shortlist — ${count} colours saved`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				className: "flex h-12 w-12 items-center justify-center rounded-full bg-brand-red text-white shadow-xl transition-colors hover:bg-red-700 md:h-14 md:w-14",
				whileHover: { scale: 1.1 },
				whileTap: { scale: .95 },
				"aria-label": "Add shade to favourites",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					width: "22",
					height: "22",
					viewBox: "0 0 24 24",
					fill: "currentColor",
					stroke: "currentColor",
					strokeWidth: "1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: count > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.span, {
					initial: { scale: 0 },
					animate: { scale: 1 },
					exit: { scale: 0 },
					className: "absolute -right-1 -top-1 flex h-6 w-6 items-center justify-center rounded-full bg-brand-charcoal text-[11px] font-bold text-white ring-2 ring-white",
					children: count
				}, count) })]
			})
		});
	}
	//#endregion
	//#region src/pages/FandeckPage.tsx
	function FandeckPage() {
		const selectedFamilyId = useFandeckStore((s) => s.selectedFamilyId);
		const { data: families, isLoading: familiesLoading } = useQuery({
			queryKey: ["families"],
			queryFn: api.families.getAll
		});
		const setSelectedFamilyId = useFandeckStore((s) => s.setSelectedFamilyId);
		if (families && families.length > 0 && selectedFamilyId === null) setSelectedFamilyId(families[0].id);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-screen flex-col overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
					className: "relative z-40 shrink-0 border-b border-gray-200 bg-white/80 backdrop-blur-md",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-3 pb-2 pt-2 md:px-4 md:py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link$2, {
								to: "/",
								className: "flex items-center gap-2 md:gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "https://static.asianpaints.com/etc.clientlibs/apcolourcatalogue/clientlibs/clientlib-global-unification/resources/images/header/asian-paints-logo.webp",
									alt: "Asian Paints",
									className: "h-7 w-auto md:h-10"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden text-lg font-semibold md:block",
									children: "Digital Fandeck"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "hidden md:block",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchBar, {})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 block md:hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchBar, { fullWidth: true })
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorRangeSelector, {
					families: families !== null && families !== void 0 ? families : [],
					isLoading: familiesLoading
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "mx-auto min-h-0 w-full max-w-7xl flex-1 px-2 py-2 md:px-4 md:py-2",
					children: selectedFamilyId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FanCard, { familyId: selectedFamilyId }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex h-full flex-col items-center justify-center text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-6xl",
								children: "🎨"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-4 text-xl font-semibold text-gray-400",
								children: "Select a colour range to begin"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-gray-400",
								children: "Pick from the colour families above to open the fandeck"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorDetailDrawer, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShortlistFloatingButton, {})
			]
		});
	}
	//#endregion
	//#region src/pages/ShortlistPage.tsx
	init_asyncToGenerator();
	function ShortlistPage() {
		const shortlistedIds = useFandeckStore((s) => s.shortlistedIds);
		const removeFromShortlist = useFandeckStore((s) => s.removeFromShortlist);
		const sessionId = useFandeckStore((s) => s.sessionId);
		const queryClient = useQueryClient();
		const [shareCopied, setShareCopied] = (0, import_react.useState)(false);
		const { data: colors, isLoading } = useQuery({
			queryKey: ["shortlistColors", shortlistedIds],
			queryFn: function() {
				var _ref = _asyncToGenerator(function* () {
					if (shortlistedIds.length === 0) return [];
					return (yield Promise.all(shortlistedIds.map((id) => api.colors.getById(id).catch(() => null)))).filter(Boolean);
				});
				return function queryFn() {
					return _ref.apply(this, arguments);
				};
			}(),
			enabled: shortlistedIds.length > 0
		});
		useMutation({ mutationFn: () => api.shortlist.create({
			sessionId,
			colorIds: shortlistedIds
		}) });
		const handleRemove = (colorId) => {
			removeFromShortlist(colorId);
			api.shortlist.remove(sessionId, colorId).catch(() => {});
			queryClient.invalidateQueries({ queryKey: ["shortlistColors"] });
		};
		const handleShare = function() {
			var _ref2 = _asyncToGenerator(function* () {
				const url = window.location.href;
				const shareData = {
					title: "My Colour Shortlist",
					text: "Check out my saved paint colours from Asian Paints",
					url
				};
				if (navigator.share && (!navigator.canShare || navigator.canShare(shareData))) try {
					yield navigator.share(shareData);
					return;
				} catch (_unused) {}
				try {
					yield navigator.clipboard.writeText(url);
					setShareCopied(true);
					setTimeout(() => setShareCopied(false), 4e3);
				} catch (_unused2) {}
			});
			return function handleShare() {
				return _ref2.apply(this, arguments);
			};
		}();
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "min-h-screen bg-brand-offwhite",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b border-gray-200 bg-white",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-5xl items-center justify-between px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link$2, {
						to: "/fandeck",
						className: "flex items-center gap-1 text-sm text-gray-500 hover:text-brand-charcoal",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
							width: "16",
							height: "16",
							viewBox: "0 0 24 24",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "m15 18-6-6 6-6" })
						}), "Back to Fandeck"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: handleShare,
						className: `flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium text-white transition-all ${shareCopied ? "bg-green-600" : "bg-brand-charcoal hover:bg-gray-700"}`,
						children: shareCopied ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
							width: "14",
							height: "14",
							viewBox: "0 0 24 24",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "2.5",
							strokeLinecap: "round",
							strokeLinejoin: "round",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "20 6 9 17 4 12" })
						}), "Copied!"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
							width: "14",
							height: "14",
							viewBox: "0 0 24 24",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "16 6 12 2 8 6" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
									x1: "12",
									x2: "12",
									y1: "2",
									y2: "15"
								})
							]
						}), "Share"] })
					})]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-5xl px-4 py-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "font-display text-3xl font-bold",
						children: ["Your Shortlist", shortlistedIds.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "ml-2 text-xl text-gray-400",
							children: [
								"(",
								shortlistedIds.length,
								")"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-gray-500",
						children: "Your saved colours for easy comparison"
					}),
					shortlistedIds.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-20 flex flex-col items-center text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex h-24 w-24 items-center justify-center rounded-full bg-gray-100",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
									width: "40",
									height: "40",
									viewBox: "0 0 24 24",
									fill: "none",
									stroke: "currentColor",
									strokeWidth: "1.5",
									className: "text-gray-300",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-6 text-xl font-semibold text-gray-600",
								children: "No colours saved yet"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 max-w-sm text-sm text-gray-400",
								children: "Browse the fandeck and tap the heart icon on colours you love. They'll appear here for easy comparison."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$2, {
								to: "/fandeck",
								className: "mt-8 rounded-full bg-brand-red px-6 py-3 text-sm font-semibold text-white transition-all hover:bg-red-700",
								children: "Explore Fandeck"
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 flex gap-1 overflow-x-auto rounded-xl shadow-lg",
						children: colors === null || colors === void 0 ? void 0 : colors.map((color) => color ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "min-h-[120px] flex-1",
							style: {
								backgroundColor: color.hexValue,
								minWidth: "60px"
							},
							title: color.name
						}, color.id) : null)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: colors === null || colors === void 0 ? void 0 : colors.map((color) => color && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
							layout: true,
							initial: {
								opacity: 0,
								scale: .9
							},
							animate: {
								opacity: 1,
								scale: 1
							},
							exit: {
								opacity: 0,
								scale: .9
							},
							className: "overflow-hidden rounded-xl bg-white shadow-md",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$2, {
								to: `/color/${color.code}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex h-36 items-end p-4",
									style: { backgroundColor: color.hexValue },
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-lg font-bold",
										style: { color: getTextColor(color.lrv) },
										children: color.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm opacity-75",
										style: { color: getTextColor(color.lrv) },
										children: color.code
									})] })
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between p-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-gray-500",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: color.hexValue }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "ml-3",
										children: ["LRV ", color.lrv]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => handleRemove(color.id),
									className: "flex items-center gap-1 text-xs text-red-500 transition-colors hover:text-red-700",
									"aria-label": `Remove ${color.name} from shortlist`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
										width: "14",
										height: "14",
										viewBox: "0 0 24 24",
										fill: "none",
										stroke: "currentColor",
										strokeWidth: "2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M18 6 6 18M6 6l12 12" })
									}), "Remove"]
								})]
							})]
						}, color.id)) })
					})] })
				]
			})]
		});
	}
	//#endregion
	//#region src/lib/colorScheme.ts
	var ROTATIONS = [
		120,
		150,
		180,
		210,
		240
	];
	function hexToHsl(hex) {
		const r = parseInt(hex.slice(1, 3), 16) / 255;
		const g = parseInt(hex.slice(3, 5), 16) / 255;
		const b = parseInt(hex.slice(5, 7), 16) / 255;
		const max = Math.max(r, g, b);
		const min = Math.min(r, g, b);
		let h = 0;
		let s = 0;
		const l = (max + min) / 2;
		if (max !== min) {
			const d = max - min;
			s = l > .5 ? d / (2 - max - min) : d / (max + min);
			switch (max) {
				case r:
					h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
					break;
				case g:
					h = ((b - r) / d + 2) / 6;
					break;
				case b: h = ((r - g) / d + 4) / 6;
			}
		}
		return [
			h * 360,
			s * 100,
			l * 100
		];
	}
	function hslToHex(h, s, l) {
		const sNorm = s / 100;
		const lNorm = l / 100;
		const a = sNorm * Math.min(lNorm, 1 - lNorm);
		const f = (n) => {
			const k = (n + h / 30) % 12;
			return lNorm - a * Math.max(-1, Math.min(k - 3, 9 - k, 1));
		};
		return "#" + [
			f(0),
			f(8),
			f(4)
		].map((x) => Math.round(x * 255).toString(16).padStart(2, "0")).join("");
	}
	function getHueName(h) {
		if (h < 15 || h >= 345) return "Red";
		if (h < 45) return "Orange";
		if (h < 75) return "Yellow";
		if (h < 105) return "Yellow Green";
		if (h < 150) return "Green";
		if (h < 195) return "Teal";
		if (h < 255) return "Blue";
		if (h < 285) return "Violet";
		if (h < 315) return "Purple";
		return "Pink";
	}
	/**
	* Synchronous, local computation — no network call needed.
	* Returns 5 shades spread across the wheel from the given base hex.
	*/
	function generateComplementaryScheme(baseHex) {
		const [h, s, l] = hexToHsl(baseHex.startsWith("#") ? baseHex : `#${baseHex}`);
		const clampedSaturation = s < 30 ? 45 : s;
		const clampedLightness = l < 25 ? 40 : l > 82 ? 70 : l;
		return ROTATIONS.map((deg) => {
			const rotatedHue = (h + deg) % 360;
			return {
				hex: hslToHex(rotatedHue, clampedSaturation, clampedLightness).toUpperCase(),
				name: getHueName(rotatedHue)
			};
		});
	}
	function colorDistance(hex1, hex2) {
		const r1 = parseInt(hex1.slice(1, 3), 16);
		const g1 = parseInt(hex1.slice(3, 5), 16);
		const b1 = parseInt(hex1.slice(5, 7), 16);
		const r2 = parseInt(hex2.slice(1, 3), 16);
		const g2 = parseInt(hex2.slice(3, 5), 16);
		const b2 = parseInt(hex2.slice(5, 7), 16);
		const dr = r1 - r2;
		const dg = g1 - g2;
		const db = b1 - b2;
		return 2 * dr * dr + 4 * dg * dg + 3 * db * db;
	}
	/**
	* Given a generated hex and the full in-memory colour catalogue, returns
	* the closest real Asian Paints shade (or null if the catalogue is empty).
	*/
	function findClosestShade(hex, allColors) {
		if (!allColors.length) return null;
		let closest = allColors[0];
		let minDist = Infinity;
		for (const c of allColors) {
			const d = colorDistance(hex, c.hexValue);
			if (d < minDist) {
				minDist = d;
				closest = c;
			}
		}
		return closest;
	}
	//#endregion
	//#region src/pages/ColorDetailPage.tsx
	init_objectSpread2();
	init_asyncToGenerator();
	function ColorDetailPage() {
		var _searchResult$content;
		const params = useParams();
		const navigate = useNavigate();
		const code = decodeURIComponent(params.code);
		const [justAdded, setJustAdded] = (0, import_react.useState)(false);
		const [shareCopied, setShareCopied] = (0, import_react.useState)(false);
		const [copiedHex, setCopiedHex] = (0, import_react.useState)(null);
		const { data: searchResult, isLoading } = useQuery({
			queryKey: ["colorByCode", code],
			queryFn: () => api.colors.search({
				q: code,
				size: 1
			})
		});
		const color = searchResult === null || searchResult === void 0 || (_searchResult$content = searchResult.content) === null || _searchResult$content === void 0 ? void 0 : _searchResult$content[0];
		const { data: detail } = useQuery({
			queryKey: ["colorDetail", color === null || color === void 0 ? void 0 : color.id],
			queryFn: () => api.colors.getById(color.id),
			enabled: !!color
		});
		const { data: similar } = useQuery({
			queryKey: ["similarColors", color === null || color === void 0 ? void 0 : color.id],
			queryFn: () => api.colors.getSimilar(color.id),
			enabled: !!color
		});
		const { data: allColors } = useQuery({
			queryKey: ["allColorsForMatching"],
			queryFn: () => api.colors.getAll(),
			staleTime: Infinity
		});
		const complementaryScheme = (0, import_react.useMemo)(() => {
			if (!(color === null || color === void 0 ? void 0 : color.hexValue)) return [];
			return generateComplementaryScheme(color.hexValue).map((g) => _objectSpread2(_objectSpread2({}, g), {}, { match: allColors && allColors.length > 0 ? findClosestShade(g.hex, allColors) : null }));
		}, [color === null || color === void 0 ? void 0 : color.hexValue, allColors]);
		const addToShortlist = useFandeckStore((s) => s.addToShortlist);
		const removeFromShortlist = useFandeckStore((s) => s.removeFromShortlist);
		const shortlistedIds = useFandeckStore((s) => s.shortlistedIds);
		(0, import_react.useEffect)(() => {
			setJustAdded(false);
			setShareCopied(false);
			setCopiedHex(null);
		}, [code]);
		if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex min-h-screen items-center justify-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-10 animate-spin rounded-full border-4 border-gray-200 border-t-brand-red" })
		});
		if (!color) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-screen flex-col items-center justify-center gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-bold",
					children: "Colour Not Found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-gray-500",
					children: [
						"No colour matches the code \"",
						code,
						"\""
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link$2, {
					to: "/fandeck",
					className: "rounded-full bg-brand-red px-6 py-3 text-sm font-semibold text-white",
					children: "Back to Fandeck"
				})
			]
		});
		const d = detail !== null && detail !== void 0 ? detail : color;
		const shortlisted = shortlistedIds.includes(d.id);
		const textColor = getTextColor(d.lrv);
		const complementaryColors = (detail === null || detail === void 0 ? void 0 : detail.complementary) && detail.complementary.length > 0 ? detail.complementary : [];
		const handleShortlist = () => {
			if (shortlisted) {
				removeFromShortlist(d.id);
				setJustAdded(false);
			} else {
				addToShortlist(d.id);
				setJustAdded(true);
				setTimeout(() => setJustAdded(false), 1800);
			}
		};
		const handleShare = function() {
			var _ref = _asyncToGenerator(function* () {
				var _navigator$canShare, _navigator;
				const shareUrl = `${window.location.origin}/color/${d.code}`;
				const shareData = {
					title: `${d.name} — Asian Paints`,
					text: `Check out this colour: ${d.name} (${d.code}) from Asian Paints`,
					url: shareUrl
				};
				if (navigator.share && ((_navigator$canShare = (_navigator = navigator).canShare) === null || _navigator$canShare === void 0 ? void 0 : _navigator$canShare.call(_navigator, shareData))) try {
					yield navigator.share(shareData);
					return;
				} catch (_unused) {}
				try {
					yield navigator.clipboard.writeText(shareUrl);
					setShareCopied(true);
					setTimeout(() => setShareCopied(false), 4e3);
				} catch (_unused2) {}
			});
			return function handleShare() {
				return _ref.apply(this, arguments);
			};
		}();
		const handleCopyHex = function() {
			var _ref2 = _asyncToGenerator(function* (hex) {
				try {
					yield navigator.clipboard.writeText(hex);
					setCopiedHex(hex);
					setTimeout(() => setCopiedHex(null), 1500);
				} catch (_unused3) {}
			});
			return function handleCopyHex(_x) {
				return _ref2.apply(this, arguments);
			};
		}();
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "min-h-screen bg-brand-offwhite",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-30 border-b border-gray-200 bg-white/90 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex w-full items-center justify-between px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => navigate(-1),
						className: "flex items-center gap-1.5 text-sm font-medium text-gray-500 hover:text-brand-charcoal",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
							width: "16",
							height: "16",
							viewBox: "0 0 24 24",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "m15 18-6-6 6-6" })
						}), "Back to Fandeck"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: handleShare,
						className: `flex items-center gap-1.5 text-sm font-medium transition-colors ${shareCopied ? "text-green-600" : "text-gray-500 hover:text-brand-charcoal"}`,
						"aria-label": "Share this colour",
						children: shareCopied ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
							width: "15",
							height: "15",
							viewBox: "0 0 24 24",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "2.5",
							strokeLinecap: "round",
							strokeLinejoin: "round",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "20 6 9 17 4 12" })
						}), "Copied!"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
							width: "15",
							height: "15",
							viewBox: "0 0 24 24",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "16 6 12 2 8 6" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
									x1: "12",
									x2: "12",
									y1: "2",
									y2: "15"
								})
							]
						}), "Share"] })
					})]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-5xl px-4 py-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-8 md:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "tiles-mob-wrapper min-w-0 relative flex min-h-[400px] flex-col items-center justify-center rounded-2xl shadow-xl",
						style: { backgroundColor: d.hexValue },
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tiles-mob absolute inset-0 rounded-2xl opacity-[0.03]",
								style: { backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='6' height='6' viewBox='0 0 6 6' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23000' fill-opacity='0.3'%3E%3Cpath d='M5 0h1L0 5V4zM6 5v1H5z'/%3E%3C/g%3E%3C/svg%3E\")" },
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display relative text-4xl font-bold",
								style: { color: textColor },
								children: d.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "relative mt-2 text-lg opacity-75",
								style: { color: textColor },
								children: d.code
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: justAdded && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
								initial: {
									opacity: 0,
									y: 10,
									scale: .9
								},
								animate: {
									opacity: 1,
									y: 0,
									scale: 1
								},
								exit: {
									opacity: 0,
									y: -6,
									scale: .9
								},
								className: "absolute bottom-6 flex items-center gap-1.5 rounded-full bg-white/90 px-4 py-1.5 text-sm font-semibold text-brand-charcoal shadow-lg backdrop-blur-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
									width: "14",
									height: "14",
									viewBox: "0 0 24 24",
									fill: "currentColor",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" })
								}), "Added to shortlist!"]
							}) })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6 min-w-0 ",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-3xl font-bold",
								children: d.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-gray-500",
								children: d.code
							})] }),
							d.collection && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium uppercase tracking-wider text-gray-400",
								children: "Collection"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-semibold",
								children: d.collection
							})] }),
							"tags" in d && d.tags && d.tags.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2",
								children: d.tags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-gray-100 px-3 py-1.5 text-xs font-medium text-gray-600",
									children: tag
								}, tag))
							}),
							complementaryColors.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-xs font-medium uppercase tracking-wider text-gray-400",
									children: "Similar Palette"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-2 text-[11px] text-gray-400",
									children: "Colours that pair well together"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "detail-page-tiles-sm flex gap-3 overflow-x-auto pb-2 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
									children: complementaryColors.map((comp, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										onClick: () => {
											useFandeckStore.getState().setSelectedFamilyId(comp.colorFamilyId);
											useFandeckStore.getState().setFanPage(0);
											navigate(`/color/${comp.code}`, { replace: true });
										},
										className: "detail-page-tiles-sm group flex shrink-0 flex-col items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-16 w-16 rounded-xl shadow-md ring-2 ring-transparent transition-all group-hover:ring-brand-red",
											style: { backgroundColor: comp.hexValue }
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-1.5 w-16 truncate text-center text-[10px] text-gray-500",
											children: comp.name
										})]
									}, i))
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-3 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
									onClick: handleShortlist,
									whileTap: { scale: .97 },
									className: `flex items-center justify-center gap-2 rounded-xl px-6 py-3.5 text-sm font-semibold transition-all duration-300 ${shortlisted ? "bg-brand-charcoal text-white" : "bg-brand-red text-white hover:bg-red-700"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.svg, {
										width: "16",
										height: "16",
										viewBox: "0 0 24 24",
										fill: shortlisted ? "currentColor" : "none",
										stroke: "currentColor",
										strokeWidth: "2",
										animate: { scale: justAdded ? [
											1,
											1.4,
											1
										] : 1 },
										transition: { duration: .3 },
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" })
									}), shortlisted ? "Remove from Shortlist" : "Add to Shortlist"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "https://www.asianpaints.com/store-locator.html",
									target: "_blank",
									rel: "noopener noreferrer",
									className: "flex items-center justify-center gap-2 rounded-xl border-2 px-6 py-3.5 text-sm font-semibold transition-all hover:border-brand-charcoal hover:text-brand-charcoal",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
										width: "16",
										height: "16",
										viewBox: "0 0 24 24",
										fill: "none",
										stroke: "currentColor",
										strokeWidth: "2",
										strokeLinecap: "round",
										strokeLinejoin: "round",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
											cx: "12",
											cy: "10",
											r: "3"
										})]
									}), "Buy at Nearest Store"]
								})]
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-bold",
							children: "Complementary Shades"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mb-4 text-[11px] text-gray-400",
							children: [
								"Colours that go well with ",
								d.name,
								", based on colour theory"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap justify-center gap-3 px-1 pb-4 sm:justify-start",
							children: complementaryScheme.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-40 shrink-0 overflow-hidden rounded-xl bg-white shadow-md transition-shadow hover:shadow-lg sm:w-32 md:w-40",
								children: c.match ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: c.match.pageUrl,
									target: "_blank",
									rel: "noopener noreferrer",
									className: "group block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-24 w-full cursor-pointer transition-transform group-hover:scale-[1.02] md:h-28",
										style: { backgroundColor: c.hex },
										title: `View ${c.match.name} on asianpaints.com`
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "px-3 py-2.5 text-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1.5 text-xs font-medium text-gray-800 group-hover:text-brand-red",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "h-3 w-3 shrink-0 rounded-full border border-gray-300",
													style: { backgroundColor: c.match.hexValue }
												}),
												c.match.name,
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
													width: "11",
													height: "11",
													viewBox: "0 0 24 24",
													fill: "none",
													stroke: "currentColor",
													strokeWidth: "2.5",
													className: "shrink-0",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "15 3 21 3 21 9" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
															x1: "10",
															y1: "14",
															x2: "21",
															y2: "3"
														})
													]
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-0.5 text-xs text-gray-400",
											children: c.match.code
										})]
									})]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-24 w-full cursor-pointer md:h-28",
									style: { backgroundColor: c.hex },
									onClick: () => handleCopyHex(c.hex),
									title: "Click to copy hex"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "px-3 py-2.5",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-gray-400",
										children: c.name
									})
								})] })
							}, c.hex))
						})
					]
				})]
			})]
		});
	}
	//#endregion
	//#region src/App.tsx
	function App() {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Routes, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Route, {
				path: "/",
				element: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FandeckPage, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Route, {
				path: "/fandeck",
				element: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FandeckPage, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Route, {
				path: "/shortlist",
				element: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShortlistPage, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Route, {
				path: "/color/:code",
				element: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorDetailPage, {})
			})
		] });
	}
	//#endregion
	//#region src/main.tsx
	var queryClient = new QueryClient();
	import_client.createRoot(document.getElementById("root")).render(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.StrictMode, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashRouter, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(App, {}) })
	}) }));
	//#endregion
})();
